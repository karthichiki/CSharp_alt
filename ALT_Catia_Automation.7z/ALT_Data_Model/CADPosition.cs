﻿using Newtonsoft.Json;
using System;

namespace ALT_Data_Model
{
    /// <summary>
    /// CAD Position class to store 3D coordinates (X, Y, Z) of a point in a CAD model.
    /// </summary>
    public class CADPosition: IEquatable<CADPosition>
    {
        [JsonProperty("x")]
        public double X { get; set; }
        [JsonProperty("y")]
        public double Y { get; set; }
        [JsonProperty("z")]
        public double Z { get; set; }

        public CADPosition()
        {
        }
        public override bool Equals(object obj)
        {
            return Equals(obj as CADPosition);
        }

        /// <summary>
        /// Check equality of two CADPosition objects with a tolerance for floating-point comparisons.
        /// </summary>
        /// <param name="other"> Cad position to be compared </param>
        /// <returns> equal or no </returns>
        public bool Equals(CADPosition other)
        {
            if (other == null) return false;

            const double tolerance = 1e-10;
            return Math.Abs(X - other.X) < tolerance &&
                   Math.Abs(Y - other.Y) < tolerance &&
                   Math.Abs(Z - other.Z) < tolerance;
        }

        /// <summary>
        /// Generate a hash code for the CADPosition object.
        /// </summary>
        /// <returns> Hash code </returns>
        public override int GetHashCode()
        {
            return (X, Y, Z).GetHashCode();
        }
    }
}
