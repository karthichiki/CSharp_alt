﻿using ALT_Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace ALT_Data_Model
{
    /// <summary>
    /// Class to ensure MessageBox dialogs appear on top of the main application window.
    /// </summary>
    public static class MessageBoxOnTop
    {
        /// <summary>
        /// Display a MessageBox dialog on top of the main application window.
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="title"></param>
        /// <param name="messageBoxButton"></param>
        /// <param name="messageBoxImage"></param>
        /// <returns> MessageBoxResult </returns>
        public static MessageBoxResult BringMessageBoxToTop(string msg, string title, MessageBoxButton messageBoxButton, MessageBoxImage messageBoxImage)
        {
            alt_WindowTracker.BringApplicationToFront("ALT_UI");
            MessageBoxResult result = MessageBoxResult.Yes;
            if (System.Windows.Application.Current.Dispatcher.CheckAccess())
            {
                result = MessageBox.Show(System.Windows.Application.Current.MainWindow, msg, title, messageBoxButton, messageBoxImage);
            }
            else
            {
                System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                    result = MessageBox.Show(System.Windows.Application.Current.MainWindow, msg, title, messageBoxButton, messageBoxImage);
                }));
            }
            return result;
        }
    }

}
