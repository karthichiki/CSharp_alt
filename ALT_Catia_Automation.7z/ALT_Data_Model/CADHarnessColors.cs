﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Media;

namespace ALT_Data_Model
{
    /// <summary>
    /// CAD Harness Colors class to manage and load color configurations from a JSON file.
    /// </summary>
    public class CADHarnessColors
    {
        public List<ColorClass> SmallColorList;
        public List<ColorClass> LargeColorList;
        public List<ColorClass> BCClassColorList;
        public List<ColorClass> BAClassColorList;
        public List<ColorClass> CClassPrincipalColorList;
        public List<ColorClass> CClassSubClassColorList;
        public List<ColorClass> CAlassPrincipalColorList;
        public List<ColorClass> CAlassSubClassColorList;
        public List<ColorClass> CBlassPrincipalColorList;
        public List<ColorClass> CBlassSubClassColorList;

        /// <summary>
        /// Initializes a new instance of the CADHarnessColors class and loads color configurations from a JSON file.
        /// </summary>
        public CADHarnessColors()
        {
            //Load the color lists from the JSON file
            string folderPath = AppDomain.CurrentDomain.BaseDirectory;
            string jsonFilePath = Path.Combine(folderPath, "Resources", "ClassesColour.json");

            var assembly = Assembly.GetExecutingAssembly();
            var resourceName = "ALT_Data_Model.Resources.ClassesColour.json";

            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                {
                    Console.WriteLine("\"ClassesColour.json\" File Not Found\"");
                    return;
                }

                using (StreamReader reader = new StreamReader(stream))
                {
                    ColorClasses colorClasses = LoadColorClasses(reader);
                    // Convert RGB values to SolidColorBrush and populate the lists
                    SmallColorList = ConvertColorList(colorClasses.PrincipleClasses);
                    LargeColorList = ConvertColorList(colorClasses.SubClasses);
                    BCClassColorList = BCClass(SmallColorList, LargeColorList);
                    BAClassColorList = BAClass(SmallColorList, LargeColorList);
                    CClassPrincipalColorList = SubClasslList(SmallColorList, "C");
                    CClassSubClassColorList = SubClasslList(LargeColorList, "C");
                    CAlassPrincipalColorList = SubClasslList(SmallColorList, "A");
                    CAlassSubClassColorList = SubClasslList(LargeColorList, "A");
                    CBlassPrincipalColorList = SubClasslList(SmallColorList, "B");
                    CBlassSubClassColorList = SubClasslList(LargeColorList, "B");
                }
            }

        }

        /// <summary>
        /// Filter color classes based on subclass format.
        /// </summary>
        /// <param name="colorList"> Color list </param>
        /// <param name="subclass"> subclass value </param>
        /// <returns></returns>
        private List<ColorClass> SubClasslList(List<ColorClass> colorList,string subclass)
        {
            List<ColorClass> CClasscolorList = new List <ColorClass>();
            foreach (var colorClass in colorList)
            {
                if (IsValidSubClassFormat(colorClass.ClassName, subclass))
                {
                    CClasscolorList.Add(colorClass);
                }
            }
            return CClasscolorList;
        }

        /// <summary>
        /// Filter color classes based on BC class format.
        /// </summary>
        /// <param name="SmallColorList"> Small color list </param>
        /// <param name="LargeColorList"> Large color list </param>
        /// <returns> List of filtered BC color list </returns>
        private List<ColorClass> BCClass(List<ColorClass> SmallColorList, List<ColorClass> LargeColorList)
        {
            List<ColorClass> BCClassColorList = new List<ColorClass>();
            foreach (ColorClass colorClass in SmallColorList)
            {
                if (IsValidFormat(colorClass.ClassName))
                {
                    BCClassColorList.Add(colorClass);
                }
            }
            foreach (ColorClass colorClass in LargeColorList)
            {
                if (IsValidFormat(colorClass.ClassName))
                {
                    BCClassColorList.Add(colorClass);
                }
            }
            return BCClassColorList;
        }

        /// <summary>
        /// Filter color classes based on BA class format.
        /// </summary>
        /// <param name="SmallColorList"> Small color list </param>
        /// <param name="LargeColorList"> Large color list </param>
        /// <returns> List of filtered BA color list </returns>
        private List<ColorClass> BAClass(List<ColorClass> SmallColorList, List<ColorClass> LargeColorList)
        {
            List<ColorClass> BCClassColorList = new List<ColorClass>();
            foreach (ColorClass colorClass in SmallColorList)
            {
                if (IsValidFormatBAClass(colorClass.ClassName))
                {
                    BCClassColorList.Add(colorClass);
                }
            }
            foreach (ColorClass colorClass in LargeColorList)
            {
                if (IsValidFormatBAClass(colorClass.ClassName))
                {
                    BCClassColorList.Add(colorClass);
                }
            }
            return BCClassColorList;
        }

        /// <summary>
        /// Validate the format of the class name.
        /// </summary>
        /// <param name="input"> tobe validated format</param>
        /// <returns> if valid ot no </returns>
        static bool IsValidFormat(string input)
        {
            string pattern = @"^(Classe [BC]\.\d+ -> [BC]\.\d+|[BC]\.\d+)$";
            return Regex.IsMatch(input, pattern);
        }

        /// <summary>
        /// Validate the format of the BA class name.
        /// </summary>
        /// <param name="input"> tobe validated format </param>
        /// <returns> if valid ot no </returns>
        static bool IsValidFormatBAClass(string input)
        {
            string pattern = @"^(Classe [BA]\.\d+ -> [BA]\.\d+|[BA]\.\d+)$";
            return Regex.IsMatch(input, pattern);
        }

        /// <summary>
        /// Validate the format of the subclass name.
        /// </summary>
        /// <param name="input"> input string </param>
        /// <param name="filterString"> filter string </param>
        /// <returns> if valid ot no </returns>
        static bool IsValidSubClassFormat(string input,string filterString)
        {
            string pattern = $@"^(Classe {filterString}\.\d+ -> {filterString}\.\d+|{filterString}\.\d+)$";
            return Regex.IsMatch(input, pattern);
        }

        // Load the color classes from the JSON file
        /// <summary>
        /// Load color classes from a JSON file.
        /// </summary>
        /// <param name="reader"> sream reader </param>
        /// <returns> ColorClasses object </returns>
        private ColorClasses LoadColorClasses(StreamReader reader)
        {
            string jsonString = reader.ReadToEnd();
            //string json = File.ReadAllText(filePath);
            return JsonConvert.DeserializeObject<ColorClasses>(jsonString);
        }

        // Convert RGB strings to SolidColorBrush for display in ListView
        /// <summary>
        /// Convert a list of ColorClass objects by transforming their RGB string values into SolidColorBrush objects.
        /// </summary>
        /// <param name="colorList"> list of colors </param>
        /// <returns> list of colors </returns>
        private List<ColorClass> ConvertColorList(List<ColorClass> colorList)
        {
            foreach (var colorClass in colorList)
            {
                // Split the RGB values (assuming they're in the format "R,G,B")
                var rgbValues = colorClass.RGBValues.Split(',').Select(byte.Parse).ToArray();
                var color = Color.FromRgb(rgbValues[0], rgbValues[1], rgbValues[2]);

                // Create a SolidColorBrush from the RGB values
                colorClass.RGBColor = new SolidColorBrush(color);
            }
            return colorList;
        }
    }

    /// <summary>
    /// Class representing a color class with its name and RGB values.
    /// </summary>
    public class ColorClass
    {
        public string ClassName { get; set; }
        public string RGBValues { get; set; } // Format: "R,G,B"
        public SolidColorBrush RGBColor { get; set; } // For binding in XAML
    }

    /// <summary>
    /// Class representing the structure of color classes in the JSON file.
    /// </summary>
    public class ColorClasses
    {
        public List<ColorClass> PrincipleClasses { get; set; }
        public List<ColorClass> SubClasses { get; set; }
    }
}
