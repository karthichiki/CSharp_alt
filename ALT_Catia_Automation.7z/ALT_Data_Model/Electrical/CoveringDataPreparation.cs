﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using ALT_Logging;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using PARTITF;
using ProductStructureTypeLib;
using System.Collections.Generic;
using System.Windows;
using MECMOD;
using INFITF;

namespace ALT_Data_Model.Electrical
{
    public class CoveringDataPreparation
    {
        private static CoveringDataPreparation _CoveringDataPreparation;
        public Product CatiaProduct { get; set; }
        public CATIEhiMultiBranchable MultiBranchable { get; set; }
        public IList<SelectedBundleSegment> IBundleSegments { get; set; }
        public string Sleeve { get; set; }
        public List<string> Zones { get; set; }

        /// <summary>
        /// Singleton accessor for <see cref="CoveringDataPreparation"/>.
        /// Ensures a single shared instance is used for user covering interactions.
        /// </summary>
        /// <returns>The singleton instance of <see cref="CoveringDataPreparation"/>.</returns>
        public static CoveringDataPreparation GetInstance()
        {
            if (_CoveringDataPreparation == null)
                _CoveringDataPreparation = new CoveringDataPreparation();

            return _CoveringDataPreparation;
        }

        /// <summary>
        /// Allows the user to interactively select one or more bundle segments in CATIA.
        /// Prompts repeatedly until the user cancels. Selected segments are stored in <see cref="IBundleSegments"/>.
        /// </summary>
        /// <returns>Semicolon separated list of selected bundle segment names; empty string if none selected.</returns>
        public string SelectBundleSegment()
        {
            var log = $"--- Select Bundle segment(s): ";
            alt_Logging_class.AddMessage(log);

            string selectedSegmentsNames = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();  
            List<string> bundleSegmentsNames = new List<string>();
            IBundleSegments = new List<SelectedBundleSegment>();   
            MessageBoxResult result;
            do
            {
                alt_WindowTracker.BringApplicationToFront("CNEXT");

                SelectedElement selectedElem = adapter.SelectRibInCatia("Select your Branchable");
                if (selectedElem == null)
                    return string.Empty;

                Rib rib = selectedElem.Value as Rib;
                if (rib == null)
                    return string.Empty;

                CATIEhiBundleSegment ehiBundleSegment = ehiAdapter.FindBundleSegmentFromRib(MultiBranchable, rib);
                if (ehiBundleSegment != null)
                {
                    SelectedBundleSegment selectedBundleSegment = new SelectedBundleSegment(ehiBundleSegment);
                    if (!bundleSegmentsNames.Contains(selectedBundleSegment.bundleSegmentName))
                    {
                        IBundleSegments.Add(selectedBundleSegment);
                        bundleSegmentsNames.Add(selectedBundleSegment.bundleSegmentName);
                    }
                }
                result = MessageBoxOnTop.BringMessageBoxToTop("Do you want to select one more?", "BundleSegment", MessageBoxButton.YesNo, MessageBoxImage.Question);
            }
            while (result == MessageBoxResult.Yes);
            
            foreach (string name in bundleSegmentsNames)
                selectedSegmentsNames += name + "; ";

            return selectedSegmentsNames;
        }

        /// <summary>
        /// Prompts the user to select a sleeve (hybrid body) in CATIA.
        /// </summary>
        /// <returns>Name of the selected sleeve hybrid body; empty if selection fails.</returns>
        public string SelectSleeve()
        {
            var log = $"--- Select sleev: ";
            alt_Logging_class.AddMessage(log);

            string selectedSleevName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            HybridBody hybridBody = adapter.SelectHbyInCatia("Select your Sleeve");
            selectedSleevName = hybridBody.get_Name();
            return selectedSleevName;
        }

        /// <summary>
        /// Prompts the user to select a multibranchable harness product in CATIA.
        /// Validates design mode and multi-branchable status before accepting.
        /// </summary>
        /// <returns>The selected multibranchable name, or empty string if selection is invalid.</returns>
        public string SelectMultiBranchable()
        {
            var log = $"--- Select MultiBranchable: ";
            alt_Logging_class.AddMessage(log);

            string multiBranchableName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            Product selectedProduct = adapter.SelectElementsInCatia("Select your harness");
            if (adapter.IsDesignModeApplied(selectedProduct))
            {
                if (!ehiAdapter.IsMultiBranchable(selectedProduct) == true)
                {
                    selectedProduct = null;
                    MessageBoxOnTop.BringMessageBoxToTop("Selected product is not a multiBranchable, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    CatiaProduct = selectedProduct;
                    multiBranchableName = selectedProduct.get_Name();
                    MultiBranchable = (CATIEhiMultiBranchable)selectedProduct;
                    log = $"--- Selected MultiBranchable: {multiBranchableName}";
                    alt_Logging_class.AddMessage(log);
                    alt_Logging_class.AddMessage("");
                }
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected multibranchable", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            return multiBranchableName;
        }

        /// <summary>
        /// Adds or removes a zone from the current covering configuration based on an update flag.
        /// </summary>
        /// <param name="zone">Zone identifier to add or remove.</param>
        /// <param name="update">"+" to add the zone, "-" to remove it.</param>
        public void UpdateZoneForCovering(string zone, string update)
        {
            if (Zones == null) Zones = new List<string>();
            if (update == "+")
            {
                Zones.Add(zone);
                foreach (string item in Zones)
                {
                    alt_Logging_class.AddMessage(item);
                }
            }
            else if (update == "-")
            {
                Zones.Remove(zone);
                foreach (string item in Zones)
                {
                    alt_Logging_class.AddMessage(item);
                }
            }
        }

        /// <summary>
        /// Clears the current selection state (product, multibranchable, bundle segments, sleeve and zones).
        /// </summary>
        public void ClearSelection()
        {
            CatiaProduct = null;
            MultiBranchable = null;
            IBundleSegments?.Clear();
            Sleeve = string.Empty;
            Zones?.Clear();
        }

        /// <summary>
        /// Represents a user-selected bundle segment and its extracted properties.
        /// </summary>
        public class SelectedBundleSegment
        {
            public CATIEhiBundleSegment CATIEhiBundleSegment;
            public string bundleSegmentName;
            public double diameter;
            public double bendRadius;
            public string Sleeve;
            public CATIEhiBranchable Branchable;
            /// <summary>
            /// Initializes a new instance of <see cref="SelectedBundleSegment"/> wrapping a CATIA bundle segment and retrieves its properties.
            /// </summary>
            /// <param name="ehiBundleSegment">Underlying CATIA EHI bundle segment object.</param>
            public SelectedBundleSegment(CATIEhiBundleSegment ehiBundleSegment)
            {
                CATIEhiBundleSegment = ehiBundleSegment;
                RetrieveProperties();
            }

            /// <summary>
            /// Extracts and caches bundle segment properties such as diameter, bend radius, branchable reference and name.
            /// </summary>
            private void RetrieveProperties()
            {
                diameter = CATIEhiBundleSegment.GetDiameter() * 1000;
                bendRadius = CATIEhiBundleSegment.GetBendRadius();
                Branchable = EhiBundleSegment.GetBranchable(CATIEhiBundleSegment);
                bundleSegmentName = EhiBranchable.GetName(Branchable) + "\\" 
                    + EhiBundleSegment.GetName(CATIEhiBundleSegment);
            }
        }
    }
}
