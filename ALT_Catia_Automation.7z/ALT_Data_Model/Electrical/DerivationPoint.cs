﻿using ACNEHIWrapper;
using CatiaDotNet.CommonExtensions;
using HybridShapeTypeLib;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using Newtonsoft.Json;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;

namespace ALT_Data_Model.Electrical
{
    /// <summary>
    /// Represents a derivation extremity (branch split / fictive point / projected point) in an electrical harness.
    /// Provides coordinate and tangent direction extraction in global coordinates and links to underlying CATIA objects.
    /// </summary>
    public class DerivationPoint : Extremity
    {
        #region Fields

        private Reference _refPoint = null;
        private Reference _curveReference = null;
        private Product _pointProduct = null;
        private Product _ehiPointProduct = null;
        private List<double> _tangentDirection = null;
        private List<double> _coordinates = null;
        private double _sleevOffset = 0;
        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a derivation extremity created by selecting an edge (split between two branches).
        /// </summary>
        /// <param name="point">Reference to the selected CATIA point (local reference).</param>
        /// <param name="curveRef">Reference to the electrical curve used for orientation.</param>
        /// <param name="ptProduct">The CATIA product containing the point.</param>
        /// <param name="tangentDirection">Local tangent direction vector at the point (will be normalized).</param>
        public DerivationPoint(Reference point, Reference curveRef, Product ptProduct, Vector3d tangentDirection)
        {
            _coordinates = new List<double>();
            _tangentDirection = new List<double>();
            _eExtermityType = ExtremityType.Derivation;

            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            _refPoint = point;
            _pointProduct = ptProduct;
            _curveReference = curveRef;

            _tangentDirection.Add(Math.Round(tangentDirection.Normalized().X, 3));
            _tangentDirection.Add(Math.Round(tangentDirection.Normalized().Y, 3));
            _tangentDirection.Add(Math.Round(tangentDirection.Normalized().Z, 3));

            if (null != _refPoint && null != _pointProduct)
            {
                Vector3d localCoordinates = adapter.GetPointFromReference(_refPoint);
                Vector3d globalCoordinates = adapter.TransformToGlobalCoordinates(localCoordinates, _pointProduct);

                _coordinates.Add(Math.Round(globalCoordinates.X, 3));
                _coordinates.Add(Math.Round(globalCoordinates.Y, 3));
                _coordinates.Add(Math.Round(globalCoordinates.Z, 3));
            }
        }

        /// <summary>
        /// Initializes a derivation extremity created by selecting a projected point (HybridShapeProject result).
        /// Tangent direction derived from vector between original and projected geometry.
        /// </summary>
        /// <param name="selectedPoint">The selected projected point element.</param>
        public DerivationPoint(SelectedElement selectedPoint)
        {
            _coordinates = new List<double>();
            _tangentDirection = new List<double>();
            _eExtermityType = ExtremityType.Derivation;
            _pointProduct = selectedPoint.LeafProduct as Product;
            _refPoint = selectedPoint.Value as Reference;

            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            HybridShapeProject project = (HybridShapeProject)selectedPoint.Value;
            Reference originValue = project.ElemToProject;
            Vector3d projectedPoint = adapter.GetPointFromReference(_refPoint);
            Vector3d originPoint = adapter.GetPointFromReference(originValue);
            Vector3d tangent = (projectedPoint - originPoint).Normalized();

            Vector3d globalCoordinates = adapter.TransformToGlobalCoordinates(projectedPoint, _pointProduct);
            Vector3d globaltangent = adapter.TransformToGlobalCoordinates(tangent, _pointProduct);

            _coordinates.Add(Math.Round(globalCoordinates.X, 3));
            _coordinates.Add(Math.Round(globalCoordinates.Y, 3));
            _coordinates.Add(Math.Round(globalCoordinates.Z, 3));

            _tangentDirection.Add(Math.Round(globaltangent.Normalized().X, 3));
            _tangentDirection.Add(Math.Round(globaltangent.Normalized().Y, 3));
            _tangentDirection.Add(Math.Round(globaltangent.Normalized().Z, 3));

            _curveReference = GetCurveAsTangentDirection(globalCoordinates);
        }

        /// <summary>
        /// Initializes a derivation extremity created by selecting an existing fictive point product.
        /// Loads reference point and infers tangent using adjacent control point on its branch spline.
        /// </summary>
        /// <param name="selectedProduct">The selected fictive point product.</param>
        public DerivationPoint(Product selectedProduct)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            _coordinates = new List<double>();
            _tangentDirection = new List<double>();
            _eExtermityType = ExtremityType.Derivation;

            Product gbnProduct = (Product)selectedProduct.Parent;
            _pointProduct = adapter.GetMultiBranchableFromGBN(gbnProduct);

            // Ref Point publication
            Publication refPointPub = CatiaProductExtensions.GetPublication(selectedProduct, "Point.1");
            Vector3d refPointCoords = adapter.GetPointFromReference((Reference)refPointPub.Valuation);
            
            IList<(CATIEhiBranchable, int)> branches = GetLinkedBranches(refPointCoords);
            if (branches != null && branches.Count > 0)
            {
                Reference nextPoint = null;
                int position = branches[0].Item2;
                HybridShapeSpline spline = EhiBranchable.GetElecCurve(branches[0].Item1);
                _refPoint = spline.GetPoint(position);
                if(position == spline.GetNbControlPoint())
                    nextPoint = spline.GetPoint(position - 1);
                else
                    nextPoint = spline.GetPoint(position + 1);

                Vector3d nextPointCoords = adapter.GetPointFromReference(nextPoint);
                Vector3d nextCoordinates = adapter.TransformToGlobalCoordinates(nextPointCoords, _pointProduct);
                Vector3d tangent = nextCoordinates - refPointCoords;
                _curveReference = _pointProduct.GetPart().CreateReferenceFromObject(spline);

                _tangentDirection.Add(Math.Round(tangent.Normalized().X, 3));
                _tangentDirection.Add(Math.Round(tangent.Normalized().Y, 3));
                _tangentDirection.Add(Math.Round(tangent.Normalized().Z, 3));
            }

            _coordinates.Add(Math.Round(refPointCoords.X, 3));
            _coordinates.Add(Math.Round(refPointCoords.Y, 3));
            _coordinates.Add(Math.Round(refPointCoords.Z, 3));
        }

        /// <summary>
        /// Initializes a derivation extremity created by selecting a point and an explicit tangent-defining edge.
        /// Optionally uses a first selected reference point to disambiguate direction inversion.
        /// </summary>
        /// <param name="selectedPoint">Selected CATIA point reference.</param>
        /// <param name="selectedEdge">Reference representing edge / curve for tangent extraction.</param>
        /// <param name="firstSelectedPoint">First point coordinates chosen earlier (used to orient tangent).</param>
        public DerivationPoint(SelectedElement selectedPoint, Reference selectedEdge, object[] firstSelectedPoint)
        {
            _coordinates = new List<double>();
            _tangentDirection = new List<double>();
            _eExtermityType = ExtremityType.Derivation;
            _pointProduct = selectedPoint.LeafProduct as Product;
            _refPoint = selectedPoint.Value as Reference;

            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Vector3d coordinates = adapter.GetPointFromReference(_refPoint);
            Vector3d globalCoordinates = adapter.TransformToGlobalCoordinates(coordinates, _pointProduct);

            Vector3d tangent = adapter.GetDirectionFromReference(selectedEdge);
            Vector3d selectedSecondPoint = new Vector3d((double)firstSelectedPoint[0], (double)firstSelectedPoint[1],
                (double)firstSelectedPoint[2]);

            _coordinates.Add(Math.Round(globalCoordinates.X, 3));
            _coordinates.Add(Math.Round(globalCoordinates.Y, 3));
            _coordinates.Add(Math.Round(globalCoordinates.Z, 3));

            Vector3d refDirection = selectedSecondPoint - coordinates;
            tangent.Normalize();
            refDirection.Normalize();
            if (Vector3d.Dot(tangent, refDirection) < 0)
                tangent = -tangent;

            _tangentDirection.Add(Math.Round(tangent.Normalized().X, 3));
            _tangentDirection.Add(Math.Round(tangent.Normalized().Y, 3));
            _tangentDirection.Add(Math.Round(tangent.Normalized().Z, 3));

            _ehiPointProduct = adapter.InsertEhiPoint(coordinates, tangent,
                _pointProduct.Parent as Product, "FICTIVE POINT TYPE 2.CATPart");
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets the CATIA display name of the referenced derivation point (empty if unavailable).
        /// </summary>
        public override string Name
        {
            get
            {
                if (_refPoint != null)
                    return _refPoint.DisplayName;

                return string.Empty;
            }
        }

        /// <summary>
        /// Gets a semicolon-delimited coordinate string (X;Y;Z) used in external DTR-style outputs.
        /// </summary>
        public override string DtrName
        {
            get
            {
                if (Coordinates != null && Coordinates.Count > 2)
                {
                    return Coordinates[0].ToString() + ";" +
                           Coordinates[1].ToString() + ";" +
                           Coordinates[2].ToString();
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Gets the global coordinates of the derivation point (millimeter precision rounded to 3 decimals).
        /// </summary>
        public override List<double> Coordinates
        {
            get { return _coordinates; }
        }

        /// <summary>
        /// Gets the normalized tangent direction vector (rounded components) associated with the point.
        /// </summary>
        public override List<double> TangentDirection
        {
            get { return _tangentDirection; }
        }

        /// <summary>
        /// Gets the extremity classification (always <see cref="ALT_Data_Model.Electrical.ExtremityType.Derivation"/> for this class).
        /// </summary>
        public override ExtremityType ExtremityType
        {
            get
            {
                return ExtremityType.Derivation;
            }
        }

        /// <summary>
        /// Gets or sets the underlying CATIA reference point (not serialized to JSON).
        /// </summary>
        [JsonIgnore]
        public Reference RefPoint
        {
            get { return _refPoint; }
            set { _refPoint = value; }
        }

        /// <summary>
        /// Gets the linked branch curve reference if a curve constraint (tangent) was detected; otherwise null.
        /// </summary>
        [JsonIgnore]
        public Reference LinkedBranchCurve
        {
            get { return _curveReference; }
        }

        /// <summary>
        /// Gets the created EHI fictive point product (only for constructor variants that insert a point).
        /// </summary>
        [JsonIgnore]
        public Product EhiPointProduct
        {
            get { return _ehiPointProduct; }
        }

        /// <summary>
        /// Gets or sets a textual classification for the derivation (e.g., split type) if required by downstream logic.
        /// </summary>
        public string DerivationType
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the sleeve offset value (reserved for future logic, currently always zero).
        /// </summary>
        public override double SleeveOffset
        {
            get
            {
                return _sleevOffset;
            }

        }
        #endregion

        #region Public Methods
        // (No public methods beyond constructors/properties at present.)
        #endregion

        #region Private Methods

        /// <summary>
        /// Attempts to find and return a curve reference serving as tangent guidance for this derivation point.
        /// Inspects linked branch splines for constraint definitions at the derivation location.
        /// </summary>
        /// <param name="projectionCoords">Global coordinates of the derivation projection.</param>
        /// <returns>Curve reference if a constraint is found; otherwise null.</returns>
        private Reference GetCurveAsTangentDirection(Vector3d projectionCoords)
        {
            IList<(CATIEhiBranchable, int)> branches = GetLinkedBranches(projectionCoords);

            //Get curve reference as tangent direction.
            if (branches != null && branches.Count > 1)
            {
                foreach (var branchData in branches)
                {
                    int position = branchData.Item2;
                    HybridShapeSpline spline = EhiBranchable.GetElecCurve(branchData.Item1);
                    if (spline.GetConstraintType(position) == 2)
                    {
                        spline.GetPointConstraintFromCurve(
                            position,
                            out Reference refCurveCst,
                            out double tangencyNorm,
                            out int invertValue,
                            out int crvCstType
                        );

                        if (refCurveCst != null)
                            return refCurveCst;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// Determines branchable elements whose first or last control point matches the provided global coordinates.
        /// </summary>
        /// <param name="projectionCoords">Global coordinates of the derivation candidate point.</param>
        /// <returns>List of tuples (branchable, control point index) indicating matching endpoints.</returns>
        private IList<(CATIEhiBranchable, int)> GetLinkedBranches(Vector3d projectionCoords)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            IList<(CATIEhiBranchable, int)> branches = new List<(CATIEhiBranchable, int)>();
            CATIEhiMultiBranchable multiBranchable = (CATIEhiMultiBranchable)_pointProduct;
            foreach (CATIEhiBranchable branch in EhiMultiBranchable.GetBranchables(multiBranchable))
            {
                if (branch == null)
                    continue;

                string name = EhiBranchable.GetName(branch);
                HybridShapeSpline spline = EhiBranchable.GetElecCurve(branch);
                try 
                {
                    Reference firstPoint = spline.GetPoint(1);
                    Vector3d firstLocalCoords = adapter.GetPointFromReference(firstPoint);
                    Vector3d firstGlobalCoords = adapter.TransformToGlobalCoordinates(firstLocalCoords, _pointProduct);
                    if (adapter.ComparePointByCoords(firstGlobalCoords, projectionCoords))
                        branches.Add((branch, 1));
                    else
                    {
                        Reference lastPoint = spline.GetPoint(spline.GetNbControlPoint());
                        Vector3d lastLocalCoords = adapter.GetPointFromReference(lastPoint);
                        Vector3d lastGlobalCoords = adapter.TransformToGlobalCoordinates(lastLocalCoords, _pointProduct);
                        if (adapter.ComparePointByCoords(lastGlobalCoords, projectionCoords))
                            branches.Add((branch, spline.GetNbControlPoint()));
                    }
                }
                catch { continue; }
                
            }

            return branches;
        }

        #endregion

        #region Protected Methods
        #endregion
    }
}
