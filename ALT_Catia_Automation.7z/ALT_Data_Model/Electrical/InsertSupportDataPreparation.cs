﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using ALT_Data_Model.SectionCut_Data_Model;
using ALT_Logging;
using ALT_XML_Adapter;
using ALT_XML_Adapter.XmlData;
using CatiaDotNet.CommonExtensions;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using MECMOD;
using OpenTK;
using PARTITF;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using CatiaDotNet.CommonServices;
using System.Reflection;

namespace ALT_Data_Model.Electrical
{
    /// <summary>
    /// Provides user-driven workflows for selecting multibranchables, section cuts, supports and inserting / aligning
    /// EHI supports within a CATIA harness context. Encapsulates CATIA selection operations and geometry mapping.
    /// Singleton access via <see cref="GetInstance"/>.
    /// </summary>
    public class InsertSupportDataPreparation
    {
        #region Fields

        private static InsertSupportDataPreparation _insertSupportDataPreparation;

        #endregion

        #region Properties

        /// <summary>Currently selected multibranchable CATIA product.</summary>
        public Product CatiaProduct { get; set; }
        /// <summary>Currently selected section cut CATIA product.</summary>
        public Product SectionCutProduct { get; set; }
        /// <summary>Name of selected multibranchable (cached for UI binding).</summary>
        public string Multibranchable { get; set; }
        /// <summary>Name of selected section cut part.</summary>
        public string SectionCutPartName { get; set; }
        /// <summary>Selected CATIA EHI branchable entity.</summary>
        public CATIEhiBranchable Branchable { get; set; }
        /// <summary>Reference support product used for alignment operations.</summary>
        public Product RefSupport { get; set; }
        /// <summary>Collection of selected supports for batch operations.</summary>
        public List<Product> SupportList { get; set; }

        #endregion

        #region Constructor
        /// <summary>
        /// Private constructor enforcing singleton pattern.
        /// </summary>
        private InsertSupportDataPreparation()
        {
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Returns singleton instance of <see cref="InsertSupportDataPreparation"/>.
        /// </summary>
        public static InsertSupportDataPreparation GetInstance()
        {
            if (_insertSupportDataPreparation == null)
                _insertSupportDataPreparation = new InsertSupportDataPreparation();

            return _insertSupportDataPreparation;
        }

        /// <summary>
        /// Prompts user to select a multibranchable harness product and validates design mode & type.
        /// Updates <see cref="CatiaProduct"/> and returns selected name (empty on failure).
        /// </summary>
        public string SelectMultiBranchable()
        {
            var log = $"--- Select MultiBranchable: ";
            alt_Logging_class.AddMessage(log);

            string multiBranchableName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            Product selectedProduct = adapter.SelectElementsInCatia("Select your harness");
            if (adapter.IsDesignModeApplied(selectedProduct))
            {

                if (!ehiAdapter.IsMultiBranchable(selectedProduct) == true)
                {
                    selectedProduct = null;
                    MessageBox.Show("Selected product is not a multiBranchable, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    CatiaProduct = selectedProduct;
                    multiBranchableName = selectedProduct.get_Name();

                    log = $"--- Selected MultiBranchable: {multiBranchableName}";
                    alt_Logging_class.AddMessage(log);
                    alt_Logging_class.AddMessage("");
                }
                Multibranchable = multiBranchableName;
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected multibranchable", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            return multiBranchableName;
        }

        /// <summary>
        /// Inserts a support (EHI support or EHI point) at a user-defined intermediate waypoint on a planar surface.
        /// Uses chosen support name to resolve geometry template from XML definitions.
        /// </summary>
        /// <param name="supportName">Name of support or point defined in XML reference data.</param>
        /// <param name="repeat">True to suppress initial instruction popup for repeated insert operations.</param>
        public void InsertSelectedSupport(string supportName, bool repeat)
        {
            IntermediateWayPoint intermediateWayPoint = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_XmlServices xmlService = alt_XmlServices.GetInstance();

            intermediateWayPoint = SelectIntermediateWayPointFromSurface(repeat);
            EhiSupport ehiSupport = xmlService.GetEhiSupportByName(supportName);
            if(ehiSupport != null)
            {
                if (intermediateWayPoint != null && CatiaProduct != null)
                {
                    Product suppParent = (Product)CatiaProduct.Parent;
                    Vector3d position = new Vector3d(intermediateWayPoint.Coordinates[0], intermediateWayPoint.Coordinates[1], intermediateWayPoint.Coordinates[2]);
                    Vector3d normal = new Vector3d(intermediateWayPoint.NormalDirection[0], intermediateWayPoint.NormalDirection[1], intermediateWayPoint.NormalDirection[2]);
                    Vector3d tangent = new Vector3d(intermediateWayPoint.TangentDirection[0], intermediateWayPoint.TangentDirection[1], intermediateWayPoint.TangentDirection[2]);

                    Vector3d supportCenter = new Vector3d(ehiSupport.Center.X, ehiSupport.Center.Y, ehiSupport.Center.Z);
                    Vector3d supportlocalTangent = new Vector3d(ehiSupport.Tangent.X, ehiSupport.Tangent.Y, ehiSupport.Tangent.Z);
                    adapter.InsertEhiSupport(position, tangent, normal, supportCenter, supportlocalTangent, 
                        suppParent, ehiSupport.PartName, 0);
                }
            }
            else
            {
                EhiPoint ehiPoint = xmlService.GetEhiPointByName(supportName);
                if(ehiPoint != null)
                {
                    Product suppParent = (Product)CatiaProduct.Parent;
                    Vector3d position = new Vector3d(intermediateWayPoint.Coordinates[0], intermediateWayPoint.Coordinates[1], intermediateWayPoint.Coordinates[2]);
                    Vector3d tangent = new Vector3d(intermediateWayPoint.TangentDirection[0], intermediateWayPoint.TangentDirection[1], intermediateWayPoint.TangentDirection[2]);                    
                    adapter.InsertEhiPoint(position, tangent, suppParent, ehiSupport.PartName);
                }
            }
        }

        /// <summary>
        /// Prompts user to select a section cut part; validates type and design mode and stores selection.
        /// </summary>
        /// <returns>The selected section cut part name, or empty string if invalid.</returns>
        public string SelectSectionCutPart()
        {
            var log = $"--- Select Section Cut Part: ";
            alt_Logging_class.AddMessage(log);

            string sectionCutPartName = string.Empty;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            Product selectedProduct = adapter.SelectElementsInCatia("Select your part");
            if (adapter.IsDesignModeApplied(selectedProduct))
            {
                if (ehiAdapter.IsSectionCut(selectedProduct) == false)
                {
                    selectedProduct = null;
                    MessageBox.Show("Selected product is not a sectionCut part, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    SectionCutProduct = selectedProduct;
                    sectionCutPartName = selectedProduct.get_Name();

                    log = $"--- Selected sectionCut part: {sectionCutPartName}";
                    alt_Logging_class.AddMessage(log);
                    alt_Logging_class.AddMessage("");
                }
                Multibranchable = sectionCutPartName;
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected sectioncut Part", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            return sectionCutPartName;
        }

        /// <summary>
        /// Updates all dummy support positions linked to circle sketches of the selected section cut.
        /// Compares current position with circle center and repositions if mismatched.
        /// </summary>
        public void UpdateSupportsPosition()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (CatiaProduct != null && SectionCutProduct != null)
            {
                var log = $"---- Start updating section cuts supports position: ";
                alt_Logging_class.AddMessage(log);

                Product suppParent = (Product)CatiaProduct.Parent;
                IList<Product> dummySupports = adapter.ExtractDummySupports(suppParent);

                DataPreProcessing dataPreProcessing = new DataPreProcessing();
                IDictionary<string, CircleSegment> circleSegmentDict = dataPreProcessing.ExtractCircleSegments(SectionCutProduct);
                foreach (Product dummySupport in dummySupports)
                {
                    if (dummySupport == null)
                        continue;

                    object[] Abs_Position = new object[12];
                    string description = dummySupport.get_DescriptionInst();
                    Abs_Position = adapter.ConvertMatrixToArray(CatiaProductExtensions.GetGlobalMatrix4d(dummySupport));

                    log = $"------- Dummy support name: {dummySupport.get_Name()}";
                    alt_Logging_class.AddMessage(log);
                    log = $"------- Dummy support linked circle: {description}";
                    alt_Logging_class.AddMessage(log);
                    if (Abs_Position != null && Abs_Position.Length > 11)
                        log = $"------- Dummy support Position: {Abs_Position[9]}; {Abs_Position[10]}; {Abs_Position[11]}";
                    else
                        log = "------- Dummy support Position: Array is null or length is insufficient.";
                    alt_Logging_class.AddMessage(log);

                    bool isFoundCircle = false;
                    bool isUpdatedSupport = false;                 
                    if (Abs_Position != null && Abs_Position.Length > 11)
                    {
                        Vector3d supportPosition = new Vector3d((double)Abs_Position[9], (double)Abs_Position[10], (double)Abs_Position[11]);
                        if (circleSegmentDict.ContainsKey(description))
                        {
                            isFoundCircle = true;
                            CircleSegment circleSegment = circleSegmentDict[description];
                            Vector3d center = new Vector3d(circleSegment.Center.X, circleSegment.Center.Y, circleSegment.Center.Z);
                            if (adapter.ComparePointByCoords(center, supportPosition) == false)
                            {
                                isUpdatedSupport = true;
                                adapter.ApplyPositionTransorm(center, dummySupport, suppParent);
                            }
                            log = $"------- Linked circle center: {center.X}; {center.Y}; {center.Z}";
                            alt_Logging_class.AddMessage(log);
                        }
                        log = $"------- Linked circle is found: {isFoundCircle.ToString()}";
                        alt_Logging_class.AddMessage(log);
                        log = $"------- Dummy support position updated: {isUpdatedSupport.ToString()}";
                        alt_Logging_class.AddMessage(log);
                        alt_Logging_class.AddMessage("");
                    }
                }
                log = $"---- End updating section cuts supports position: ";
                alt_Logging_class.AddMessage(log);
            }
        }

        /// <summary>
        /// Prompts user to select a branchable by picking a rib; resolves branchable and stores it.
        /// </summary>
        /// <returns>Fully qualified branchable name (MultiBranchable\Branch) or empty on failure.</returns>
        public string SelectBranchable()
        {
            var log = $"--- Select Branchable: ";
            alt_Logging_class.AddMessage(log);

            string selectedBranchableName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();

            alt_WindowTracker.BringApplicationToFront("CNEXT");

            SelectedElement selectedElem = adapter.SelectRibInCatia("Select your Branchable");
            if (selectedElem == null)
                return string.Empty;

            Rib rib = selectedElem.Value as Rib;
            if (rib == null)
            {
                MessageBox.Show("Selected element is not a branchable, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return string.Empty;
            }

            // Try to get Product
            CatiaProduct = selectedElem.LeafProduct as Product;
            if (CatiaProduct == null)
            {
                MessageBox.Show("Rib parent is not a Product. Please select again.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return string.Empty;
            }

            var mbbns = CatiaProduct as CATIEhiMultiBranchable;
            if (mbbns == null)
            {
                MessageBox.Show("Can't get multibranchable from selected branch. Please select again.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return string.Empty;
            }

            CATIEhiBranchable ehiBranchable = ehiAdapter.FindBranchableFromRib(mbbns, rib);
            if (ehiBranchable != null)
            {
                selectedBranchableName = CatiaProduct.get_Name() + "\\" + EhiBranchable.GetName(ehiBranchable);
                Branchable = ehiBranchable;
            }

            return selectedBranchableName;
        }

        /// <summary>
        /// Prompts user to select a reference support product for alignment operations.
        /// </summary>
        /// <returns>Name of selected reference support or empty string on failure.</returns>
        public string SelectReferenceSupport()
        {
            var log = $"--- Select Reference Support: ";
            alt_Logging_class.AddMessage(log);

            string supportPartName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            alt_WindowTracker.BringApplicationToFront("CNEXT");
            Product selectedProduct = adapter.SelectElementsInCatia("Select your Reference Support");
            if (adapter.IsDesignModeApplied(selectedProduct))
            {
                if (ehiAdapter.IsSupport(selectedProduct) == false)
                {
                    selectedProduct = null;
                    MessageBox.Show("Selected product is not a Support, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    RefSupport = selectedProduct;
                    supportPartName = selectedProduct.get_Name();

                    log = $"--- Selected Reference support: {supportPartName}";
                    alt_Logging_class.AddMessage(log);
                    alt_Logging_class.AddMessage("");
                }
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected sectioncut Part", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            return supportPartName;
        }

        /// <summary>
        /// Allows user multi-selection of support products and stores them in <see cref="SupportList"/>.
        /// </summary>
        /// <returns>Semicolon separated list of selected support names; empty on cancellation.</returns>
        public string SelectSupports()
        {
            var log = $"--- Select Support(s): ";
            alt_Logging_class.AddMessage(log);

            string selectedSupportNames = "";

            if (SupportList == null)
                SupportList = new List<Product>();
            else
                SupportList.Clear();

            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_WindowTracker.BringApplicationToFront("CNEXT");

            object[] SelFilfer = new object[1] { "Product" };
            Product[] selectedProducts = adapter.MultiSelectElementsInCatia("Select your Supports", SelFilfer);
            if (selectedProducts == null)
                return string.Empty;

            foreach (Product support in selectedProducts)
            {
                if (support == null)
                    continue;

                SupportList.Add(support);
                selectedSupportNames += support.get_Name() + "; ";
            }

            return selectedSupportNames;
        }

        /// <summary>
        /// Aligns all selected supports along the tangent direction of the reference support by projecting each
        /// support position onto the reference line.
        /// </summary>
        /// <returns>"Successfull" on completion, or empty string if preconditions are not met.</returns>
        public string AlignSupportsPosition()
        {
            var log = $"--- Align Support Positions: ";
            alt_Logging_class.AddMessage(log);
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            if (RefSupport == null)
            {
                MessageBox.Show("No reference support selected, please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return string.Empty;
            }
            if (SupportList == null || SupportList.Count == 0)
            {
                MessageBox.Show("No support list selected, please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return string.Empty;
            }
            if (Branchable == null)
            {
                MessageBox.Show("No branchable selected, please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return string.Empty;
            }

            //1. Get info from reference support
            object[] Abs_Position = new object[12];
            RefSupport.Position.GetComponents(Abs_Position);
            ElbSupport elbSupport = new ElbSupport(RefSupport);

            Vector3d tangent = new Vector3d(elbSupport.TangentDirection[0],
                                            elbSupport.TangentDirection[1],
                                            elbSupport.TangentDirection[2]);
            Vector3d refPosition = new Vector3d(Convert.ToDouble(Abs_Position[9]),
                                                Convert.ToDouble(Abs_Position[10]),
                                                Convert.ToDouble(Abs_Position[11]));

            foreach (Product support in SupportList)
            {
                if (support == null)
                    continue;

                object[] absPosition = new object[12];
                support.Position.GetComponents(absPosition);
                Vector3d suppPosition = new Vector3d(Convert.ToDouble(absPosition[9]),
                                                Convert.ToDouble(absPosition[10]),
                                                Convert.ToDouble(absPosition[11]));

                //new position
                Vector3d newPosition = adapter.ProjectPointOnLine(refPosition, suppPosition, tangent);
                absPosition[9] = newPosition.X;
                absPosition[10] = newPosition.Y;
                absPosition[11] = newPosition.Z;
                support.Position.SetComponents(absPosition);
            }

            Product geomPrd = (Product)CatiaProduct.Parent;
            geomPrd.Update();

            return "Successfull";
        }

        /// <summary>
        /// Inserts dummy supports for every circle sketch associated with the selected multibranchable harness.
        /// </summary>
        public void InsertSupportsForAllSectionsCuts()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (CatiaProduct == null)
            {
                MessageBox.Show("Please select multibranchable first", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var log = $"---- Start inserting supports for all section cuts: ";
            alt_Logging_class.AddMessage(log);
            log = $"------- Selected Harness: {CatiaProduct.get_Name()}";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");

            var circles = SectionCutJsonHelper.GetCirclesByHarness(CatiaProduct.get_Name());
            if (circles == null)
            {
                log = $"------- No sketches found for selected harness inserting supports for all section cuts.";
                alt_Logging_class.AddMessage(log);
                alt_Logging_class.AddMessage("");
                return;
            }

            foreach (var circle in circles)
            {
                string circlePath = circle.Key;
                log = $"------- Circle sketch : {circlePath}";
                alt_Logging_class.AddMessage(log);

                foreach (var (center, tangent) in circle.Value)
                {
                    log = $"------- Position : {center.X}; {center.Y}; {center.Z}";
                    alt_Logging_class.AddMessage(log);
                    log = $"------- Tangent : {tangent.X}; {tangent.Y}; {tangent.Z}";
                    alt_Logging_class.AddMessage(log);

                    Product dummySupport = null;
                    try
                    {
                        Product suppParent = (Product)CatiaProduct.Parent;
                        dummySupport = adapter.InsertDummySupport(center, tangent, suppParent, "DUMMY SUPPORT 20 X 20.CATPart");
                        if (dummySupport != null)
                            dummySupport.set_DescriptionInst(circlePath);

                        log = $"------- Dummy Support inserted : {dummySupport.get_Name()}";
                        alt_Logging_class.AddMessage(log);
                    }
                    catch (Exception ex)
                    {
                        MethodBase currentMethod = MethodBase.GetCurrentMethod();
                        TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                            currentMethod.Name + " - " + ex.Message);

                        log = $"------- Dummy Support not inserted : {ex.Message}";
                        alt_Logging_class.AddMessage(log);
                    }
                }
                alt_Logging_class.AddMessage("");
            }

            log = $"---- End inserting supports for all section cuts. ";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");
        }

        #endregion

        #region Private Methods
        /// <summary>
        /// Guides the user through selecting two points on a planar face and a reference edge to build an intermediate waypoint
        /// containing position, tangent and normal directions used for support insertion.
        /// </summary>
        /// <param name="repeat">If true, suppresses help popup for repeated selections.</param>
        /// <returns>Constructed <see cref="IntermediateWayPoint"/> or null if selection invalid/cancelled.</returns>
        private IntermediateWayPoint SelectIntermediateWayPointFromSurface(bool repeat)
        {
            IntermediateWayPoint intermediateWayPoint = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            object[] firstSurfaceSelectedPoint = new object[3];
            object[] inputObject = null;
            string displayMsg = "Select two points from planar surface: \n" +
                "1.The first point is where support will be inserted. \n" +
                "2.The second point defines the tangent direction. \n" +
                "3.The edge which defines tangent reference.";
            if(!repeat)
            MessageBoxOnTop.BringMessageBoxToTop(displayMsg, "UserInput", MessageBoxButton.OK, MessageBoxImage.Information);
            alt_WindowTracker.BringApplicationToFront("CNEXT");
            inputObject = new object[1] { "Face" };
            SelectedElement selectedFace = adapter.SelectHybridshapeInCatia("Please select first point from surface", inputObject, ref firstSurfaceSelectedPoint);
            if (selectedFace != null && selectedFace.Value != null)
            {
                if (adapter.IsPlanarFace(selectedFace.Value as Face))
                {
                    Reference face = adapter.GetElemReferenceByName(adapter, selectedFace);
                    object[] sightDirection = new object[3];
                    Viewer3D viewer = adapter.GetCurrentViewer();
                    if (viewer != null)
                        viewer.Viewpoint3D.GetSightDirection(sightDirection);

                    object[] secondSurfaceSelectedPoint = new object[3];
                    selectedFace = adapter.SelectHybridshapeInCatia("Please select second point from surface", inputObject, ref secondSurfaceSelectedPoint);
                    if (face != null && firstSurfaceSelectedPoint != null && firstSurfaceSelectedPoint.Count() > 2
                        && secondSurfaceSelectedPoint != null && secondSurfaceSelectedPoint.Count() > 2
                        && sightDirection != null && sightDirection.Count() > 2)
                    {
                        object[] edgeSelectedPoint = new object[3];
                        inputObject = new object[1] { "Edge" };
                        SelectedElement selectedEdge = adapter.SelectHybridshapeInCatia("Please select an edge as reference", inputObject, ref edgeSelectedPoint);
                        Reference edge = adapter.GetElemReferenceByName(adapter, selectedEdge);
                        if (edge != null)
                            intermediateWayPoint = new IntermediateWayPoint(face, edge, firstSurfaceSelectedPoint, secondSurfaceSelectedPoint, sightDirection);
                    }
                }
                else
                {
                    displayMsg = "Please select an planar surface";
                    MessageBoxOnTop.BringMessageBoxToTop(displayMsg, "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            return intermediateWayPoint;
        }

        #endregion
    }
}
