﻿using CatiaDotNet.CommonExtensions;
using CatiaDotNet.CommonServices;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Newtonsoft.Json;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace ALT_Data_Model.Electrical
{
    /// <summary>
    /// Represents a harness support extremity and provides its reference point, tangent direction
    /// and sleeve offset (distance to sleeve end) extracted from CATIA publications.
    /// </summary>
    public class ElbSupport : Extremity
    {
        #region Fields
        /// <summary>Underlying CATIA product representing the support.</summary>
        readonly private Product _product = null;
        /// <summary>Projected reference point coordinates (X,Y,Z).</summary>
        readonly private List<double> _refPointCoords = null;
        /// <summary>Normalized tangent direction vector components.</summary>
        readonly private List<double> _tangentDirection = null;
        /// <summary>Computed sleeve offset (in meters if adapter returns mm).</summary>
        public double _sleevOffset = 0;
        #endregion

        #region Constructor
        /// <summary>
        /// Initializes a new instance of <see cref="ElbSupport"/> and immediately retrieves geometric properties
        /// (reference point, tangent direction, sleeve offset) from CATIA.
        /// </summary>
        /// <param name="product">Support CATIA product.</param>
        public ElbSupport(Product product)
        {
            _product = product;

            _product = product;
            _refPointCoords = new List<double>();
            _tangentDirection = new List<double>();
            RetrieveProperties();
        }
        #endregion

        #region Properties

        /// <summary>
        /// CATIA display name of the support product (empty if null).
        /// </summary>
        public override string Name
        {
            get
            {
                if (_product == null)
                    return string.Empty;
                else
                    return _product.get_Name();
            }
        }

        /// <summary>
        /// Projected reference point coordinates (X,Y,Z) on the support out-plane.
        /// </summary>
        public override List<double> Coordinates
        {
            get { return _refPointCoords; }
        }

        /// <summary>
        /// Normalized tangent direction vector for the support.
        /// </summary>
        public override List<double> TangentDirection
        {
            get { return _tangentDirection; }
        }

        /// <summary>
        /// Extremity classification (Support).
        /// </summary>
        public override ExtremityType ExtremityType
        {
            get
            {
                return ExtremityType.Support;
            }
        }

        /// <summary>
        /// Part number of the support product used as DTR name.
        /// </summary>
        public override string DtrName
        {
            get
            {
                if (_product == null)
                    return string.Empty;
                else
                    return _product.get_PartNumber();
            }
        }

        /// <summary>
        /// Underlying CATIA product (excluded from JSON serialization).
        /// </summary>
        [JsonIgnore]
        public Product SupportProduct
        {
            get { return _product; }
        }

        /// <summary>
        /// Sleeve offset distance (projected reference point to sleeve end) in meters (0 on failure).
        /// </summary>
        public override double SleeveOffset
        {
            get
            {
                return _sleevOffset;
            }

        }

        #endregion

        #region Public Methods
        // No additional public methods.
        #endregion

        #region Private Methods

        /// <summary>
        /// Retrieves geometric properties from CATIA: reference point, out-plane projection, tangent direction
        /// and triggers sleeve offset calculation.
        /// </summary>
        private void RetrieveProperties()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            try
            {
                //Ref Point
                Publication refPointPub = CatiaProductExtensions.GetPublication(_product, "EHISUPPORT-RefPoint1");
                Vector3d refPoint = adapter.GetPointFromReference((Reference)refPointPub.Valuation);

                //OutPlane
                Publication outPlanePub = CatiaProductExtensions.GetPublication(_product, "EHISUPPORT-RefPlane2");
                Vector3d outPlaneOrigin = adapter.GetPlaneOriginFromReference((Reference)outPlanePub.Valuation);

                //Project ref point on out plane
                Vector4d outPlaneEquation = adapter.GetPlaneEquationFromReference(outPlanePub.Valuation as Reference);
                Vector3d projectedPoint = adapter.ProjectPointOnPlane(refPoint, outPlaneEquation);
                Vector3d tangent = adapter.Round(refPoint - projectedPoint, 3).Normalized();

                _refPointCoords.Add(Math.Round(projectedPoint.X, 3));
                _refPointCoords.Add(Math.Round(projectedPoint.Y, 3));
                _refPointCoords.Add(Math.Round(projectedPoint.Z, 3));

                _tangentDirection.Add(tangent.X);
                _tangentDirection.Add(tangent.Y);
                _tangentDirection.Add(tangent.Z);

                CalculateSleevOffset(projectedPoint);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Computes the sleeve offset using the projected reference point and the "Sleeve end point" publication if present.
        /// Sets offset to 0 if data is unavailable or on error.
        /// </summary>
        /// <param name="projectedPoint">Projected reference point on the support plane.</param>
        private void CalculateSleevOffset(Vector3d projectedPoint)
        {
            try
            {
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                Publication publicationPt2 = CatiaProductExtensions.GetPublication(_product, "Sleeve end point");
                if(projectedPoint == null || publicationPt2 == null)
                {
                    _sleevOffset = 0;
                    return;
                }
                Vector3d point2 = adapter.GetPointFromReference((Reference)publicationPt2.Valuation);
                _sleevOffset = adapter.DistanceBtwVector3d(projectedPoint, point2) / 1000;
            }
            catch
            {
                _sleevOffset = 0;
            }
           
        }

        #endregion
    }
}
