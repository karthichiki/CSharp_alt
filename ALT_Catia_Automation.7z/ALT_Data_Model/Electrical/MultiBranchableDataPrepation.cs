﻿using ALT_CATIA_Adapter;
using ALT_Data_Model.Electrical;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Threading;
using ALT_Logging;
using ALT_Data_Model.UI_Data_Model;
using INFITF;
using ALT_Data_Model.Unity;
using System.IO;
using System.Xml.Serialization;
using System.Globalization;
using HybridShapeTypeLib;

namespace ALT_Data_Model
{
    public class MultiBranchableDataPrepation
    {
        #region Fields
        private static MultiBranchableDataPrepation _MultiBranchableDataPreparation;
        alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
        private Dictionary<string,List<PPL_Electrical>> _supplierData = null;
        internal Dictionary<string, List<SynopticConnector>> _SynopticData = null;
        internal Dictionary<string, List<FAF_Extract>> _ExtractFAFData = null;
        internal Dictionary<string, object> _PPL_CableData = null;
        internal Dictionary<string, List<PPL_Cables>> _Standard_EN_cables = null;
        internal Dictionary<string, List<PPL_Cables>> _Standard_NAM_cables = null;
        internal Dictionary<string, List<PPL_Cables>> _Specific_cables_DTREN = null;

        #endregion

        #region Properties

        public Product CatiaProduct { get; set; }
        public Extremity FirstExtremity { get; set; }
        public Extremity SecondExtremity { get; set; }
        public string CorrugatedSleeveExternalDiameter { get; set; }
        public string CorrugatedSleeveDTRNumber { get; set; }
        public GeometricalHarness GeometricalHarness { get; set; }
        public string Multibranchable { get; set; }
        public List<IntermediateWayPoint> IntermediateWayPoints { get; set; }

        #endregion

        #region Constructor
        private MultiBranchableDataPrepation()
        {
            IntermediateWayPoints = new List<IntermediateWayPoint>();
        }
        #endregion

        #region Public Methods
        public static MultiBranchableDataPrepation GetInstance()
        {
            if (_MultiBranchableDataPreparation == null)
                _MultiBranchableDataPreparation = new MultiBranchableDataPrepation();

            return _MultiBranchableDataPreparation;
        }

        public string SelectMultiBranchable()
        {
            var log = $"--- Select MultiBranchable: ";
            alt_Logging_class.AddMessage(log);

            string multiBranchableName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            Product selectedProduct = adapter.SelectElementsInCatia("Select your harness");
            if(adapter.IsDesignModeApplied(selectedProduct))
            {
                if (!ehiAdapter.IsMultiBranchable(selectedProduct) == true)
                {
                    selectedProduct = null;
                    MessageBox.Show("Selected product is not a multiBranchable, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    CatiaProduct = selectedProduct;
                    multiBranchableName = selectedProduct.get_Name();

                    log = $"--- Selected MultiBranchable: {multiBranchableName}";
                    alt_Logging_class.AddMessage(log);
                    alt_Logging_class.AddMessage("");
                }
                Multibranchable = multiBranchableName;
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected multibranchable", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            return multiBranchableName;
        }

        public bool ValidateSelectedMultiBranchable(string multiBranchableName, string synoptic_File_Path)
        {
            bool isMultibranchable = false;

            _SynopticData = alt_JsonReaderService.ParseHarnessInSynoptic(synoptic_File_Path);

            if (_SynopticData.Any(x => x.Key.Contains(multiBranchableName.Split(';')[0])))
                isMultibranchable = true;

            return isMultibranchable;
        }

        public int ExtractDataFromXml(string xmlPath)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(GeometricalHarness));

            if (!System.IO.File.Exists(xmlPath))
            { return 0; }

            using (StreamReader reader = new StreamReader(xmlPath))
            {
                GeometricalHarness = (GeometricalHarness)serializer.Deserialize(reader);
                 
            }
            return 1;
        }

        /// <summary>
        /// Select first extremity
        /// </summary>
        /// <param name="extractFaF"></param>
        /// <returns></returns>
        public Extremity SelectFirstExtremity(string extractFaF)
        {
            var log = $"--- Start selecting First Extremity:";
            alt_Logging_class.AddMessage(log);

            FirstExtremity = SelectExtremityGenericFunction("First", extractFaF);

            if (FirstExtremity != null)
            {
                log = $"------ Name: {FirstExtremity.Name}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Position: {FirstExtremity.Coordinates[0]} ,{FirstExtremity.Coordinates[1]}, {FirstExtremity.Coordinates[2]}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Direction: {FirstExtremity.TangentDirection[0]} ,{FirstExtremity.TangentDirection[1]}, {FirstExtremity.TangentDirection[2]}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Has derivations: {FirstExtremity.HasDerivation.ToString()}";
                alt_Logging_class.AddMessage(log);
            }
            else
            {
                log = $"------ First Extremity: {FirstExtremity}";
                alt_Logging_class.AddMessage(log);
            }

            log = $"--- End Selecting First Extremity.";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");
            return FirstExtremity;

        }

        /// <summary>
        /// Select second extremity
        /// </summary>
        /// <param name="extractFaF"></param>
        /// <returns></returns>
        public Extremity SelectSecondExtremity(string extractFaF)
        {
            var log = $"--- Start Selecting Second Extremity:";
            alt_Logging_class.AddMessage(log);

            SecondExtremity = SelectExtremityGenericFunction("Second", extractFaF);
            if (SecondExtremity != null)
            {
                log = $"------ Name: {SecondExtremity.Name}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Position: {SecondExtremity.Coordinates[0]} ,{SecondExtremity.Coordinates[1]}, {SecondExtremity.Coordinates[2]}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Direction: {SecondExtremity.TangentDirection[0]} ,{SecondExtremity.TangentDirection[1]}, {SecondExtremity.TangentDirection[2]}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Has derivations: {SecondExtremity.HasDerivation.ToString()}";
                alt_Logging_class.AddMessage(log);
            }
            else
            {
                log = $"------ Second Extremity: {SecondExtremity}";
                alt_Logging_class.AddMessage(log);
            }
            log = $"--- End Selecting Second Extremity.";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");

            return SecondExtremity;

        }

        /// <summary>
        /// Select extremity generic process
        /// </summary>
        /// <param name="extremityValue"></param>
        /// <returns></returns>
        private Extremity SelectExtremityGenericFunction(string extremityValue, string extractFaF)
        {
            Extremity extremity = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            string displayMsg = "Select extremity, we have 4 cases: \n" +
                    "1.Product: should be support or connector. \n" +
                    "2.Edge: should be circle edge defined between two branches. \n" +
                    "3.Point: should be point where you will insert EhiPoint. \n" +
                    "4.Projection: derivation point based on projection. \n";

            BringMessageBoxToTop(displayMsg, "UserInput", MessageBoxButton.OK, MessageBoxImage.Information);
            alt_WindowTracker.BringApplicationToFront("CNEXT");
            SelectedElement selectedElement = adapter.SelectExtremityInCatia("Select " + extremityValue + " Extremity: Product, Edge circle or Point");
            if (selectedElement == null)
                return null;

            switch (selectedElement.Type)
            {
                case "Product":
                    if(!adapter.IsDesignModeApplied(selectedElement.Value as Product))
                    {
                        MessageBox.Show("Please activate design mode", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                        extremity = HandleProduct(selectedElement, extractFaF);
                    break;

                case "Edge":
                    if(adapter.IsReferenceCircle(selectedElement.Reference))
                        extremity = HandleEdge(selectedElement);
                    else
                        MessageBox.Show("Please select a circular edge defined between two branchables", 
                            "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    break;

                case "Point":
                        extremity = HandlePoint(selectedElement);
                    break;

                case "HybridShapeProject":
                    if (adapter.IsProjectionOfPoint(selectedElement.Value as HybridShapeProject))
                    {
                        extremity = HandleProjection(selectedElement);
                    }
                    else
                        MessageBox.Show("Please select a point projection", "Warning", 
                            MessageBoxButton.OK, MessageBoxImage.Warning);
                    break;

                default:
                    MessageBox.Show("Selected Extremity is not a product or edge or point or project, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    break;
            }
            return extremity;
        }

        /// <summary>
        /// Select Intermediate way point
        /// </summary>
        /// <param name="selectionParameter"></param>
        public void SelectInterMediateWayPoints(string selectionParameter)
        {
            IntermediateWayPoint intermediateWayPoint = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (selectionParameter == "PLS")
                intermediateWayPoint = SelectIntermediateWayPointFromSurface();
            else
            {
                object[] selectedPoint = new object[3];
                BringMessageBoxToTop("Please select a product", "UserInput", MessageBoxButton.OK, MessageBoxImage.Information);
                alt_WindowTracker.BringApplicationToFront("CNEXT");
                object[] inputObject = new object[1] { "Product" };
                SelectedElement selectedEhiSupport = adapter.SelectHybridshapeInCatia("Please select a product", inputObject, ref selectedPoint);
                Product ehiSupport = (Product)selectedEhiSupport.Value;
                intermediateWayPoint = new IntermediateWayPoint(ehiSupport);
            }
            IntermediateWayPoints.Add(intermediateWayPoint);
        }

        private MessageBoxResult BringMessageBoxToTop(string msg, string title, MessageBoxButton messageBoxButton, MessageBoxImage messageBoxImage)
        {
            alt_WindowTracker.BringApplicationToFront("ALT_UI");
            MessageBoxResult result = MessageBoxResult.Yes;
            if (System.Windows.Application.Current.Dispatcher.CheckAccess())
            {
                 result = MessageBox.Show(System.Windows.Application.Current.MainWindow, msg , title , messageBoxButton, messageBoxImage);
            }
            else
            {
                System.Windows.Application.Current.Dispatcher.Invoke(DispatcherPriority.Normal, new Action(() => {
                 result = MessageBox.Show(System.Windows.Application.Current.MainWindow, msg, title, messageBoxButton, messageBoxImage);
                }));
            }
            return result;
        }

        public List<string> GetMultibranchableList()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            return adapter.GetOpenedMultiBranchableList();
        }

        /// <summary>
        /// Read supplier data
        /// </summary>
        /// <param name="ReadSupplierData"></param>
        /// <returns></returns>
        public Dictionary<string, List<PPL_Electrical>> ReadSupplierData(string eqtLocationFilePath)
        {
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            _supplierData = alt_JsonReaderService.ParseSupplier(eqtLocationFilePath);
            return _supplierData;
        }
        /// <summary>
        /// Calculate Bend Radius using supplier data
        /// </summary>
        /// <param name="diameter"></param>
        /// <param name="supplierName"></param>
        /// <returns></returns>
        public List<PPL_Electrical> CalculateBendRadiusUsingSupplier(string diameter)
        {
            double dia = double.Parse(diameter);
            double x = Math.Sqrt((100 * dia * dia) / 60);
            //List<PPL_Electrical> pplElectrical = _supplierData;
            
            double difference = 0;
            double bendRadius = 0;
            List < PPL_Electrical > selectedElectrical = new List<PPL_Electrical>();
            foreach (var pplElectrical in _supplierData)
            {
                PPL_Electrical electrical = new PPL_Electrical();
                double closestValue = double.MaxValue;
                foreach (PPL_Electrical _pplElectrical in pplElectrical.Value)
                {
                    if (_pplElectrical.External_Diameter.ToUpper() == "NA" || _pplElectrical.Internal_Diameter.ToUpper() == "NA" || _pplElectrical.External_Diameter.ToUpper() == "MAX./EXTERNAL DIAMETER (mm)" || _pplElectrical.Type.ToUpper() != "CORRUGATED")
                    {
                        continue;
                    }
                    difference = Math.Abs(double.Parse(_pplElectrical.Internal_Diameter, CultureInfo.InvariantCulture) - x);
                    if (difference <= closestValue)
                    {
                        closestValue = difference;
                        if (_pplElectrical.Static_Bending_Radius != "NA")
                        {
                            electrical = _pplElectrical;
                            //bendRadius = double.Parse(_pplElectrical.Static_Bending_Radius);
                            //CorrugatedSleeveNominalDiameter = _pplElectrical.Nominal_Diameter;
                            //CorrugatedSleeveDTRNumber = _pplElectrical.DTR_Number;
                        }
                    }
                }
                if(electrical.DTR_Number != null)
                selectedElectrical.Add(electrical);
            }
            return selectedElectrical;
        }
        /// <summary>
        /// Calculate Bend Radius using supplier data
        /// </summary>
        /// <param name="diameter"></param>
        /// <param name="supplierName"></param>
        /// <returns></returns>
        public double CalculateBendRadiusUsingSupplier(string diameter, string supplierName)
        {
            double dia = double.Parse(diameter, System.Globalization.CultureInfo.InvariantCulture);
            double x = Math.Sqrt((100 * dia * dia)/60);
            List<PPL_Electrical> pplElectrical = _supplierData[supplierName];
            double closestValue = double.MaxValue;
            double difference = 0;
            double bendRadius = 0;
            foreach(PPL_Electrical _pplElectrical in pplElectrical)
            {
                if (_pplElectrical.Internal_Diameter == "NA")
                {
                    continue;
                }
                difference = Math.Abs(double.Parse(_pplElectrical.Internal_Diameter, CultureInfo.InvariantCulture) - x);
                if (difference < closestValue)
                {
                    closestValue = difference;
                    if(_pplElectrical.Static_Bending_Radius != "NA")
                    {
                        bendRadius = double.Parse(_pplElectrical.Static_Bending_Radius);
                        //CorrugatedSleeveNominalDiameter = _pplElectrical.Nominal_Diameter;
                        //CorrugatedSleeveDTRNumber = _pplElectrical.DTR_Number;
                    }
                }
            }
            return bendRadius;
        }

        /// <summary>
        /// Calculate Bend Radius for Unique and Specific cables
        /// </summary>
        /// <param name="multibranchableName"></param>
        /// <param name="jsonFilePaths"></param>
        /// <param name="connector1Name"></param>
        /// <param name="connector2Name"></param>
        /// <param name="projectType"></param>
        /// <param name="cableType"></param>
        /// <returns></returns>
        public PPL_Cables CalculateBendRadius(string multibranchableName, FilePaths jsonFilePaths, string connector1Name, string connector2Name, string projectType, string cableType)
        {
            string dtr_Number = "";
            string unit = "";
            PPL_Cables pPL_Cables = new PPL_Cables();
            if(_SynopticData == null)
            _SynopticData = alt_JsonReaderService.ParseHarnessInSynoptic(jsonFilePaths.Synoptic_File_Path);
            _ExtractFAFData = alt_JsonReaderService.ParseHarness(jsonFilePaths.Extract_FAF_Path);
            alt_JsonReaderService.ParseDTR(jsonFilePaths.PPL_Cable_Path, out _Standard_EN_cables, out _Standard_NAM_cables, out _Specific_cables_DTREN);
            dtr_Number = GetDTRNumber(multibranchableName, connector1Name, connector2Name);
            if (dtr_Number == "") 
            {
                MessageBox.Show(cableType + " Cable cannot be created in between selected Connectors. Please Select other Cable Type.");
                return pPL_Cables;
            }
            List<PPL_Cables> cableData = new List<PPL_Cables>();
            List<PPL_Cables> unitData = new List<PPL_Cables>();
            if (projectType == "EN (european norme)" && cableType == "Unique")
            {
                unit = "mm";
                _Standard_EN_cables.TryGetValue("DTR", out unitData);
                _Standard_EN_cables.TryGetValue(dtr_Number, out cableData);
            }
            else if (projectType == "NAM (north american)" && cableType == "Unique")
            {
                unit = "inch";
                _Standard_NAM_cables.TryGetValue("DTR", out unitData);
                _Standard_NAM_cables.TryGetValue(dtr_Number, out cableData);
            }
            else if (cableType == "Specific")
            {
                unit = "mm";
                _Specific_cables_DTREN.TryGetValue("DTR", out unitData);
                _Specific_cables_DTREN.TryGetValue(dtr_Number, out cableData);
            }

            if (cableData == null)
            {
                MessageBox.Show("DTR number not found, Please Enter Diameter and BendRadius manually", "Warning", MessageBoxButton.OK);
                return pPL_Cables;
            }
            string static_Bending_Radius_unit = "";
            string section_unit = "";
            string diameterUnit = "";
            int i = -1;
            int k = -1;
            foreach (PPL_Cables data in unitData)
            {
                static_Bending_Radius_unit = GetUnit(data.Static_Bending_Radius);
                if (static_Bending_Radius_unit.Contains("-"))
                {
                    i = GetBendRadiusUnit(static_Bending_Radius_unit, unit);
                    if (i != -1)
                    {
                        static_Bending_Radius_unit = static_Bending_Radius_unit.Split('-')[i].Trim();
                    }
                }

                section_unit = GetUnit(data.Section);
                if (section_unit.Contains("\r\n"))
                {
                    int j = GetBendRadiusUnit(section_unit, unit);
                    if (j != -1)
                    {
                        section_unit = section_unit.Split('\n')[j];
                    }
                    else
                    {
                        section_unit = "";
                    } 
                }

                diameterUnit = GetUnit(data.Diameter);
                if (diameterUnit.Contains("-"))
                {
                    k = GetBendRadiusUnit(diameterUnit, unit);
                    if (k != -1)
                    {
                        diameterUnit = diameterUnit.Split('-')[i].Trim();
                    }
                }
                else if(data.Diameter == "")
                {
                    diameterUnit = "mm";
                }
            }

            foreach (PPL_Cables data in cableData)
            {
                if (data.Static_Bending_Radius.Contains("\n") && i != -1)
                {
                    data.Static_Bending_Radius = data.Static_Bending_Radius.Split('\n')[i].Trim();
                }
                if (data.Diameter.Contains("\n"))
                {
                    data.Diameter = data.Diameter.Split('\n')[k].Trim();
                }
                if (data.Static_Bending_Radius != "")
                {
                    pPL_Cables.Static_Bending_Radius = data.Static_Bending_Radius + " " + static_Bending_Radius_unit;
                    pPL_Cables.Section = data.Section + " " + section_unit;
                    pPL_Cables.Diameter = data.Diameter + " " + diameterUnit;
                    pPL_Cables.DTR_Number = dtr_Number;
                }
                else
                {
                    MessageBox.Show("DTR number not found, Please Enter Diameter and BendRadius manually", "Warning", MessageBoxButton.OK);
                    return pPL_Cables;
                }
                
            }
            return pPL_Cables;
        }

        /// <summary>
        /// Reset user selection
        /// </summary>
        public void ResetSelection()
        {
            FirstExtremity = null;
            SecondExtremity = null;
            IntermediateWayPoints.Clear();
        }

        public void SetDerivationType(string selectedType, string extremityNumber)
        {
            var log = "";
            if (extremityNumber == "1")
            {
                if(FirstExtremity is DerivationPoint derivationPoint)
                {
                    derivationPoint.DerivationType = selectedType;
                    log = $"--- First Extremity Selected Derivation Type: " + derivationPoint.DerivationType;
                }            }
            else if(extremityNumber == "2")
            {
                if (SecondExtremity is DerivationPoint derivationPoint)
                {
                    derivationPoint.DerivationType = selectedType;
                    log = $"--- Second Extremity Selected Derivation Type: " + derivationPoint.DerivationType;
                }
            }
            
            alt_Logging_class.AddMessage(log);
        }

        public void CorrugatedUnchecked()
        {
            CorrugatedSleeveDTRNumber = string.Empty;
            CorrugatedSleeveExternalDiameter = string.Empty;
        }
        public void CorrugatedSelected(string sleeve, string diameter)
        {
            CorrugatedSleeveDTRNumber = sleeve;
            CorrugatedSleeveExternalDiameter = diameter;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Get bend radius unit
        /// </summary>
        /// <param name="static_Bending_Radius_unit"></param>
        /// <param name="requiredUnit"></param>
        /// <returns></returns>
        private int GetBendRadiusUnit(string static_Bending_Radius_unit, string requiredUnit)
        {
            int i = -1;
            if (static_Bending_Radius_unit.ToLower().Contains("-") && static_Bending_Radius_unit.ToLower().Contains("inch") && static_Bending_Radius_unit.ToLower().Contains("mm"))
            {
                if (static_Bending_Radius_unit.ToLower().Split('-')[0].Trim().Contains(requiredUnit))
                {
                    return 0;
                }
                else if (static_Bending_Radius_unit.ToLower().Split('-')[1].Trim().Contains(requiredUnit))
                {
                    return 1;
                }
            }
            return i;
        }

        /// <summary>
        /// Get unit used for BendRadius and Diameter
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        private string GetUnit(string input)
        {
            string requiredString = "";
            int startIndex = input.IndexOf('(') + 1;
            int endIndex = input.IndexOf(')');
            int startlastIndex = input.LastIndexOf('(') + 1;
            int endlastIndex = input.LastIndexOf(')');
            // Extract the substring between '(' and ')'
            if (startIndex > 0 && endIndex > startIndex)
            {
                requiredString = input.Substring(startIndex, endIndex - startIndex);
                if (requiredString.Contains("inch") || requiredString.Contains("mm")) return requiredString;
                else
                {
                    if (startlastIndex > 0 && endlastIndex > startlastIndex)
                    {
                        requiredString = input.Substring(startlastIndex, endlastIndex - startlastIndex);
                        if (requiredString.Contains("inch") || requiredString.Contains("mm")) return requiredString;
                        else return "";
                    }
                }
            }
            else
            {
                return "";
            }
            return "";
        }

        /// <summary>
        /// Get DTR Number from FAF_Extract
        /// </summary>
        /// <param name="multibranchableName"></param>
        /// <param name="connector1Name"></param>
        /// <param name="connector2Name"></param>
        /// <param name="dtr_Number"></param>
        /// <returns></returns>
        private string GetDTRNumber(string multibranchableName, string connector1Name, string connector2Name)
        {
            string dtr_Number = "";
            var fAF_Extract_SelectedWire = _ExtractFAFData.Where(x => x.Key.Contains(multibranchableName.Split(';')[0])).ToList().First();
            foreach (var item in fAF_Extract_SelectedWire.Value)
            {
                if ((item.From_Device == connector1Name && item.To_Device == connector2Name) || (item.From_Device == connector2Name && item.To_Device == connector1Name))
                {
                    dtr_Number = item.Part_Number;
                }
            }

            return dtr_Number;
        }

        /// <summary>
        /// Check if connector has derivation or not
        /// </summary>
        /// <param name="connectorName"></param>
        /// <param name="extract_FAF_Path"></param>
        /// <returns></returns>
        private bool CheckDerivations(string connectorName, string extract_FAF_Path)
        {
            List<string> connectors = new List<string>();
            if (string.IsNullOrEmpty(Multibranchable))
                alt_Logging_class.AddError($"There is no selection for Multibranchable. Therefore It is impossible to verify whether the {connectorName} has branches.");
            else if (extract_FAF_Path == "")
                alt_Logging_class.AddError($"Extract FAF file is not extracted. Therefore It is impossible to verify whether the {connectorName} has branches.");
            else
            {
                _ExtractFAFData = alt_JsonReaderService.ParseHarness(extract_FAF_Path);
                var fAF_Extract_SelectedWire = _ExtractFAFData.Where(x => x.Key.Contains(Multibranchable.Split(';')[0])).ToList();
                foreach (var item in fAF_Extract_SelectedWire)
                {
                    foreach (var element in item.Value)
                    {
                        if (element.From_Device == connectorName || element.To_Device == connectorName)
                        {
                            connectors.Add(element.From_Device);
                            connectors.Add(element.To_Device);
                        }
                    }
                }
                connectors.Distinct();
            }
            if (connectors.Count > 2)
                return true;//"has derivation's";
            else
                return false;//"has no derivation";
        }

        //public void UpdateZoneForExtremity(string extremityNumber, string zone, string update)
        //{
        //    try
        //    {
        //        if (extremityNumber == "1")
        //        {
        //            if (FirstExtremity.Zone == null) FirstExtremity.Zone = new List<string>();
        //            if (update == "+")
        //            {
        //                FirstExtremity.Zone.Add(zone);
        //                string log = $"--- First Extremity {FirstExtremity.Name} Selected Zone: {FirstExtremity.Zone}";
        //                alt_Logging_class.AddMessage(log);
        //                foreach (string item in FirstExtremity.Zone)
        //                {
        //                    alt_Logging_class.AddMessage(item);
        //                }
        //            }
        //            else if (update == "-")
        //            {
        //                FirstExtremity.Zone.Remove(zone);
        //                string log = $"--- First Extremity {FirstExtremity.Name} Selected Zone: {FirstExtremity.Zone}";
        //                alt_Logging_class.AddMessage(log);
        //                foreach (string item in FirstExtremity.Zone)
        //                {
        //                    alt_Logging_class.AddMessage(item);
        //                }
        //            }
        //        }
        //        else if (extremityNumber == "2")
        //        {
        //            if (SecondExtremity.Zone == null) SecondExtremity.Zone = new List<string>();
        //            if (update == "+")
        //            {
        //                SecondExtremity.Zone.Add(zone);
        //                string log = $"--- Second Extremity {SecondExtremity.Name} Selected Zone: {SecondExtremity.Zone}";
        //                alt_Logging_class.AddMessage(log);
        //                foreach (string item in SecondExtremity.Zone)
        //                {
        //                    alt_Logging_class.AddMessage(item);
        //                }
        //            }
        //            else if (update == "-")
        //            {
        //                SecondExtremity.Zone.Remove(zone);
        //                string log = $"--- Second Extremity {SecondExtremity.Name} Selected Zone: {SecondExtremity.Zone}";
        //                alt_Logging_class.AddMessage(log);
        //                foreach (string item in SecondExtremity.Zone)
        //                {
        //                    alt_Logging_class.AddMessage(item);
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
            
        //}

        /// <summary>
        /// Select intermediate way point by selecting a surface and direction
        /// </summary>
        private IntermediateWayPoint SelectIntermediateWayPointFromSurface()
        {
            IntermediateWayPoint intermediateWayPoint = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            object[] firstSurfaceSelectedPoint = new object[3];
            object[] inputObject = null;
            string displayMsg = "Select two points from the surface: \n" +
                "1.The first point is where support will be inserted. \n" +
                "2.The second point defines the tangent direction.  \n " +
                "3.The edge which defines tangent reference.";

            BringMessageBoxToTop(displayMsg, "UserInput", MessageBoxButton.OK, MessageBoxImage.Information);
            alt_WindowTracker.BringApplicationToFront("CNEXT");
            inputObject = new object[1] { "Face" };
            SelectedElement selectedFace = adapter.SelectHybridshapeInCatia("Please select first point from surface", inputObject, ref firstSurfaceSelectedPoint);
            if (selectedFace != null)
            {
                Reference face = adapter.GetElemReferenceByName(adapter, selectedFace);
                object[] sightDirection = new object[3];
                Viewer3D viewer = adapter.GetCurrentViewer();
                if (viewer != null)
                    viewer.Viewpoint3D.GetSightDirection(sightDirection);

                object[] secondSurfaceSelectedPoint = new object[3];
                selectedFace = adapter.SelectHybridshapeInCatia("Please select second point from surface", inputObject, ref secondSurfaceSelectedPoint);
                if (face != null && firstSurfaceSelectedPoint != null && firstSurfaceSelectedPoint.Count() > 2
                    && secondSurfaceSelectedPoint != null && secondSurfaceSelectedPoint.Count() > 2
                    && sightDirection != null && sightDirection.Count() > 2)
                {
                    object[] edgeSelectedPoint = new object[3];
                    inputObject = new object[1] { "Edge" };
                    SelectedElement selectedEdge = adapter.SelectHybridshapeInCatia("Please select an edge as reference", inputObject, ref edgeSelectedPoint);
                    Reference edge = adapter.GetElemReferenceByName(adapter, selectedEdge);
                    if (edge != null)
                        intermediateWayPoint = new IntermediateWayPoint(face, edge, firstSurfaceSelectedPoint, secondSurfaceSelectedPoint, sightDirection);
                }
            }

            return intermediateWayPoint;
        }

        /// <summary>
        /// Handle product selection
        /// </summary>
        /// <param name="selectedElement"></param>
        /// <returns></returns>
        private Extremity HandleProduct(SelectedElement selectedElement, string extractFaF)
        {
            Extremity extremity = null;
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            Product product = (Product)selectedElement.Value;
            if (ehiAdapter.IsConnector(product))
            {
                bool hasDerivation = CheckDerivations(product.get_Name(), extractFaF);
                extremity = new ElbConnector(product, hasDerivation);
            }
            else if (ehiAdapter.IsSupport(product))
            {
                bool hasDerivation = CheckDerivations(product.get_Name(), extractFaF);
                extremity = new ElbSupport(product);
            }
            else if(ehiAdapter.IsFictivePointType(product))
            {
                extremity = new DerivationPoint(product);
            }
            else
            {
                product = null;
                MessageBox.Show("Selected Extremity is not a support, connector or an Fictive Point Type2, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            return extremity;
        }

        /// <summary>
        /// Handle edge selection
        /// </summary>
        /// <param name="selectedElement"></param>
        /// <returns></returns>
        private Extremity HandleEdge(SelectedElement selectedElement)
        {
            Extremity extremity = null;
            bool ehiSupport = false;
            MessageBoxResult messageBoxResult = MessageBoxResult.Yes;
            messageBoxResult = BringMessageBoxToTop("Do you want to insert an EHI Support? Else an Ehi point will be inserted", "UserInput", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (messageBoxResult == MessageBoxResult.Yes)
                ehiSupport = true;

            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            if(ehiAdapter.IsMultiBranchable(selectedElement.LeafProduct as Product))
            {
                alt_DerivationPointMgr derPointMgr = new alt_DerivationPointMgr(selectedElement, ehiSupport);
                if (!derPointMgr.CheckLinckedBranches())
                    MessageBox.Show("Can't found branches linked to selected derivation, Be sure you split branch and update multibranchable", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                else
                {
                    if (derPointMgr.ManageDerivationPoint() == true)
                        extremity = new DerivationPoint(derPointMgr.DervivationPoint,
                                                        derPointMgr.LinkedBranchCurve,
                                                        derPointMgr.DerPointProduct,
                                                        derPointMgr.TangentDirection);
                }
            }
            else
            {
                MessageBox.Show("Selected edge don't belong to multibranchable, please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            return extremity;
        }

        /// <summary>
        /// Handle point selection
        /// </summary>
        /// <param name="selectedElement"></param>
        /// <returns></returns>
        private Extremity HandlePoint(SelectedElement selectedElement)
        {
            Extremity extremity = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();

            Product parentProduct = selectedElement.LeafProduct as Product;
            if (ehiAdapter.IsFictivePointType(parentProduct))
            {
                extremity = new DerivationPoint(parentProduct);
            }
            else
            {
                object[] selectedPoint = new object[3];
                object[] surfaceSelectedPoint = new object[3];
                object[] inputObject = null;
                string displayMsg = "1.Select point from the surface to define tangent direction: \n" +
                    "2.Select the edge which defines tangent reference.";

                BringMessageBoxToTop(displayMsg, "UserInput", MessageBoxButton.OK, MessageBoxImage.Information);
                alt_WindowTracker.BringApplicationToFront("CNEXT");
                inputObject = new object[1] { "Face" };
                SelectedElement selectedFace = adapter.SelectHybridshapeInCatia("Please a point from surface", inputObject, ref surfaceSelectedPoint);
                if (selectedFace != null)
                {
                    object[] edgeSelectedPoint = new object[3];
                    inputObject = new object[1] { "Edge" };
                    SelectedElement selectedEdge = adapter.SelectHybridshapeInCatia("Please select an edge as reference", inputObject, ref edgeSelectedPoint);
                    Reference edge = adapter.GetElemReferenceByName(adapter, selectedEdge);
                    if (edge != null)
                        extremity = new DerivationPoint(selectedElement, edge, surfaceSelectedPoint);
                }
            }
            return extremity;
        }

        /// <summary>
        /// Handle projection selection
        /// </summary>
        /// <param name="selectedElement"></param>
        /// <returns></returns>
        private Extremity HandleProjection(SelectedElement selectedElement)
        {
            Extremity extremity = null;

            HybridShapeProject project = (HybridShapeProject)selectedElement.Value;
            Reference originValue = project.ElemToProject;
            extremity = new DerivationPoint(selectedElement);

            return extremity;
        }

        #endregion
    }
}
