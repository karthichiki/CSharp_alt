﻿using System.Collections.Generic;

namespace ALT_Data_Model
{
    /// <summary>
    /// Defines supported extremity element classifications used in harness modeling.
    /// </summary>
    public enum ExtremityType 
    { 
        /// <summary>No defined extremity type.</summary>
        None, 
        /// <summary>Electrical connector extremity.</summary>
        Connector, 
        /// <summary>Derivation / branch split extremity.</summary>
        Derivation, 
        /// <summary>Support / fixing element extremity.</summary>
        Support, 
        /// <summary>AMP (auxiliary) extremity type.</summary>
        Amp 
    }

    /// <summary>
    /// Abstract base class describing a generic harness extremity (connector, derivation, support, etc.).
    /// Derived classes supply concrete coordinate, tangent and classification data.
    /// </summary>
    public abstract class Extremity
    {
        #region Fields

        /// <summary>Internal cached name (may be unused by some derived types).</summary>
        private string _name = string.Empty;
        /// <summary>Internal cached DTR / part number string (may be unused by some derived types).</summary>
        private string _dtrName = string.Empty;
        /// <summary>Extremity classification backing field.</summary>
        protected ExtremityType _eExtermityType;

        #endregion

        #region Constructor
        /// <summary>
        /// Default constructor for base extremity. (Protected initialization executed in derived classes.)
        /// </summary>
        public Extremity()
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Display name of the extremity (usually CATIA product name or composed identifier).
        /// </summary>
        public abstract string Name
        {
            get;
        }

        /// <summary>
        /// DTR / part number or external reference identifier for the extremity.
        /// </summary>
        public abstract string DtrName
        {
            get;
        }

        /// <summary>
        /// Sleeve offset value (units defined by implementing class, typically meters) relative to extremity reference.
        /// </summary>
        public abstract double SleeveOffset
        { 
            get; 
        }

        /// <summary>
        /// Tangent direction vector components (normalized if supplied) associated with extremity (optional override).
        /// </summary>
        public virtual List<double> TangentDirection
        {
            get;
        }

        /// <summary>
        /// Strongly-typed classification for the extremity.
        /// </summary>
        public abstract ExtremityType ExtremityType
        {
            get;
        }

        /// <summary>
        /// Spatial coordinates of the extremity reference point (X,Y,Z) (optional override).
        /// </summary>
        public virtual List<double> Coordinates
        {
            get;
        }

        /// <summary>
        /// Tangency distance placeholder value (constant 10.5) – adjust when implementing tangency logic.
        /// </summary>
        public double TangencyDistance
        {
            get
            {
                return 10.5;
            }
        }

        /// <summary>
        /// Example list of string properties (currently returns duplicate placeholder entries).
        /// </summary>
        public List<string> Properties
        {
            get
            {
                List<string> properties = new List<string>();
                properties.Add("propertie1");
                properties.Add("propertie1");
                return properties;
            }
        }

        /// <summary>
        /// Indicates whether the extremity has a derivation (branch continuation). Default implementation unspecified.
        /// </summary>
        public virtual bool HasDerivation
        {
            get;
        }

        /// <summary>
        /// Gets or sets whether the extremity orientation / direction is inverted.
        /// </summary>
        public bool IsInverted { set; get; }

        #endregion

        #region Public Methods      


        #endregion

        #region Protected Methods
        #endregion
    }
}
