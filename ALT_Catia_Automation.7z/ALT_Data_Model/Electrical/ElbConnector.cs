﻿using ALT_Logging;
using CatiaDotNet.CommonServices;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace ALT_Data_Model.Electrical
{
    /// <summary>
    /// Represents a connector extremity (electrical / cavity component) with its connection point
    /// and oriented tangent direction resolved from CATIA publications.
    /// </summary>
    public class ElbConnector: Extremity
    {
        #region Fields
        readonly private Product _product = null;
        private Reference _referenceFace = null;
        private Reference _referencePoint = null;
        readonly private List<double> _conectionPoint = null;
        readonly private List<double> _tangentDirection = null;
        readonly private bool _hasDerivation = false;
        private double _sleevOffset = 0;
        #endregion

        #region Constructor
        /// <summary>
        /// Creates a connector extremity for a given CATIA product and indicates whether
        /// the connector has a derivation (branch continuation) downstream.
        /// Automatically extracts publications and populates coordinates and tangent direction.
        /// </summary>
        /// <param name="product">Underlying CATIA product representing the connector.</param>
        /// <param name="hasDerivation">True if this connector leads to a derivation node.</param>
        public ElbConnector(Product product, bool hasDerivation)
        {
            _product = product;
            _eExtermityType = ExtremityType.Connector;
            _conectionPoint = new List<double>();
            _tangentDirection = new List<double>();
            _hasDerivation = hasDerivation;
            RetrieveProperties();
        }
        #endregion

        #region Properties

        /// <summary>
        /// Gets the CATIA display name of the connector product, or empty if undefined.
        /// </summary>
        public override string Name
        {
            get
            {
                if (_product == null)
                    return string.Empty;
                else
                    return _product.get_Name();
            }
        }

        /// <summary>
        /// Gets a DTR-friendly identifier (PartNumber) for the connector.
        /// </summary>
        public override string DtrName
        {
            get
            {
                if (_product == null)
                    return string.Empty;
                else
                    return _product.get_PartNumber();
            }
        }

        /// <summary>
        /// Gets the connection point global coordinates (X,Y,Z) extracted from publication (BCP point).
        /// </summary>
        public override List<double> Coordinates
        {
            get { return _conectionPoint; }
        }

        /// <summary>
        /// Gets the (inverted) tangent direction vector pointing inside the connector for downstream usage.
        /// </summary>
        public override List<double> TangentDirection
        {
            get { return _tangentDirection; }
        }

        /// <summary>
        /// Gets the extremity type (Connector).
        /// </summary>
        public override ExtremityType ExtremityType
        {
            get
            {
                return ExtremityType.Connector;
            }
        }

        /// <summary>
        /// Indicates if this connector directly precedes a derivation node.
        /// </summary>
        public override bool HasDerivation
        {
            get
            {
                return _hasDerivation;
            }
        }

        /// <summary>
        /// Gets the sleeve offset (reserved future use, currently always zero).
        /// </summary>
        public override double SleeveOffset
        {
            get
            {
                return _sleevOffset;
            }

        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Returns the CATIA reference for the published connection point (BCP) if available.
        /// </summary>
        public Reference GetReference()
        {
            return _referencePoint;
        }

        /// <summary>
        /// Returns the CATIA reference for the published face used to derive tangent direction, if any.
        /// </summary>
        public Reference GetReferenceFace()
        {
            return _referenceFace;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Extracts connector publications (point and face), computes connection point coordinates and tangent direction.
        /// Aligns tangent with cavity / connector face if such a publication exists and stores the inverted vector.
        /// </summary>
        private void RetrieveProperties()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            try
            {
                Publication conPublication = ExtractReferencePointPublication();
                if (conPublication == null)
                {
                    var log = $"------ BCP generated publication not found... ";
                    alt_Logging_class.AddMessage(log);
                }
                else
                {
                    var log = $"------ Publication with name : {conPublication.get_Name()} is found... ";
                    alt_Logging_class.AddMessage(log);

                    _referencePoint = (Reference)conPublication.Valuation;
                    Vector3d connectionPoint = adapter.GetPointFromReference(_referencePoint);

                    connectionPoint = adapter.Round(connectionPoint, 3);
                    _conectionPoint.Add(connectionPoint.X);
                    _conectionPoint.Add(connectionPoint.Y);
                    _conectionPoint.Add(connectionPoint.Z);

                    Publication facePublication = ExtractReferenceFacePublication();
                    if (facePublication == null)
                    {
                        log = $"------ Face generated publication not found... ";
                        alt_Logging_class.AddMessage(log);
                    }
                    else
                    {
                        log = $"------ Publication with name : {facePublication.get_Name()} is found... ";
                        alt_Logging_class.AddMessage(log);

                        _referenceFace = (Reference)facePublication.Valuation;
                        Vector3d tangent = adapter.GetPlaneDirectionFromReference(_referenceFace);
                        tangent = adapter.Round(tangent, 3);

                        Publication genFaceCavityOrConnector = ExtractConnectorOrCavityFacePublication();
                        if (genFaceCavityOrConnector != null)
                        {
                            log = $"------ publication with name : {genFaceCavityOrConnector.get_Name()} is found... ";
                            alt_Logging_class.AddMessage(log);
                            Vector4d planeEquation = adapter.GetPlaneEquationFromReference(genFaceCavityOrConnector.Valuation as Reference);
                            Vector3d projectedPoint = adapter.ProjectPointOnPlane(connectionPoint, planeEquation);
                            Vector3d projectionDirection = projectedPoint - connectionPoint;
                            if (Vector3d.Dot(projectionDirection, tangent) < 0)
                                tangent = -tangent;
                        }
                        else
                        {
                            log = $"------ Cavity or connector publication is not found, tangent can be in wrong direction... ";
                            alt_Logging_class.AddMessage(log);
                        }

                        //Invert tangent direction: Unity need, they want tangent to be inside connector.
                        _tangentDirection.Add(-tangent.X);
                        _tangentDirection.Add(-tangent.Y);
                        _tangentDirection.Add(-tangent.Z);
                    }

                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Searches the product publications for a connection point (BCP) reference publication.
        /// </summary>
        /// <returns>Publication containing BCP point reference; otherwise null.</returns>
        private Publication ExtractReferencePointPublication()
        {
            try
            {
                Publications publications = _product.Publications;
                if (publications == null)
                    return null;

                for (int nCount = 1; nCount <= _product.Publications.Count; nCount++)
                {
                    object iIdentifier = nCount;
                    Publication publication = publications.Item(ref iIdentifier);
                    if (publication.Valuation is Reference item &&
                        item.DisplayName.ToUpper().Contains("BCP"))
                        return publication;
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ElbConnector::GetReferencePoint" + ex.Message);
                return null;
            }
        }

        /// <summary>
        /// Searches for a face publication whose plane contains the connection point (FACE_GENERATED).
        /// Used to derive tangent orientation.
        /// </summary>
        /// <returns>Matching face publication or null if none fits criteria.</returns>
        private Publication ExtractReferenceFacePublication()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            try
            {
                Publications publications = _product.Publications;
                if (publications == null)
                    return null;

                for (int nCount = 1; nCount <= _product.Publications.Count; nCount++)
                {
                    object iIdentifier = nCount;
                    Publication publication = publications.Item(ref iIdentifier);
                    if (publication.Valuation is Reference item &&
                        publication.get_Name().ToUpper().Contains("FACE_GENERATED"))
                    {
                        Reference referenceFace = publication.Valuation as Reference;
                        Vector4d planeEquation = adapter.GetPlaneEquationFromReference(referenceFace);
                        if (adapter.IsPointBelongToPlane(planeEquation, new Vector3d(_conectionPoint[0],
                            _conectionPoint[1], _conectionPoint[2])))
                            return publication;
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ElbConnector::GetReferencePoint" + ex.Message);
                return null;
            }
        }

        /// <summary>
        /// Finds a publication representing the connector/cavity face (FACE_GENERATED + CAVITY/CONNECTOR) to
        /// validate tangent direction orientation relative to plane normal.
        /// </summary>
        /// <returns>Publication if found; otherwise null.</returns>
        private Publication ExtractConnectorOrCavityFacePublication()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            try
            {
                Publications publications = _product.Publications;
                if (publications == null)
                    return null;

                for (int nCount = 1; nCount <= _product.Publications.Count; nCount++)
                {
                    object iIdentifier = nCount;
                    Publication publication = publications.Item(ref iIdentifier);
                    if (publication.Valuation is Reference item &&
                        publication.get_Name().ToUpper().Contains("FACE_GENERATED"))
                    {
                        if (publication.get_Name().ToUpper().Contains("CAVITY") ||
                            publication.get_Name().ToUpper().Contains("CONNECTOR"))

                            return publication;
                    }
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine("ElbConnector::ExtractGeneratedFaceFacePublication" + ex.Message);
                return null;
            }
        }

        #endregion
    }
}
