﻿using CatiaDotNet.CommonServices;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace ALT_Data_Model.Electrical
{
    /// <summary>
    /// Defines the origin/type of an intermediate waypoint used for support insertion or referencing EHI support geometry.
    /// </summary>
    public enum IntermediateWayPointType { None, EhiSupport, Surface }

    /// <summary>
    /// Represents an intermediate waypoint containing position, tangent and normal directions.
    /// Waypoint may be derived from user surface selections (Surface) or an existing EHI support (EhiSupport).
    /// </summary>
    public class IntermediateWayPoint
    {
        #region Fields

        private string _name = string.Empty;
        private Reference _face = null;
        private Reference _edge = null;
        private Product _product = null;
        private Vector3d _firstSelectedPoint = Vector3d.Zero;
        private Vector3d _secondSelectedPoint = Vector3d.Zero;
        private Vector3d _sightDirection = Vector3d.Zero;
        private IntermediateWayPointType _eIntermediateWayPointType;

        private static int _countIndex = 0;


        #endregion

        #region Properties

        /// <summary>
        /// Gets the generated waypoint name (e.g. ForcePoint_n).
        /// </summary>
        public string Name
        {
            get { return _name; }
        }

        /// <summary>
        /// Gets the tangent vector components (X,Y,Z) normalized to 3 decimals.
        /// </summary>
        public List<double> TangentDirection
        {
            get;
        }

        /// <summary>
        /// Gets the normal vector components (X,Y,Z) to the selected face (Surface origin only).
        /// Empty for EhiSupport origin.
        /// </summary>
        public List<double> NormalDirection
        {
            get;
        }

        /// <summary>
        /// Gets the waypoint coordinates (X,Y,Z) in model space (rounded to 3 decimals).
        /// </summary>
        public virtual List<double> Coordinates
        {
            get;
        }

        /// <summary>
        /// Placeholder tangency distance (constant 10.5) reserved for future logic.
        /// </summary>
        public double TangencyDistance
        {
            get
            {
                return 10.5;
            }
        }

        /// <summary>
        /// Placeholder string property collection (returns two duplicate sample entries).
        /// </summary>
        public List<string> Properties
        {
            get
            {
                List<string> properties = new List<string>();
                properties.Add("propertie1");
                properties.Add("propertie1");
                return properties;
            }
        }

        /// <summary>
        /// Gets the CATIA product if the waypoint originated from an existing support; null for surface-based waypoints.
        /// </summary>
        public Product SupportProduct
        {
            get { return _product; }
        }

        /// <summary>
        /// Gets the waypoint origin type (Surface or EhiSupport).
        /// </summary>
        public IntermediateWayPointType IntermediateWayPointType
        {
            get { return _eIntermediateWayPointType; }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Builds a surface-based waypoint from two user-selected points on a planar face and a reference edge.
        /// The first point defines position; the vector to the second defines tangent orientation.
        /// The face normal (adjusted to viewing direction) defines the normal.
        /// </summary>
        /// <param name="face">Selected planar face reference.</param>
        /// <param name="edge">Selected edge reference used to compute tangent direction.</param>
        /// <param name="firstSelectedPoint">First point coordinates array (length 3).</param>
        /// <param name="secondSelectedPoint">Second point coordinates array (length 3).</param>
        /// <param name="sightDirection">Viewer sight direction array (length 3) to disambiguate normal orientation.</param>
        public IntermediateWayPoint(Reference face, Reference edge, object[] firstSelectedPoint, object[] secondSelectedPoint, object[] sightDirection) 
        {

            Coordinates = new List<double>();
            TangentDirection = new List<double>();
            NormalDirection = new List<double>();

            _face = face;
            _edge = edge;

            _firstSelectedPoint.X = (double)firstSelectedPoint[0];
            _firstSelectedPoint.Y = (double)firstSelectedPoint[1];
            _firstSelectedPoint.Z = (double)firstSelectedPoint[2];

            _secondSelectedPoint.X = (double)secondSelectedPoint[0];
            _secondSelectedPoint.Y = (double)secondSelectedPoint[1];
            _secondSelectedPoint.Z = (double)secondSelectedPoint[2];

            _sightDirection.X = (double)sightDirection[0];
            _sightDirection.Y = (double)sightDirection[1];
            _sightDirection.Z = (double)sightDirection[2];

            _countIndex++;
            _name = "ForcePoint_" + _countIndex.ToString();
            _eIntermediateWayPointType = IntermediateWayPointType.Surface;

            RetrieveProperties();
        }

        /// <summary>
        /// Builds a waypoint from an existing EHI support product (copies its position & tangent, no normal vector).
        /// </summary>
        /// <param name="product">EHI support CATIA product.</param>
        public IntermediateWayPoint(Product product)
        {
            _product = product;
            Coordinates = new List<double>();
            TangentDirection = new List<double>();
            _countIndex++;
            _name = "ForcePoint_" + _countIndex.ToString();
            _eIntermediateWayPointType = IntermediateWayPointType.EhiSupport;

            RetrieveProperties();
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Offsets the waypoint position along its normal vector by half the specified diameter (used to position supports).
        /// No effect if NormalDirection list is empty (EhiSupport origin).
        /// </summary>
        /// <param name="diameter">Outer diameter used to compute offset (same units as coordinates).</param>
        public void ChangePosition(double diameter)
        {
            Vector3d normalVect = new Vector3d(NormalDirection[0], NormalDirection[1], NormalDirection[2]);
            Vector3d offset = normalVect * (diameter/2);
            Vector3d position = new Vector3d(Coordinates[0], Coordinates[1], Coordinates[2]); 
            Vector3d newPosition = position + offset;

            Coordinates[0] = newPosition.X;
            Coordinates[1] = newPosition.Y;
            Coordinates[2] = newPosition.Z;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Populates Coordinates, TangentDirection and NormalDirection depending on origin (support or surface selection).
        /// For surface selection, tangent is derived from edge vs point direction and normal from face orientation.
        /// </summary>
        private void RetrieveProperties()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            try
            {
                if (_product != null)
                {
                    ElbSupport elbSupport = new ElbSupport(_product);

                    Coordinates.Add(elbSupport.Coordinates[0]);
                    Coordinates.Add(elbSupport.Coordinates[1]);
                    Coordinates.Add(elbSupport.Coordinates[2]);

                    TangentDirection.Add(elbSupport.TangentDirection[0]);
                    TangentDirection.Add(elbSupport.TangentDirection[1]);
                    TangentDirection.Add(elbSupport.TangentDirection[2]);
                }
                else
                {
                    Coordinates.Add(Math.Round(_firstSelectedPoint.X, 3));
                    Coordinates.Add(Math.Round(_firstSelectedPoint.Y, 3));
                    Coordinates.Add(Math.Round(_firstSelectedPoint.Z, 3));

                    Vector3d refDirection = _secondSelectedPoint - _firstSelectedPoint;
                    Vector3d direction = adapter.GetDirectionFromReference(_edge);

                    direction.Normalize();
                    refDirection.Normalize();
                    if (Vector3d.Dot(direction, refDirection) < 0)
                        direction = -direction;

                    TangentDirection.Add(Math.Round(direction.Normalized().X, 3));
                    TangentDirection.Add(Math.Round(direction.Normalized().Y, 3));
                    TangentDirection.Add(Math.Round(direction.Normalized().Z, 3));

                    Vector3d normalVect = adapter.GetPlaneDirectionFromReference(_face);
                    if (Vector3d.Dot(_sightDirection, normalVect) > 0)
                        normalVect = -normalVect;

                    NormalDirection.Add(Math.Round(normalVect.Normalized().X, 3));
                    NormalDirection.Add(Math.Round(normalVect.Normalized().Y, 3));
                    NormalDirection.Add(Math.Round(normalVect.Normalized().Z, 3));
                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        #endregion
    }
}
