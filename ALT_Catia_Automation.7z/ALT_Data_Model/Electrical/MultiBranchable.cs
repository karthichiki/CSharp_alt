﻿using ProductStructureTypeLib;
using System.Collections.Generic;

namespace ALT_Data_Model
{
    /// <summary>
    /// Represents a multi-branchable electrical harness element aggregating its CATIA product reference,
    /// extremity endpoints, intermediate routing points and geometric attributes (diameter, bend radius, cable class).
    /// </summary>
    public class MultiBranchable
    {
        /// <summary>
        /// Underlying CATIA product representing the multibranchable harness.
        /// </summary>
        public Product CatiaProduct { get; set; }
        /// <summary>
        /// First end extremity (e.g., connector / support / derivation) of the harness segment.
        /// </summary>
        public Extremity FirstExtrimity { get; set; }
        /// <summary>
        /// Second end extremity of the harness segment.
        /// </summary>
        public Extremity SecondExtrimity { get; set; }
        /// <summary>
        /// Ordered collection of intermediate extremities / waypoints between the two main ends.
        /// </summary>
        public List<Extremity> MiddlePoints { get; set; }
        /// <summary>
        /// Nominal outer diameter of the harness (units consistent with CATIA model, typically mm).
        /// </summary>
        public double Diameter { get; set; }
        /// <summary>
        /// Minimum bend radius applied to the harness routing (same units as diameter).
        /// </summary>
        public double BendRadius { get; set; }
        /// <summary>
        /// Cable class / classification attribute (numeric code conveyed as double for compatibility).
        /// </summary>
        public double CableClass { get; set; }
        //public string Zone { get; set; }
        /// <summary>
        /// Private constructor enforces controlled instantiation (e.g., via factory not yet implemented).
        /// </summary>
        private MultiBranchable()
        {
            
        }
    }
}
