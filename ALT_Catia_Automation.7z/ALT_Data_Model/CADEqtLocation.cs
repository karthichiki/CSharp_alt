﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace ALT_Data_Model
{
    /// <summary>
    /// CAD Equipment Location class to store information about a location in a CAD model, including its name and associated connectors.
    /// </summary>
    public class CADEqtLocation
    {
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("connectors")]
        public List<CADConnector> Connectors { get; set; }

        public CADEqtLocation()
        {
            Connectors = new List<CADConnector>();
        }
    }
}
