﻿/// <summary>
/// Utility class for .
/// </summary>
/// <remarks>
/// This class is used to .
/// </remarks>
/// 

using ALT_Data_Model;
using ALT_Data_Model.Accessories_Data_Model;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Logging;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing;
using DocumentFormat.OpenXml.Spreadsheet;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace ALT_Data_Model
{
    /// <summary>
    /// Utility class for reading Excel files.
    /// </summary>
    public class alt_ExcelReaderService
    {
        private static alt_ExcelReaderService _xlService;

        /// <summary>
        /// XXX.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        public static alt_ExcelReaderService GetInstance()
        {
            if (_xlService == null)
                _xlService = new alt_ExcelReaderService();

            return _xlService;
        }

        /// <summary>
        /// Check if file exists.
        /// </summary>
        /// <param name="excelFilePath"> file name</param>
        /// <returns> status if file exists</returns>
        public bool FileExist(string excelFilePath)
        {
            try
            {
                if (File.Exists(excelFilePath) == true)
                    return true;
            }
            catch
            {
                return false;
            }

            return false;
        }

        /// <summary>
        /// This method Reads Synoptic Excel file
        /// </summary>
        /// <param name="excelFilePath"> synoptic file name</param>
        /// <returns> dictionary of harnesses with their associated synoptic connectors. </returns>
        public Dictionary<string, List<SynopticConnector>> ReadSynopticFile(string excelFilePath)
        {
            try
            {
                bool foundRepetition = false;
                var harnesses = new Dictionary<string, List<SynopticConnector>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        foundRepetition = false;
                        if (harnesses.ContainsKey(row.Cell(13).GetString()))
                        {
                            foreach(var syn in harnesses[row.Cell(13).GetString()])
                            {
                                if(syn.ConnectorName == row.Cell(7).GetString() && syn.DeviceAcronym == row.Cell(6).GetString())
                                {
                                    foundRepetition = true;
                                    break;
                                }
                            }
                        }
                        if(foundRepetition) continue;
                        SynopticConnector synopticData = new SynopticConnector(row.Cell(1).GetString(), row.Cell(2).GetString(),
                        row.Cell(3).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(),
                        row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString(),
                        row.Cell(11).GetString(), row.Cell(12).GetString(), row.Cell(14).GetString(), row.Cell(15).GetString(),
                        row.Cell(16).GetString(), row.Cell(17).GetString(), row.Cell(18).GetString(), row.Cell(19).GetString(),
                        row.Cell(20).GetString());

                        var harnessName = row.Cell(13).GetString();
                        if (!harnesses.ContainsKey(harnessName))
                            harnesses[harnessName] = new List<SynopticConnector>();
                        harnesses[harnessName].Add(synopticData);

                    }
                }
                return harnesses;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Validates selected Excel file is a Synoptic File or not.
        /// </summary>
        /// <param name="excelFilePath"> synoptic file path </param>
        /// <returns> status if valid or no</returns>
        public bool Validate_Synoptic_File(string excelFilePath)
        {
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    IXLWorksheet worksheet = workbook.Worksheet(1);
                    IXLRow xLRow = worksheet.Row(1);

                    if (xLRow.Cell(1).GetString().ToUpper().Trim() == "GID" && xLRow.Cell(6).GetString().ToUpper().Trim() == "Device Acronym".ToUpper() &&
                        xLRow.Cell(7).GetString().ToUpper().Trim() == "Connector Name".ToUpper() && xLRow.Cell(11).GetString().ToUpper().Trim() == "Part Number".ToUpper() &&
                        xLRow.Cell(13).GetString().ToUpper().Trim() == "Harness".ToUpper() && xLRow.Cell(15).GetString().ToUpper().Trim() == "IPOH Y/N".ToUpper() &&
                        xLRow.Cell(16).GetString().ToUpper().Trim() == "CM Y/N".ToUpper() && xLRow.Cell(18).GetString().ToUpper().Trim() == "Car Name".ToUpper())
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return false;
            }
        }

        /// <summary>
        /// This method Reads Extract_FaF Excel file
        /// </summary>
        /// <param name="excelFilePath"> Extract_FaF excel file path</param>
        /// <returns> Dictionary with FAF_Extract objects </returns>
        public Dictionary<string, List<FAF_Extract>> ExtractFAF(string excelFilePath)
        {
            try
            {
                var harnesses = new Dictionary<string, List<FAF_Extract>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        FAF_Extract fAF_Extract = new FAF_Extract(row.Cell(1).GetString(), row.Cell(2).GetString(),
                            row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString(),
                            row.Cell(8).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString(),
                            row.Cell(11).GetString(), row.Cell(12).GetString());

                        var harnessName = row.Cell(3).GetString();
                        if (!harnesses.ContainsKey(harnessName))
                            harnesses[harnessName] = new List<FAF_Extract>();
                        harnesses[harnessName].Add(fAF_Extract);
                    }
                }
                return harnesses;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads PPL_Electrical Excel file
        /// </summary>
        /// <param name="excelFilePath"> PPL_Electrical excel file path</param>
        /// <returns> Dictionary with PPL_Electrical objects </returns>
        public Dictionary<string, List<PPL_Electrical>> PPL_Electrical(string excelFilePath)
        {
            try
            {
                var electricals = new Dictionary<string, List<PPL_Electrical>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("CONDUIT - SHEATH ");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        PPL_Electrical ppl_Electrical = new PPL_Electrical(row.Cell(1).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString(), row.Cell(12).GetString(), row.Cell(5).GetString(), row.Cell(11).GetString());

                        var supplier = row.Cell(21).GetString();
                        if (!electricals.ContainsKey(supplier))
                            electricals[supplier] = new List<PPL_Electrical>();
                        electricals[supplier].Add(ppl_Electrical);
                    }
                }
                return electricals;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads PPL_Cables Excel file
        /// </summary>
        /// <param name="excelFilePath"> PPL_Cables excel file path</param>
        /// <returns> Dictionary with PPL_Cables objects </returns>
        public Dictionary<string, List<PPL_Cables>> PPL_EN_Cables(string excelFilePath)
        {
            try
            {
                var cables = new Dictionary<string, List<PPL_Cables>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheetName = "Standard EN cables";
                    var worksheet = workbook.Worksheet(sheetName);
                    ExtractCables(cables, worksheet, 13, 14, sheetName);
                }
                return cables;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Extracts Cables from the given worksheet and adds them to the provided dictionary.
        /// </summary>
        /// <param name="cables"></param>
        /// <param name="worksheet"></param>
        /// <param name="cellnum1"></param>
        /// <param name="cellnum2"></param>
        /// <param name="sheetName"></param>
        private static void ExtractCables(Dictionary<string, List<PPL_Cables>> cables, IXLWorksheet worksheet, int cellnum1, int cellnum2, string sheetName)
        {
            string diameterHeader = "Maximal outer diameter (sheath)";
            int cellnum3 = -1;
            bool diaHeader = true;

            foreach (var row in worksheet.RowsUsed().Skip(1))
            {
                string contentType = row.Cell(1).GetString();
                string header = "";
                string cell3 = "";
                if (sheetName == "Standard EN cables")
                {
                    string pattern = @"EN\d+-\d+(-\d+)?";
                    Match match = Regex.Match(row.Cell(1).GetString(), pattern);
                    if (match.Success)
                    {
                        header = match.Value;
                    }
                }
                if (sheetName == "Standard NAM cables")
                {
                    if (contentType.ToLower().Contains("Control cable".ToLower()) && contentType.ToLower().Contains("Single core".ToLower()))
                    {
                        header = row.Cell(12).GetString().Trim() + "V Control (mono)";
                    }
                    else if (contentType.ToLower().Contains("Control cable".ToLower()) && contentType.ToLower().Contains("Multi core screened".ToLower()))
                    {
                        header = row.Cell(12).GetString().Trim() + "V Control (multi)";
                    }
                    else if (contentType.ToLower().Contains("Power cable".ToLower()) && contentType.ToLower().Contains("Single core".ToLower()))
                    {
                        header = row.Cell(12).GetString().Trim() + "V Power (mono)";
                    }
                    else if (contentType.ToLower().Contains("Power cable".ToLower()) && contentType.ToLower().Contains("High temperature".ToLower()))
                    {
                        header = row.Cell(12).GetString().Trim() + "V HT (mono)";
                    }
                }
                if (sheetName == "Specific cables (DTREN)")
                {
                    cellnum3 = 14;
                }
                if (header != "") cellnum3 = GetCell3Num(worksheet, header, diameterHeader);
                if (contentType.ToLower() == "Component type".ToLower()) cell3 = "OuterDiameter..";
                else if (cellnum3 != -1)
                {
                    cell3 = row.Cell(cellnum3).GetString();
                    if (diaHeader)
                    {
                        string cell3Header = worksheet.Cell(2, cellnum3).GetString().Trim();
                        try
                        {
                            foreach (var ppl in cables)
                            {
                                foreach (var cable in ppl.Value)
                                {
                                    if (cable.Diameter == "OuterDiameter..") cable.Diameter = cell3Header;
                                }
                            }

                            //if (pPL_Cables != null) pPL_Cables.Diameter = cell3Header;
                        }
                        catch (Exception)
                        {

                            throw;
                        }

                        diaHeader = false;
                    }
                }
                PPL_Cables ppl_Cables = new PPL_Cables(row.Cell(cellnum1).GetString(), row.Cell(cellnum2).GetString(), cell3);

                string DTRName = row.Cell(2).GetString();
                if (!cables.ContainsKey(DTRName))
                    cables[DTRName] = new List<PPL_Cables>();
                cables[DTRName].Add(ppl_Cables);
            }
        }

        /// <summary>
        /// This method finds the column number of a specific header in the worksheet.
        /// </summary>
        /// <param name="worksheet"></param>
        /// <param name="header"></param>
        /// <param name="diameterHeader"></param>
        /// <returns> column number of a specific header in the worksheet </returns>
        private static int GetCell3Num(IXLWorksheet worksheet, string header, string diameterHeader)
        {
            int cellNumber = -1;
            foreach (var cell in worksheet.CellsUsed())
            {
                if (StringComparer.InvariantCultureIgnoreCase.Equals(
                        cell.GetString().Replace(" ", ""),
                        header.Replace(" ", "")))
                {
                    if (cell.IsMerged())
                    {
                        foreach (var celladdress in cell.MergedRange().Cells())
                        {
                            string column = celladdress.Address.ColumnLetter;
                            int rowNumber = celladdress.Address.RowNumber;
                            rowNumber++;
                            string newCellAddress = column + rowNumber;
                            if (worksheet.Cell(newCellAddress).GetString().ToLower().Contains(diameterHeader.ToLower()))
                            {
                                return celladdress.Address.ColumnNumber;
                            }
                        }
                        foreach (var celladdress in cell.MergedRange().Cells())
                        {
                            string column = celladdress.Address.ColumnLetter;
                            int rowNumber = celladdress.Address.RowNumber;
                            rowNumber++;
                            string newCellAddress = column + rowNumber;
                            if (worksheet.Cell(newCellAddress).GetString().ToLower().Contains("Maximal core diameter".ToLower()))
                            {
                                return celladdress.Address.ColumnNumber;
                            }
                        }
                    }
                    else
                    {
                        return cell.Address.ColumnNumber;
                    }
                    break;
                }
            }

            return cellNumber;
        }

        /// <summary>
        /// Remove alphabets from the cell address to get the numeric part and Convert the numeric part to an integer and return it
        /// </summary>
        /// <param name="cellAddress"></param>
        /// <returns></returns>
        static int ExtractRowNumber(string cellAddress)
        {
            string numericPart = new string(cellAddress.Where(char.IsDigit).ToArray());

            return int.Parse(numericPart);
        }

        /// <summary>
        /// Keep only alphabetic characters (column letters)
        /// </summary>
        /// <param name="cellAddress"></param>
        /// <returns></returns>
        static string ExtractColumnLetters(string cellAddress)
        {
            return new string(cellAddress.Where(char.IsLetter).ToArray());
        }

        /// <summary>
        /// This method Reads PPL_NAM_Cables Excel file
        /// </summary>
        /// <param name="excelFilePath"> PPL_Cables excel file path</param>
        /// <returns> Dictionary with PPL_Cables objects </returns>
        public Dictionary<string, List<PPL_Cables>> PPL_NAM_Cables(string excelFilePath)
        {
            try
            {
                var cables = new Dictionary<string, List<PPL_Cables>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheetName = "Standard NAM cables";
                    var worksheet = workbook.Worksheet(sheetName);
                    ExtractCables(cables, worksheet, 13, 14, sheetName);
                }
                return cables;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads PPL_Specific_Cables Excel file
        /// </summary>
        /// <param name="excelFilePath"> PPL_Cables excel file path</param>
        /// <returns> Dictionary with PPL_Cables objects </returns>
        public Dictionary<string, List<PPL_Cables>> PPL_Specific_Cables(string excelFilePath)
        {
            try
            {
                var cables = new Dictionary<string, List<PPL_Cables>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheetName = "Specific cables (DTREN)";
                    var worksheet = workbook.Worksheet(sheetName);
                    ExtractCables(cables, worksheet, 16, 17, sheetName);
                }
                return cables;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }


        /// <summary>
        /// This method Validates selected Excel file is a Extract_FaF or not
        /// </summary>
        /// <param name="excelFilePath"></param>
        /// <returns></returns>
        public bool Validate_Extract_faf_File(string excelFilePath)
        {
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    IXLWorksheet worksheet = workbook.Worksheet(1);
                    IXLRow xLRow = worksheet.Row(1);

                    if (xLRow.Cell(1).GetString().ToUpper().Trim() == "GID" && xLRow.Cell(2).GetString().ToUpper().Trim() == "Cable ID".ToUpper() &&
                        xLRow.Cell(3).GetString().ToUpper().Trim() == "Harness".ToUpper() && xLRow.Cell(4).GetString().ToUpper().Trim() == "Class".ToUpper() &&
                        xLRow.Cell(5).GetString().ToUpper().Trim() == "Part Number".ToUpper() && xLRow.Cell(6).GetString().ToUpper().Trim() == "Cable Designation".ToUpper() &&
                        xLRow.Cell(7).GetString().ToUpper().Trim() == "From Device".ToUpper() && xLRow.Cell(8).GetString().ToUpper().Trim() == "From Car".ToUpper())
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return false;
            }
        }
        /// <summary>
        /// This method Validates selected Excel file is a PPL_Cables_File or not
        /// </summary>
        /// <param name="excelFilePath"></param>
        /// <returns></returns>
        public bool Validate_PPL_Cables_File(string excelFilePath)
        {
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheet1Name = "Standard EN cables";
                    string sheet2Name = "Standard NAM cables";
                    string sheet3Name = "Specific cables (DTREN)";

                    bool sheet1Exists = false, sheet2Exists = false, sheet3Exists = false;
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (string.Equals(worksheet.Name.Trim(), sheet1Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet1Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet2Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet2Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet3Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet3Exists = true;
                        }
                    }
                    return sheet1Exists && sheet2Exists && sheet3Exists ? true : false;
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return false;

            }
        }

        /// <summary>
        /// This method Validates selected Excel file is a PPL_Electrical_File or not
        /// </summary>
        /// <param name="excelFilePath"></param>
        /// <returns></returns>
        public bool Validate_PPL_Electrical_File(string excelFilePath)
        {
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheetName = "CONDUIT - SHEATH";

                    bool sheetExists = false;
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (string.Equals(worksheet.Name.Trim(), sheetName, StringComparison.OrdinalIgnoreCase))
                        {
                            sheetExists = true;
                            break;
                        }
                    }
                    return sheetExists ? true : false;
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return false;

            }
        }

        /// <summary>
        /// This method Validates selected Excel file is a 3PL_File or not
        /// </summary>
        /// <param name="excelFilePath"></param>
        /// <returns> status if 3PL_File or no </returns>
        public bool Validate_3PL_File(string excelFilePath)
        {
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheet1Name = "CORRUGATED SLEEVE";
                    string sheet2Name = "WRAP AROUND SLEEVE";
                    string sheet3Name = "WRAP AROUND GRIP SLEEVE";
                    string sheet4Name = "EMC SLEEVE";
                    string sheet5Name = "DIVISIBLE SLEEVE";
                    string sheet6Name = "EXPANDABLE SLEEVE";
                    string sheet7Name = "TAPES & LABELS";

                    bool sheet1Exists = false, sheet2Exists = false, sheet3Exists = false, sheet4Exists = false, sheet5Exists = false, sheet6Exists = false, sheet7Exists = false;
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (string.Equals(worksheet.Name.Trim(), sheet1Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet1Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet2Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet2Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet3Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet3Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet4Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet4Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet5Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet5Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet6Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet6Exists = true;
                        }
                        if (string.Equals(worksheet.Name.Trim(), sheet7Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet7Exists = true;
                        }
                    }
                    return sheet1Exists && sheet2Exists && sheet3Exists && sheet4Exists && sheet5Exists && sheet6Exists ? true : false;
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return false;

            }
        }


        /// <summary>
        /// This method Reads CorrugatedSleeve Excel file
        /// </summary>
        /// <param name="excelFilePath"> CorrugatedSleeve excel file path</param>
        /// <returns> Dictionary with CorrugatedSleeve objects </returns
        public Dictionary<string, List<CorrugatedSleeve>> CorrugatedSleeve(string excelFilePath)
        {
            try
            {
                var corrugated = new Dictionary<string, List<CorrugatedSleeve>>();
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("CORRUGATED SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        CorrugatedSleeve corrugatedSleeve = new CorrugatedSleeve(row.Cell(2).GetString(), row.Cell(4).GetString(), cellColor, row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(11).GetString());

                        var supplier = row.Cell(9).GetString();
                        if (!corrugated.ContainsKey(supplier))
                            corrugated[supplier] = new List<CorrugatedSleeve>();
                        corrugated[supplier].Add(corrugatedSleeve);
                    }
                }
                return corrugated;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads Divisible Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns>Dictionary with Divisible objects </returns>
        internal Dictionary<string, List<Divisible>> Divisible(string pl3FilePath)
        {
            try
            {
                var divisibleDictionary = new Dictionary<string, List<Divisible>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("DIVISIBLE SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        Divisible divisible = new Divisible(row.Cell(2).GetString(), cellColor, row.Cell(6).GetString(), row.Cell(7).GetString());

                        var supplier = row.Cell(8).GetString();
                        if (!divisibleDictionary.ContainsKey(supplier))
                            divisibleDictionary[supplier] = new List<Divisible>();
                        divisibleDictionary[supplier].Add(divisible);
                    }
                }
                return divisibleDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads ElectricalInsulationSleeve Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with Electrical_Insulation_Sleeve objects</returns>
        internal Dictionary<string, List<Electrical_Insulation_Sleeve>> ElectricalInsulationSleeve(string pl3FilePath)
        {
            try
            {
                var ElectricalInsulationDictionary = new Dictionary<string, List<Electrical_Insulation_Sleeve>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("ELECTRICAL INSULATION SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        Electrical_Insulation_Sleeve electricalInsulationSleeve = new Electrical_Insulation_Sleeve(row.Cell(2).GetString(), cellColor, row.Cell(4).GetString(), row.Cell(6).GetString());

                        var DIELECTRIC_STRENGTH_kV = row.Cell(5).GetString();
                        if (!ElectricalInsulationDictionary.ContainsKey(DIELECTRIC_STRENGTH_kV))
                            ElectricalInsulationDictionary[DIELECTRIC_STRENGTH_kV] = new List<Electrical_Insulation_Sleeve>();
                        ElectricalInsulationDictionary[DIELECTRIC_STRENGTH_kV].Add(electricalInsulationSleeve);
                    }
                }
                return ElectricalInsulationDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads EMC Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with EMC objects </returns>
        internal Dictionary<string, List<EMC>> EMC(string pl3FilePath)
        {
            try
            {
                var emcDictionary = new Dictionary<string, List<EMC>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("EMC SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        EMC emcSleeve = new EMC(row.Cell(2).GetString(), cellColor, row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString());

                        var partNumber = row.Cell(8).GetString();
                        if (!emcDictionary.ContainsKey(partNumber))
                            emcDictionary[partNumber] = new List<EMC>();
                        emcDictionary[partNumber].Add(emcSleeve);
                    }
                }
                return emcDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads ExpandableSleeve Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with ExpandableSleeve objects </returns>
        internal Dictionary<string, List<ExpandableSleeve>> ExpandableSleeve(string pl3FilePath)
        {
            try
            {
                var expandableSleeveDictionary = new Dictionary<string, List<ExpandableSleeve>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("EXPANDABLE SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        ExpandableSleeve expandableSleeve = new ExpandableSleeve(row.Cell(2).GetString(), cellColor, row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString());

                        var partNumber = row.Cell(8).GetString();
                        if (!expandableSleeveDictionary.ContainsKey(partNumber))
                            expandableSleeveDictionary[partNumber] = new List<ExpandableSleeve>();
                        expandableSleeveDictionary[partNumber].Add(expandableSleeve);
                    }
                }
                return expandableSleeveDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads FlameRetardantSleeve Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with Flame_Retardant_Sleeve objects </returns>
        internal Dictionary<string, List<Flame_Retardant_Sleeve>> FlameRetardantSleeve(string pl3FilePath)
        {
            try
            {
                var expandableSleeveDictionary = new Dictionary<string, List<Flame_Retardant_Sleeve>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("FLAME RETARDANT SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        Flame_Retardant_Sleeve expandableSleeve = new Flame_Retardant_Sleeve(row.Cell(2).GetString(), cellColor, row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString());

                        var partNumber = row.Cell(8).GetString();
                        if (!expandableSleeveDictionary.ContainsKey(partNumber))
                            expandableSleeveDictionary[partNumber] = new List<Flame_Retardant_Sleeve>();
                        expandableSleeveDictionary[partNumber].Add(expandableSleeve);
                    }
                }
                return expandableSleeveDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads HeatShrinkableSleeve Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with Heat_Shrinkable_Sleeve objects </returns>
        internal Dictionary<string, List<Heat_Shrinkable_Sleeve>> HeatShrinkableSleeve(string pl3FilePath)
        {
            try
            {
                var heatshrinkableSleeveDictionary = new Dictionary<string, List<Heat_Shrinkable_Sleeve>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("HEAT SHRINKABLE SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color cColor = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = cColor.R.ToString() + ", " + cColor.G.ToString() + ", " + cColor.B.ToString();
                        Heat_Shrinkable_Sleeve heatshrinkableSleeve = new Heat_Shrinkable_Sleeve(row.Cell(2).GetString(), cellColor, row.Cell(6).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString(), row.Cell(14).GetString(), row.Cell(13).GetString());

                        var color = row.Cell(4).GetString();
                        if (!heatshrinkableSleeveDictionary.ContainsKey(color))
                            heatshrinkableSleeveDictionary[color] = new List<Heat_Shrinkable_Sleeve>();
                        heatshrinkableSleeveDictionary[color].Add(heatshrinkableSleeve);
                    }
                }
                return heatshrinkableSleeveDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads WrapAroundGripSleeve Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with WrapAroundGripSleeve objects </returns>
        internal Dictionary<string, List<WrapAroundGripSleeve>> WrapAroundGripSleeve(string pl3FilePath)
        {
            try
            {
                var WrapAroundGripSleeveDictionary = new Dictionary<string, List<WrapAroundGripSleeve>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("WRAP AROUND GRIP SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        WrapAroundGripSleeve heatshrinkableSleeve = new WrapAroundGripSleeve(row.Cell(2).GetString(), cellColor, row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString());

                        var partnumber = row.Cell(8).GetString();
                        if (!WrapAroundGripSleeveDictionary.ContainsKey(partnumber))
                            WrapAroundGripSleeveDictionary[partnumber] = new List<WrapAroundGripSleeve>();
                        WrapAroundGripSleeveDictionary[partnumber].Add(heatshrinkableSleeve);
                    }
                }
                return WrapAroundGripSleeveDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads WrapAroundSleeve Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with WrapAroundSleeve objects </returns>
        internal Dictionary<string, List<WrapAroundSleeve>> WrapAroundSleeve(string pl3FilePath)
        {
            try
            {
                var WrapAroundSleeveDictionary = new Dictionary<string, List<WrapAroundSleeve>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("WRAP AROUND SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        WrapAroundSleeve WrapAroundSleeve = new WrapAroundSleeve(row.Cell(2).GetString(), cellColor, row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString());

                        var partnumber = row.Cell(8).GetString();
                        if (!WrapAroundSleeveDictionary.ContainsKey(partnumber))
                            WrapAroundSleeveDictionary[partnumber] = new List<WrapAroundSleeve>();
                        WrapAroundSleeveDictionary[partnumber].Add(WrapAroundSleeve);
                    }
                }
                return WrapAroundSleeveDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads Global Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns>returns dictionary with PL3_Global objects</returns>
        internal Dictionary<string, List<PL3_Global>> pl3_Global_File(string pl3FilePath)
        {
            try
            {
                var WrapAroundSleeveDictionary = new Dictionary<string, List<PL3_Global>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("Global");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        System.Drawing.Color color = new System.Drawing.Color();
                        try { color = row.Cell(3).Style.Font.FontColor.Color; } catch { alt_Logging_class.AddError("Error while reading color 3PL_Projet_File: DTR: " + row.Cell(3).GetString()); }
                        try
                        {
                            string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                            PL3_Global WrapAroundSleeve = new PL3_Global(row.Cell(3).GetString(), row.Cell(4).GetString(), row.Cell(6).GetString());

                            var partnumber = cellColor;
                            if (!WrapAroundSleeveDictionary.ContainsKey(partnumber))
                                WrapAroundSleeveDictionary[partnumber] = new List<PL3_Global>();
                            WrapAroundSleeveDictionary[partnumber].Add(WrapAroundSleeve);
                        }
                        catch (Exception)
                        {
                            alt_Logging_class.AddError("Error while reading row 3PL_Projet_File: DTR: " + row.Cell(3).GetString());
                        }
                    }
                }
                return WrapAroundSleeveDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Reads Connector Excel file
        /// </summary>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <returns> returns dictionary with PL3_Connector objects </returns>
        internal Dictionary<string, PL3_Connector> pl3_Connector_File(string pl3FilePath)
        {
            try
            {
                var pl3connectorDict = new Dictionary<string, PL3_Connector>();
                //var pl3connector = new List<PL3_Connector>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("Connectors");
                    foreach (var row in worksheet.RowsUsed().Skip(3))
                    {
                        string dtr = row.Cell(3).GetString();
                        string ppl = row.Cell(4).GetString();
                        string desp = row.Cell(6).GetString();
                        string componentType = row.Cell(2).GetString();
                        PL3_Connector connectordetails = new PL3_Connector(dtr, ppl, desp, componentType);
                        if(!pl3connectorDict.ContainsKey(dtr))
                            pl3connectorDict.Add(dtr, connectordetails);
                    }
                }
                return pl3connectorDict;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// This method Validates selected Excel file is a 3PL_Projet_File or not
        /// </summary>
        /// <param name="excelFilePath"> 3PL_Projet_File file path </param>
        /// <returns> status if 3PL_Projet_File is valid</returns>
        public bool Validate_3PL_Projet_File(string excelFilePath)
        {
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    string sheet1Name = "Global";

                    bool sheet1Exists = false;
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (string.Equals(worksheet.Name.Trim(), sheet1Name, StringComparison.OrdinalIgnoreCase))
                        {
                            sheet1Exists = true;
                        }
                    }
                    return sheet1Exists ? true : false;
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return false;

            }
        }

        /// <summary>
        /// This method Reads CableGland from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline file path</param>
        /// <returns> returns dictionary with CableGland objects </returns>
        public Dictionary<string, List<CableGland>> ReadCableGland(string excelFilePath)
        {
            var WrapAroundCableGland = new Dictionary<string, List<CableGland>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("CABLE GLAND");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {

                        CableGland cableGland = new CableGland(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString()
                           , row.Cell(10).GetString(), row.Cell(11).GetString(), row.Cell(12).GetString(), row.Cell(13).GetString(), row.Cell(14).GetString());

                        var partnumber = row.Cell(14).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<CableGland>();
                        WrapAroundCableGland[partnumber].Add(cableGland);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads Front page from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline file path </param>
        /// <returns> List of row content of front page </returns>
        public List<string> ReadFrontPage(string excelFilePath)
        {
            List<string> couplerList = new List<string>();

            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("Front page");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        if (row.Cell(1).GetString().Contains("COUPLER"))
                        {
                            couplerList.Add(row.Cell(1).GetString());
                        }

                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return couplerList;
        }

        /// <summary>
        /// This method Reads DTRs from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline file path </param>
        /// <param name="sheetName"> sheetname </param>
        /// <returns> List of DTRs </returns>
        public List<string> ReadOnlyDTRs(string excelFilePath, string sheetName)
        {
            List<string> dtrList = new List<string>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(sheetName);
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        dtrList.Add(row.Cell(2).GetString());
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return dtrList;
        }

        /// <summary>
        /// This method Reads 3PL Projet Excel file
        /// </summary>
        /// <param name="excelFilePath"> 3PL Projet file path </param>
        /// <returns> List of Projet3PL objects </returns>
        public List<Projet3PL> Read3PLFile(string excelFilePath)
        {
            List<Projet3PL> cableGlandList = new List<Projet3PL>();

            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("Global");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {

                        Projet3PL cableGland = new Projet3PL(row.Cell(1).GetString(), row.Cell(2).GetString(), row.Cell(3).GetString(),
                            row.Cell(4).GetString(), row.Cell(5).GetString(), row.Cell(6).GetString(), row.Cell(7).GetString()
                           , row.Cell(8).GetString(), row.Cell(9).GetString());

                        cableGlandList.Add(cableGland);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return cableGlandList;
        }

        /// <summary>
        /// This method Reads Coupler from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <param name="sheetName"></param>
        /// <returns> returns dictionary with Coupler objects </returns>
        public Dictionary<string, List<Coupler>> ReadCoupler(string excelFilePath, string sheetName)
        {
            List<Coupler> couplerList = new List<Coupler>();
            var WrapAroundCableGland = new Dictionary<string, List<Coupler>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(sheetName);
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        Coupler coupler = new Coupler(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString()
                           , row.Cell(10).GetString());

                        var partnumber = row.Cell(10).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<Coupler>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads BlindPlug from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with BlindPlug objects</returns>
        public Dictionary<string, List<BlindPlug>> ReadBlindPlug(string excelFilePath)
        {
            List<BlindPlug> couplerList = new List<BlindPlug>();
            var WrapAroundCableGland = new Dictionary<string, List<BlindPlug>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("BLIND PLUG");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        BlindPlug coupler = new BlindPlug(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString());

                        var partnumber = row.Cell(7).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<BlindPlug>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads ReducerExtentionWithSeal from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with ReducerExtentionWithSeal objects</returns>
        public Dictionary<string, List<ReducerExtentionWithSeal>> ReadReducerExtender(string excelFilePath)
        {
            List<ReducerExtentionWithSeal> couplerList = new List<ReducerExtentionWithSeal>();
            var WrapAroundCableGland = new Dictionary<string, List<ReducerExtentionWithSeal>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("REDUCER - EXTENSION WITH SEAL");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        ReducerExtentionWithSeal coupler = new ReducerExtentionWithSeal(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString());

                        var partnumber = row.Cell(10).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<ReducerExtentionWithSeal>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads FlatSeal from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with FlatSeal objects</returns>
        public Dictionary<string, List<FlatSeal>> ReadSeal(string excelFilePath)
        {
            List<FlatSeal> couplerList = new List<FlatSeal>();
            var WrapAroundCableGland = new Dictionary<string, List<FlatSeal>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("FLAT SEAL");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        FlatSeal coupler = new FlatSeal(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString(), row.Cell(11).GetString(), row.Cell(12).GetString());

                        var partnumber = row.Cell(12).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<FlatSeal>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads FirewallCoupler from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with FirewallCoupler objects</returns>
        public Dictionary<string, List<FirewallCoupler>> ReadFireWallCoupler(string excelFilePath)
        {
            List<FirewallCoupler> couplerList = new List<FirewallCoupler>();
            var WrapAroundCableGland = new Dictionary<string, List<FirewallCoupler>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("FIREWALL COUPLER");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        FirewallCoupler coupler = new FirewallCoupler(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString());

                        var partnumber = row.Cell(10).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<FirewallCoupler>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads EmcAdapter from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with EmcAdapter objects</returns>
        public Dictionary<string, List<EmcAdapter>> ReadEMCAdapter(string excelFilePath)
        {
            List<EmcAdapter> couplerList = new List<EmcAdapter>();
            var WrapAroundCableGland = new Dictionary<string, List<EmcAdapter>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("EMC ADAPTER");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        EmcAdapter coupler = new EmcAdapter(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString());

                        var partnumber = row.Cell(9).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<EmcAdapter>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads SwivelAdapter from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with SwivelAdapter objects</returns>
        public Dictionary<string, List<SwivelAdapter>> ReadSwiveledAdapter(string excelFilePath)
        {
            List<SwivelAdapter> couplerList = new List<SwivelAdapter>();
            var WrapAroundCableGland = new Dictionary<string, List<SwivelAdapter>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("SWIVEL ADAPTER");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        SwivelAdapter coupler = new SwivelAdapter(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString(), row.Cell(10).GetString());

                        var partnumber = row.Cell(10).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<SwivelAdapter>();
                        WrapAroundCableGland[partnumber].Add(coupler);
                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads CouplerCombination from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <param name="dtrheader"> DTR </param>
        /// <param name="exceptions"> things to avoid in the sheet </param>
        /// <returns> returns dictionary with CombinedCouplers objects </returns>
        public Dictionary<string, List<CombinedCouplers>> ReadCouplerCombination(string excelFilePath, string dtrheader, List<string> exceptions)
        {
            List<CombinedCouplers> couplerList = new List<CombinedCouplers>();
            var WrapAroundCableGland = new Dictionary<string, List<CombinedCouplers>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("COUPLER (T, Y, Reducer, etc)");
                    bool startProcessing = false;
                    foreach (var row in worksheet.RowsUsed())
                    {
                        if (!startProcessing)
                        {
                            if (row.Cell(2).GetString() == dtrheader)
                            {
                                startProcessing = true; // Start processing from the next row
                            }
                            continue;
                        }
                        if (startProcessing)
                        {
                            if (exceptions.Contains(row.Cell(2).GetString())) break;
                            CombinedCouplers coupler = new CombinedCouplers(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString());

                            var partnumber = row.Cell(6).GetString();
                            if (!WrapAroundCableGland.ContainsKey(partnumber))
                                WrapAroundCableGland[partnumber] = new List<CombinedCouplers>();
                            WrapAroundCableGland[partnumber].Add(coupler);
                        }

                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads YCoupler from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <param name="exceptions"> things to avoid in the sheet </param>
        /// <returns> returns dictionary with YCoupler objects </returns>
        public Dictionary<string, List<YCoupler>> ReadYCoupler(string excelFilePath, List<string> exceptions)
        {
            List<YCoupler> couplerList = new List<YCoupler>();
            var WrapAroundCableGland = new Dictionary<string, List<YCoupler>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("COUPLER (T, Y, Reducer, etc)");
                    bool startProcessing = false;
                    foreach (var row in worksheet.RowsUsed())
                    {
                        if (!startProcessing)
                        {
                            if (row.Cell(2).GetString() == "DTR Y coupler")
                            {
                                startProcessing = true; // Start processing from the next row
                            }
                            continue;
                        }
                        if (startProcessing)
                        {
                            if (exceptions.Contains(row.Cell(2).GetString())) break;
                            YCoupler coupler = new YCoupler(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                            row.Cell(6).GetString(), row.Cell(7).GetString());

                            var partnumber = row.Cell(7).GetString();
                            if (!WrapAroundCableGland.ContainsKey(partnumber))
                                WrapAroundCableGland[partnumber] = new List<YCoupler>();
                            WrapAroundCableGland[partnumber].Add(coupler);
                        }

                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads TerminalSleev from Cable_Accessories_Guideline file
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path</param>
        /// <returns>returns dictionary with TerminalSleev objects</returns>
        public Dictionary<string, List<TerminalSleev>> ReadTerminalSleev(string excelFilePath)
        {
            List<TerminalSleev> couplerList = new List<TerminalSleev>();
            var WrapAroundCableGland = new Dictionary<string, List<TerminalSleev>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("TERMINAL SLEEVE");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        TerminalSleev coupler = new TerminalSleev(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
                        row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString());

                        var partnumber = row.Cell(9).GetString();
                        if (!WrapAroundCableGland.ContainsKey(partnumber))
                            WrapAroundCableGland[partnumber] = new List<TerminalSleev>();
                        WrapAroundCableGland[partnumber].Add(coupler);

                    }
                }

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundCableGland;
        }

        /// <summary>
        /// This method Reads Front page from Cable_Accessories_Guideline file and converts to json
        /// </summary>
        /// <param name="excelFilePath"> Cable_Accessories_Guideline path </param>
        /// <returns> returns dictionary with front page content </returns>
        public Dictionary<string, List<string>> ReadFrontPagetoJson(string excelFilePath)
        {
            List<string> frontPage = new List<string>();
            var WrapAroundFrontPage = new Dictionary<string, List<string>>();
            try
            {
                using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (worksheet.Name.Contains("COUPLER")) frontPage.Add(worksheet.Name);

                    }

                    //var worksheet = workbook.Worksheet("Front page");
                    //foreach (var row in worksheet.RowsUsed().Skip(1))
                    //{
                    //    if (row.Cell(1).GetString().Contains("COUPLER"))
                    //    {
                    //        frontPage.Add(row.Cell(1).GetString());
                    //    }
                    //}
                }
                WrapAroundFrontPage.Add("frontPage", frontPage);

            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }

            return WrapAroundFrontPage;
        }

        ///// <summary>
        ///// Gets or sets .
        ///// </summary>
        ///// <value>
        ///// A.
        ///// </value>
        //internal Dictionary<Tapes_Labels> sReadTapesFile(string excelFilePath)
        //{
        //    Dictionary<Tapes_Labels> tapesAndLabelsList = new List<Tapes_Labels>();

        //    try
        //    {
        //        using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        //        using (var workbook = new XLWorkbook(stream))
        //        {
        //            var worksheet = workbook.Worksheet("CABLE GLAND");
        //            foreach (var row in worksheet.RowsUsed().Skip(1))
        //            {

        //                CableGland cableGland = new CableGland(row.Cell(2).GetString(), row.Cell(4).GetString(), row.Cell(5).GetString(),
        //                    row.Cell(6).GetString(), row.Cell(7).GetString(), row.Cell(8).GetString(), row.Cell(9).GetString()
        //                   , row.Cell(10).GetString(), row.Cell(11).GetString(), row.Cell(12).GetString(), row.Cell(13).GetString(), row.Cell(14).GetString());

        //                var partnumber = row.Cell(14).GetString();
        //                if (!WrapAroundCableGland.ContainsKey(partnumber))
        //                    WrapAroundCableGland[partnumber] = new List<CableGland>();
        //                WrapAroundCableGland[partnumber].Add(cableGland);
        //            }
        //        }
        //        using (var stream = new FileStream(excelFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
        //        using (var workbook = new XLWorkbook(stream))
        //        {
        //            var worksheet = workbook.Worksheet("TAPES & LABELS");
        //            foreach (var row in worksheet.RowsUsed().Skip(1))
        //            {
        //                Tapes_Labels cableGland = new Tapes_Labels(row.Cell(2).GetString(), row.Cell(5).GetString(), row.Cell(4).GetString());
        //                tapesAndLabelsList.Add(cableGland);
        //            }
        //        }
        //    }
        //    catch (Exception exception)
        //    {
        //        string Errormsg = exception.Message;
        //        return null;
        //    }

        //    return tapesAndLabelsList;
        //}

        /// <summary>
        /// This method Reads Tapes_Labels from 3plFilePath file
        /// </summary>
        /// <param name="excelFilePath"> 3plFilePath path</param>
        /// <returns>returns dictionary with Tapes_Labels objects</returns>
        internal Dictionary<string, List<Tapes_Labels>> ReadTapesFile(string pl3FilePath)
        {
            try
            {
                var TapesLabelsDictionary = new Dictionary<string, List<Tapes_Labels>>();
                using (var stream = new FileStream(pl3FilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet("TAPES & LABELS");
                    foreach (var row in worksheet.RowsUsed().Skip(1))
                    {
                        //System.Drawing.Color color = row.Cell(2).Style.Fill.BackgroundColor.Color;
                        //string cellColor = color.R.ToString() + ", " + color.G.ToString() + ", " + color.B.ToString();
                        if (row.Cell(2).GetString() == "DTR0000554002")
                        {
                            continue;
                        }
                        Tapes_Labels TapesLabelSleeve = new Tapes_Labels(row.Cell(2).GetString(), row.Cell(5).GetString(), row.Cell(4).GetString(), row.Cell(6).GetString());
                        var cell = row.Cell(1);
                        string topLeftValue = string.Empty;
                        // Check if cell is merged
                        if (cell.IsMerged())
                        {
                            // Get the range this cell belongs to
                            var mergedRange = cell.MergedRange();

                            // Get only the top-left cell's value
                            topLeftValue = mergedRange.FirstCell().GetString();

                        }
                        else
                        {
                            topLeftValue = row.Cell(1).GetString();
                        }
                            var type = topLeftValue;
                        if (!TapesLabelsDictionary.ContainsKey(type))
                            TapesLabelsDictionary[type] = new List<Tapes_Labels>();
                        TapesLabelsDictionary[type].Add(TapesLabelSleeve);
                    }
                }
                return TapesLabelsDictionary;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }
    }
}
