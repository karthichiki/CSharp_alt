﻿using ALT_Data_Model.Accessories_Data_Model;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Model.UnityDataModel;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;

namespace ALT_Data_Model
{
    /// <summary>
    /// read json file.
    /// </summary>
    public class alt_JsonReaderService
    {
        private static alt_JsonReaderService _jsonReaderService;
        public FAF_Extract FAF_Extract;

        /// <summary>
        /// alt_JsonReaderService.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private alt_JsonReaderService()
        {
            FAF_Extract = new FAF_Extract();

        }

        /// <summary>
        /// GetInstance.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public static alt_JsonReaderService GetInstance()
        {
            if (_jsonReaderService == null)
                _jsonReaderService = new alt_JsonReaderService();

            return _jsonReaderService;
        }

        /// <summary>
        /// checks if file exist.
        /// </summary>
        /// <param name="excelFilePath"> excel file path</param>
        /// <returns> status exists or no </returns>
        public bool FileExist(string excelFilePath)
        {
            try
            {
                if (File.Exists(excelFilePath) == true)
                    return true;
            }
            catch
            {
                return false;
            }

            return false;
        }

        /// <summary>
        /// parse eqt location file.
        /// </summary>
        /// <param name="excelFilePath"> eq location json file</param>
        /// <returns> retuns CADEqtLocation object </returns>
        public CADEqtLocation ParseEqtLocationFile(string excelFilePath)
        {
            try
            {
                CADEqtLocation cadEqtLocation = null;
                string json = File.ReadAllText(excelFilePath);
                cadEqtLocation = JsonConvert.DeserializeObject<CADEqtLocation>(json);
                return cadEqtLocation;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// checks if json is synoptic json.
        /// </summary>
        /// <param name="jsonFillePath"> synoptic json file path </param>
        /// <returns> status if synoptic or no </returns>
        public bool IsaSynopticJson(string jsonFillePath)
        {
            bool correctNode = false;
            try
            {
                if (!File.Exists(jsonFillePath))
                {
                    return correctNode;
                }
                string json = File.ReadAllText(jsonFillePath);
                var jsonObject = JObject.Parse(json);

                // Access the first and second nodes
                var firstNode = jsonObject.Properties().ElementAt(1); // Get first node

                List<string> nodes = new List<string> { "Guid", "AMD", "ExtSynRevision", "SynopticVersion" };
                int i = 0;


                if (firstNode.Value is JArray firstNodeArray)
                {
                    // Get the first element from the array
                    var firstElement = firstNodeArray[0];
                    if (firstElement is JObject firstElementObject)
                    {
                        foreach (var property in firstElementObject)
                        {
                            if (property.Key == nodes[i])
                            {
                                correctNode = true;
                                i++;
                                if (i >= 4) return correctNode;
                            }
                            else
                            {
                                correctNode = false;
                                return correctNode;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                return correctNode;
            }
            return correctNode;
        }

        /// <summary>
        /// checks if json is FAF extract json.
        /// </summary>
        /// <param name="jsonFillePath"> FaF json path</param>
        /// <returns> Check result true or false </returns>
        public bool IsaExtractFAFJson(string jsonFillePath)
        {
            bool correctNode = false;
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                // Access the first and second nodes
                var firstNode = jsonObject.Properties().ElementAt(1); // Get first node

                List<string> nodes = new List<string> { "Guid", "Cable_ID", "Harness", "Class" };
                int i = 0;


                if (firstNode.Value is JArray firstNodeArray)
                {
                    // Get the first element from the array
                    var firstElement = firstNodeArray[0];
                    if (firstElement is JObject firstElementObject)
                    {
                        foreach (var property in firstElementObject)
                        {
                            if (property.Key == nodes[i])
                            {
                                correctNode = true;
                                i++;
                                if (i >= 4) return correctNode;
                            }
                            else
                            {
                                correctNode = false;
                                return correctNode;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                List<string> nodes = new List<string> { "Standard_EN_cables", "Standard_NAM_cables", "Specific_cables_DTREN" };
                return correctNode;
            }
            return correctNode;
        }

        /// <summary>
        /// checks if json is PPLCable extract json.
        /// </summary>
        /// <param name="jsonFillePath"> PPLCable json path</param>
        /// <returns> Check result true or false </returns>
        public bool IsaPPLCableJson(string jsonFillePath)
        {
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);
                List<string> nodes = new List<string> { "Standard_EN_cables", "Standard_NAM_cables", "Specific_cables_DTREN" };
                // Access the first node
                var firstNode = jsonObject.Properties().ElementAt(0);
                var secondNode = jsonObject.Properties().ElementAt(1);
                var thirdNode = jsonObject.Properties().ElementAt(2);
                if (firstNode.Name == nodes[0] && secondNode.Name == nodes[1] && thirdNode.Name == nodes[2])
                {
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }

        /// <summary>
        /// checks if json is PPLElectrical extract json.
        /// </summary>
        /// <param name="jsonFillePath"> PPLElectrical json path</param>
        /// <returns> Check result true or false </returns>
        public bool IsaPPLElectricalJson(string jsonFillePath)
        {
            bool correctNode = false;
            try
            {
                List<string> nodes = new List<string> { "Static_Bending_Radius", "Internal_Diameter" };
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);
                // Access the first node
                var firstNode = jsonObject.Properties().ElementAt(0);
                int i = 0;


                if (firstNode.Value is JArray firstNodeArray)
                {
                    // Get the first element from the array
                    var firstElement = firstNodeArray[0];
                    if (firstElement is JObject firstElementObject)
                    {
                        foreach (var property in firstElementObject)
                        {
                            if (property.Key == nodes[i])
                            {
                                correctNode = true;
                                i++;
                                if (i >= 2) return correctNode;
                            }
                            else
                            {
                                correctNode = false;
                                return correctNode;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }

        /// <summary>
        /// parse DTR.
        /// </summary>
        /// <param name="jsonFilePath"></param>
        /// <param name="en_Cables"></param>
        /// <param name="nam_Cables"></param>
        /// <param name="standard_Cables"></param>
        public void ParseDTR(string jsonFilePath, out Dictionary<string, List<PPL_Cables>> en_Cables, out Dictionary<string, List<PPL_Cables>> nam_Cables, out Dictionary<string, List<PPL_Cables>> standard_Cables)
        {
            en_Cables = new Dictionary<string, List<PPL_Cables>>();
            nam_Cables = new Dictionary<string, List<PPL_Cables>>();
            standard_Cables = new Dictionary<string, List<PPL_Cables>>();
            string json = File.ReadAllText(jsonFilePath);
            var mainDict = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, List<PPL_Cables>>>>(json);
            if (mainDict != null)
            {
                mainDict.TryGetValue("Standard_EN_cables", out en_Cables);
                mainDict.TryGetValue("Standard_NAM_cables", out nam_Cables);
                mainDict.TryGetValue("Specific_cables_DTREN", out standard_Cables);
            }
            else
            {
                Console.WriteLine("Failed to deserialize JSON.");
            }
        }

        /// <summary>
        /// parse the harness json file.
        /// </summary>
        /// <param name="jsonFilePath"> file path </param>
        /// <returns> Dictionary with list of FAF_Extract </returns>
        public Dictionary<string, List<FAF_Extract>> ParseHarness(string jsonFilePath)
        {
            string json = File.ReadAllText(jsonFilePath);
            var jsonObject = JsonConvert.DeserializeObject<Dictionary<string, List<FAF_Extract>>>(json);
            return jsonObject;
        }

        /// <summary>
        /// Parse harness in synoptic.
        /// </summary>
        /// <param name="jsonFilePath"> json file path </param>
        /// <returns> Dictionary with list of SynopticConnector </returns>
        public Dictionary<string, List<SynopticConnector>> ParseHarnessInSynoptic(string jsonFilePath)
        {
            string json = File.ReadAllText(jsonFilePath);
            var jsonObject = JsonConvert.DeserializeObject<Dictionary<string, List<SynopticConnector>>>(json);
            return jsonObject;
        }

        /// <summary>
        /// Parse supplier data.
        /// </summary>
        /// <param name="jsonFilePath"> json file path </param>
        /// <returns> Dictionary with list of PPL_Electrical </returns>
        public Dictionary<string, List<PPL_Electrical>> ParseSupplier(string jsonFilePath)
        {
            string jsonString = File.ReadAllText(jsonFilePath);

            // Deserialize JSON to a dictionary
            var supplierData = JsonConvert.DeserializeObject<Dictionary<string, List<PPL_Electrical>>>(jsonString);

            return supplierData;
        }

        /// <summary>
        ///  SerializeUnityData.
        /// </summary>
        /// <param name="unityData"> UnityData object</param>
        /// <returns> serialized data </returns>
        public string SerializeUnityData(UnityData unityData)
        {
            return JsonConvert.SerializeObject(unityData);
        }

        /// <summary>
        /// SerializeUnityDataPersist.
        /// </summary>
        /// <param name="unityData"> UnityDataPersist object </param>
        /// <returns> serialized data </returns>
        public string SerializeUnityDataPersist(UnityDataPersist unityData)
        {
            return JsonConvert.SerializeObject(unityData);
        }

        /// <summary>
        /// DeserializeUnityData.
        /// </summary>
        /// <param name="jsonInfo"> raw json data </param>
        /// <returns> UnityData object </returns>
        public UnityData DeserializeUnityData(string jsonInfo)
        {
            UnityData unityData = null;
            try
            {
                unityData = JsonConvert.DeserializeObject<UnityData>(jsonInfo);
            }
            catch (Exception ex)
            {
                string errorMsg = ex.Message;
            }
            return unityData;
        }

        ///// <summary>
        ///// ParseEqtLocationFile.
        ///// </summary>
        ///// <value>
        ///// 
        ///// </value>
        //public ObservableCollection<FirstExtremityZoneModel> FirstExtremityReadZones(string zoneJsonFilePath)
        //{
        //    try
        //    {
        //        ObservableCollection<FirstExtremityZoneModel> zones = new ObservableCollection<FirstExtremityZoneModel>();

        //        if(File.Exists(zoneJsonFilePath))
        //        {
        //            string json = File.ReadAllText(zoneJsonFilePath);
        //            var zoneOptionList = JsonConvert.DeserializeObject<string[]>(json);
        //            zones = new ObservableCollection<FirstExtremityZoneModel>();
        //            foreach (var zone in zoneOptionList)
        //            {
        //                zones.Add(new FirstExtremityZoneModel { FirstExtremityZoneName = zone, FirstExtremityIsSelected = false });
        //            }
        //        }
        //        return zones;
        //    }
        //    catch (Exception exception)
        //    {
        //        string Errormsg = exception.Message;
        //        return null;
        //    }
        //}

        ///// <summary>
        ///// ParseEqtLocationFile.
        ///// </summary>
        ///// <value>
        ///// 
        ///// </value>
        //public ObservableCollection<SecondExtremityZoneModel> SecondExtremityReadZones(string zoneJsonFilePath)
        //{
        //    try
        //    {
        //        ObservableCollection<SecondExtremityZoneModel> zones = new ObservableCollection<SecondExtremityZoneModel>();

        //        if (File.Exists(zoneJsonFilePath))
        //        {
        //            string json = File.ReadAllText(zoneJsonFilePath);
        //            var zoneOptionList = JsonConvert.DeserializeObject<string[]>(json);
        //            zones = new ObservableCollection<SecondExtremityZoneModel>();
        //            foreach (var zone in zoneOptionList)
        //            {
        //                zones.Add(new SecondExtremityZoneModel { SecondExtremityZoneName = zone, SecondExtremityIsSelected = false });
        //            }
        //        }
        //        return zones;
        //    }
        //    catch (Exception exception)
        //    {
        //        string Errormsg = exception.Message;
        //        return null;
        //    }
        //}

        ///// <summary>
        ///// ParseEqtLocationFile.
        ///// </summary>
        ///// <value>
        ///// 
        ///// </value>
        //public ObservableCollection<MultibranchableZoneModel> MultibranchableReadZones(string zoneJsonFilePath)
        //{
        //    try
        //    {
        //        ObservableCollection<MultibranchableZoneModel> zones = new ObservableCollection<MultibranchableZoneModel>();

        //        if (File.Exists(zoneJsonFilePath))
        //        {
        //            string json = File.ReadAllText(zoneJsonFilePath);
        //            var zoneOptionList = JsonConvert.DeserializeObject<string[]>(json);
        //            zones = new ObservableCollection<MultibranchableZoneModel>();
        //            foreach (var zone in zoneOptionList)
        //            {
        //                zones.Add(new MultibranchableZoneModel { MultibranchableZoneName = zone, MultibranchableIsSelected = false });
        //            }
        //        }
        //        return zones;
        //    }
        //    catch (Exception exception)
        //    {
        //        string Errormsg = exception.Message;
        //        return null;
        //    }
        //}

        /// <summary>
        /// get covering zones from json file.
        /// </summary>
        /// <param name="zoneJsonFilePath"> json file path </param>
        /// <returns> List of CoveringZoneModel </returns>
        public ObservableCollection<CoveringZoneModel> CoveringReadZones(string zoneJsonFilePath)
        {
            try
            {
                ObservableCollection<CoveringZoneModel> zones = new ObservableCollection<CoveringZoneModel>();

                if (File.Exists(zoneJsonFilePath))
                {
                    string json = File.ReadAllText(zoneJsonFilePath);
                    var zoneOptionList = JsonConvert.DeserializeObject<string[]>(json);
                    zones = new ObservableCollection<CoveringZoneModel>();
                    foreach (var zone in zoneOptionList)
                    {
                        zones.Add(new CoveringZoneModel { CoveringZoneName = zone, CoveringIsSelected = false });
                    }
                }
                return zones;
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
        }

        /// <summary>
        /// read sleeve json file.
        /// </summary>
        /// <param name="jsonFilePath"> json file path </param>
        /// <returns> SleeveCatalog object </returns>
        public SleeveCatalog ReadSleeveJson(string jsonFilePath)
        {
            SleeveCatalog _data = new SleeveCatalog();
            if (File.Exists(jsonFilePath))
            {
                var json = File.ReadAllText(jsonFilePath);
                _data = JsonConvert.DeserializeObject<SleeveCatalog>(json);
            }
            return _data;
        }

        /// <summary>
        /// checks if json is 3PL extract json.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> status if file is 3PLJson </returns>
        public bool isa3PLJson(string jsonFillePath)
        {
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);
                List<string> nodes = new List<string> { "CorrugatedSleeve", "Divisible", "ElectricalInsulationSleeve", "EMC", "ExpandableSleeve", "FlameRetardantSleeve", "HeatShrinkableSleeve", "WrapAroundGripSleeve", "WrapAroundSleeve" };
                // Access the first node
                var firstNode = jsonObject.Properties().ElementAt(0);
                var secondNode = jsonObject.Properties().ElementAt(1);
                var thirdNode = jsonObject.Properties().ElementAt(2);
                var forthNode = jsonObject.Properties().ElementAt(3);
                var fifthNode = jsonObject.Properties().ElementAt(4);
                var sixthNode = jsonObject.Properties().ElementAt(5);
                var seventhNode = jsonObject.Properties().ElementAt(6);
                var eighthNode = jsonObject.Properties().ElementAt(7);
                var ninthNode = jsonObject.Properties().ElementAt(8);
                if (firstNode.Name == nodes[0] && secondNode.Name == nodes[1] && thirdNode.Name == nodes[2] && forthNode.Name == nodes[3] && fifthNode.Name == nodes[4] && sixthNode.Name == nodes[5] && seventhNode.Name == nodes[6] && eighthNode.Name == nodes[7] && ninthNode.Name == nodes[8])
                {
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }

        /// <summary>
        /// checks if json is 3PLProjet extract json.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> status if file is 3PL_ProjetJson </returns>
        public bool isa3PL_ProjetJson(string jsonFillePath)
        {
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);
                List<string> nodes = new List<string> { "0, 0, 0", "255, 0, 0" };
                // Access the first node
                var firstNode = jsonObject.Properties().ElementAt(0);
                if (firstNode.Name == nodes[0] || firstNode.Name == nodes[1])
                {
                    return true;
                }
            }
            catch (Exception)
            {
                return false;
            }
            return false;
        }

        /// <summary>
        /// read 3PL json file.
        /// </summary>
        /// <param name="jsonFilePath"> json file path </param>
        /// <returns> PL3_Combined object </returns>
        public PL3_Combined Read3PLJson(string jsonFilePath)
        {
            PL3_Combined _data = new PL3_Combined();
            if (File.Exists(jsonFilePath))
            {
                var json = File.ReadAllText(jsonFilePath);
                _data = JsonConvert.DeserializeObject<PL3_Combined>(json);
            }
            return _data;
        }

        /// <summary>
        /// read 3PLProjet json file.
        /// </summary>
        /// <param name="jsonFilePath"> json file path </param>
        /// <returns> Dictionary with list of PL3_Global </returns>
        public Dictionary<string, List<PL3_Global>> Read3PLProjetJson(string jsonFilePath)
        {
            Dictionary<string, List<PL3_Global>> _data = new Dictionary<string, List<PL3_Global>>();
            if (File.Exists(jsonFilePath))
            {
                var json = File.ReadAllText(jsonFilePath);
                _data = JsonConvert.DeserializeObject<Dictionary<string, List<PL3_Global>>>(json);
            }
            return _data;
        }

        /// <summary>
        /// read cable gland json file.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> list of CableGland </returns>
        public List<CableGland> ReadCableGland(string jsonFillePath)
        {
            List<CableGland> cableGlands = new List<CableGland>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);
                List<string> nodes = new List<string> { "CableGland" };

                if (jsonObject.TryGetValue(nodes[0], out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            CableGland gland = item.ToObject<CableGland>();
                            cableGlands.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return cableGlands;
        }

        /// <summary>
        /// read coupler json file.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <param name="nodeName"> node to extract </param>
        /// <returns> List of Coupler </returns>
        public List<Coupler> ReadCoupler(string jsonFillePath, string nodeName)
        {
            List<Coupler> coupler = new List<Coupler>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue(nodeName, out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            Coupler gland = item.ToObject<Coupler>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read front page json file.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> List of fonr page content </returns>
        public List<string> ReadFrontPage(string jsonFillePath)
        {
            List<string> coupler = new List<string>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("FrontPage", out JToken frontPageNode))
                {
                    if (frontPageNode["frontPage"] is JArray array)
                    {
                        foreach (var item in array)
                        {
                            coupler.Add(item.ToString());
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read combined coupler json file.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <param name="nodeName"> Node name</param>
        /// <returns> List of CombinedCouplers objects </returns>
        public List<CombinedCouplers> ReadCombinedCouplers(string jsonFillePath, string nodeName)
        {
            List<CombinedCouplers> coupler = new List<CombinedCouplers>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue(nodeName, out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            CombinedCouplers gland = item.ToObject<CombinedCouplers>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read terminal sleev json file. 
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <param name="nodeName"> Node name in json </param>
        /// <returns> List of TerminalSleev objects </returns>
        public List<TerminalSleev> ReadTerminalSleev(string jsonFillePath, string nodeName)
        {
            List<TerminalSleev> coupler = new List<TerminalSleev>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue(nodeName, out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            TerminalSleev gland = item.ToObject<TerminalSleev>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read YCoupler
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <param name="nodeName"> Node name</param>
        /// <returns> List of YCoupler objects </returns>
        public List<YCoupler> ReadYCoupler(string jsonFillePath, string nodeName)
        {
            List<YCoupler> coupler = new List<YCoupler>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue(nodeName, out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            YCoupler gland = item.ToObject<YCoupler>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read firewall coupler json file.
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> List of FirewallCoupler objects </returns>
        public List<FirewallCoupler> ReadFirewallCoupler(string jsonFillePath)
        {
            List<FirewallCoupler> coupler = new List<FirewallCoupler>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("FirewallCoupler", out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            FirewallCoupler gland = item.ToObject<FirewallCoupler>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read swivel adapter 
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> List of SwivelAdapter objects </returns>
        public List<SwivelAdapter> ReadSwivelAdapter(string jsonFillePath)
        {
            List<SwivelAdapter> coupler = new List<SwivelAdapter>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("SwiveledAdapter", out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            SwivelAdapter gland = item.ToObject<SwivelAdapter>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read emc adapter
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> List of EmcAdapter objects </returns>
        public List<EmcAdapter> ReadEmcAdapter(string jsonFillePath)
        {
            List<EmcAdapter> coupler = new List<EmcAdapter>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("EmcAdapter", out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            EmcAdapter gland = item.ToObject<EmcAdapter>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read blind plug 
        /// </summary>
        /// <param name="jsonFillePath">  json file path  </param>
        /// <returns> List of BlindPlug objects </returns>
        public List<BlindPlug> ReadBlindPlug(string jsonFillePath)
        {
            List<BlindPlug> coupler = new List<BlindPlug>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("BlindPlug", out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            BlindPlug gland = item.ToObject<BlindPlug>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read flat seal 
        /// </summary>
        /// <param name="jsonFillePath">  json file path  </param>
        /// <returns> List of FlatSeal objects </returns>
        public List<FlatSeal> ReadFlatSeal(string jsonFillePath)
        {
            List<FlatSeal> coupler = new List<FlatSeal>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("FlatSeal", out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            FlatSeal gland = item.ToObject<FlatSeal>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read reducer extention with seal
        /// </summary>
        /// <param name="jsonFillePath"> json file path </param>
        /// <returns> List of ReducerExtentionWithSeal objects </returns>
        public List<ReducerExtentionWithSeal> ReadReducerExtender(string jsonFillePath)
        {
            List<ReducerExtentionWithSeal> coupler = new List<ReducerExtentionWithSeal>();
            try
            {
                string json = File.ReadAllText(jsonFillePath);
                JObject jsonObject = JObject.Parse(json);

                if (jsonObject.TryGetValue("ReducerExtender", out JToken cableGlandNode))
                {
                    foreach (var part in cableGlandNode.Children<JProperty>())
                    {
                        // Each part.Value is a JArray of CableGland items
                        foreach (var item in part.Value.Children<JObject>())
                        {
                            ReducerExtentionWithSeal gland = item.ToObject<ReducerExtentionWithSeal>();
                            coupler.Add(gland);
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Handle exceptions as needed
            }
            return coupler;
        }

        /// <summary>
        /// read 3PLProjet connector json file.
        /// </summary>
        /// <param name="jsonFilePath"> json file path </param>
        /// <returns> Dictionary with list of PL3_Connector  </returns>
        public Dictionary<string, PL3_Connector> Read3PLProjetConnectorJson(string jsonFilePath)
        {
            Dictionary<string, PL3_Connector> _data = new Dictionary<string, PL3_Connector>();
            if (File.Exists(jsonFilePath))
            {
                var json = File.ReadAllText(jsonFilePath);
                _data = JsonConvert.DeserializeObject<Dictionary<string, PL3_Connector>>(json);
            }
            return _data;
        }
    }
}
