﻿using CatiaDotNet.CommonExtensions;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Newtonsoft.Json;
using ProductStructureTypeLib;


namespace ALT_Data_Model
{
    /// <summary>
    /// CAD Connector class to store information about a connector in a CAD model.
    /// </summary>
    public class CADConnector
    {
        #region Properties
        [JsonProperty("name")]
        public string Name { get; set; }
        [JsonProperty("partnumber")]
        public string PartNumber { get; set; }
        [JsonProperty("transform")]
        public CADTransform Transform { get; set; }

        [JsonIgnore]
        public string Description { get; set; }
        [JsonIgnore]
        public Product CatiaProduct { get; set; }
        public int GroupIndex { get; set; } = 0;
        #endregion

        #region Constructor
        public CADConnector(Product product)
        {
            CatiaProduct = product;
            ExtractInfo();
        }
        public CADConnector()
        {
        }
        #endregion

        #region Public Methods
        #endregion

        #region Private Methods
        /// <summary>
        /// Extracts information from the CATIA Product object and populates the CADConnector properties.
        /// </summary>
        private void ExtractInfo()
        {
            alt_CATIA_Adapter catiaAdapter = alt_CATIA_Adapter.GetInstance();
            if (CatiaProduct != null)
            {
                PartNumber = CatiaProduct.get_PartNumber();
                Name = CatiaProduct.get_Name();
                Description = CatiaProduct.get_DescriptionRef();
                
                object[] Abs_Position = new object[12];
                Abs_Position = catiaAdapter.ConvertMatrixToArray(CatiaProductExtensions.GetGlobalMatrix4d(CatiaProduct));
               
                CADPosition position = new CADPosition();
                position.X = (double)Abs_Position[9];
                position.Y = (double)Abs_Position[10];
                position.Z = (double)Abs_Position[11];

                CADRotation rotation = new CADRotation();
                rotation.M11 = (double)Abs_Position[0];
                rotation.M12 = (double)Abs_Position[1];
                rotation.M13 = (double)Abs_Position[2];
                rotation.M21 = (double)Abs_Position[3];
                rotation.M22 = (double)Abs_Position[4];
                rotation.M23 = (double)Abs_Position[5];
                rotation.M31 = (double)Abs_Position[6];
                rotation.M32 = (double)Abs_Position[7];
                rotation.M33 = (double)Abs_Position[8];

                Transform = new CADTransform();
                Transform.Position = position;
                Transform.Rotation = rotation;
            }
        }
        #endregion
    }
}