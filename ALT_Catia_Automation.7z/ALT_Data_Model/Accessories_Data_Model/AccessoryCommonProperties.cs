﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Base class containing common accessory metadata shared across accessory data models.
    /// Provides supplier, part identification and DTR reference information.
    /// </summary>
    public class AccessoryCommonProperties
    {
        /// <summary>
        /// Gets or sets the OEM / internal part number identifying the accessory.
        /// </summary>
        public string PartNumber { get; set; }

        /// <summary>
        /// Gets or sets the DTR (Design / Technical Reference) code associated with the accessory specification.
        /// </summary>
        public string DTR { get; set; }

        /// <summary>
        /// Gets or sets the supplier or manufacturer name / code providing the accessory.
        /// </summary>
        public string Supplier { get; set; }

    }
}
