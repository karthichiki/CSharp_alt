﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a blind plug accessory (threaded sealing element) with thread size and length
    /// plus common accessory metadata inherited from <see cref="AccessoryCommonProperties"/>.
    /// </summary>
    public class BlindPlug : AccessoryCommonProperties
    {
        /// <summary>
        /// Gets or sets the nominal thread size (e.g. M12, M16, 1/4\" NPT) of the blind plug.
        /// </summary>
        public string Thread_Size { get; set; }

        /// <summary>
        /// Gets or sets the engaged thread length or depth specification.
        /// </summary>
        public string Thread_Length { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="BlindPlug"/> class populating all descriptive fields.
        /// </summary>
        /// <param name="dtr">Design / technical reference identifier.</param>
        /// <param name="threadsize">Nominal thread size (format as provided in source data).</param>
        /// <param name="threadlength">Nominal thread length / engagement specification.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="partnumber">Supplier or internal part number.</param>
        public BlindPlug(string dtr, string threadsize, string threadlength, string supplier, string partnumber)
        {
            DTR = dtr;
            Thread_Size = threadsize;
            Thread_Length = threadlength;
            Supplier = supplier;
            PartNumber = partnumber;
        }
    }
  
}
