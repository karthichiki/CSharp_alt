﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a conduit / cable coupler accessory with sealing, thread and dimensional attributes.
    /// </summary>
    public class Coupler
    {
        /// <summary>
        /// Gets or sets the design / technical reference (DTR) identifier for the coupler.
        /// </summary>
        public string CouplerDTR { get; set; }
        /// <summary>
        /// Gets or sets the nominal conduit size supported by the coupler.
        /// </summary>
        public string ConduitSize { get; set; }
        /// <summary>
        /// Gets or sets the seal type (material / style) used in the coupler.
        /// </summary>
        public string SealType { get; set; }
        /// <summary>
        /// Gets or sets the thread designation (e.g., M20x1.5, NPT 1/2").
        /// </summary>
        public string Thread { get; set; }
        /// <summary>
        /// Gets or sets the threaded engagement length.
        /// </summary>
        public string ThreadLength { get; set; }
        /// <summary>
        /// Gets or sets the internal diameter value (clear opening) of the coupler.
        /// </summary>
        public string InternalDiameter { get; set; }
        /// <summary>
        /// Gets or sets the supplier / manufacturer name or code.
        /// </summary>
        public string Supplier { get; set; }
        /// <summary>
        /// Gets or sets the supplier or internal part number.
        /// </summary>
        public string PartNumber { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Coupler"/> class with all descriptive properties.
        /// </summary>
        /// <param name="couplerDTR">Design / technical reference identifier.</param>
        /// <param name="conduitSize">Nominal conduit size.</param>
        /// <param name="sealType">Seal type/material.</param>
        /// <param name="thread">Thread designation.</param>
        /// <param name="threadLength">Thread length specification.</param>
        /// <param name="internalDiameter">Internal diameter / clear bore.</param>
        /// <param name="supplier">Supplier / manufacturer.</param>
        /// <param name="partNumber">Part number identifier.</param>
        public Coupler(string couplerDTR, string conduitSize , string sealType, string thread, string threadLength, string internalDiameter, string supplier, string partNumber)
        {
            PartNumber = partNumber;
            CouplerDTR = couplerDTR;
            InternalDiameter = internalDiameter;
            SealType = sealType;
            Thread = thread;
            ThreadLength = threadLength;
            Supplier = supplier;
            ConduitSize = conduitSize;
        }

    }
}
