﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents an EMC (electromagnetic compatibility) adapter accessory with conduit, thread and dimensional data
    /// plus common metadata inherited from <see cref="AccessoryCommonProperties"/>.
    /// </summary>
    public class EmcAdapter : AccessoryCommonProperties
    {
        /// <summary>
        /// Gets or sets the nominal conduit size supported by the EMC adapter.
        /// </summary>
        public string ConduitSize { get; set; }
        /// <summary>
        /// Gets or sets the thread designation (e.g., M25x1.5).
        /// </summary>
        public string Thread { get; set; }
        /// <summary>
        /// Gets or sets the thread engagement length specification.
        /// </summary>
        public string ThreadLength { get; set; }
        /// <summary>
        /// Gets or sets the internal diameter (clear opening) of the adapter.
        /// </summary>
        public string InternalDiameter { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="EmcAdapter"/> class populating all descriptive fields.
        /// </summary>
        /// <param name="dtr">Design / technical reference identifier.</param>
        /// <param name="conduitSize">Nominal conduit size.</param>
        /// <param name="thread">Thread designation.</param>
        /// <param name="threadlength">Thread engagement length.</param>
        /// <param name="internaldiameter">Internal diameter / clear bore.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="partnumber">Supplier or internal part number.</param>
        public EmcAdapter(string dtr, string conduitSize, string thread, string threadlength, string internaldiameter, string supplier , string partnumber)
        {
            // assign the values to the properties
            DTR = dtr;
            ConduitSize = conduitSize;
            Thread = thread;
            ThreadLength = threadlength;
            InternalDiameter = internaldiameter;
            Supplier = supplier;
            PartNumber = partnumber;
               
        }
    }

}
