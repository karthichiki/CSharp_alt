﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a 3PL (third party logistics / project) component record with revision, classification
    /// and supplier related metadata extracted from the 3PL source file.
    /// </summary>
    public class Projet3PL
    {
        /// <summary>
        /// Gets or sets the 3PL revision identifier.
        /// </summary>
        public string Rev3PL { get; set; }
        /// <summary>
        /// Gets or sets the component type/category.
        /// </summary>
        public string ComponentType { get; set; }
        /// <summary>
        /// Gets or sets the design / technical reference (DTR) code.
        /// </summary>
        public string DTR { get; set; }
        /// <summary>
        /// Gets or sets the PPL (parts list / product list) reference.
        /// </summary>
        public string PPL { get; set; }
        /// <summary>
        /// Gets or sets the EED (engineering/electrical designation) field.
        /// </summary>
        public string EED { get; set; }
        /// <summary>
        /// Gets or sets the textual description of the component.
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the unit of measure (e.g., pcs, m, set).
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// Gets or sets the supplier / manufacturer name or code.
        /// </summary>
        public string Supplier { get; set; }
        /// <summary>
        /// Gets or sets the supplier specific reference / part number.
        /// </summary>
        public string SupplierReference { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Projet3PL"/> class populating all metadata fields.
        /// </summary>
        /// <param name="rev3PL">3PL revision identifier.</param>
        /// <param name="componentType">Component type/category.</param>
        /// <param name="dtr">Design / technical reference code.</param>
        /// <param name="ppl">PPL (parts / product list) reference.</param>
        /// <param name="eed">EED designation field.</param>
        /// <param name="description">Human readable description.</param>
        /// <param name="unit">Unit of measure.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="supplierReference">Supplier specific reference / part number.</param>
        public Projet3PL(string rev3PL, string componentType, string dtr, string ppl, string eed, string description, string unit, string supplier, string supplierReference)
        {
            Rev3PL = rev3PL;
            ComponentType = componentType;
            DTR = dtr;
            PPL = ppl;
            EED = eed;
            Description = description;
            Unit = unit;
            Supplier = supplier;
            SupplierReference = supplierReference;
        }
    }
}
