﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a cable gland accessory including mechanical, sealing and operational envelope data
    /// plus common metadata inherited from <see cref="AccessoryCommonProperties"/>.
    /// </summary>
    public class CableGland : AccessoryCommonProperties
    {
        /// <summary>
        /// Gets or sets the nominal thread size (e.g., M20, M25).
        /// </summary>
        public string ThreadSize { get; set; }
        /// <summary>
        /// Gets or sets the thread engagement length specification.
        /// </summary>
        public string ThreadLength { get; set; }
        /// <summary>
        /// Gets or sets the gland mechanical / design type (e.g., EMC, standard, angled).
        /// </summary>
        public string Type { get; set; }
        /// <summary>
        /// Gets or sets the seal material / sealing technology (e.g., NBR, EPDM).
        /// </summary>
        public string SealType { get; set; }
        /// <summary>
        /// Gets or sets the minimum supported cable diameter.
        /// </summary>
        public string MinCableDiameter { get; set; }
        /// <summary>
        /// Gets or sets the maximum supported cable diameter.
        /// </summary>
        public string MaxCableDiameter { get; set; }
        /// <summary>
        /// Gets or sets the maximum lug width allowed for termination (if applicable).
        /// </summary>
        public string MaxLugWidth { get; set; }
        /// <summary>
        /// Gets or sets the minimum operational temperature rating.
        /// </summary>
        public string UseMinTemperature { get; set; }
        /// <summary>
        /// Gets or sets the maximum operational temperature rating.
        /// </summary>
        public string UseMaxTemperature { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CableGland"/> class with all descriptive and specification values.
        /// </summary>
        /// <param name="cabledtr">Design / technical reference code for the gland.</param>
        /// <param name="thredsize">Nominal thread size.</param>
        /// <param name="thredlength">Thread engagement length.</param>
        /// <param name="type">Gland mechanical/design type.</param>
        /// <param name="sealtype">Sealing material / type.</param>
        /// <param name="mincabledia">Minimum cable diameter.</param>
        /// <param name="maxcabledia">Maximum cable diameter.</param>
        /// <param name="maxlugwidth">Maximum lug width value.</param>
        /// <param name="usemintemp">Minimum usage temperature.</param>
        /// <param name="usemaxtemp">Maximum usage temperature.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="partnumber">Supplier or internal part number.</param>
        public CableGland(string cabledtr,string thredsize, string thredlength, string type, string sealtype,  string mincabledia, string maxcabledia, string maxlugwidth, string usemintemp, string usemaxtemp, string supplier, string partnumber)
        {
            DTR = cabledtr;
            ThreadSize = thredsize;
            ThreadLength = thredlength;
            Type = type;
            SealType = sealtype;
            MinCableDiameter = mincabledia;
            MaxCableDiameter = maxcabledia;
            MaxLugWidth = maxlugwidth;
            UseMinTemperature = usemintemp;
            UseMaxTemperature = usemaxtemp;
            Supplier = supplier;
            PartNumber = partnumber;

        }
    }
}
