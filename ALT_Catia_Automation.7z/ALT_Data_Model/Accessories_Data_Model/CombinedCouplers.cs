﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a combined coupler accessory (for conduit / tubing transitions)
    /// with conduit size plus common accessory metadata.
    /// </summary>
    public class CombinedCouplers : AccessoryCommonProperties
    {
        /// <summary>
        /// Gets or sets the nominal conduit size supported by the coupler.
        /// </summary>
        public string ConduitSize { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="CombinedCouplers"/> class with identifying data.
        /// </summary>
        /// <param name="dtr">Design / technical reference identifier.</param>
        /// <param name="conduitSize">Nominal conduit size.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="partnumber">Supplier or internal part number.</param>
        public CombinedCouplers(string dtr, string conduitSize, string supplier, string partnumber)
        {
            DTR = dtr;
            ConduitSize = conduitSize;
            Supplier = supplier;
            PartNumber = partnumber;
        }
    }
}
