﻿

namespace ALT_Data_Model.Accessories_Data_Model
{
    public class FirewallCoupler : AccessoryCommonProperties
    {
        public string Comptable_with_coupler_Size { get; set; }
        public string Thread_Male { get; set; }
        public string Thread_Female { get; set; }
        public string Seal_Type { get; set; }
        public string Thread_Length { get; set; }

        public  FirewallCoupler(string dtr, string ComptableWithCouplerSize, string ThreadMale, string ThreadFemale,string SealType, string ThreadLength, string supplier, string partnumber)
        {
            // assign the values to the properties
            DTR = dtr;
            Comptable_with_coupler_Size = ComptableWithCouplerSize;
            Thread_Male = ThreadMale;
            Thread_Female = ThreadFemale;
            Seal_Type = SealType;
            Thread_Length = ThreadLength;
            Supplier = supplier;
            PartNumber = partnumber;


        }

    }
}
