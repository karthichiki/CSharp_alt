﻿

namespace ALT_Data_Model.Accessories_Data_Model
{
    public class YCoupler: AccessoryCommonProperties
    {
        public string ConduitInSize { get; set; }
        public string ConduitOutSize { get; set; }
        public YCoupler(string dtr, string conduitInSize, string conduitOutSize, string supplier, string partnumber)
        {
            DTR = dtr;
            ConduitInSize = conduitInSize;
            ConduitOutSize = conduitOutSize;
            Supplier = supplier;
            PartNumber = partnumber;
        }
    }
}
