﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a terminal sleeve accessory with conduit sizing and dimensional data.
    /// Inherits common metadata from <see cref="AccessoryCommonProperties"/>.
    /// </summary>
    public class TerminalSleev : AccessoryCommonProperties
    {
        /// <summary>
        /// Nominal conduit size supported by the sleeve.
        /// </summary>
        public string ConduiSize { get; set; }
        /// <summary>
        /// Internal (clear) diameter of the sleeve.
        /// </summary>
        public string InternalDiameter { get; set; }
        /// <summary>
        /// External diameter of the sleeve.
        /// </summary>
        public string ExternalDiameter { get; set; }
        /// <summary>
        /// Overall length of the sleeve.
        /// </summary>
        public string Length { get; set; }
        /// <summary>
        /// Creates a new terminal sleeve instance and populates its dimensional and identification properties.
        /// </summary>
        /// <param name="dtr">Design / technical reference identifier.</param>
        /// <param name="conduitsize">Nominal conduit size.</param>
        /// <param name="intDia">Internal diameter.</param>
        /// <param name="extDia">External diameter.</param>
        /// <param name="length">Overall length.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="partnumber">Supplier or internal part number.</param>
        public TerminalSleev(string dtr, string conduitsize, string intDia, string extDia, string length , string supplier, string partnumber)
        {
            PartNumber = partnumber;
            DTR = dtr;
            Supplier = supplier;
            ConduiSize = conduitsize;
            InternalDiameter = intDia;
            ExternalDiameter = extDia;
            Length = length;
        }
    }
}
