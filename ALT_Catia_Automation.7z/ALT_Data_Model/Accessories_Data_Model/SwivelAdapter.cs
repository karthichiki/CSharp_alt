﻿

namespace ALT_Data_Model.Accessories_Data_Model
{
    public class SwivelAdapter : AccessoryCommonProperties
    {
        public string MaleThread { get; set; }
        public string FemaleThread { get; set; }
        public string SealThread { get; set; }
        public string ThreadLength { get; set; }
        public string InternalDiameter { get; set; }

        public SwivelAdapter(string dtr, string malethread, string femalethread, string sealthread, string threadlength, string internalDia, string supplier, string partnumber) 
        {
            // assign the values to the properties
            DTR = dtr;
            MaleThread = malethread;
            FemaleThread = femalethread;
            SealThread = sealthread;
            ThreadLength = threadlength;
            InternalDiameter = internalDia;
            Supplier = supplier;
            PartNumber = partnumber;

        }
    }
}
