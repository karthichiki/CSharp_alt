﻿
namespace ALT_Data_Model.Accessories_Data_Model
{
    public class ReducerExtentionWithSeal : AccessoryCommonProperties
    {
        public string Type { get; set; }
        public string SealType { get; set; }
        public string MaleThread { get; set; }
        public string FemaleThread { get; set; }
        public string MaleThreadLength { get; set; }
        
        public ReducerExtentionWithSeal(string dtr, string type, string sealtype, string malethread, string femalethread, string malethreadlength, string supplier, string partnumber)
        {
            DTR = dtr;
            Type = type;
            SealType = sealtype;
            MaleThread = malethread;
            FemaleThread = femalethread;
            MaleThreadLength = malethreadlength;
            Supplier = supplier;
            PartNumber = partnumber;
        }
    }
}
