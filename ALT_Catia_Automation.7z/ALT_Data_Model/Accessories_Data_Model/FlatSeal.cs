﻿namespace ALT_Data_Model.Accessories_Data_Model
{
    /// <summary>
    /// Represents a flat seal / gasket accessory including dimensional, thermal and material data
    /// plus common identification metadata inherited from <see cref="AccessoryCommonProperties"/>.
    /// </summary>
    public class FlatSeal : AccessoryCommonProperties
    {
        /// <summary>
        /// Gets or sets the nominal size designation of the flat seal.
        /// </summary>
        public string Size { get; set; }
        /// <summary>
        /// Gets or sets the thickness of the seal (typically in mm).
        /// </summary>
        public string Thickness { get; set; }
        /// <summary>
        /// Gets or sets the internal diameter (clear inner opening) of the seal.
        /// </summary>
        public string InternalDiameter { get; set; }
        /// <summary>
        /// Gets or sets the outer diameter of the seal.
        /// </summary>
        public string OutDiameter { get; set; }
        /// <summary>
        /// Gets or sets the minimum rated operating temperature.
        /// </summary>
        public string MinTemp { get; set; }
        /// <summary>
        /// Gets or sets the maximum rated operating temperature.
        /// </summary>
        public string MaxTemp { get; set; }
        /// <summary>
        /// Gets or sets the seal material specification (e.g., EPDM, NBR, Silicone).
        /// </summary>
        public string Material { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="FlatSeal"/> class with all descriptive fields.
        /// </summary>
        /// <param name="dtr">Design / technical reference identifier.</param>
        /// <param name="size">Nominal size designation.</param>
        /// <param name="thickness">Thickness value.</param>
        /// <param name="intDia">Internal diameter.</param>
        /// <param name="OutDia">Outer diameter.</param>
        /// <param name="minTemp">Minimum operating temperature.</param>
        /// <param name="maxtemp">Maximum operating temperature.</param>
        /// <param name="material">Material specification.</param>
        /// <param name="supplier">Supplier / manufacturer name or code.</param>
        /// <param name="partnumber">Supplier or internal part number.</param>
        public FlatSeal( string dtr, string size, string thickness, string intDia, string OutDia, string minTemp, string maxtemp, string material, string supplier, string partnumber)
        {
            DTR = dtr;
            Size = size;
            Thickness = thickness;
            InternalDiameter = intDia;
            OutDiameter = OutDia;
            MinTemp = minTemp;
            MaxTemp = maxtemp;
            Material = material;
            Supplier = supplier;
            PartNumber = partnumber;

        }
    }
}
