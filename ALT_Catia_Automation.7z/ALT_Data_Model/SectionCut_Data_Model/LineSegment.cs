﻿using MECMOD;
using Microsoft.SqlServer.Server;
using OpenTK;
using System;
using System.Windows.Media.Media3D;

namespace ALT_Data_Model.SectionCut_Data_Model
{
    public class LineSegment : Segment
    {
        public Point3D Start { get; set; }
        public Point3D End { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="LineSegment"/> class.
        /// </summary>
        /// <param name="LineElement"> Selected line </param>
        /// <param name="transformationMatrix"> Transformation matrix of the location</param>
        /// <param name="matrix3D"> 3d matrix of the location </param>
        public LineSegment(Line2D LineElement, object[] transformationMatrix, Matrix3D matrix3D)
        {
            object[] stpointarr = new object[2];
            LineElement.StartPoint.GetCoordinates(stpointarr);
            Point3D tempStart = this.SketchGlobalAxis(transformationMatrix, Convert.ToDouble(stpointarr[0]), Convert.ToDouble(stpointarr[1]));
            this.Start = this.ConvertToGlobal(tempStart, matrix3D);
            object[] edpointarr = new object[2];
            LineElement.EndPoint.GetCoordinates(edpointarr);
            Point3D tempEnd = this.SketchGlobalAxis(transformationMatrix, Convert.ToDouble(edpointarr[0]), Convert.ToDouble(edpointarr[1]));
            this.End = this.ConvertToGlobal(tempEnd, matrix3D);
            Type = "Line";
        }
    }
}
