﻿
using MECMOD;
using OpenTK;
using System;
using System.Windows.Media.Media3D;

namespace ALT_Data_Model.SectionCut_Data_Model
{
    public abstract class Segment
    {
        public string Type { get; set; }  // Line, Circle, etc.

        /// <summary>
        /// Convert 2D sketch coordinates to 3D global coordinates using the provided transformation matrix.
        /// </summary>
        /// <param name="transformationMatrix"> transformation matrix </param>
        /// <param name="X"> X coordinate </param>
        /// <param name="Y"> Y coordinate </param>
        /// <returns> 3d point </returns>
        public Point3D SketchGlobalAxis(object[] transformationMatrix, double X, double Y)
        {

            // Extract transformation values
            double xOrigin = (double)transformationMatrix[0];   // X of sketch origin in 3D
            double yOrigin = (double)transformationMatrix[1];  // Y of sketch origin in 3D
            double zOrigin = (double)transformationMatrix[2];  // Z of sketch origin in 3D

            double xDirX = (double)transformationMatrix[3];  // X direction vector X component
            double xDirY = (double)transformationMatrix[4];  // X direction vector Y component
            double xDirZ = (double)transformationMatrix[5];  // X direction vector Z component

            double yDirX = (double)transformationMatrix[6];  // Y direction vector X component
            double yDirY = (double)transformationMatrix[7];  // Y direction vector Y component
            double yDirZ = (double)transformationMatrix[8];  // Y direction vector Z component


            // Convert 2D sketch point to 3D global coordinates
            double globalX = xOrigin + X * xDirX + Y * yDirX;
            double globalY = yOrigin + X * xDirY + Y * yDirY;
            double globalZ = zOrigin + X * xDirZ + Y * yDirZ;

            Point3D point3D = new Point3D(globalX, globalY, globalZ);

            return point3D;

        }

        /// <summary>
        /// Get the normal direction of the sketch plane using the transformation matrix.
        /// </summary>
        /// <param name="transformationMatrix"> transformation matrix of sketch</param>
        /// <returns> Vector 3d of the normal</returns>
        public Vector3D GetNormalDirectionofSketch(object[] transformationMatrix)
        {
            Vector3D HorizontalNormal = new Vector3D(Convert.ToDouble(transformationMatrix[3]), Convert.ToDouble(transformationMatrix[4]), Convert.ToDouble(transformationMatrix[5]));
            Vector3D VerticalNormal = new Vector3D(Convert.ToDouble(transformationMatrix[6]), Convert.ToDouble(transformationMatrix[7]), Convert.ToDouble(transformationMatrix[8]));
            return Vector3D.CrossProduct(HorizontalNormal, VerticalNormal);
        }

        /// <summary>
        /// Convert a local 3D point to global coordinates using the provided transformation matrix.
        /// </summary>
        /// <param name="localPoint"> local coordinate</param>
        /// <param name="transformationMatrix"> transformation matrix </param>
        /// <returns> global coordinates </returns>
        public Point3D ConvertToGlobal(Point3D localPoint, Matrix3D transformationMatrix)
        {
            // Convert back to Point3D (ignore w if it's 1, otherwise normalize)
            return Point3D.Multiply(localPoint, transformationMatrix);
        }
    }
}
