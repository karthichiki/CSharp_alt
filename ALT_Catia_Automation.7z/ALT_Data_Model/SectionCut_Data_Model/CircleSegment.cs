﻿using Infrastructure_Layer.ALT_CATIA_Adapter;
using MECMOD;
using OpenTK;
using System;
using System.Linq;
using System.Numerics;
using System.Windows.Media.Media3D;

namespace ALT_Data_Model.SectionCut_Data_Model
{
    public class CircleSegment : Segment
    {
        public Point3D Center { get; set; }
        public double Radius { get; set; }
        public Vector3D Normal { get; set; } // Defines the plane in which the circle lies
        public string Name { get; set; }
        public string Harness_Instance_Name { get; set; }
        public string Branchable_Name { get; set; }

        /// <summary>
        /// Initializes a new instance of the CircleSegment class based on a Circle2D element from CATIA.
        /// </summary>
        /// <param name="CircleElement"></param>
        /// <param name="transformationMatrix"> transformation matrix of the location </param>
        /// <param name="matrix3D"> 3d matrix of the location </param>
        /// <param name="part"> Part linked to the circle selected</param>
        public CircleSegment(Circle2D CircleElement, object[] transformationMatrix, Matrix3D matrix3D, Part part)
        {
            Point3D center = new Point3D();
            try
            {
                object[] objects = new object[2];
                CircleElement.GetCenter(objects);// .GetCoordinates(objects);
                center = this.SketchGlobalAxis(transformationMatrix, Convert.ToDouble(objects[0]), Convert.ToDouble(objects[1]));

            }
            catch
            {
                Vector3d vector3D = alt_CATIA_Adapter.GetInstance().GetCenterFromReference(part.CreateReferenceFromObject(CircleElement));
                center = new Point3D(vector3D.X, vector3D.Y, vector3D.Z);
            }
            
            this.Center = this.ConvertToGlobal(center, matrix3D);
            this.Name = CircleElement.get_Name();
            this.Radius = CircleElement.Radius;
            this.Normal = this.GetNormalDirectionofSketch(transformationMatrix);
            string[] splitstr = CircleElement.get_Name().Split('/');
            if (splitstr.Length>0)
            {
                if (splitstr.FirstOrDefault().Split(';').Length>0)
                {
                    this.Harness_Instance_Name = splitstr.FirstOrDefault().Split(';').FirstOrDefault();

                }
                this.Branchable_Name = splitstr.Last();
            }
            Type = "Circle";
        }

        //public CircleSegment(Ellipse2D EllipseElement, object[] transformationMatrix, Matrix3D matrix3D, Part part)
        //{
        //    Point3D center = new Point3D();
        //    try
        //    {
        //        object[] objects = new object[2];
        //        EllipseElement.GetCenter(objects);//.GetCoordinates(objects);
        //        center = this.SketchGlobalAxis(transformationMatrix, Convert.ToDouble(objects[0]), Convert.ToDouble(objects[1]));

        //    }
        //    catch
        //    {
        //        Vector3d vector3D = alt_CATIA_Adapter.GetInstance().GetCenterFromReference(part.CreateReferenceFromObject(EllipseElement));
        //        center = new Point3D(vector3D.X, vector3D.Y, vector3D.Z);
        //    }
            
        //    this.Center = this.ConvertToGlobal(center, matrix3D);
        //    this.Name = EllipseElement.get_Name();
        //    this.Radius = EllipseElement.MajorRadius;
        //    this.Normal = this.GetNormalDirectionofSketch(transformationMatrix);
        //    string[] splitstr = EllipseElement.get_Name().Split('/');
        //    if (splitstr.Length>0)
        //    {
        //        this.Harness_Instance_Name = splitstr.FirstOrDefault();
        //        this.Branchable_Name = splitstr.Last();
        //    }
        //    Type = "Circle";
        //}
    }
}
