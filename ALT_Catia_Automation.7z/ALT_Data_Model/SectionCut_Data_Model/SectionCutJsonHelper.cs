﻿using ALT_Data_Model.UnityDataModel;
using ALT_Logging;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using OpenTK;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace ALT_Data_Model.SectionCut_Data_Model
{
    public static class SectionCutJsonHelper
    {
        /// <summary>
        /// Get the section cut name and segment name by circle center coordinates from JSON file.
        /// </summary>
        /// <param name="circleCenter"> 3d vector of the circle</param>
        /// <returns> Name of the circle found </returns>
        public static string GetCircleNameByCenter(Vector3d circleCenter)
        {
            try
            {
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                string jsonFilePath = GetJsonFilePath();
                if (!File.Exists(jsonFilePath))
                {
                    var log = $"------- Secion cuts json file not found: {jsonFilePath}";
                    alt_Logging_class.AddMessage(log);
                    return null;
                }

                string jsonData = File.ReadAllText(jsonFilePath);
                var sections = JArray.Parse(jsonData);
                if(sections == null)
                {
                    var log = $"------- Secion cuts json file is empty, no info finded: {jsonFilePath}";
                    alt_Logging_class.AddMessage(log);
                    return null;
                }
                foreach (var section in sections)
                {
                    var segments = section["Segments"];
                    if (segments != null)
                    {
                        foreach (var segment in segments)
                        {
                            if (segment["Type"]?.ToString() == "Circle")
                            {
                                string centerString = segment["Center"]?.ToString();
                                if (!string.IsNullOrEmpty(centerString))
                                {
                                    Vector3d center = ParseCoordinates(centerString);
                                    if (adapter.ComparePointByCoords(center, circleCenter))
                                        return section["Name"].ToString() + "/" + segment["Name"]?.ToString();
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading or processing the JSON file: {ex.Message}");
            }

            return null;
        }

        /// <summary>
        /// Get all circles (center and normal) by harness name from JSON file.
        /// </summary>
        /// <param name="harnessName"> name of the harness </param>
        /// <returns> dictionary with the circle with centre and normal vectors </returns>
        public static Dictionary<string, List<(Vector3d, Vector3d)>> GetCirclesByHarness(string harnessName)
        {
            var dict = new Dictionary<string, List<(Vector3d, Vector3d)>>();
            try
            {
                string jsonFilePath = GetJsonFilePath();
                if (!File.Exists(jsonFilePath))
                {
                    var log = $"------- Secion cuts json file not found: {jsonFilePath}";
                    alt_Logging_class.AddMessage(log);
                    return null;
                }

                string jsonData = File.ReadAllText(jsonFilePath);
                var sections = JArray.Parse(jsonData);
                if (sections == null)
                {
                    var log = $"------- Secion cuts json file is empty, no info finded: {jsonFilePath}";
                    alt_Logging_class.AddMessage(log);
                    return null;
                }

                foreach (var section in sections)
                {
                    var segments = section["Segments"];
                    if (segments != null)
                    {
                        foreach (var segment in segments)
                        {
                            if (segment["Type"]?.ToString() == "Circle")
                            {
                                string segHarnessName = segment["Harness_Instance_Name"]?.ToString();
                                if (string.IsNullOrEmpty(segHarnessName))
                                    continue;

                                if (harnessName.Contains(segHarnessName))
                                {
                                    Vector3d center = ParseCoordinates(segment["Center"]?.ToString());
                                    Vector3d normal = ParseCoordinates(segment["Normal"]?.ToString());
                                    string path = section["Name"].ToString() + "/" + segment["Name"]?.ToString();

                                    if (!dict.ContainsKey(path))
                                        dict[path] = new List<(Vector3d, Vector3d)>();

                                    dict[path].Add((center, normal));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading or processing the JSON file: {ex.Message}");
                return null;
            }

            return dict;
        }

        /// <summary>
        /// Parse a coordinate string in the format "X,Y,Z" into a Vector3d.
        /// </summary>
        /// <param name="coord"> coordinate as string </param>
        /// <returns> vector 3d of the coordinate value </returns>
        /// <exception cref="FormatException"></exception>
        private static Vector3d ParseCoordinates(string coord)
        {
            // Split the coordinate string by comma
            var parts = coord.Split(',');

            // Ensure there are exactly three parts (X, Y, Z)
            if (parts.Length != 3)
            {
                throw new FormatException($"Invalid coordinate format: {coord}");
            }

            // Parse each part as a double using InvariantCulture
            return new Vector3d(
                double.Parse(parts[0].Trim(), CultureInfo.InvariantCulture),
                double.Parse(parts[1].Trim(), CultureInfo.InvariantCulture),
                double.Parse(parts[2].Trim(), CultureInfo.InvariantCulture)
            );
        }

        /// <summary>
        /// Get the path of the JSON file from environment variable.
        /// </summary>
        /// <returns> Path of json file </returns>
        private static string GetJsonFilePath()
        {
            string envValue = Environment.GetEnvironmentVariable("HAT_User_Zone_Path", EnvironmentVariableTarget.User);
            string folderPath = Path.Combine(envValue, "Unity_Data", "Ref_Data");
            string jsonFilePath = Path.Combine(folderPath, "SectionCuts", "Sectioncuts.json");
            return jsonFilePath;
        }
    }

    /// <summary>
    /// Class representing the structure of the JSON configuration file.
    /// </summary>
    public static class PathPointFilterJsonHelper
    {
        /// <summary>
        /// Get the list of ignored path points from the JSON configuration file.
        /// </summary>
        /// <param name="filePath"> file path </param>
        /// <returns> List if ignored path points </returns>
        public static List<string> GetIgnoredPathPoints(string filePath)
        {
            try
            {
                // Parse JSON
                string jsonText = File.ReadAllText(filePath);
                PathPointConfig config = JsonConvert.DeserializeObject<PathPointConfig>(jsonText);

                // Get list of ignored names and set values to Upper
                List<string> ignoredItems = config.parentObjectType
                                            .Where(item => item.ignored)
                                            .Select(item => item.name.ToUpper())
                                            .ToList();
                return ignoredItems;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading or processing the JSON file: {ex.Message}");
            }

            return null;
        }
    }
}
