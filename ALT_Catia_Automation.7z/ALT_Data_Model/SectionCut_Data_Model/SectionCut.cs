﻿using MECMOD;
using OpenTK;
using System.Collections.Generic;
using System.Windows.Media.Media3D;

namespace ALT_Data_Model.SectionCut_Data_Model
{
    public class SectionCut
    {
        public string Name { get; set; }
        public List<Segment> Segments { get; set; } = new List<Segment>();
        public Sketch Sketch { get; set; }

        /// <summary>
        /// Initializes a new instance of the SectionCut class based on a Sketch element from CATIA.
        /// </summary>
        /// <param name="sketch"> selected sketch in catia </param>
        /// <param name="matrix3D"> 3d matrix of the location </param>
        /// <param name="part"> part linked to the sketch </param>
        public SectionCut(Sketch sketch, Matrix3D matrix3D, Part part)
        {
            this.Name = sketch.get_Name();
            this.Sketch = sketch;
            ExtractSegments(matrix3D, part);
        }

        /// <summary>
        /// Extracts segments from the sketch and populates the Segments list.
        /// </summary>
        /// <param name="matrix3D"> 3d matrix of the location  </param>
        /// <param name="part"> part linked to the sketch </param>
        private void ExtractSegments(Matrix3D matrix3D, Part part)
        {
            object[] transformationMatrix = new object[9];
            this.Sketch.GetAbsoluteAxisData(transformationMatrix);

            foreach (GeometricElement EachGeoElement in this.Sketch.GeometricElements)
            {
                Segment segment = null;
                if (EachGeoElement.GeometricType == CatGeometricType.catGeoTypeCircle2D)
                {
                    Circle2D CircleElement = (Circle2D)EachGeoElement;

                    segment = new CircleSegment(CircleElement, transformationMatrix, matrix3D, part);
                }
                //else if (EachGeoElement.GeometricType == CatGeometricType.catGeoTypeEllipse2D)
                //{
                //    Ellipse2D CircleElement = (Ellipse2D)EachGeoElement;

                //    segment = new CircleSegment(CircleElement, transformationMatrix, matrix3D, part);

                //}
                else if (EachGeoElement.GeometricType == CatGeometricType.catGeoTypeLine2D)
                {
                    Line2D LineElement = (Line2D)EachGeoElement;
                    segment = new LineSegment(LineElement, transformationMatrix, matrix3D);
                }

                if (segment != null)
                    this.Segments.Add(segment);
            }
        }
    }
}
