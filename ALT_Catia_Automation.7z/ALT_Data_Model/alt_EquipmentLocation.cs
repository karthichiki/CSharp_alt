﻿using System;

namespace ALT_Data_Model
{
    /// <summary>
    /// Class representing the location of equipment.
    /// </summary>
    public class alt_EquipmentLocation
    {
        public string EquipmentLocationPath { get; set; }

        /// <summary>
        /// Constructor that initializes the EquipmentLocationPath to the system's temporary directory.
        /// </summary>
        public alt_EquipmentLocation()
        {
            string userName = Environment.UserName;
            EquipmentLocationPath = System.IO.Path.GetTempPath();
        }
    }
}
