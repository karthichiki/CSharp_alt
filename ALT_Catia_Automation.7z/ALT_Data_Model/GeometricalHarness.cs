﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;

namespace ALT_Data_Model.Unity
{
    [XmlRoot("IGE-XAO_GEOMETRICAL_HARNESS")]
    public class GeometricalHarness
    {
        [XmlElement("GeometricalHarness")]
        public CtGH_GeometricalHarness GeometricalHarnessElement { get; set; }

        [XmlAttribute("EDB_InstanceID")]
        public string EDB_InstanceID { get; set; }

        [XmlAttribute("LengthUnit")]
        public string LengthUnit { get; set; }

        [XmlAttribute("XSDversion")]
        public decimal XSDversion { get; set; }

        [XmlAttribute("XMLSourceName")]
        public string XMLSourceName { get; set; }

        [XmlAttribute("XMLSourceVersion")]
        public string XMLSourceVersion { get; set; }

        [XmlAttribute("TimeStamp")]
        public DateTime TimeStamp { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a segment in a geometrical harness with various attributes such as Tag, Port IDs, Length, Diameter, Environmental Zone, Protection Type, and more.
    /// </summary>
    public class AgGH_Segment
    {
        [XmlAttribute("Tag")]
        public string Tag { get; set; }

        [XmlAttribute("PortID1")]
        public string PortID1 { get; set; }

        [XmlAttribute("PortID2")]
        public string PortID2 { get; set; }

        [XmlAttribute("Length")]
        public double Length { get; set; }

        [XmlAttribute("Forced_Length")]
        public double ForcedLength { get; set; }

        [XmlAttribute("Diameter")]
        public double Diameter { get; set; }

        [XmlAttribute("Max_Diameter")]
        public double MaxDiameter { get; set; }

        [XmlAttribute("Min_Diameter")]
        public double MinDiameter { get; set; }

        [XmlAttribute("Ext_Diameter")]
        public double ExtDiameter { get; set; }

        [XmlAttribute("EnvironmentalZone")]
        public string EnvironmentalZone { get; set; }

        [XmlAttribute("ProtectionType")]
        public string ProtectionType { get; set; } = "None";

        [XmlAttribute("BendRadius")]
        public double BendRadius { get; set; }

        [XmlAttribute("LinearMass")]
        public double LinearMass { get; set; }

        [XmlAttribute("DZone")]
        public string DZone { get; set; }

        [XmlAttribute("LacingTape")]
        public string LacingTape { get; set; } = "No";

        [XmlAttribute("Pressure")]
        public string Pressure { get; set; } = "Yes";
    }

    /// <summary>
    /// Represents a port in a geometrical harness with attributes such as PortID, PortType, Side, and coordinates (X, Y, Z).
    /// </summary>
    public class AgGH_Port
    {
        [XmlAttribute("PortID")]
        public string PortID { get; set; }

        [XmlAttribute("PortType")]
        public string PortType { get; set; } = "LocalPoint";

        [XmlAttribute("Side")]
        public string Side { get; set; }

        [XmlAttribute("X")]
        public double X { get; set; }

        [XmlAttribute("Y")]
        public double Y { get; set; }

        [XmlAttribute("Z")]
        public double Z { get; set; }
    }

    /// <summary>
    /// Represents a branch in a geometrical harness with attributes such as Tag, Segregation, Port IDs, Length, LoopOfBranch, and more.
    /// </summary>
    public class AgGH_GeometricalHarnessBranch
    {
        [XmlAttribute("Tag")]
        public string Tag { get; set; }

        [XmlAttribute("Segregation")]
        public string Segregation { get; set; }

        [XmlAttribute("Sensible")]
        public bool Sensible { get; set; } = false;

        [XmlAttribute("PortID1")]
        public string PortID1 { get; set; }

        [XmlAttribute("PortID2")]
        public string PortID2 { get; set; }

        [XmlAttribute("Length")]
        public double Length { get; set; }

        [XmlAttribute("CuttingLength")]
        public double CuttingLength { get; set; }

        [XmlAttribute("LoopOfBranch")]
        public string LoopOfBranch { get; set; } = "No";

        [XmlAttribute("UseComposedCables")]
        public string UseComposedCables { get; set; } = "No";

        [XmlAttribute("CC_MaxNumber")]
        public int CC_MaxNumber { get; set; }

        [XmlAttribute("CC_MaxSpare")]
        public string CC_MaxSpare { get; set; }
    }


    /// <summary>
    /// Represents a text element in a geometrical harness with three text attributes: Text1, Text2, and Text3.
    /// </summary>
    public class AgGH_Text
    {
        [XmlAttribute("Text1")]
        public string Text1 { get; set; }

        [XmlAttribute("Text2")]
        public string Text2 { get; set; }

        [XmlAttribute("Text3")]
        public string Text3 { get; set; }
    }

    /// <summary>
    /// Represents the main geometrical harness element with various attributes such as Tag, Section, SubSection, DZone, Description, Solution, Version, and more.
    /// </summary>
    public class AgGH_GeometricalHarness
    {
        [XmlAttribute("Tag")]
        public string Tag { get; set; }

        [XmlAttribute("Section")]
        public string Section { get; set; }

        [XmlAttribute("SubSection")]
        public string SubSection { get; set; }

        [XmlAttribute("DZone")]
        public string DZone { get; set; }

        [XmlAttribute("Description")]
        public string Description { get; set; }

        [XmlAttribute("Solution")]
        public string Solution { get; set; }

        [XmlAttribute("Version")]
        public string Version { get; set; }

        [XmlAttribute("Sensible")]
        public bool Sensible { get; set; } = false;

        [XmlAttribute("NotEssentialRoute")]
        public string NotEssentialRoute { get; set; }

        [XmlAttribute("CalculatedWithErrors")]
        public bool CalculatedWithErrors { get; set; } = false;
    }

    /// <summary>
    /// Represents a list of logs with a language attribute.
    /// </summary>
    public class AgLOG_LogsList
    {
        [XmlAttribute("Language")]
        public string Language { get; set; }
    }


    /// <summary>
    /// Represents an error log entry with attributes such as Description, DZone, DetectedBy, DateWithTime, and MessageType.
    /// </summary>
    public class AgLOG_Error
    {
        [XmlAttribute("Description")]
        public string Description { get; set; }

        [XmlAttribute("DZone")]
        public string DZone { get; set; }

        [XmlAttribute("DetectedBy")]
        public string DetectedBy { get; set; }

        [XmlAttribute("DateWithTime")]
        public DateTime DateWithTime { get; set; }

        [XmlAttribute("MessageType")]
        public string MessageType { get; set; }
    }

    /// <summary>
    /// Represents a warning log entry with attributes such as Description, DZone, DetectedBy, DateWithTime, and MessageType.
    /// </summary>
    public class AgLOG_ObjectDescription
    {
        [XmlAttribute("ObjectType")]
        public string ObjectType { get; set; }

        [XmlAttribute("ObjectTag")]
        public string ObjectTag { get; set; }

        [XmlAttribute("InitialValue")]
        public string InitialValue { get; set; }

        [XmlAttribute("ModifiedValue")]
        public string ModifiedValue { get; set; }
    }

    /// <summary>
    /// A collection of simple types used in the Geometrical Harness XML schema.
    /// </summary>
    public class SimpleTypes
    {
        [XmlType("tGH_Description")]
        public class TGH_Description
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Coordinate")]
        public class TGH_Coordinate
        {
            [XmlText]
            public double Value { get; set; }
        }

        [XmlType("tGH_AttributeValue")]
        public class TGH_AttributeValue
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_AttributeName")]
        public class TGH_AttributeName
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Splice_List")]
        public class TGH_Splice_List
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Equipment_List")]
        public class TGH_Equipment_List
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_SymbolName")]
        public class TGH_SymbolName
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_SymbolFamily")]
        public class TGH_SymbolFamily
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Class")]
        public class TGH_Class
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_PartNumber")]
        public class TGH_PartNumber
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_ProtectionType")]
        public class TGH_ProtectionType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_AccessoryCategory")]
        public class TGH_AccessoryCategory
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_IAType")]
        public class TGH_IAType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_EDB_InstanceID")]
        public class TGH_EDB_InstanceID
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_LengthUnit")]
        public class TGH_LengthUnit
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_XSDVersion")]
        public class TGH_XSDVersion
        {
            [XmlText]
            public decimal Value { get; set; }
        }

        [XmlType("tGH_DZone")]
        public class TGH_DZone
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_VersionNumber")]
        public class TGH_VersionNumber
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_VersionStatus")]
        public class TGH_VersionStatus
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Tag")]
        public class TGH_Tag
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_ExtendedTag")]
        public class TGH_ExtendedTag
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_BranchTag")]
        public class TGH_BranchTag
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_PortID")]
        public class TGH_PortID
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Section")]
        public class TGH_Section
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Text")]
        public class TGH_Text
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_ConnectiveDeviceType")]
        public class TGH_ConnectiveDeviceType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_ConnectorType")]
        public class TGH_ConnectorType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_NodeType")]
        public class TGH_NodeType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_PortType")]
        public class TGH_PortType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_EnvironmentalZone")]
        public class TGH_EnvironmentalZone
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Segregation")]
        public class TGH_Segregation
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_SolutionNumber")]
        public class TGH_SolutionNumber
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_YesNo")]
        public class TGH_YesNo
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_XMLSourceName")]
        public class TGH_XMLSourceName
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_XMLSourceVersion")]
        public class TGH_XMLSourceVersion
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_RemarkValue")]
        public class TGH_RemarkValue
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_CC_MaxSpare")]
        public class TGH_CC_MaxSpare
        {
            [XmlText]
            public double Value { get; set; }
        }

        [XmlType("tGH_CodingValue")]
        public class TGH_CodingValue
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_CodingType")]
        public class TGH_CodingType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_EquipmentCenterRequirement")]
        public class TGH_EquipmentCenterRequirement
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_SubSectionRequirement")]
        public class TGH_SubSectionRequirement
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_LocationType")]
        public class TGH_LocationType
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_Side")]
        public class TGH_Side
        {
            [XmlText]
            public string Value { get; set; }
        }

        [XmlType("tGH_NonNegativeDouble")]
        public class TGH_NonNegativeDouble
        {
            [XmlText]
            public double Value { get; set; }
        }

        [XmlType("tGH_DateTime")]
        public class TGH_DateTime
        {
            [XmlText]
            public DateTime Value { get; set; }
        }

    }

    /// <summary>
    /// Represents the main geometrical harness element with user attributes, branches, devices, port nodes, remarks, and logs.
    /// </summary>
    public class CtGH_GeometricalHarness
    {
        [XmlElement("UserAttribute")]
        public List<CtGH_UserAttribute> UserAttributes { get; set; }

        [XmlElement("GeometricalHarnessBranchesList")]
        public CtGH_GeometricalHarnessBranchesList GeometricalHarnessBranchesList { get; set; }

        [XmlElement("ConnectiveDevicesList")]
        public CtGH_ConnectiveDevicesList ConnectiveDevicesList { get; set; }

        [XmlElement("PortNodesList")]
        public CtGH_PortNodesList PortNodesList { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlElement("LogsList")]
        public CLOG_Logs LogsList { get; set; }

        [XmlAttribute("LH_Based")]
        public bool LH_Based { get; set; } = false;

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a user-defined attribute with a name and value.
    /// </summary>
    public class CtGH_UserAttribute
    {
        [XmlAttribute("AttributeName")]
        public string AttributeName { get; set; }

        [XmlAttribute("AttributeValue")]
        public string AttributeValue { get; set; }
    }

    /// <summary>
    /// Represents a list of geometrical harness branches.
    /// </summary>
    public class CtGH_GeometricalHarnessBranchesList
    {
        [XmlElement("GeometricalHarnessBranch")]
        public List<CtGH_GeometricalHarnessBranch> GeometricalHarnessBranches { get; set; }
    }

    /// <summary>
    /// Represents a list of connective devices.
    /// </summary>
    public class CtGH_ConnectiveDevicesList
    {
        [XmlElement("ConnectiveDevice")]
        public List<CtGH_ConnectiveDevice> ConnectiveDevices { get; set; }
    }

    /// <summary>
    /// Represents a list of port nodes.
    /// </summary>
    public class CtGH_PortNodesList
    {
        [XmlElement("PortNode")]
        public List<CtGH_PortNode> PortNodes { get; set; }
    }

    /// <summary>
    /// Represents a port node with port links, remarks, and various attributes such as Tag, NodeType, OverlappedSleeve, and Shared.
    /// </summary>
    public class CtGH_PortNode
    {
        [XmlElement("PortLink")]
        public List<CtGH_PortLink> PortLinks { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlAttribute("Tag")]
        public string Tag { get; set; }

        [XmlAttribute("NodeType")]
        public string NodeType { get; set; }

        [XmlAttribute("OverlappedSleeve")]
        public bool OverlappedSleeve { get; set; } = false;

        [XmlAttribute("Shared")]
        public string Shared { get; set; } = "No";

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a Remark with attributes such as RemarkValue, Origin, and DocumentReference.
    /// </summary>
    public class CtGH_Remark
    {
        [XmlAttribute("RemarkValue")]
        public string RemarkValue { get; set; }

        [XmlAttribute("Origin")]
        public string Origin { get; set; }

        [XmlAttribute("DocumentReference")]
        public string DocumentReference { get; set; }
    }


    /// <summary>
    /// Represents a Logs element containing lists of errors, warnings, and information messages, along with a language attribute.
    /// </summary>
    public class CLOG_Logs
    {
        [XmlElement("ErrorsList")]
        public CLOG_Errors ErrorsList { get; set; }

        [XmlElement("WarningsList")]
        public CLOG_Warnings WarningsList { get; set; }

        [XmlElement("InformationsList")]
        public CLOG_Informations InformationsList { get; set; }

        [XmlAttribute("Language")]
        public string Language { get; set; }
    }

    /// <summary>
    /// Represents a list of error messages.
    /// </summary>
    public class CLOG_Errors
    {
        [XmlElement("Error")]
        public List<CLOG_Message> Errors { get; set; }
    }

    /// <summary>
    /// Represents a list of warning messages.
    /// </summary>
    public class CLOG_Warnings
    {
        [XmlElement("Warning")]
        public List<CLOG_Message> Warnings { get; set; }
    }

    /// <summary>
    /// Represents a list of informational messages.
    /// </summary>
    public class CLOG_Informations
    {
        [XmlElement("Information")]
        public List<CLOG_Message> Informations { get; set; }
    }

    /// <summary>
    /// Represents a log message with attributes such as Description, DZone, DetectedBy, DateWithTime, MessageType, ID, and lists of object descriptions and message parameters.
    /// </summary>
    public class CLOG_Message
    {
        [XmlElement("ObjectDescription")]
        public List<CLOG_ObjectDescription> ObjectDescriptions { get; set; }

        [XmlElement("MessageParametersList")]
        public CLOG_MessageParametersList MessageParametersList { get; set; }

        [XmlAttribute("Description")]
        public string Description { get; set; }

        [XmlAttribute("DZone")]
        public string DZone { get; set; }

        [XmlAttribute("DetectedBy")]
        public string DetectedBy { get; set; }

        [XmlAttribute("DateWithTime")]
        public DateTime DateWithTime { get; set; }

        [XmlAttribute("MessageType")]
        public string MessageType { get; set; }

        [XmlAttribute("ID")]
        public string ID { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a list of message parameters.
    /// </summary>
    public class CLOG_MessageParametersList
    {
        [XmlElement("MessageParameter")]
        public List<CLOG_MessageParameter> MessageParameters { get; set; }
    }

    /// <summary>
    /// Represents a message parameter with a value and any additional attributes.
    /// </summary>
    public class CLOG_MessageParameter
    {
        [XmlAttribute("Value")]
        public string Value { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a description of an object involved in a log message, including its type, tag, initial value, modified value, and any additional attributes.
    /// </summary>
    public class CLOG_ObjectDescription
    {
        [XmlAttribute("ObjectType")]
        public string ObjectType { get; set; }

        [XmlAttribute("ObjectTag")]
        public string ObjectTag { get; set; }

        [XmlAttribute("InitialValue")]
        public string InitialValue { get; set; }

        [XmlAttribute("ModifiedValue")]
        public string ModifiedValue { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// A string type that can hold up to 255 characters.
    /// </summary>
    public class TLOG_String0To255
    {
        [XmlText]
        public string Value { get; set; }
    }

    /// <summary>
    /// A decimal type representing the XSD version.
    /// </summary>
    public class TLOG_XSDVersion
    {
        [XmlText]
        public decimal Value { get; set; }
    }

    /// <summary>
    /// Represents a branch in a geometrical harness with user attributes, segments, ports, remarks, and any additional attributes.
    /// </summary>
    public class CtGH_GeometricalHarnessBranch
    {
        [XmlElement("UserAttribute")]
        public List<CtGH_UserAttribute> UserAttributes { get; set; }

        [XmlElement("Segment")]
        public List<CtGH_Segment> Segments { get; set; }

        [XmlElement("Port")]
        public List<CtGH_Port> Ports { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a connective device in a geometrical harness with user attributes, accessories, ports, remarks, and various attributes such as Tag, Label, MatingTag, Type, ConnectorType, PartNumber, and more.
    /// </summary>
    public class CtGH_ConnectiveDevice
    {
        [XmlElement("UserAttribute")]
        public List<CtGH_UserAttribute> UserAttributes { get; set; }

        [XmlElement("Accessory")]
        public List<CtGH_Accessory> Accessories { get; set; }

        [XmlElement("Port")]
        public List<CtGH_Port> Ports { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlAttribute("Tag")]
        public string Tag { get; set; }

        [XmlAttribute("Label")]
        public string Label { get; set; }

        [XmlAttribute("MatingTag")]
        public string MatingTag { get; set; }

        [XmlAttribute("Type")]
        public string Type { get; set; }

        [XmlAttribute("ConnectorType")]
        public string ConnectorType { get; set; }

        [XmlAttribute("PartNumber")]
        public string PartNumber { get; set; }

        [XmlAttribute("Segregation")]
        public string Segregation { get; set; }

        [XmlAttribute("ParentTag")]
        public string ParentTag { get; set; }

        [XmlAttribute("LocationTag")]
        public string LocationTag { get; set; }

        [XmlAttribute("Class")]
        public string Class { get; set; }

        [XmlAttribute("SymbolName")]
        public string SymbolName { get; set; }

        [XmlAttribute("SymbolFamily")]
        public string SymbolFamily { get; set; }

        [XmlAttribute("ParentType")]
        public string ParentType { get; set; }

        [XmlAttribute("ExtraLength")]
        public double ExtraLength { get; set; }

        [XmlAttribute("MountedOnHarness")]
        public string MountedOnHarness { get; set; } = "Yes";

        [XmlAttribute("DeliveredWithHarness")]
        public string DeliveredWithHarness { get; set; } = "Yes";

        [XmlAttribute("ContactsMounted")]
        public string ContactsMounted { get; set; } = "Yes";

        [XmlAttribute("StudDiameter")]
        public double StudDiameter { get; set; }

        [XmlAttribute("CodingType")]
        public string CodingType { get; set; }

        [XmlAttribute("CodingValue")]
        public string CodingValue { get; set; }

        [XmlAttribute("EquipmentCenterRequirement")]
        public string EquipmentCenterRequirement { get; set; }

        [XmlAttribute("SubSectionRequirement")]
        public string SubSectionRequirement { get; set; }

        [XmlAttribute("LocationType")]
        public string LocationType { get; set; }

        [XmlAttribute("ParentDeliveredWithHarness")]
        public string ParentDeliveredWithHarness { get; set; }

        [XmlAttribute("ParentMountedOnHarness")]
        public string ParentMountedOnHarness { get; set; }

        [XmlAttribute("Side")]
        public string Side { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a segment in a geometrical harness with accessories, splice/equipment zones, user attributes, remarks, and any additional attributes.
    /// </summary>
    public class CtGH_Segment
    {
        [XmlElement("Accessory")]
        public List<CtGH_Accessory> Accessories { get; set; }

        [XmlElement("Sp_Float_Eq_Zone")]
        public CtGH_Sp_Float_Eq_Zone SpFloatEqZone { get; set; }

        [XmlElement("UserAttribute")]
        public List<CtGH_UserAttribute> UserAttributes { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a port in a geometrical harness with accessories, splice/equipment zones, remarks, and any additional attributes.
    /// </summary>
    public class CtGH_Port
    {
        [XmlElement("Accessory")]
        public List<CtGH_Accessory> Accessories { get; set; }

        [XmlElement("Sp_Float_Eq_Zone")]
        public CtGH_Sp_Float_Eq_Zone SpFloatEqZone { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a splice or equipment zone in a geometrical harness with attributes such as Tag, Type, Length, SpliceList, EquipmentList, StaggeringValue, SpacingValue, and AllowSpliceCompression.
    /// </summary>
    public class CtGH_Sp_Float_Eq_Zone
    {
        [XmlAttribute("Tag")]
        public string Tag { get; set; }

        [XmlAttribute("Type")]
        public string Type { get; set; } = "All";

        [XmlAttribute("Length")]
        public double Length { get; set; }

        [XmlAttribute("Splice_List")]
        public string SpliceList { get; set; }

        [XmlAttribute("Equipment_List")]
        public string EquipmentList { get; set; }

        [XmlAttribute("StaggeringValue")]
        public double StaggeringValue { get; set; }

        [XmlAttribute("SpacingValue")]
        public double SpacingValue { get; set; }

        [XmlAttribute("AllowSpliceCompression")]
        public string AllowSpliceCompression { get; set; } = "No";

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents an accessory in a geometrical harness with user attributes, remarks, and various attributes such as Type, PartNumber, Quantity, Label, InsideHarness, Diameter, Thickness, Width, Length, Text1, Text2, Text3, Segregation, Category, ColorMarker, ProtectionOrder, and any additional attributes.
    /// </summary>
    public class CtGH_Accessory
    {
        [XmlElement("UserAttribute")]
        public List<CtGH_UserAttribute> UserAttributes { get; set; }

        [XmlElement("Remark")]
        public List<CtGH_Remark> Remarks { get; set; }

        [XmlAttribute("Type")]
        public string Type { get; set; }

        [XmlAttribute("PartNumber")]
        public string PartNumber { get; set; }

        [XmlAttribute("Quantity")]
        public double Quantity { get; set; } = 1;

        [XmlAttribute("Label")]
        public string Label { get; set; }

        [XmlAttribute("Inside_Harness")]
        public string InsideHarness { get; set; }

        [XmlAttribute("Diameter")]
        public double Diameter { get; set; }

        [XmlAttribute("Thickness")]
        public double Thickness { get; set; }

        [XmlAttribute("Width")]
        public double Width { get; set; }

        [XmlAttribute("Length")]
        public double Length { get; set; }

        [XmlAttribute("Text1")]
        public string Text1 { get; set; }

        [XmlAttribute("Text2")]
        public string Text2 { get; set; }

        [XmlAttribute("Text3")]
        public string Text3 { get; set; }

        [XmlAttribute("Segregation")]
        public string Segregation { get; set; }

        [XmlAttribute("Category")]
        public string Category { get; set; }

        [XmlAttribute("ColorMarker")]
        public string ColorMarker { get; set; }

        [XmlAttribute("ProtectionOrder")]
        public int ProtectionOrder { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }

    /// <summary>
    /// Represents a link to a port in a geometrical harness with a PortID attribute and any additional attributes.
    /// </summary>
    public class CtGH_PortLink
    {
        [XmlAttribute("PortID")]
        public string PortID { get; set; }

        [XmlAnyAttribute]
        public XmlAttribute[] AnyAttributes { get; set; }
    }
}
