﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using ALT_Data_Model.Accessories_Data_Model;
using ALT_Logging;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using PARTITF;
using System;
using System.Collections.Generic;
using System.Windows;
using INFITF;
using CatiaDotNet.CommonServices;
using OpenTK;
using ProductStructureTypeLib;
using MECMOD;

namespace ALT_Data_Model
{
    /// <summary>
    /// The class is used to prepare data for accessorization
    /// </summary>
    public class AccessorizationDataPreparation
    {
        private static AccessorizationDataPreparation _AccessorizationPreparation;
        private List<CableGland> _cableGlandList = null;
        private List<string> _couplerList = null;
        private List<Projet3PL> _3PLFile = null;
        private List<Coupler> _coupler = null;
        private List<CombinedCouplers> _combinedCoupler = null;
        private List<YCoupler> _yCoupler = null;
        private List<TerminalSleev> _terminalSleev = null;
        public IList<SelectedBundleSegment> IBundleSegments { get; set; }
        public CATIEhiMultiBranchable MultiBranchable { get; set; }
        public Product CatiaProduct { get; set; }

        public List<CableGland> CableGlandList
        {
            get
            {
                return _cableGlandList;
            }
        }

        /// <summary>
        /// Get instance of AccessorizationDataPreparation class
        /// </summary>
        /// <returns> AccessorizationDataPreparation class object </returns>
        public static AccessorizationDataPreparation GetInstance()
        {
            if (_AccessorizationPreparation == null)
                _AccessorizationPreparation = new AccessorizationDataPreparation();
            return _AccessorizationPreparation;
        }

        /// <summary>
        /// Read cable gland from json file
        /// </summary>
        /// <param name="accessoryFilePath"> path to read the cable gland data from the json file </param>
        /// <returns> List of cable gland </returns>
        public List<CableGland> ReadCableGland(string accessoryFilePath)
        {
            alt_JsonReaderService jsonReaderService = alt_JsonReaderService.GetInstance();
            _cableGlandList = jsonReaderService.ReadCableGland(accessoryFilePath);
            return _cableGlandList;
        }

        /// <summary>
        /// Read front page from the Accessories Guideline json file
        /// </summary>
        /// <param name="accessoryFilePath">Accessories Guideline json file path</param>
        /// <returns> List of accessory front page data </returns>
        public List<string> ReadAccessoryFrontPage(string accessoryFilePath)
        {
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            _couplerList = alt_JsonReaderService.ReadFrontPage(accessoryFilePath);
            return _couplerList;

        }

        /// <summary>
        /// Read DTRs from the sheet name from the Accessories Guideline excel file
        /// </summary>
        /// <param name="accessoryFilePath"> Accessories Guideline excel file path </param>
        /// <param name="sheetName"> sheet name from the excel file</param>
        /// <returns> List of DTRs </returns>
        public List<string> ReadOnlyDTRs(string accessoryFilePath, string sheetName)
        {
            alt_ExcelReaderService excelReader = alt_ExcelReaderService.GetInstance();
            return excelReader.ReadOnlyDTRs(accessoryFilePath, sheetName);
        }

        /// <summary>
        /// Read 3PL_Projet from the excel file
        /// </summary>
        /// <param name="accessoryFilePath"> 3PL_Projet excel file path </param>
        public void Read3PLFile(string accessoryFilePath)
        {
            alt_ExcelReaderService excelReader = alt_ExcelReaderService.GetInstance();
            _3PLFile = excelReader.Read3PLFile(accessoryFilePath);
        }

        /// <summary>
        /// Import DTR from DMA
        /// </summary>
        /// <param name="inputs"> the inputs required to get DTR</param>
        /// <returns> Status of import </returns>
        public string ImportDTRFromDMA(List<string> inputs)
        {
            return CheckIn3PLProject(inputs[0], inputs[1]);

        }

        /// <summary>
        /// Select MultiBranchable from CATIA
        /// </summary>
        /// <returns></returns>
        public string SelectMultiBranchable()
        {
            var log = $"--- Select MultiBranchable: ";
            alt_Logging_class.AddMessage(log);

            string multiBranchableName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            Product selectedProduct = adapter.SelectElementsInCatia("Select your harness");
            if (adapter.IsDesignModeApplied(selectedProduct))
            {
                if (!ehiAdapter.IsMultiBranchable(selectedProduct) == true)
                {
                    selectedProduct = null;
                    MessageBoxOnTop.BringMessageBoxToTop("Selected product is not a multiBranchable, Please select again", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
                else
                {
                    CatiaProduct = selectedProduct;
                    multiBranchableName = selectedProduct.get_Name();
                    MultiBranchable = (CATIEhiMultiBranchable)selectedProduct;
                    log = $"--- Selected MultiBranchable: {multiBranchableName}";
                    alt_Logging_class.AddMessage(log);
                    alt_Logging_class.AddMessage("");
                }
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected multibranchable", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            return multiBranchableName;
        }

        /// <summary>
        /// Check in 3PL project for the selected DTR in UI
        /// </summary>
        /// <param name="harnessName"> loaded harness name </param>
        /// <param name="dtrValue"> DTR to be added</param>
        /// <returns> status of the selected DTR </returns>
        public string CheckIn3PLProject(string harnessName, string dtrValue) 
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_WindowTracker.BringApplicationToFront("CNEXT");
            object[] inputObject = new object[1] { "Face" };
            object[] selectedPoint = new object[3];
            SelectedElement selectedProduct = adapter.SelectHybridshapeInCatia("Select a rib", inputObject, ref selectedPoint);
            Vector3d newPosition = new Vector3d(
                Convert.ToDouble(selectedPoint[0]),
                Convert.ToDouble(selectedPoint[1]),
                Convert.ToDouble(selectedPoint[2])
            );
            Matrix4d prdMatrix = CatiaPosition.GetMatrix4d(newPosition, new Vector3d(1, 0, 0), new Vector3d(0, 1, 0), new Vector3d(0, 0, 1));
            object[] Abs_Position = new object[12];
            Abs_Position = adapter.ConvertMatrixToArray(prdMatrix);
            string status = adapter.AddFromDMAForAccesssorization(dtrValue + ":-", "", harnessName, Abs_Position);
            if (status.Contains("Success"))
            {
                MessageBox.Show("DTR imported successfully: " + dtrValue, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return "SUCCESS";
            }
            else
            {
                MessageBox.Show("DTR not found in dma: " + dtrValue, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return "FAILURE";
            }
        }

        /// <summary>
        /// Select single bundle segment from CATIA
        /// </summary>
        /// <returns> The values of the properties in the selected Bundle segment</returns>
        public List<string> SelectSingleBundleSegment()
        {
            var log = $"--- Select Branchable: ";
            alt_Logging_class.AddMessage(log);
            List<string> returnValues = new List<string>();
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            double diameter = 0.0;

            SelectedElement selectedElem = adapter.SelectRibInCatia("Select your Branchable");
            if (selectedElem == null)
                return new List<string>();

            Rib rib = selectedElem.Value as Rib;
            if (rib == null) 
                return new List<string>();

            CATIEhiBundleSegment cATIEhiBundleSegment = ehiAdapter.FindBundleSegmentFromRib(MultiBranchable, rib);
            if (cATIEhiBundleSegment != null)
            {
                SelectedBundleSegment selectedBundleSegments = new SelectedBundleSegment(cATIEhiBundleSegment);
                string bundleSegmentName = EhiBundleSegment.GetName(cATIEhiBundleSegment);
                returnValues.Add(bundleSegmentName);
                diameter = cATIEhiBundleSegment.GetDiameter();
                returnValues.Add((diameter * 1000).ToString());
                return returnValues;
            }
            else
            {
                return new List<string>();
            }
        }

        /// <summary>
        /// Select sleeve from CATIA
        /// </summary>
        /// <returns> Name of sleev selected </returns>
        public string SelectSleeve()
        {
            var log = $"--- Select sleev: ";
            alt_Logging_class.AddMessage(log);

            string selectedSleevName = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            HybridBody hybridBody = adapter.SelectHbyInCatia("Select your Sleeve");
            selectedSleevName = hybridBody.get_Name();
            return selectedSleevName;
        }

    }

    /// <summary>
    /// Class to store the selected bundle segment properties
    /// </summary>
    public class SelectedBundleSegment
    {
        public CATIEhiBundleSegment CATIEhiBundleSegment;
        public string bundleSegmentName;
        public double diameter;
        public double bendRadius;
        public string Sleeve;
        public CATIEhiBranchable Branchable;
        public SelectedBundleSegment(CATIEhiBundleSegment ehiBundleSegment)
        {
            CATIEhiBundleSegment = ehiBundleSegment;
            RetrieveProperties();
        }

        /// <summary>
        /// Retrieve properties of the selected bundle segment
        /// </summary>
        private void RetrieveProperties()
        {
            diameter = CATIEhiBundleSegment.GetDiameter() * 1000;
            bendRadius = CATIEhiBundleSegment.GetBendRadius();
            Branchable = EhiBundleSegment.GetBranchable(CATIEhiBundleSegment);
            bundleSegmentName = EhiBranchable.GetName(Branchable) + "\\"
                + EhiBundleSegment.GetName(CATIEhiBundleSegment);
        }
    }
}
