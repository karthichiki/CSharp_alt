﻿using ALT_Data_Model.Electrical;
using OpenTK;
using System;
using System.Collections.Generic;
using System.Globalization;

namespace ALT_Data_Model.UnityDataModel
{
    #region CreateBranchInput
    /// <summary>
    /// Data model for sending branch creation commands and associated data to Unity.
    /// </summary>
    public class UnityData
    {
        public string cmd { get; set; }
        public Data data { get; set; }
        public UnityData(string command)
        {
            cmd = command;
        }
    }

    /// <summary>
    /// Holds the product name and branch details for a specific branch to be created in Unity.
    /// </summary>
    public class Data
    {
        public string productName { get; set; }
        public Branch branch { get; set; }
        public Data(string productName)
        {
            this.productName = productName;
        }
    }

    /// <summary>
    /// Represents a branch in a harness, including start and end points, intermediate waypoints,
    /// </summary>
    public class Branch
    {
        public StartPoint startPoint { get; set; }
        public EndPoint endPoint { get; set; }
        public List<MiddlePoint> middlePoints { get; set; }
        public List<PathPoint> pathPoints { get; set; }
        public double diameter { get; set; }
        public double bendRadius { get; set; }
        public string cableClass { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="Branch"/> class with specified parameters.
        /// </summary>
        /// <param name="startExtremity"></param>
        /// <param name="endExtremity"></param>
        /// <param name="midPoints"></param>
        /// <param name="diameter"></param>
        /// <param name="bendRadius"></param>
        /// <param name="cableClass"></param>
        public Branch(Extremity startExtremity, Extremity endExtremity, List<IntermediateWayPoint> midPoints,
             double diameter, double bendRadius, string cableClass)
        {
            startPoint = new StartPoint(startExtremity);
            endPoint = new EndPoint(endExtremity);
            middlePoints = new List<MiddlePoint>();
            if(midPoints != null)
            {
                foreach (IntermediateWayPoint interWayPoint in midPoints)
                {
                    if (interWayPoint == null)
                        continue;

                    if(interWayPoint.IntermediateWayPointType != IntermediateWayPointType.EhiSupport)
                        interWayPoint.ChangePosition(diameter);

                    MiddlePoint middlePoint = new MiddlePoint(interWayPoint);
                    middlePoints.Add(middlePoint);
                }
            }
            
            this.diameter = diameter;
            this.bendRadius = bendRadius;
            this.cableClass = cableClass;
        }
    }

    /// <summary>
    /// Represents the starting point of a branch, including position, tangency, type, and properties.
    /// </summary>
    public class StartPoint
    {
        public Position position { get; set; }
        public Direction tangency { get; set; }
        public double tangencyDistance { get; set; }
        public string type { get; set; }
        public List<string> properties { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="StartPoint"/> class using the provided extremity data.
        /// </summary>
        /// <param name="extremity"> extrimity object </param>
        public StartPoint(Extremity extremity)
        {
            if(extremity != null)
            {
                if(extremity.Coordinates != null && extremity.Coordinates.Count > 2)
                    position = new Position(extremity.Coordinates);

                if (extremity.TangentDirection != null && extremity.TangentDirection.Count > 2)
                    tangency = new Direction(extremity.TangentDirection);

                type = extremity.ExtremityType.ToString();

                properties = new List<string>();
                properties = extremity.Properties;
                tangencyDistance = extremity.TangencyDistance;
            }
        }
    }

    /// <summary>
    /// Represents the ending point of a branch, including position, tangency, type, and properties.
    /// </summary>
    public class EndPoint
    {
        public Position position { get; set; }
        public Direction tangency { get; set; }
        public double tangencyDistance { get; set; }
        public string type { get; set; }
        public List<string> properties { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="EndPoint"/> class using the provided extremity data.
        /// </summary>
        /// <param name="extremity"> extrimity object </param>
        public EndPoint(Extremity extremity)
        {
            if (extremity != null)
            {
                if (extremity.Coordinates != null && extremity.Coordinates.Count > 2)
                    position = new Position(extremity.Coordinates);

                if (extremity.TangentDirection != null && extremity.TangentDirection.Count > 2)
                    tangency = new Direction(extremity.TangentDirection);

                type = extremity.ExtremityType.ToString();

                properties = new List<string>();
                properties = extremity.Properties;
                tangencyDistance = extremity.TangencyDistance;
            }
        }
    }

    /// <summary>
    /// Represents an intermediate waypoint in a branch, including position, tangency, name, and properties.
    /// </summary>
    public class MiddlePoint
    {
        public string name { get; set; }
        public Position position { get; set; }
        public Direction tangency { get; set; }
        public double tangencyDistance { get; set; }
        public List<string> properties { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="MiddlePoint"/> class using the provided intermediate waypoint data.
        /// </summary>
        /// <param name="extremity"> extrimity object </param>
        public MiddlePoint(IntermediateWayPoint extremity)
        {
            if (extremity != null)
            {
                if (extremity.Coordinates != null && extremity.Coordinates.Count > 2)
                    position = new Position(extremity.Coordinates);

                if (extremity.TangentDirection != null && extremity.TangentDirection.Count > 2)
                    tangency = new Direction(extremity.TangentDirection);

                name = extremity.Name;

                properties = new List<string>();
                properties = extremity.Properties;
                tangencyDistance = extremity.TangencyDistance;
            }
        }
    }

    /// <summary>
    /// Represents a point along the path of a branch, including position, cable tray assignment,
    /// </summary>
    public class PathPoint
    {
        public Position position { get; set; }
        public string assignedCableTray { get; set; }
        public string partDescription { get; set; }
        public Direction routingAreaDirection { get; set; }
        public Direction routingAreaNormal { get; set; }
        public Direction tangency { get; set; }
        public string parentObjectType { get; set; }
        public string isSupport { get; set; }

        /// <summary>
        /// Tangent direction vector components (normalized if supplied).
        /// </summary>
        /// <returns> 3d vector for the tangent </returns>
        public Vector3d TangentDirection()
        {
            //return new Vector3d(routingAreaDirection.x, routingAreaDirection.y, routingAreaDirection.z);
            return new Vector3d(tangency.x, tangency.y, tangency.z);
        }

        /// <summary>
        /// Normal direction vector components (normalized if supplied).
        /// </summary>
        /// <returns> 3d vector for the normal </returns>
        public Vector3d NormalDirection()
        {
            return new Vector3d(routingAreaNormal.x, routingAreaNormal.y, routingAreaNormal.z);
        }

        /// <summary>
        /// populate the required parqmeters from the intermediate waypoint
        /// </summary>
        /// <param name="interPoint"> Intermediate point object</param>
        public void CopyFromIntermediatePoint(IntermediateWayPoint interPoint)
        {
            if (routingAreaDirection == null)
                routingAreaDirection = new Direction(interPoint.TangentDirection);
            else
            {
                routingAreaDirection.x = interPoint.TangentDirection[0];
                routingAreaDirection.y = interPoint.TangentDirection[1];
                routingAreaDirection.z = interPoint.TangentDirection[2];
            }

            if (routingAreaNormal == null)
                routingAreaNormal = new Direction(interPoint.NormalDirection);
            else
            {
                routingAreaNormal.x = interPoint.NormalDirection[0];
                routingAreaNormal.y = interPoint.NormalDirection[1];
                routingAreaNormal.z = interPoint.NormalDirection[2];
            }
        }
    }

    /// <summary>
    /// Represents a 3D position with X, Y, and Z coordinates.
    /// </summary>
    public class Position
    {
        public double x { get; set; }
        public double y { get; set; }
        public double z { get; set; }

        public Position(List<double> coordinates)
        {
            if (coordinates != null && coordinates.Count > 2)
            {
                x = coordinates[0];
                y = coordinates[1];
                z = coordinates[2];
            }
        }
    }

    /// <summary>
    /// Represents a 3D direction vector with X, Y, and Z components.
    /// </summary>
    public class Direction
    {
        public double x { get; set; }
        public double y { get; set; }
        public double z { get; set; }

        public Direction(List<double> coordinates)
        {
            if (coordinates != null && coordinates.Count > 2)
            {
                x = coordinates[0];
                y = coordinates[1];
                z = coordinates[2];
            }
        }
    }

    #endregion

    #region PersistenceBranchInput

    /// <summary>
    /// Data model for persisting branch data in Unity.
    /// </summary>
    public class UnityDataPersist
    {
        public string cmd { get; set; }
        public List<DataPersist> data { get; set; }
        public UnityDataPersist(string command)
        {
            cmd = command;
            data = new List<DataPersist>();
        }
    }

    /// <summary>
    /// Holds the branch path and associated path points for persistence in Unity.
    /// </summary>
    public class DataPersist
    {
        public string branchPath { get; set; }
        public List<PathPointPersist> pathPoints { get; set; }
        public double diameter { get; set; }

        //public double bendRadiusRatio { get; set; }
        public double bendRadius { get; set; }
        public string cableClass { get; set; }
        public ColorData colorData { get; set; }

        /// <summary>
        /// Initializes a new instance of the <see cref="DataPersist"/> class with specified parameters.
        /// </summary>
        /// <param name="ipathPoints"></param>
        /// <param name="ibranchPath"></param>
        /// <param name="icolorData"></param>
        public DataPersist(List<PathPointPersist> ipathPoints, string ibranchPath, List<int> icolorData)
        {
            branchPath = ibranchPath;
            pathPoints = ipathPoints;
            if(icolorData != null && icolorData.Count > 2)
            {
                colorData = new ColorData();
                colorData.r = icolorData[0]/255;
                colorData.g = icolorData[1]/255;
                colorData.b = icolorData[2]/255;
                colorData.a = 1;

            }
        }
    }

    public class PathPointPersist
    {
        public Position position { get; set; }

        public PathPointPersist(List<double> points)
        {
            position = new Position(points);
        }
    }

    public class ColorData
    {
        public float r { get; set; }
        public float g { get; set; }
        public float b { get; set; }
        public float a { get; set; }
    }

    #endregion

    #region SplineFilter
    public class ParentObjectTypeItem
    {
        public string name { get; set; }
        public bool ignored { get; set; }
    }

    public class PathPointConfig
    {
        public List<ParentObjectTypeItem> parentObjectType { get; set; }
    }
    #endregion
}
