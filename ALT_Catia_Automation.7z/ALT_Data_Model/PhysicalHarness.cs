﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ALT_Data_Model.PH_Data_Model
{
    // using System.Xml.Serialization;
    // XmlSerializer serializer = new XmlSerializer(typeof(IGEXAOPHYSICALHARNESS));
    // using (StringReader reader = new StringReader(xml))
    // {
    //    var test = (IGEXAOPHYSICALHARNESS)serializer.Deserialize(reader);
    // }

    [XmlRoot(ElementName = "UserAttribute")]
    public class UserAttribute
    {

        [XmlAttribute(AttributeName = "AttributeName")]
        public string AttributeName { get; set; }

        [XmlAttribute(AttributeName = "AttributeValue")]
        public string AttributeValue { get; set; }
    }

    [XmlRoot(ElementName = "ConnectiveDevice")]
    public class ConnectiveDevice
    {

        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }

        [XmlAttribute(AttributeName = "MountedOnHarness")]
        public string MountedOnHarness { get; set; }

        [XmlAttribute(AttributeName = "DeliveredWithHarness")]
        public string DeliveredWithHarness { get; set; }

        [XmlAttribute(AttributeName = "ContactsMounted")]
        public string ContactsMounted { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "LocationTag")]
        public string LocationTag { get; set; }

        [XmlAttribute(AttributeName = "TT_NbPosition")]
        public int TTNbPosition { get; set; }

        [XmlAttribute(AttributeName = "ProvidedWithEquipment")]
        public string ProvidedWithEquipment { get; set; }

        [XmlAttribute(AttributeName = "CodingType")]
        public string CodingType { get; set; }

        [XmlElement(ElementName = "Shunt")]
        public List<Shunt> Shunt { get; set; }

        [XmlAttribute(AttributeName = "Label")]
        public string Label { get; set; }

        [XmlAttribute(AttributeName = "ParentTag")]
        public string ParentTag { get; set; }

        [XmlAttribute(AttributeName = "TB_NbPosition")]
        public int TBNbPosition { get; set; }

        [XmlAttribute(AttributeName = "TB_Position")]
        public int TBPosition { get; set; }

        [XmlAttribute(AttributeName = "StartXPosition")]
        public int StartXPosition { get; set; }

        [XmlAttribute(AttributeName = "GB_GroundCategory")]
        public string GBGroundCategory { get; set; }

        [XmlAttribute(AttributeName = "Mass")]
        public double Mass { get; set; }

        [XmlAttribute(AttributeName = "EstimatedCost")]
        public int EstimatedCost { get; set; }

        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }

        [XmlAttribute(AttributeName = "PN_Version")]
        public int PNVersion { get; set; }

        [XmlAttribute(AttributeName = "PN_Source")]
        public string PNSource { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "PN_Status")]
        public string PNStatus { get; set; }

        [XmlElement(ElementName = "Pin")]
        public List<Pin> Pin { get; set; }

        [XmlAttribute(AttributeName = "ElectricalType")]
        public string ElectricalType { get; set; }

        [XmlAttribute(AttributeName = "SymbolName")]
        public string SymbolName { get; set; }

        [XmlAttribute(AttributeName = "SymbolFamily")]
        public string SymbolFamily { get; set; }

        [XmlElement(ElementName = "Port")]
        public Port Port { get; set; }

        [XmlAttribute(AttributeName = "ParentDeliveredWithHarness")]
        public string ParentDeliveredWithHarness { get; set; }

        [XmlAttribute(AttributeName = "LocationType")]
        public string LocationType { get; set; }

        [XmlAttribute(AttributeName = "ParentType")]
        public string ParentType { get; set; }

        [XmlAttribute(AttributeName = "MatingTag")]
        public string MatingTag { get; set; }

        [XmlElement(ElementName = "ConnectiveAccessory")]
        public List<ConnectiveAccessory> ConnectiveAccessory { get; set; }

        [XmlAttribute(AttributeName = "Class")]
        public string Class { get; set; }

        [XmlAttribute(AttributeName = "ConnectivityType")]
        public string ConnectivityType { get; set; }
    }

    [XmlRoot(ElementName = "Pin")]
    public class Pin
    {

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "ManufacturerSignal")]
        public string ManufacturerSignal { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "ContactGauge")]
        public string ContactGauge { get; set; }

        [XmlAttribute(AttributeName = "Gender")]
        public string Gender { get; set; }

        [XmlAttribute(AttributeName = "InterfaceType")]
        public string InterfaceType { get; set; }

        [XmlAttribute(AttributeName = "SignalDirection")]
        public string SignalDirection { get; set; }

        [XmlAttribute(AttributeName = "SignalType")]
        public string SignalType { get; set; }

        [XmlAttribute(AttributeName = "SignalCategory")]
        public string SignalCategory { get; set; }

        [XmlAttribute(AttributeName = "PowerName")]
        public string PowerName { get; set; }

        [XmlAttribute(AttributeName = "MaxVoltageDrop")]
        public int MaxVoltageDrop { get; set; }

        [XmlAttribute(AttributeName = "Intensity")]
        public double Intensity { get; set; }

        [XmlAttribute(AttributeName = "IntensityMax")]
        public int IntensityMax { get; set; }

        [XmlAttribute(AttributeName = "IntensityBlocked")]
        public int IntensityBlocked { get; set; }

        [XmlAttribute(AttributeName = "Power")]
        public int Power { get; set; }
    }

    [XmlRoot(ElementName = "Shunt")]
    public class Shunt
    {

        [XmlElement(ElementName = "Pin")]
        public List<Pin> Pin { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }
    }

    [XmlRoot(ElementName = "Port")]
    public class Port
    {

        [XmlElement(ElementName = "PortAccessory")]
        public List<PortAccessory> PortAccessory { get; set; }

        [XmlAttribute(AttributeName = "X")]
        public string X { get; set; }

        [XmlAttribute(AttributeName = "Y")]
        public double Y { get; set; }

        [XmlAttribute(AttributeName = "Z")]
        public string Z { get; set; }

        [XmlAttribute(AttributeName = "PortType")]
        public string PortType { get; set; }

        [XmlAttribute(AttributeName = "PortID")]
        public string PortID { get; set; }
    }

    [XmlRoot(ElementName = "ConnectiveDevicesList")]
    public class ConnectiveDevicesList
    {

        [XmlElement(ElementName = "ConnectiveDevice")]
        public List<ConnectiveDevice> ConnectiveDevice { get; set; }
    }

    [XmlRoot(ElementName = "Wire")]
    public class Wire
    {

        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "Length")]
        public int Length { get; set; }

        [XmlAttribute(AttributeName = "Length_Status")]
        public string LengthStatus { get; set; }

        [XmlAttribute(AttributeName = "Gauge")]
        public string Gauge { get; set; }

        [XmlAttribute(AttributeName = "Wire_Type")]
        public string WireType { get; set; }

        [XmlAttribute(AttributeName = "Class")]
        public string Class { get; set; }

        [XmlAttribute(AttributeName = "Segregation")]
        public string Segregation { get; set; }

        [XmlAttribute(AttributeName = "TemperatureZone")]
        public int TemperatureZone { get; set; }

        [XmlAttribute(AttributeName = "Net")]
        public string Net { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }

        [XmlAttribute(AttributeName = "PN_Version")]
        public int PNVersion { get; set; }

        [XmlAttribute(AttributeName = "Material")]
        public string Material { get; set; }

        [XmlAttribute(AttributeName = "MaterialType")]
        public string MaterialType { get; set; }

        [XmlAttribute(AttributeName = "ExternalDiameter")]
        public double ExternalDiameter { get; set; }

        [XmlAttribute(AttributeName = "LinearMass")]
        public double LinearMass { get; set; }

        [XmlAttribute(AttributeName = "ProvidedWithEquipment")]
        public string ProvidedWithEquipment { get; set; }

        [XmlAttribute(AttributeName = "Color")]
        public string Color { get; set; }

        [XmlAttribute(AttributeName = "TagType")]
        public string TagType { get; set; }

        [XmlAttribute(AttributeName = "CableOrder")]
        public int CableOrder { get; set; }

        [XmlAttribute(AttributeName = "WireOrder")]
        public int WireOrder { get; set; }

        [XmlAttribute(AttributeName = "SourceType")]
        public string SourceType { get; set; }

        [XmlAttribute(AttributeName = "ManualAssignation")]
        public string ManualAssignation { get; set; }

        [XmlAttribute(AttributeName = "PN_Source")]
        public string PNSource { get; set; }

        [XmlAttribute(AttributeName = "XDirectionLength")]
        public int XDirectionLength { get; set; }

        [XmlAttribute(AttributeName = "NonProtectedXDirectionLength")]
        public int NonProtectedXDirectionLength { get; set; }

        [XmlAttribute(AttributeName = "ProtectedLength")]
        public int ProtectedLength { get; set; }

        [XmlAttribute(AttributeName = "BendRadius")]
        public int BendRadius { get; set; }

        [XmlAttribute(AttributeName = "PN_Status")]
        public string PNStatus { get; set; }

        [XmlAttribute(AttributeName = "Mass")]
        public string Mass { get; set; }
    }

    [XmlRoot(ElementName = "WiresList")]
    public class WiresList
    {

        [XmlElement(ElementName = "Wire")]
        public List<Wire> Wire { get; set; }

        [XmlElement(ElementName = "WireGroup")]
        public List<WireGroup> WireGroup { get; set; }
    }

    [XmlRoot(ElementName = "PartNumber")]
    public class PartNumber
    {

        [XmlAttribute(AttributeName = "PartNumber")]
        public string partNumber { get; set; }

        [XmlAttribute(AttributeName = "Quantity")]
        public int Quantity { get; set; }

        [XmlAttribute(AttributeName = "PN_Type")]
        public string PNType { get; set; }

        [XmlAttribute(AttributeName = "PN_Version")]
        public int PNVersion { get; set; }

        [XmlAttribute(AttributeName = "Cost")]
        public int Cost { get; set; }

        [XmlAttribute(AttributeName = "Mass")]
        public double Mass { get; set; }

        [XmlAttribute(AttributeName = "Unit")]
        public string Unit { get; set; }

        [XmlAttribute(AttributeName = "Manual")]
        public string Manual { get; set; }

        [XmlAttribute(AttributeName = "UnitType")]
        public string UnitType { get; set; }

        [XmlAttribute(AttributeName = "PN_Source")]
        public string PNSource { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "PN_Status")]
        public string PNStatus { get; set; }
    }

    [XmlRoot(ElementName = "EndFittingPartNumbers")]
    public class EndFittingPartNumbers
    {

        [XmlElement(ElementName = "PartNumber")]
        public PartNumber PartNumber { get; set; }
    }

    [XmlRoot(ElementName = "WireExtremity")]
    public class WireExtremity
    {

        [XmlElement(ElementName = "EndFittingPartNumbers")]
        public EndFittingPartNumbers EndFittingPartNumbers { get; set; }

        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }

        [XmlAttribute(AttributeName = "WireTag")]
        public string WireTag { get; set; }

        [XmlAttribute(AttributeName = "Pin")]
        public string Pin { get; set; }

        [XmlAttribute(AttributeName = "PinParent")]
        public string PinParent { get; set; }

        [XmlAttribute(AttributeName = "ParentTag")]
        public string ParentTag { get; set; }

        [XmlAttribute(AttributeName = "ShuntTag")]
        public string ShuntTag { get; set; }

        [XmlAttribute(AttributeName = "Side")]
        public string Side { get; set; }

        [XmlAttribute(AttributeName = "ConnectOrder")]
        public int ConnectOrder { get; set; }

        [XmlAttribute(AttributeName = "ContactNumber")]
        public int ContactNumber { get; set; }
    }

    [XmlRoot(ElementName = "WiresExtremitiesList")]
    public class WiresExtremitiesList
    {

        [XmlElement(ElementName = "WireExtremity")]
        public List<WireExtremity> WireExtremity { get; set; }
    }

    [XmlRoot(ElementName = "WireHarness")]
    public class WireHarness
    {

        [XmlElement(ElementName = "WiresList")]
        public WiresList WiresList { get; set; }

        [XmlElement(ElementName = "WiresExtremitiesList")]
        public WiresExtremitiesList WiresExtremitiesList { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "WiresNumber")]
        public int WiresNumber { get; set; }

        [XmlAttribute(AttributeName = "Segregation")]
        public string Segregation { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "Solution")]
        public int Solution { get; set; }

        [XmlAttribute(AttributeName = "Validity")]
        public string Validity { get; set; }

        [XmlAttribute(AttributeName = "VersionNb")]
        public string VersionNb { get; set; }

        [XmlAttribute(AttributeName = "ValidityType")]
        public string ValidityType { get; set; }

        [XmlAttribute(AttributeName = "LC_Status")]
        public string LCStatus { get; set; }

        [XmlAttribute(AttributeName = "Version")]
        public string Version { get; set; }
    }

    [XmlRoot(ElementName = "Segment")]
    public class Segment
    {

        [XmlElement(ElementName = "Protection")]
        public List<Protection> Protection { get; set; }

        [XmlAttribute(AttributeName = "PortID1")]
        public string PortID1 { get; set; }

        [XmlAttribute(AttributeName = "PortID2")]
        public string PortID2 { get; set; }

        [XmlAttribute(AttributeName = "ProtectionType")]
        public string ProtectionType { get; set; }

        [XmlAttribute(AttributeName = "Pressure")]
        public string Pressure { get; set; }

        [XmlAttribute(AttributeName = "LacingTape")]
        public string LacingTape { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "Length")]
        public int Length { get; set; }

        [XmlAttribute(AttributeName = "Diameter")]
        public double Diameter { get; set; }

        [XmlAttribute(AttributeName = "BendRadius")]
        public int BendRadius { get; set; }

        [XmlAttribute(AttributeName = "Ext_Diameter")]
        public double ExtDiameter { get; set; }

        [XmlAttribute(AttributeName = "EnvironmentalZone")]
        public string EnvironmentalZone { get; set; }

        [XmlAttribute(AttributeName = "GH_Diameter")]
        public double GHDiameter { get; set; }

        [XmlAttribute(AttributeName = "Int_Diameter")]
        public double IntDiameter { get; set; }

        [XmlAttribute(AttributeName = "DiameterStatus")]
        public string DiameterStatus { get; set; }

        [XmlAttribute(AttributeName = "LinearMass")]
        public double LinearMass { get; set; }

        [XmlAttribute(AttributeName = "CableBendRadius")]
        public int CableBendRadius { get; set; }
    }

    [XmlRoot(ElementName = "Protection")]
    public class Protection
    {

        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }

        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "Label")]
        public string Label { get; set; }

        [XmlAttribute(AttributeName = "Length")]
        public int Length { get; set; }

        [XmlAttribute(AttributeName = "Category")]
        public string Category { get; set; }

        [XmlAttribute(AttributeName = "Diameter")]
        public string Diameter { get; set; }

        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }

        [XmlAttribute(AttributeName = "PN_Source")]
        public string PNSource { get; set; }

        [XmlAttribute(AttributeName = "PN_Version")]
        public int PNVersion { get; set; }

        [XmlAttribute(AttributeName = "PN_Status")]
        public string PNStatus { get; set; }

        [XmlAttribute(AttributeName = "LinearMass")]
        public double LinearMass { get; set; }
    }

    [XmlRoot(ElementName = "PortAccessory")]
    public class PortAccessory
    {

        [XmlElement(ElementName = "UserAttribute")]
        public UserAttribute UserAttribute { get; set; }

        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }

        [XmlAttribute(AttributeName = "Quantity")]
        public int Quantity { get; set; }

        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }

        [XmlAttribute(AttributeName = "Label")]
        public string Label { get; set; }

        [XmlAttribute(AttributeName = "Category")]
        public string Category { get; set; }

        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }

        [XmlAttribute(AttributeName = "PN_Source")]
        public string PNSource { get; set; }

        [XmlAttribute(AttributeName = "PN_Status")]
        public string PNStatus { get; set; }

        [XmlAttribute(AttributeName = "Mass")]
        public double Mass { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "PN_Version")]
        public int PNVersion { get; set; }
    }

    [XmlRoot(ElementName = "GeometricalHarnessBranch")]
    public class GeometricalHarnessBranch
    {

        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }

        [XmlElement(ElementName = "Segment")]
        public List<Segment> Segment { get; set; }

        [XmlElement(ElementName = "Port")]
        public List<Port> Port { get; set; }

        [XmlAttribute(AttributeName = "PortID1")]
        public string PortID1 { get; set; }

        [XmlAttribute(AttributeName = "PortID2")]
        public string PortID2 { get; set; }

        [XmlAttribute(AttributeName = "UseComposedCables")]
        public string UseComposedCables { get; set; }

        [XmlAttribute(AttributeName = "LoopOfBranch")]
        public string LoopOfBranch { get; set; }

        [XmlAttribute(AttributeName = "Sensible")]
        public bool Sensible { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "Segregation")]
        public string Segregation { get; set; }
    }

    [XmlRoot(ElementName = "GeometricalHarnessBranchesList")]
    public class GeometricalHarnessBranchesList
    {

        [XmlElement(ElementName = "GeometricalHarnessBranch")]
        public List<GeometricalHarnessBranch> GeometricalHarnessBranch { get; set; }
    }

    [XmlRoot(ElementName = "PortLink")]
    public class PortLink
    {

        [XmlAttribute(AttributeName = "PortID")]
        public string PortID { get; set; }
    }

    [XmlRoot(ElementName = "PortNode")]
    public class PortNode
    {

        [XmlElement(ElementName = "PortLink")]
        public List<PortLink> PortLink { get; set; }

        [XmlAttribute(AttributeName = "Shared")]
        public string Shared { get; set; }

        [XmlAttribute(AttributeName = "OverlappedSleeve")]
        public bool OverlappedSleeve { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "NodeType")]
        public string NodeType { get; set; }
    }

    [XmlRoot(ElementName = "PortNodesList")]
    public class PortNodesList
    {

        [XmlElement(ElementName = "PortNode")]
        public List<PortNode> PortNode { get; set; }
    }

    [XmlRoot(ElementName = "GeometricalHarness")]
    public class GeometricalHarness
    {

        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }

        [XmlElement(ElementName = "GeometricalHarnessBranchesList")]
        public GeometricalHarnessBranchesList GeometricalHarnessBranchesList { get; set; }

        [XmlElement(ElementName = "PortNodesList")]
        public PortNodesList PortNodesList { get; set; }

        [XmlAttribute(AttributeName = "LH_Based")]
        public bool LHBased { get; set; }

        [XmlAttribute(AttributeName = "CalculatedWithErrors")]
        public bool CalculatedWithErrors { get; set; }

        [XmlAttribute(AttributeName = "Sensible")]
        public bool Sensible { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "Section")]
        public string Section { get; set; }

        [XmlAttribute(AttributeName = "Version")]
        public string Version { get; set; }

        [XmlAttribute(AttributeName = "Solution")]
        public int Solution { get; set; }
    }

    [XmlRoot(ElementName = "CrossedSegment")]
    public class CrossedSegment
    {

        [XmlAttribute(AttributeName = "PortID1")]
        public string PortID1 { get; set; }

        [XmlAttribute(AttributeName = "PortID2")]
        public string PortID2 { get; set; }
    }

    [XmlRoot(ElementName = "CrossedBranch")]
    public class CrossedBranch
    {

        [XmlElement(ElementName = "CrossedSegment")]
        public List<CrossedSegment> CrossedSegment { get; set; }

        [XmlAttribute(AttributeName = "BranchTag")]
        public string BranchTag { get; set; }
    }

    [XmlRoot(ElementName = "WireRoute")]
    public class WireRoute
    {

        [XmlElement(ElementName = "CrossedBranch")]
        public List<CrossedBranch> CrossedBranch { get; set; }

        [XmlAttribute(AttributeName = "WireTag")]
        public string WireTag { get; set; }
    }

    [XmlRoot(ElementName = "Routing")]
    public class Routing
    {

        [XmlElement(ElementName = "WireRoute")]
        public List<WireRoute> WireRoute { get; set; }

        [XmlElement(ElementName = "WireGroupRoute")]
        public List<WireGroupRoute> WireGroupRoute { get; set; }
    }

    [XmlRoot(ElementName = "LogsList")]
    public class LogsList
    {
        [XmlElement(ElementName = "ErrorsList")]
        public string ErrorsList { get; set; }

        [XmlElement(ElementName = "WarningsList")]
        public WarningsList WarningsList { get; set; }

        [XmlAttribute(AttributeName = "Language")]
        public string Language { get; set; }
    }

    [XmlRoot(ElementName = "PhysicalHarness")]
    public class PhysicalHarness
    {
        [XmlElement(ElementName = "ConnectiveDevicesList")]
        public ConnectiveDevicesList ConnectiveDevicesList { get; set; }

        [XmlElement(ElementName = "WireHarness")]
        public WireHarness WireHarness { get; set; }

        [XmlElement(ElementName = "GeometricalHarness")]
        public GeometricalHarness GeometricalHarness { get; set; }

        [XmlElement(ElementName = "Routing")]
        public Routing Routing { get; set; }

        [XmlElement(ElementName = "LogsList")]
        public LogsList LogsList { get; set; }

        [XmlAttribute(AttributeName = "LH_Based")]
        public bool LHBased { get; set; }

        [XmlAttribute(AttributeName = "Sensible")]
        public bool Sensible { get; set; }

        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }

        [XmlAttribute(AttributeName = "Section")]
        public string Section { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "Solution")]
        public int Solution { get; set; }

        [XmlAttribute(AttributeName = "Version")]
        public string Version { get; set; }

        [XmlAttribute(AttributeName = "ValidityType")]
        public string ValidityType { get; set; }

        [XmlAttribute(AttributeName = "LC_Status")]
        public string LCStatus { get; set; }

        [XmlAttribute(AttributeName = "WiresNumber")]
        public int WiresNumber { get; set; }

        [XmlAttribute(AttributeName = "CalculatedWithErrors")]
        public bool CalculatedWithErrors { get; set; }

        [XmlAttribute(AttributeName = "DevicesNumber")]
        public int DevicesNumber { get; set; }

        [XmlAttribute(AttributeName = "CablesNumber")]
        public int CablesNumber { get; set; }

        [XmlAttribute(AttributeName = "PickupShieldingsNumber")]
        public int PickupShieldingsNumber { get; set; }

        [XmlAttribute(AttributeName = "MassWires")]
        public double MassWires { get; set; }

        [XmlAttribute(AttributeName = "MassCables")]
        public double MassCables { get; set; }

        [XmlAttribute(AttributeName = "MassProtection")]
        public int MassProtection { get; set; }

        [XmlAttribute(AttributeName = "MassSleeves")]
        public int MassSleeves { get; set; }

        [XmlAttribute(AttributeName = "MassOverbraiding")]
        public int MassOverbraiding { get; set; }

        [XmlAttribute(AttributeName = "MassConnectiveDevices")]
        public double MassConnectiveDevices { get; set; }

        [XmlAttribute(AttributeName = "MassAccessories")]
        public double MassAccessories { get; set; }

        [XmlAttribute(AttributeName = "MassEndFitting")]
        public double MassEndFitting { get; set; }

        [XmlAttribute(AttributeName = "MassTotal")]
        public string MassTotal { get; set; }

        [XmlAttribute(AttributeName = "GravityCenterX")]
        public int GravityCenterX { get; set; }

        [XmlAttribute(AttributeName = "GravityCenterY")]
        public int GravityCenterY { get; set; }

        [XmlAttribute(AttributeName = "GravityCenterZ")]
        public int GravityCenterZ { get; set; }

        [XmlAttribute(AttributeName = "MaterialCost")]
        public int MaterialCost { get; set; }

        [XmlAttribute(AttributeName = "DiameterStatus")]
        public string DiameterStatus { get; set; }

        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }
    }

    [XmlRoot(ElementName = "IGE-XAO_PHYSICAL_HARNESS")]
    public class Physical_Harness
    {
        [XmlElement(ElementName = "PhysicalHarness")]
        public PhysicalHarness PhysicalHarness { get; set; }

        [XmlAttribute(AttributeName = "LengthUnit")]
        public string LengthUnit { get; set; }

        [XmlAttribute(AttributeName = "MassUnit")]
        public string MassUnit { get; set; }

        [XmlAttribute(AttributeName = "VolumeUnit")]
        public string VolumeUnit { get; set; }

        [XmlAttribute(AttributeName = "AreaUnit")]
        public string AreaUnit { get; set; }

        [XmlAttribute(AttributeName = "EDB_InstanceID")]
        public string EDBInstanceID { get; set; }

        [XmlAttribute(AttributeName = "XMLSourceName")]
        public string XMLSourceName { get; set; }

        [XmlAttribute(AttributeName = "XMLSourceVersion")]
        public double XMLSourceVersion { get; set; }

        [XmlAttribute(AttributeName = "GaugeUnit")]
        public string GaugeUnit { get; set; }

        [XmlAttribute(AttributeName = "XSDversion")]
        public string XSDversion { get; set; }
    }

    [XmlRoot(ElementName = "WarningsList")]
    public class WarningsList
    {
        [XmlElement(ElementName = "Warning")]
        public List<Warning> Warning { get; set; }
    }

    [XmlRoot(ElementName = "Warning")]
    public class Warning
    {
        [XmlElement(ElementName = "ObjectDescription")]
        public ObjectDescription ObjectDescription { get; set; }

        [XmlElement(ElementName = "MessageParametersList")]
        public MessageParametersList MessageParametersList { get; set; }

        [XmlAttribute(AttributeName = "MessageType")]
        public string MessageType { get; set; }

        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }

        [XmlAttribute(AttributeName = "DetectedBy")]
        public string DetectedBy { get; set; }

        [XmlAttribute(AttributeName = "DateWithTime")]
        public DateTime DateWithTime { get; set; }
    }

    [XmlRoot(ElementName = "ObjectDescription")]
    public class ObjectDescription
    {

        [XmlAttribute(AttributeName = "ObjectTag")]
        public string ObjectTag { get; set; }

        [XmlAttribute(AttributeName = "ObjectType")]
        public string ObjectType { get; set; }
    }

    [XmlRoot(ElementName = "MessageParametersList")]
    public class MessageParametersList
    {

        [XmlElement(ElementName = "MessageParameter")]
        public MessageParameter MessageParameter { get; set; }
    }

    [XmlRoot(ElementName = "MessageParameter")]
    public class MessageParameter
    {

        [XmlAttribute(AttributeName = "Value")]
        public string Value { get; set; }
    }

    [XmlRoot(ElementName = "ConnectiveAccessory")]
    public class ConnectiveAccessory
    {
        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }
        [XmlAttribute(AttributeName = "ID")]
        public string ID { get; set; }
        [XmlAttribute(AttributeName = "Quantity")]
        public double Quantity { get; set; }
        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }
        [XmlAttribute(AttributeName = "Label")]
        public string Label { get; set; }
        [XmlAttribute(AttributeName = "Category")]
        public string Category { get; set; }
        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }
        [XmlAttribute(AttributeName = "PN_Source")]
        public string PN_Source { get; set; }
        [XmlAttribute(AttributeName = "Mass")]
        public string Mass { get; set; }
        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }
        [XmlAttribute(AttributeName = "PN_Version")]
        public string PN_Version { get; set; }
        [XmlAttribute(AttributeName = "PN_Status")]
        public string PN_Status { get; set; }
    }

    [XmlRoot(ElementName = "WireGroup")]
    public class WireGroup
    {
        [XmlElement(ElementName = "Wire")]
        public List<Wire> Wire { get; set; }
        [XmlElement(ElementName = "UserAttribute")]
        public List<UserAttribute> UserAttribute { get; set; }
        [XmlAttribute(AttributeName = "Tag")]
        public string Tag { get; set; }
        [XmlAttribute(AttributeName = "Type")]
        public string Type { get; set; }
        [XmlAttribute(AttributeName = "Wire_Type")]
        public string WireType { get; set; }
        [XmlAttribute(AttributeName = "Color")]
        public string Color { get; set; }
        [XmlAttribute(AttributeName = "Length")]
        public int Length { get; set; }
        [XmlAttribute(AttributeName = "Class")]
        public string Class { get; set; }
        [XmlAttribute(AttributeName = "Segregation")]
        public string Segregation { get; set; }
        [XmlAttribute(AttributeName = "Gauge")]
        public string Gauge { get; set; }
        [XmlAttribute(AttributeName = "ProvidedWithEquipment")]
        public string ProvidedWithEquipment { get; set; }
        [XmlAttribute(AttributeName = "TagType")]
        public string TagType { get; set; }
        [XmlAttribute(AttributeName = "ManualAssignation")]
        public string ManualAssignation { get; set; }
        [XmlAttribute(AttributeName = "CreationType")]
        public string CreationType { get; set; }
        [XmlElement(ElementName = "WireGroup")]
        public WireGroup wireGroup { get; set; }
        [XmlAttribute(AttributeName = "PartNumber")]
        public string PartNumber { get; set; }
        [XmlAttribute(AttributeName = "PN_Version")]
        public int PNVersion { get; set; }
        [XmlAttribute(AttributeName = "LinearMass")]
        public double LinearMass { get; set; }
        [XmlAttribute(AttributeName = "Description")]
        public string Description { get; set; }
        [XmlAttribute(AttributeName = "ExternalDiameter")]
        public double ExternalDiameter { get; set; }
        [XmlAttribute(AttributeName = "BendRadius")]
        public int BendRadius { get; set; }
        [XmlAttribute(AttributeName = "PN_Status")]
        public string PNStatus { get; set; }
        [XmlAttribute(AttributeName = "Mass")]
        public double Mass { get; set; }
        [XmlAttribute(AttributeName = "CableOrder")]
        public string CableOrder { get; set; }
        [XmlAttribute(AttributeName = "SourceType")]
        public string SourceType { get; set; }
    }

    [XmlRoot(ElementName = "WireGroupRoute")]
    public class WireGroupRoute
    {
        [XmlElement(ElementName = "CrossedBranch")]
        public List<CrossedBranch> CrossedBranch { get; set; }
        [XmlAttribute(AttributeName = "WireGroupTag")]
        public string WireGroupTag { get; set; }
    }
}
