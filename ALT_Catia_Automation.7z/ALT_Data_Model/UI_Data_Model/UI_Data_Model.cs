﻿
using System.Collections.Generic;

namespace ALT_Data_Model.UI_Data_Model
{
    class UI_Data_Model
    {
        
    }

    /// <summary>
    /// Represents a row of data in a table with properties for connector synoptic, connector harness,
    /// </summary>
    public class TableData
    {
        public string ConnectorSynoptic { get; set; }
        public string ConnectorHarness { get; set; }
        public string Action { get; set; }
        public bool IsChecked { get; set; } // Boolean property for checkbox
        public string Status { get; set; }
        public bool IsEnable { get; set; } = false;
    }

    /// <summary>
    /// Represents file paths for various resources used in the application.
    /// </summary>
    public class FilePaths
    {
        public string Synoptic_File_Path { get; set; }
        public string Extract_FAF_Path { get; set; }
        public string PPL_Cable_Path { get; set; }
        public string PPL_Electrical_Path { get; set; }
        public string Sleeve_Catalog_Json_Path { get; set; }
        public string PL3_Path { get; set; }
        public string PL3_Projet_Path { get; set; }
    }

    /// <summary>
    /// Represents a model for the first extremity zone with properties for the zone name and selection status.
    /// </summary>
    public class FirstExtremityZoneModel
    {
        public string FirstExtremityZoneName { get; set; }
        public bool FirstExtremityIsSelected { get; set; }
        
    }

    /// <summary>
    /// Represents a model for the second extremity zone with properties for the zone name and selection status.
    /// </summary>
    public class SecondExtremityZoneModel
    {
        public string SecondExtremityZoneName { get; set; }
        public bool SecondExtremityIsSelected { get; set; }
    }

    /// <summary>
    /// Represents a model for a multibranchable zone with properties for the zone name and selection status.
    /// </summary>
    public class MultibranchableZoneModel
    {
        public string MultibranchableZoneName { get; set; }
        public bool MultibranchableIsSelected { get; set; }
    }

    /// <summary>
    /// Represents a model for a covering zone with properties for the zone name and selection status.
    /// </summary>
    public class CoveringZoneModel
    {
        public string CoveringZoneName { get; set; }
        public bool CoveringIsSelected { get; set; }
    }

    /// <summary>
    /// Represents a synoptic instance with properties for connectors, status, and combined names.
    /// </summary>
    public class SynopticInstance
    {
        public string PHConnector { get; set; }         // First string
        public string SynopticConnector { get; set; }       // Second string
        public bool Status { get; set; }         // Bool
        public string CombinedNames { get; set; }
        public string DisplayStatus => Status ? "Valid" : "Invalid"; // This is what you show
    }

    /// <summary>
    /// Represents a corrugation item with properties for branchable, bundle segment, sleeve, and result.
    /// </summary>
    public class CorrugItem
    {
        public string Branchable { get; set; }
        public string BundleSegment { get; set; }
        public string Sleeve { get; set; }
        public string Result { get; set; }
    }

    /// <summary>
    /// Represents a Harting item with properties for DTR number and instance name.
    /// </summary>
    public class HartingItem
    {
        public string DTRNumber { get; set; }
        public string InstanceName { get; set; }
    }
}
