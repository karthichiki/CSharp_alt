﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class SleeveCatalog
    {
        public Dictionary<string, Dictionary<string, List<string>>> Sleeve_Elec { get; set; }
    }
}
