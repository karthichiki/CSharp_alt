﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class WrapAroundGripSleeve
    {
        #region Properties
        public string DTR;
        public string DTR_Color;
        public string Size;
        public string Dia_Min;
        public string DIA_Max;
        public string SUPPLIER;
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="WrapAroundGripSleeve"/> class with all descriptive fields.
        /// </summary>
        /// <param name="_DTR"></param>
        /// <param name="_DTR_Color"></param>
        /// <param name="_Size"></param>
        /// <param name="_Dia_Min"></param>
        /// <param name="_DIA_Max"></param>
        /// <param name="_SUPPLIER"></param>
        public WrapAroundGripSleeve(string _DTR, string _DTR_Color, string _Size, string _Dia_Min, string _DIA_Max, string _SUPPLIER)
        {
            DTR = _DTR;
            DTR_Color = _DTR_Color;
            Size = _Size;
            Dia_Min = _Dia_Min;
            DIA_Max = _DIA_Max;
            SUPPLIER = _SUPPLIER;
        }
    }
}
