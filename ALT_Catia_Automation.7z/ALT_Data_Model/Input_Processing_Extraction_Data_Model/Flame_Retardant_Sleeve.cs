﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class Flame_Retardant_Sleeve
    {
        #region Properties
        public string DTR;
        public string DTR_Color;
        public string Size;
        public string Dia_Min;
        public string DIA_Max;
        public string Supplier;
        #endregion

        /// <summary>
        /// constructor for Flame_Retardant_Sleeve
        /// </summary>
        /// <param name="_DTR"> DTR value</param>
        /// <param name="_DTR_Color"> Color value </param>
        /// <param name="_Size"> Sleeve Size</param>
        /// <param name="_Dia_Min"> Sleeve min diameter </param>
        /// <param name="_DIA_Max"> Sleeve max diameter</param>
        public Flame_Retardant_Sleeve(string _DTR, string _DTR_Color, string _Size, string _Dia_Min, string _DIA_Max, string _Supplier)
        {
            DTR = _DTR;
            DTR_Color = _DTR_Color;
            Size = _Size;
            Dia_Min = _Dia_Min;
            DIA_Max = _DIA_Max;
            Supplier = _Supplier;
        }
    }
}
