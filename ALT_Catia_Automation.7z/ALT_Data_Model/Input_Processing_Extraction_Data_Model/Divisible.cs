﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    /// <summary>
    /// Represents a divisible (split) sleeve with its technical specifications including DTR, color,
    /// internal diameter, and minimum bend radius.
    /// </summary>
    public class Divisible
    {
        #region Properties
        /// <summary>
        /// Design / technical reference identifier for the sleeve.
        /// </summary>
        public string DTR { get; set; }
        /// <summary>
        /// DTR color code or specification.
        /// </summary>
        public string DTR_Color { get; set; }
        /// <summary>
        /// Internal diameter specification.
        /// </summary>
        public string Dia_Int { get; set; }
        /// <summary>
        /// Minimum bend radius specification.
        /// </summary>
        public string Min_BR { get; set; }
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="Divisible"/> class with all descriptive fields.
        /// </summary>
        /// <param name="_DTR">Design / technical reference identifier.</param>
        /// <param name="_DTR_Color">DTR color code or specification.</param>
        /// <param name="dia_Int">Internal diameter specification.</param>
        /// <param name="min_BR">Minimum bend radius specification.</param>
        public Divisible(string _DTR, string _DTR_Color, string dia_Int, string min_BR)
        {
            DTR = _DTR;
            DTR_Color = _DTR_Color;
            Dia_Int = dia_Int;
            Min_BR = min_BR;
        }
    }

}
