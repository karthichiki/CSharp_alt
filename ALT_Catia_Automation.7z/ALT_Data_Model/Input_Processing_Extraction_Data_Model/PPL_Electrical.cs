﻿
namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class PPL_Electrical
    {
        #region Properties
        public string Static_Bending_Radius;
        public string Internal_Diameter;
        public string DTR_Number;
        public string Nominal_Diameter;
        public string Type;
        public string External_Diameter;
        #endregion

        #region Constructor
        public PPL_Electrical()
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PPL_Electrical"/> class with all descriptive fields.
        /// </summary>
        /// <param name="dtrNumber"> dtr value </param>
        /// <param name="nominalDiameter"> nominal diameter value</param>
        /// <param name="diameter"> diameter value</param>
        /// <param name="staticBendingRadius"> staticbend radius value </param>
        /// <param name="type"> type of electrical cable </param>
        /// <param name="externalDiameter"> external diameter of cable </param>
        public PPL_Electrical(string dtrNumber, string nominalDiameter, string diameter, string staticBendingRadius, string type, string externalDiameter)
        {
            DTR_Number = dtrNumber;
            Nominal_Diameter = nominalDiameter;
            Internal_Diameter = diameter;
            Static_Bending_Radius = staticBendingRadius;
            Type = type;
            External_Diameter = externalDiameter;
        }
        #endregion
    }
}
