﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    /// <summary>
    /// Represents an electrical insulation sleeve with its technical specifications including DTR, color,
    /// and internal diameter.
    /// </summary>
    public class Electrical_Insulation_Sleeve
    {
        #region Properties
        /// <summary>
        /// Design / technical reference identifier for the sleeve.
        /// </summary>
        public string DTR { get; set; }
        /// <summary>
        /// DTR color code or specification.
        /// </summary>
        public string DTR_Color { get; set; }
        /// <summary>
        /// Internal diameter specification.
        /// </summary>
        public string DIA_int { get; set; }

        /// <summary>
        /// Supplier specification.
        /// </summary>
        public string Supplier { get; set; }
        #endregion
        /// <summary>
        /// Initializes a new instance of the <see cref="Electrical_Insulation_Sleeve"/> class with all descriptive fields.
        /// </summary>
        /// <param name="_DTR">Design / technical reference identifier.</param>
        /// <param name="_DTR_Color">DTR color code or specification.</param>
        /// <param name="_DIA_int">Internal diameter specification.</param>
        public Electrical_Insulation_Sleeve(string _DTR, string _DTR_Color, string _DIA_int, string _supplier)
        {
            DTR = _DTR;
            DTR_Color = _DTR_Color;
            DIA_int = _DIA_int;
            Supplier = _supplier;
        }
    }
}
