﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class PL3_Connector
    {

        #region Properties
        public string DTR_Number;
        public string ComponentType;
        public string PPL;
        public string DESCRIPTION;
        #endregion

        #region Constructor
        public PL3_Connector()
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PL3_Connector"/> class with all descriptive fields.
        /// </summary>
        /// <param name="dtr"> DTR name </param>
        /// <param name="ppl"></param>
        /// <param name="desp"></param>
        /// <param name="componentType"></param>
        public PL3_Connector(string dtr, string ppl, string desp, string componentType)
        {
            DTR_Number = dtr;
            PPL = ppl;
            DESCRIPTION = desp;
            ComponentType = componentType;
        }
        #endregion
    }

}
