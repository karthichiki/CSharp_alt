﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class PL3_Combined
    {
        #region Properties
        public Dictionary<string, List<CorrugatedSleeve>> CorrugatedSleeve { get; set; }
        public Dictionary<string, List<Divisible>> Divisible { get; set; }
        public Dictionary<string, List<Electrical_Insulation_Sleeve>> ElectricalInsulationSleeve { get; set; }
        public Dictionary<string, List<EMC>> EMC { get; set; }
        public Dictionary<string, List<ExpandableSleeve>> ExpandableSleeve { get; set; }
        public Dictionary<string, List<Flame_Retardant_Sleeve>> FlameRetardantSleeve { get; set; }
        public Dictionary<string, List<Heat_Shrinkable_Sleeve>> HeatShrinkableSleeve { get; set; }
        public Dictionary<string, List<WrapAroundGripSleeve>> WrapAroundGripSleeve { get; set; }
        public Dictionary<string, List<WrapAroundSleeve>> WrapAroundSleeve { get; set; }
        public Dictionary<string, List<Tapes_Labels>> ColorRingSleeve { get; set; }
        #endregion
    }
}
