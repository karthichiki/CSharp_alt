﻿
namespace ALT_Data_Model
{
    public class PPL_Cables
    {
        #region Properties
        public string Section;
        public string Static_Bending_Radius;
        public string Diameter;
        public string DTR_Number;

        #endregion

        #region Constructor
        public PPL_Cables()
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PPL_Cables"/> class with all descriptive fields.
        /// </summary>
        /// <param name="section"></param>
        /// <param name="staticBendingRadius"> bend radius value</param>
        /// <param name="diameter"> diameter value</param>
        public PPL_Cables(string section, string staticBendingRadius, string diameter)
        {
            Section = section;
            Static_Bending_Radius = staticBendingRadius;
            Diameter = diameter;
        }
        #endregion
    }
}
