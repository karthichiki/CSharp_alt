﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class Tapes_Labels
    {
        #region Properties
        public string DTR { get; set; }
        public string Color { get; set; }
        public string Width { get; set; }

        public string Supplier { get; set; }
        #endregion
        /// <summary>
        /// Initializes a new instance of the <see cref="Tapes_Labels"/> class with all descriptive fields.
        /// </summary>
        /// <param name="_DTR"> dtr value </param>
        /// <param name="_Color"> color</param>
        /// <param name="_Width"> width value </param>
        public Tapes_Labels(string _DTR, string _Color, string _Width, string _Supplier)
        {
            DTR = _DTR;
            Color = _Color;
            Width = _Width;
            Supplier = _Supplier;
        }
    }
}
