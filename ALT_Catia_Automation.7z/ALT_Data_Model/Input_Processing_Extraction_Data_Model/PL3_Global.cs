﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class PL3_Global
    {
        #region Properties
        public string DTR_Number;
        public string PPL;
        public string Description;
        #endregion

        #region Constructor
        public PL3_Global()
        {

        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PL3_Global"/> class with all descriptive fields.
        /// </summary>
        /// <param name="dtr"> dtr name </param>
        /// <param name="ppl"> ppl </param>
        /// <param name="description"> description value </param>
        public PL3_Global(string dtr, string ppl, string description)
        {
            DTR_Number = dtr;
            PPL = ppl;
            Description = description;
        }
        #endregion
    }
}
