﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    public class Heat_Shrinkable_Sleeve
    {
        #region Properties
        public string DTR;
        public string DTR_Color;
        public string RESISTANT_TO_FUEL;
        public string DIAMETER_BEFORE_SHRINKABLE_mm;
        public string DIAMETER_AFTER_SHRINKABLE_mm;
        public string Part_number;
        public string Supplier;
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="Heat_Shrinkable_Sleeve"/> class with all descriptive fields.
        /// </summary>
        /// <param name="_DTR"></param>
        /// <param name="_DTR_Color"></param>
        /// <param name="_RESISTANT_TO_FUEL"></param>
        /// <param name="_DIAMETER_BEFORE_SHRINKABLE_mm"></param>
        /// <param name="_DIAMETER_AFTER_SHRINKABLE_mm"></param>
        /// <param name="_Part_number"></param>
        public Heat_Shrinkable_Sleeve(string _DTR, string _DTR_Color, string _RESISTANT_TO_FUEL, string _DIAMETER_BEFORE_SHRINKABLE_mm, string _DIAMETER_AFTER_SHRINKABLE_mm, string _Part_number, string supplier)
        {
            DTR = _DTR;
            DTR_Color = _DTR_Color;
            RESISTANT_TO_FUEL = _RESISTANT_TO_FUEL;
            DIAMETER_AFTER_SHRINKABLE_mm = _DIAMETER_AFTER_SHRINKABLE_mm;
            DIAMETER_BEFORE_SHRINKABLE_mm = _DIAMETER_BEFORE_SHRINKABLE_mm;
            Part_number = _Part_number;
            Supplier = supplier;
        }
    }
}
