﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Model.Input_Processing_Extraction_Data_Model
{
    /// <summary>
    /// Represents a corrugated sleeve with its technical specifications including DTR, size, diameter,
    /// bend radius, and fire/smoke rating.
    /// </summary>
    public class CorrugatedSleeve
    {
        #region Properties
        /// <summary>
        /// Design / technical reference identifier for the sleeve.
        /// </summary>
        public string DTR { get; set; }
        /// <summary>
        /// DTR color code or specification.
        /// </summary>
        public string DTR_Color { get; set; }
        /// <summary>
        /// Internal diameter specification.
        /// </summary>
        public string DIA_int { get; set; }
        /// <summary>
        /// Minimum static bend radius in millimeters.
        /// </summary>
        public string Min_BR_mm_ST { get; set; }
        /// <summary>
        /// Fire and smoke performance rating / standard.
        /// </summary>
        public string FIRE_AND_SMOKE { get; set; }
        /// <summary>
        /// Nominal size designation of the sleeve.
        /// </summary>
        public string SIZE { get; set; }
        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="CorrugatedSleeve"/> class with all descriptive fields.
        /// </summary>
        /// <param name="_DTR">Design / technical reference identifier.</param>
        /// <param name="size">Nominal size designation.</param>
        /// <param name="_DTR_Color">DTR color code or specification.</param>
        /// <param name="_DIA_int">Internal diameter specification.</param>
        /// <param name="_Min_BR_mm_ST">Minimum static bend radius in millimeters.</param>
        /// <param name="_FIRE_AND_SMOKE">Fire and smoke performance rating.</param>
        public CorrugatedSleeve(string _DTR, string size, string _DTR_Color, string _DIA_int, string _Min_BR_mm_ST, string _FIRE_AND_SMOKE)
        {
            DTR = _DTR;
            SIZE = size;
            DTR_Color = _DTR_Color;
            DIA_int = _DIA_int;
            Min_BR_mm_ST = _Min_BR_mm_ST;
            FIRE_AND_SMOKE = _FIRE_AND_SMOKE;
        }
    }
}
