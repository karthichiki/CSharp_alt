﻿
namespace ALT_Data_Model
{
    public class FAF_Extract
    {
        #region Properties
        public string Guid;
        public string Cable_ID;
        public string Harness;
        public string Class;
        public string Part_Number;
        public string Cable_Designation;
        public string From_Device;
        public string From_Car;
        public string From_Localization;
        public string To_Device;
        public string To_Car;
        public string To_Localization;

        #endregion

        #region Constructor
        public FAF_Extract()
        {
                
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="FAF_Extract"/> class with all descriptive fields.
        /// </summary>
        /// <param name="guid"></param>
        /// <param name="cable_ID"></param>
        /// <param name="classFaf"></param>
        /// <param name="part_Number"></param>
        /// <param name="cable_Designation"></param>
        /// <param name="from_Device"></param>
        /// <param name="from_Car"></param>
        /// <param name="from_Localization"></param>
        /// <param name="to_Device"></param>
        /// <param name="to_Car"></param>
        /// <param name="to_Localization"></param>
        public FAF_Extract(string guid, string cable_ID, string classFaf, string part_Number,
            string cable_Designation, string from_Device, string from_Car, string from_Localization,
            string to_Device, string to_Car, string to_Localization)
        {
            Guid = guid;
            Cable_ID = cable_ID;
            Class = classFaf;
            Part_Number = part_Number;
            Cable_Designation = cable_Designation;
            From_Device = from_Device;
            From_Car = from_Car;
            From_Localization = from_Localization;
            To_Device = to_Device;
            To_Car = to_Car;
            To_Localization = to_Localization;
        }
        #endregion

        #region Public Methods
    
        #endregion
    }
}
