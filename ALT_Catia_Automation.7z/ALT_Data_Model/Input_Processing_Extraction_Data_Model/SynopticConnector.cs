﻿namespace ALT_Data_Model
{
    public class SynopticConnector
    {
        #region Properties
        public string Guid;
        public string AMD;
        public string ExtSynRevision;
        public string SynopticVersion;
        public string ChangeRequest;
        public string DeviceAcronym;
        public string ConnectorName;
        public string SynopticConnectorName;
        public string ConnectorCustomerName;
        public string Localization;
        public string FunctionalFlow;
        public string PartNumber;
        public string KeyingValue;
        public string EnvironmentalZone;
        public bool IPOH = false;
        public bool CM = false;
        public string Comments;
        public string CarName;
        public string NeoType;
        public string Status;
        public ConnectorLocation ConnectorActionStatus;
        public CADTransform Transform;
        #endregion

        #region Constructor
        public SynopticConnector()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SynopticConnector"/> class with all descriptive fields.
        /// </summary>
        /// <param name="guid"></param>
        /// <param name="aMD"></param>
        /// <param name="extSynRevision"></param>
        /// <param name="synopticVersion"></param>
        /// <param name="changeRequest"></param>
        /// <param name="deviceAcronym"></param>
        /// <param name="connectorName"></param>
        /// <param name="connectorCustomerName"></param>
        /// <param name="localization"></param>
        /// <param name="functionalFlow"></param>
        /// <param name="partNumber"></param>
        /// <param name="keyingValue"></param>
        /// <param name="environmentalZone"></param>
        /// <param name="iPOH"></param>
        /// <param name="cM"></param>
        /// <param name="comments"></param>
        /// <param name="carName"></param>
        /// <param name="neoType"></param>
        /// <param name="status"></param>
        public SynopticConnector(string guid, string aMD, string extSynRevision, string synopticVersion, string changeRequest,
            string deviceAcronym, string connectorName, string connectorCustomerName, string localization,
            string functionalFlow, string partNumber, string keyingValue, string environmentalZone,
            string iPOH, string cM, string comments, string carName, string neoType, string status)
        {
            Guid = guid;
            AMD = aMD;
            ExtSynRevision = extSynRevision;
            SynopticVersion = synopticVersion;
            ChangeRequest = changeRequest;
            DeviceAcronym = deviceAcronym;
            ConnectorName = connectorName;
            SynopticConnectorName = CreateSynopticConnectorName(deviceAcronym, connectorName);
            ConnectorCustomerName = connectorCustomerName;
            Localization = localization;
            FunctionalFlow = functionalFlow;
            PartNumber = partNumber;
            KeyingValue = keyingValue;
            EnvironmentalZone = environmentalZone;
            IPOH = iPOH.ToUpper() == "Y";
            CM = cM.ToUpper() == "Y";
            Comments = comments;
            CarName = carName;
            NeoType = neoType;
            Status = status;
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Creates a synoptic connector name based on the device acronym and connector name.
        /// </summary>
        /// <param name="DeviceAcronym"></param>
        /// <param name="connectorName"></param>
        /// <returns> returns synoptic name </returns>
        public string CreateSynopticConnectorName(string DeviceAcronym, string connectorName)
        {
            string synopticConnectorName;
            if (string.IsNullOrEmpty(connectorName))
                synopticConnectorName = DeviceAcronym;
            else
            {
                if (string.IsNullOrEmpty(DeviceAcronym) || DeviceAcronym == "PB" || 
                    DeviceAcronym == "PBM" || DeviceAcronym == "TB")
                    synopticConnectorName = connectorName;
                else
                    synopticConnectorName = DeviceAcronym + "_" + connectorName;
            }

            return synopticConnectorName;
        }
        #endregion
    }
}
