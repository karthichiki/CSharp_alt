﻿
namespace ALT_Data_Model
{
    /// <summary>
    /// Enumeration representing the status of a connector in the comparison process.
    /// </summary>
    public enum ConnectorStatus
    { 
        None,
        OK,
        ToBeAdded, 
        ToBeDeleted, 
        ToBeReplaced,
        ToBeRepositioned
    }

    /// <summary>
    /// Enumeration representing the source location for loading or adding a connector.
    /// </summary>
    public enum ConnectorLocation
    {
        LoadFromDMA,
        LoadFromEQTLOcation,
        LoadFromCatalog,
        AddFromDMA,
        ReplaceFromEQTLOcation
    }

    /// <summary>
    /// Represents the comparison data between CAD connectors and synoptic connectors.
    /// </summary>
    public class CADCompareData
    {
        #region Properties
        public string SynopticConnector { get; set; }
        public string CatiaConnector { get; set; }
        public string Action { get; set; }
        public ConnectorStatus Status { get; set; }
        public int GroupIndex { get; set; }

        #endregion

        #region Constructor
        public CADCompareData()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CADCompareData"/> class by comparing a CAD connector and a synoptic connector.
        /// </summary>
        /// <param name="cadConnector"> CADconnector data </param>
        /// <param name="synopticConn"> Synoptic data </param>
        public CADCompareData(CADConnector cadConnector, SynopticConnector synopticConn)
        {
            if (cadConnector == null)
            {
                CatiaConnector = string.Empty;
                SynopticConnector = synopticConn.SynopticConnectorName;
                Status = ConnectorStatus.ToBeAdded;
                if (synopticConn.ConnectorActionStatus == ConnectorLocation.LoadFromEQTLOcation)
                    Action = "To be loaded from EQT Location";
                else if (synopticConn.ConnectorActionStatus == ConnectorLocation.LoadFromDMA)
                {
                    Action = "DTR mismatching: To be loaded from DMA";
                }
                else if(synopticConn.ConnectorActionStatus == ConnectorLocation.LoadFromCatalog)
                    Action = "To be added from catalog";
                else if (synopticConn.ConnectorActionStatus == ConnectorLocation.AddFromDMA)
                    Action = "To be loaded from DMA";

            }
            if (synopticConn == null)
            {
                SynopticConnector = string.Empty;
                CatiaConnector = cadConnector.Name;
                Status = ConnectorStatus.ToBeDeleted;
            }
            if (cadConnector != null && synopticConn != null)
            {
                GroupIndex = cadConnector.GroupIndex;
                SynopticConnector = synopticConn.SynopticConnectorName;
                CatiaConnector = cadConnector.Name;
                if (cadConnector.Transform.Equals(synopticConn.Transform))
                {
                    if(cadConnector.PartNumber.Substring(0,4) == "FICT")
                    {
                        if(synopticConn.PartNumber != "") //// changing this may break the grouped concept logic
                        { 
                            Status = ConnectorStatus.ToBeReplaced;
                            Action = "DTR mismatching: To be loaded from DMA";
                        }
                        else
                            Status = ConnectorStatus.OK;

                    }
                    else if (synopticConn.ConnectorActionStatus == ConnectorLocation.LoadFromEQTLOcation)
                    {
                        if(synopticConn.PartNumber != cadConnector.PartNumber && synopticConn.PartNumber != "")
                        {
                            Status = ConnectorStatus.ToBeReplaced;
                            Action = "DTR mismatching: To be loaded from DMA";
                        }
                        else
                            Status = ConnectorStatus.OK;
                        
                    }
                    else if(synopticConn.ConnectorActionStatus == ConnectorLocation.LoadFromCatalog)
                    {
                        Status = ConnectorStatus.ToBeReplaced;
                        Action = "To be added from catalog";
                    }
                    else if (synopticConn.ConnectorActionStatus == ConnectorLocation.ReplaceFromEQTLOcation)
                    {
                        Status = ConnectorStatus.ToBeReplaced;
                        Action = "DTR mismatching: To be replaced from EQT Location";
                    }
                    else
                    {
                        Status = ConnectorStatus.ToBeReplaced;
                        Action = "DTR mismatching: To be loaded from DMA";
                    }
                }
                else
                {
                    Status = ConnectorStatus.ToBeRepositioned;
                    if (synopticConn.ConnectorActionStatus == ConnectorLocation.LoadFromEQTLOcation)
                        Action = "To be loaded from EQT Location";
                    else if (synopticConn.ConnectorActionStatus == ConnectorLocation.ReplaceFromEQTLOcation)
                        Action = "To be loaded from EQT Location"; ///// to be confirmed
                    else
                        Action = "DTR mismatching: To be loaded from DMA";
                }
            }
        }

        #endregion

        #region Public Methods
        #endregion

        #region Private Methods
        #endregion
    }
}
