﻿using IGESDataProcessor;
using System.Windows.Media.Media3D;

namespace Test
{
    /// <summary>
    /// Represents a product with its identification metadata, transformation matrix, and parsed IGES geometry data.
    /// </summary>
    public class Product_cls
    {
        /// <summary>
        /// Gets or sets the part number identifier.
        /// </summary>
        public string part_number { get; set; }
        /// <summary>
        /// Gets or sets the human-readable part name.
        /// </summary>
        public string part_name { get; set; }
        /// <summary>
        /// Gets or sets the descriptive text for the part.
        /// </summary>
        public string part_description { get; set; }
        /// <summary>
        /// Gets or sets the full file path to the product's source file.
        /// </summary>
        public string full_Path { get; set; }
        /// <summary>
        /// Gets or sets the 3D transformation matrix applied to this product instance.
        /// </summary>
        public Matrix3D Transformation { get; set; }
        /// <summary>
        /// Gets or sets the processed IGES geometry data, including shells and body information.
        /// </summary>
        public IGPro_IGESPartGeometryInfo IGESData { get; set; }
    }
}
