﻿using ALT_CATIA_Adapter;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.PH_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Logging;
using ClosedXML.Excel;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using KnowledgewareTypeLib;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ALT_Data_Model
{
    /// <summary>
    /// Class to prepare and compare Physical Harness data from different sources (CATIA, Synoptic, PH XML).
    /// </summary>
    public class PhysicalHarnessDataPreparation
    {
        #region Fields
        public List<(string, string, bool)> PH_Synoptic_InstanceNameCheck = new List<(string, string, bool)>();
        public List<(string, string, bool, string)> PH_Synoptic_DTRNumberCheck = new List<(string, string, bool, string)>();

        public List<(string, string, bool)> PH_CATIAConnector_InstanceNameCheck = new List<(string, string, bool)>();
        public List<(string, string, bool, string)> PH_CATIAConnector_DTRNumberCheck = new List<(string, string, bool, string)>();

        public List<(string, string, bool)> PH_CATIALug_InstanceNameCheck = new List<(string, string, bool)>();
        public List<(string, string, bool)> PH_CATIALug_DTRNumberCheck = new List<(string, string, bool)>();

        public List<(string, string, string, bool)> CORRUG_BRCheck = new List<(string, string, string, bool)>();

        public List<(string, string, bool)> PHHarting3PLCheck = new List<(string, string, bool)>();

        //public List<(string, string)> PH_CATIA_Backshell_MatchingData = new List<(string, string)>();
        //public List<(string, string)> PH_CATIA_Backshell_NotMatchingData = new List<(string, string)>();

        #region Data List
        public List<(string, string)> CATIA_ConnectorsData = new List<(string, string)>();
        public List<(string, string)> CATIA_NonConnectorsData = new List<(string, string)>();
        public List<(string, string)> PHFile_ConnectorsData = new List<(string, string)>();
        //public List<(string, string)> PHFile_BackshellData = new List<(string, string)>();
        public List<(string, string)> PHFile_LugData = new List<(string, string)>();
        public List<(string, string)> Synoptic_ConnectorData = new List<(string, string)>();

        #endregion
        private static PhysicalHarnessDataPreparation _PHDataPreparation;
        #endregion

        #region Constructor
        public PhysicalHarnessDataPreparation()
        {

        }
        #endregion

        #region Public Methods
        public static PhysicalHarnessDataPreparation GetInstance()
        {
            if (_PHDataPreparation == null)
                _PHDataPreparation = new PhysicalHarnessDataPreparation();
            return _PHDataPreparation;
        }

        /// <summary>
        /// Reads and processes the Physical Harness XML file, comparing its data with CATIA and Synoptic data.
        /// </summary>
        /// <param name="xmlPath"> xml path </param>
        /// <param name="jsonfilePaths"> json file paths</param>
        /// <returns> status of reading process </returns>
        public string ReadPhysicalHarness(string xmlPath, FilePaths jsonfilePaths)
        {
            PH_Synoptic_InstanceNameCheck.Clear();
            PH_Synoptic_DTRNumberCheck.Clear();
            PH_CATIAConnector_InstanceNameCheck.Clear();
            PH_CATIAConnector_DTRNumberCheck.Clear();
            PH_CATIALug_InstanceNameCheck.Clear();
            PH_CATIALug_DTRNumberCheck.Clear();
            //PH_CATIA_Backshell_MatchingData.Clear();
            //PH_CATIA_Backshell_NotMatchingData.Clear();

            string result = string.Empty;
            Physical_Harness phAccessory = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Physical_Harness));
                using (FileStream fs = new FileStream(xmlPath, FileMode.Open))
                {
                    try
                    {
                        phAccessory = (Physical_Harness)serializer.Deserialize(fs);
                    }
                    catch (Exception)
                    {
                        alt_Logging_class.AddError("Deserialization Failed");
                    }
                    alt_Logging_class.AddMessage("Deserialization of Physical Harness XML completed successfully.");
                    PH_Catia_Synoptic_DataComparison(phAccessory, jsonfilePaths);
                    result = "Success";
                }
            }
            catch
            {
                result = "Deserialization Failed, Please check the PH xml and relevant product is open in CATIA.";

            }
            return result;
        }

        /// <summary>
        /// Reads and processes the Physical Harness XML file for CORRUG protection, checking bend radius compliance.
        /// </summary>
        /// <param name="xmlPath"> xml path </param>
        /// <param name="jsonfilePaths"> json file paths </param>
        /// <returns> status of operation </returns>
        public string ReadPhysicalHarnessCORRUG(string xmlPath, FilePaths jsonfilePaths)
        {
            CORRUG_BRCheck.Clear();

            string result = string.Empty;
            Physical_Harness phAccessory = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Physical_Harness));
                using (FileStream fs = new FileStream(xmlPath, FileMode.Open))
                {
                    phAccessory = (Physical_Harness)serializer.Deserialize(fs);
                    PH_CORRUG_BR_DIA_Check(phAccessory);
                    result = "Success";
                }
            }
            catch
            {
                result = "Deserialization Failed, Please check the PH xml.";

            }
            return result;
        }

        /// <summary>
        /// Reads and processes the Physical Harness XML file for Harting 3PL connectors, checking against 3PL project data.
        /// </summary>
        /// <param name="xmlPath"> xml path </param>
        /// <param name="jsonfilePaths"> json file paths </param>
        /// <returns> status of operation </returns>
        public string ReadPhysicalHarnessHarting(string xmlPath, FilePaths jsonfilePaths)
        {
            PHHarting3PLCheck.Clear();

            string result = string.Empty;
            Physical_Harness phAccessory = null;
            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(Physical_Harness));
                using (FileStream fs = new FileStream(xmlPath, FileMode.Open))
                {
                    phAccessory = (Physical_Harness)serializer.Deserialize(fs);
                    PH_3PLL_Harting_Check(phAccessory, jsonfilePaths.PL3_Projet_Path);
                    result = "Success";
                }
            }
            catch
            {
                result = "Deserialization Failed, Please check the PH xml.";
            }
            return result;
        }

        #region PH_Catia_Synoptic Data Comparison
        /// <summary>
        /// Compares data from Physical Harness XML with CATIA and Synoptic data.
        /// </summary>
        /// <param name="phAccessory"> Physical harness object</param>
        /// <param name="jsonfilePaths"> json file paths </param>
        public void PH_Catia_Synoptic_DataComparison(Physical_Harness phAccessory, FilePaths jsonfilePaths)
        {
            alt_Logging_class.AddMessage("PH_Catia_Synoptic_DataComparison started.");
            string HarnessName = GetHarnessName(phAccessory);
            alt_Logging_class.AddMessage("HarnessName: " + HarnessName);
            (CATIA_ConnectorsData,CATIA_NonConnectorsData) = GetProductDataFromCatia(HarnessName);
            PHFile_ConnectorsData = GetConnectorsDataFromPHFile(phAccessory);
            //List<(string, string)> PHFile_BackshellData = GetBackshellDataFromPHFile(phAccessory);
            PHFile_LugData = GetLugDataFromPHFile(phAccessory);
            Synoptic_ConnectorData = GetConnectorsDataFromSynoptic(jsonfilePaths, phAccessory.PhysicalHarness.Description);
            
            PH_Synoptic_Connector_DataComparison(PHFile_ConnectorsData, Synoptic_ConnectorData);
            PH_CATIA_Connector_DataComparison(CATIA_ConnectorsData, PHFile_ConnectorsData);
            PH_CATIA_Lug_DataComparison(CATIA_ConnectorsData, PHFile_LugData);
            alt_Logging_class.AddMessage("PH_Catia_Synoptic_DataComparison Completed.");
            //PH_CATIA_Backshell_DataComparison(CATIA_NonConnectorsData, PHFile_BackshellData);
        }

        /// <summary>
        /// Compares connector data between Physical Harness XML and Synoptic data.
        /// </summary>
        /// <param name="PHFile_ConnectorsData"> Physical harness data</param>
        /// <param name="Synoptic_ConnectorData"> Synoptic data </param>
        public void PH_Synoptic_Connector_DataComparison(List<(string, string)> PHFile_ConnectorsData, List<(string, string)> Synoptic_ConnectorData)
        {
            foreach (var PH_data in PHFile_ConnectorsData)
            {
                bool IsChecked = false;
                int count = 0;

                foreach (var Syn_data in Synoptic_ConnectorData)
                {
                    count++;
                    if (PH_data.Item1 == Syn_data.Item1)
                    {
                        IsChecked = true;
                        PH_Synoptic_DTRNumberCheck.Add((PH_data.Item1, Syn_data.Item1, IsChecked, PH_data.Item2));
                        break;
                    }
                    else if (IsChecked == false && count >= Synoptic_ConnectorData.Count)
                    {
                        PH_Synoptic_DTRNumberCheck.Add((PH_data.Item1, "", IsChecked, PH_data.Item2));
                    }
                }
            }

            foreach (var PH_data in PHFile_ConnectorsData)
            {
                bool IsChecked = false;
                int count = 0;

                foreach (var Syn_data in Synoptic_ConnectorData)
                {
                    count++;
                    if (PH_data.Item2 == Syn_data.Item2)
                    {
                        IsChecked = true;
                        PH_Synoptic_InstanceNameCheck.Add((PH_data.Item2, Syn_data.Item2, IsChecked));
                        break;
                    }
                    else if (IsChecked == false && count >= Synoptic_ConnectorData.Count)
                    {
                        PH_Synoptic_InstanceNameCheck.Add((PH_data.Item2, "", IsChecked));
                    }
                }
            }
        }

        /// <summary>
        /// Compares connector data between Physical Harness XML and CATIA data.
        /// </summary>
        /// <param name="CATIA_ConnectorsData"> Catia data </param>
        /// <param name="PHFile_ConnectorsData"> PH data </param>
        public void PH_CATIA_Connector_DataComparison(List<(string, string)> CATIA_ConnectorsData, List<(string, string)> PHFile_ConnectorsData)
        {
            alt_Logging_class.AddMessage("PH_CATIA_Connector_DataComparison started.");
            foreach (var PH_data in PHFile_ConnectorsData)
            {
                bool IsChecked = false;
                int count = 0;

                foreach (var CAT_data in CATIA_ConnectorsData)
                {
                    count++;
                    if (CAT_data.Item1 == PH_data.Item1)
                    {
                        IsChecked = true;
                        PH_CATIAConnector_DTRNumberCheck.Add((PH_data.Item1, CAT_data.Item1, IsChecked, PH_data.Item2));
                        alt_Logging_class.AddMessage($"Adding to PH_CATIAConnector_DTRNumberCheck {PH_data.Item1} {CAT_data.Item1} {IsChecked}");
                        break;
                    }
                    else if (IsChecked == false && count >= CATIA_ConnectorsData.Count)
                    {
                        PH_CATIAConnector_DTRNumberCheck.Add((PH_data.Item1, "", IsChecked, PH_data.Item2));
                        alt_Logging_class.AddMessage($"Adding to PH_CATIAConnector_DTRNumberCheck {PH_data.Item1} {CAT_data.Item1} {IsChecked}");
                    }
                }
            }
            alt_Logging_class.AddMessage($"Count of PH_CATIAConnector_DTRNumberCheck {PH_CATIAConnector_DTRNumberCheck.Count}");
            foreach (var PH_data in PHFile_ConnectorsData)
            {
                bool IsChecked = false;
                int count = 0;

                foreach (var CAT_data in CATIA_ConnectorsData)
                {
                    count++;
                    if (CAT_data.Item2 == PH_data.Item2)
                    {
                        IsChecked = true;
                        PH_CATIAConnector_InstanceNameCheck.Add((PH_data.Item2, CAT_data.Item2, IsChecked));
                        alt_Logging_class.AddMessage($"Adding to PH_CATIAConnector_InstanceNameCheck {PH_data.Item2} {CAT_data.Item2} {IsChecked}");
                        break;
                    }
                    else if (IsChecked == false && count >= CATIA_ConnectorsData.Count)
                    {
                        PH_CATIAConnector_InstanceNameCheck.Add((PH_data.Item2, "", IsChecked));
                        alt_Logging_class.AddMessage($"Adding to PH_CATIAConnector_InstanceNameCheck {PH_data.Item2} {CAT_data.Item2} {IsChecked}");
                    }
                }
            }

            alt_Logging_class.AddMessage($"Count of PH_CATIAConnector_InstanceNameCheck {PH_CATIAConnector_InstanceNameCheck.Count}");
        }

        /// <summary>
        /// Compares lug data between Physical Harness XML and CATIA data.
        /// </summary>
        /// <param name="CATIA_ConnectorsData"> Catia connector data </param>
        /// <param name="PHFile_LugData"> Lug data </param>
        public void PH_CATIA_Lug_DataComparison(List<(string, string)> CATIA_ConnectorsData, List<(string, string)> PHFile_LugData)
        {
            foreach (var PH_data in PHFile_LugData)
            {
                bool IsChecked = false;
                int count = 0;

                foreach (var CAT_data in CATIA_ConnectorsData)
                {
                    count++;
                    if (CAT_data.Item1 == PH_data.Item1)
                    {
                        IsChecked = true;
                        PH_CATIAConnector_DTRNumberCheck.Add((PH_data.Item1, CAT_data.Item1, IsChecked, PH_data.Item2));
                        break;
                    }
                    else if (IsChecked == false && count >= CATIA_ConnectorsData.Count)
                    {
                        PH_CATIAConnector_DTRNumberCheck.Add((PH_data.Item1, "", IsChecked, PH_data.Item2));
                    }
                }
            }

            foreach (var PH_data in PHFile_LugData)
            {
                bool IsChecked = false;
                int count = 0;

                foreach (var CAT_data in CATIA_ConnectorsData)
                {
                    count++;
                    if (CAT_data.Item2 == PH_data.Item2)
                    {
                        IsChecked = true;
                        PH_CATIAConnector_InstanceNameCheck.Add((PH_data.Item2, CAT_data.Item2, IsChecked));
                        break;
                    }
                    else if (IsChecked == false && count >= CATIA_ConnectorsData.Count)
                    {
                        PH_CATIAConnector_InstanceNameCheck.Add((PH_data.Item2, "", IsChecked));
                    }
                }
            }
        }

        #region Get Lists of Data's
        /// <summary>
        /// Gets connector data from the Synoptic JSON file for a specific harness.
        /// </summary>
        /// <param name="jsonfilePaths"> json file paths </param>
        /// <param name="_harnessName"> Harness name </param>
        /// <returns></returns>
        public List<(string, string)> GetConnectorsDataFromSynoptic(FilePaths jsonfilePaths, string _harnessName)
        {
            List<(string, string)> SynopticConnectorData = new List<(string, string)>();

            Dictionary<string, List<SynopticConnector>> _SynopticData = null;
            if (_SynopticData == null)
                _SynopticData = alt_JsonReaderService.GetInstance().ParseHarnessInSynoptic(jsonfilePaths.Synoptic_File_Path);

            foreach (var synopticdata in _SynopticData)
            {
                if (synopticdata.Key == _harnessName)
                {
                    foreach (var value in synopticdata.Value)
                    {
                        SynopticConnectorData.Add((value.PartNumber, value.SynopticConnectorName));
                    }
                }
            }
            return SynopticConnectorData;
        }

        /// <summary>
        /// Gets connector and non-connector product data from CATIA for a specific harness.
        /// </summary>
        /// <param name="HarnessName"> Harness name</param>
        /// <returns> 2 lists connectors non connectors </returns>
        public (List<(string, string)>, List<(string, string)>) GetProductDataFromCatia(string HarnessName)
        {
            alt_Logging_class.AddMessage(" Collecting Connectors from Catia Started.");
            List<(string, string)> CATIAFileConnectors = new List<(string, string)>();
            List<(string, string)> CATIAFileNonConnectors = new List<(string, string)>();

            Application application = alt_CATIA_Adapter.GetInstance().Catia_App;
            ProductDocument productDocument = alt_CATIA_Adapter.GetInstance().RootDocument;
            INFITF.Selection selection = productDocument.Selection;

            try
            {
                selection.Clear();
                string query = $"Name='{HarnessName}',all";
                selection.Search(query);

                for (int i = 1; i <= selection.Count; i++)
                {
                    Product product = selection.Item(i).Value as Product;
                    Product ParentProduct = product?.Parent as Product;

                    foreach (Product childproduct in ParentProduct.Products)
                    {
                        bool ConnectorAvailability = ALT_CATIA_Adapter.alt_CATIAEhi_Adapter.GetInstance().IsConnector(childproduct);
                        if (ConnectorAvailability)
                        {
                            try
                            {
                                CATIAFileConnectors.Add((childproduct.get_PartNumber(), childproduct.get_Name()));
                                alt_Logging_class.AddMessage("Adding to CATIAFileConnectors " + childproduct.get_PartNumber() + "," + childproduct.get_Name());
                            }
                            catch (Exception)
                            {
                                alt_Logging_class.AddError("Adding to CATIAFileConnectors Failed");
                            }
                        }
                        else
                        {
                            try
                            {
                                CATIAFileNonConnectors.Add((childproduct.get_PartNumber(), childproduct.get_Name()));
                                alt_Logging_class.AddMessage("Adding to CATIAFileNonConnectors " + childproduct.get_PartNumber() + "," + childproduct.get_Name());
                            }
                            catch (Exception)
                            {
                                alt_Logging_class.AddError("Adding to CATIAFileNonConnectors Failed");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                alt_Logging_class.AddMessage("Returning Catia Connectors (null, null)");
                return (null, null);
            }
            alt_Logging_class.AddMessage($"Catia Connectors Collected. CATIAFileConnectors: { CATIAFileConnectors.Count }, CATIAFileNonConnectors: { CATIAFileNonConnectors.Count }");
            
            return (CATIAFileConnectors, CATIAFileNonConnectors);
        }

        /// <summary>
        /// Gets connector data from the Physical Harness XML file.
        /// </summary>
        /// <param name="phAccessory"> Physical Harness object</param>
        /// <returns> Connector data </returns>
        public List<(string, string)> GetConnectorsDataFromPHFile(Physical_Harness phAccessory)
        {
            List<(string, string)> PHFileConnectors = new List<(string, string)>();

            foreach (var connectiveDevice in phAccessory.PhysicalHarness.ConnectiveDevicesList.ConnectiveDevice)
            {
                if (connectiveDevice.MountedOnHarness == "Yes" && connectiveDevice.Type != "Shell")
                {
                    PHFileConnectors.Add((connectiveDevice.PartNumber, connectiveDevice.Tag));
                }
            }

            return PHFileConnectors;
        }

        /// <summary>
        /// Gets backshell data from the Physical Harness XML file.
        /// </summary>
        /// <param name="phAccessory"> Physical Harness object </param>
        /// <returns> Backshell data </returns>
        public List<(string, string)> GetBackshellDataFromPHFile(Physical_Harness phAccessory)
        {
            List<(string, string)> PHFile_BackshellType = new List<(string, string)>();

            foreach (var connectiveDevice in phAccessory.PhysicalHarness.ConnectiveDevicesList.ConnectiveDevice)
            {
                if (connectiveDevice.MountedOnHarness == "Yes")
                {
                    foreach (var ConnectiveAccessory in connectiveDevice.ConnectiveAccessory)
                    {
                        if (ConnectiveAccessory.Type == "Backshell")
                        {
                            PHFile_BackshellType.Add((ConnectiveAccessory.PartNumber, ConnectiveAccessory.Label));
                        }
                    }
                }
            }
            return PHFile_BackshellType;
        }

        /// <summary>
        /// Gets lug data from the Physical Harness XML file.
        /// </summary>
        /// <param name="phAccessory"> Physical Harness object </param>
        /// <returns> Lug Data </returns>
        public List<(string, string)> GetLugDataFromPHFile(Physical_Harness phAccessory)
        {
            List<(string, string)> PHFile_LugType = new List<(string, string)>();

            foreach (var connectiveDevice in phAccessory.PhysicalHarness.ConnectiveDevicesList.ConnectiveDevice)
            {
                if (connectiveDevice.MountedOnHarness == "No" && connectiveDevice.Type == "Lug")
                {
                    PHFile_LugType.Add((connectiveDevice.PartNumber, connectiveDevice.Tag));
                }
            }
            return PHFile_LugType;
        }

        /// <summary>
        /// Gets the harness name from the Physical Harness object. 
        /// </summary>
        /// <param name="phAccessory"> Physical Harness object </param>
        /// <returns> Harness name </returns>
        public string GetHarnessName(Physical_Harness phAccessory)
        {
            string result = string.Empty;
            foreach (var userAttribute in phAccessory.PhysicalHarness.GeometricalHarness.UserAttribute)
            {
                if (userAttribute.AttributeName == "See_MBS_Name")
                {
                    result = userAttribute.AttributeValue;
                    break;
                }
            }
            return result;
        }
        #endregion

        #region PH_CATIA_Backshell_DataComparison
        //public void PH_CATIA_Backshell_DataComparison(List<(string, string)> CATIA_NonConnectorsData, List<(string, string)> PHFile_BackshellData)
        //{
        //    foreach (var PH_data in PHFile_BackshellData)
        //    {
        //        bool matching = false;
        //        int count = 0;

        //        foreach (var CAT_data in CATIA_NonConnectorsData)
        //        {
        //            count++;
        //            if (CAT_data.Item2.Contains("BACKSHELL"))
        //            {
        //                if (CAT_data.Item1 == PH_data.Item1 && CAT_data.Item2 == PH_data.Item2)
        //                {
        //                    matching = true;
        //                    PH_CATIA_Backshell_MatchingData.Add((PH_data.Item1, PH_data.Item2));
        //                    break;
        //                }
        //            }
        //            else if (matching == false && count >= CATIA_NonConnectorsData.Count)
        //            {
        //                PH_CATIA_Backshell_NotMatchingData.Add((PH_data.Item1, PH_data.Item2));
        //            }

        //        }
        //    }
        //}
        #endregion

        #endregion

        #region PH_CORRUG_BR_DIA_Check
        /// <summary>
        /// Checks bend radius compliance for CORRUG protection in the Physical Harness XML.
        /// </summary>
        /// <param name="phAccessory"> Physical Harness object </param>
        public void PH_CORRUG_BR_DIA_Check(Physical_Harness phAccessory)
        {
            string HarnessName = PhysicalHarnessDataPreparation.GetInstance().GetHarnessName(phAccessory);

            foreach (var GeometricalHarnessBranch in phAccessory.PhysicalHarness.GeometricalHarness.GeometricalHarnessBranchesList.GeometricalHarnessBranch)
            {
                foreach (var Segment in GeometricalHarnessBranch.Segment)
                {
                    if (!(Segment.DiameterStatus == "Match" || Segment.DiameterStatus == "OK"))
                    {
                        foreach (var Protection in Segment.Protection)
                        {
                            if (Protection.Type == "Sleeve")
                            {
                                if (Protection.Label.Contains("CORRUG"))
                                {
                                    string BranchName = null;
                                    foreach (var userAttribute in GeometricalHarnessBranch.UserAttribute)
                                    {
                                        if (userAttribute.AttributeName == "See_Branchable_Name")
                                            BranchName = userAttribute.AttributeValue;
                                    }
                                    string Diameter = Protection.Diameter;
                                    string Label = Protection.Label;

                                    Match match = Regex.Match(Label, @" - (\w+)\s*/");

                                    if (match.Success)
                                    {
                                        string brand = match.Groups[1].Value;
                                        Console.WriteLine(brand);

                                        double CalculateBendRadius = MultiBranchableDataPrepation.GetInstance().CalculateBendRadiusUsingSupplier(Diameter, brand);
                                        bool isChecked = false;
                                        if (CalculateBendRadius <= Segment.BendRadius)
                                        {
                                            isChecked = true;
                                            CORRUG_BRCheck.Add((BranchName, Segment.Tag, Protection.PartNumber, isChecked));
                                        }
                                        else
                                        {
                                            CORRUG_BRCheck.Add((BranchName, Segment.Tag, Protection.PartNumber, isChecked));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region PH_Harting3PLCheck
        /// <summary>
        /// Checks Harting 3PL connectors in the Physical Harness XML against a 3PL project.
        /// </summary>
        /// <param name="phAccessory"> Physical Harness object </param>
        /// <param name="PL3_Projet_Path"> 3Pl projet Path </param>
        public void PH_3PLL_Harting_Check(Physical_Harness phAccessory, string PL3_Projet_Path)
        {
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            string pl3connector = PL3_Projet_Path.Replace(".json", "_ConnectorList.json");
            Dictionary<string, List<PL3_Global>> pl3_Global = alt_JsonReaderService.Read3PLProjetJson(PL3_Projet_Path);
            Dictionary<string, PL3_Connector> pl3_Connectors = alt_JsonReaderService.Read3PLProjetConnectorJson(pl3connector);


            Dictionary<string, string> keyValuePairs = new Dictionary<string, string>();

            foreach (List<PL3_Global> plGlobals in pl3_Global.Values)
            {
                foreach (PL3_Global pl3 in plGlobals)
                {
                    if (!keyValuePairs.ContainsKey(pl3.DTR_Number))
                        keyValuePairs.Add(pl3.DTR_Number, pl3.DTR_Number);
                }
            }

            foreach (string dtrNumber in pl3_Connectors.Keys)
            {
                try
                {
                    if (!keyValuePairs.ContainsKey(dtrNumber))
                        keyValuePairs.Add(dtrNumber, dtrNumber);
                }
                catch (Exception)
                {
                    alt_Logging_class.AddError($"----- Error while adding dtrNumber {dtrNumber} to Dictionary");
                }
            }

            PHFile_ConnectorsData = GetConnectorsDataFromPHFile(phAccessory);
            
            foreach (var PH_DTRNumber in PHFile_ConnectorsData)
            {
                string tempstr = string.Empty;
                keyValuePairs.TryGetValue(PH_DTRNumber.Item1, out tempstr);
                if (!string.IsNullOrEmpty(tempstr))
                {
                    PHHarting3PLCheck.Add((PH_DTRNumber.Item1, PH_DTRNumber.Item2, true));
                }
            }
        }

        public List<string> PPL_Harting(string excelFilePath)
        {
            var DTRNumbers_3PLL = new List<string>();
            try
            {
                using (SpreadsheetDocument document = SpreadsheetDocument.Open(excelFilePath, false))
                {
                    WorkbookPart workbookPart = document.WorkbookPart;

                    foreach (Sheet sheet in workbookPart.Workbook.Sheets)
                    {
                        // Get the relationship ID of the sheet
                        string relationshipId = sheet.Id;

                        // Try to get the WorksheetPart using the relationship ID
                        OpenXmlPart part = workbookPart.GetPartById(relationshipId);

                        Console.WriteLine(sheet.Name);
                        if (sheet.Name == "Connecteur Harting " && part is WorksheetPart worksheetPart)
                        {
                            var sheetData = worksheetPart.Worksheet.GetFirstChild<SheetData>();
                            if (sheetData == null)
                                 continue;

                             Row headerRow = sheetData.Elements<Row>().FirstOrDefault(r => r.RowIndex == 3);
                             if (headerRow == null)
                                  continue;

                             string dtrColumnLetter = null;

                            foreach (Cell cell in headerRow.Elements<Cell>())
                            {
                                string headerText = GetCellValue(cell, workbookPart);

                                if (string.Equals(headerText, "DTR", StringComparison.OrdinalIgnoreCase))
                                {
                                    dtrColumnLetter = GetColumnName(cell.CellReference);
                                    break;
                                }
                            }

                            if (string.IsNullOrEmpty(dtrColumnLetter))
                                continue; // "DTR" not found in this sheet

                            // Start from row 4 onwards
                            foreach (Row row in sheetData.Elements<Row>().Where(r => r.RowIndex >= 4))
                            {
                                // Get the cell in column D (column 4)
                                Cell cell = row.Elements<Cell>().FirstOrDefault(c => string.Compare(GetColumnName(c.CellReference), dtrColumnLetter, true) == 0);

                                if (cell != null)
                                {
                                    string cellValue = GetCellValue(cell, workbookPart);
                                    DTRNumbers_3PLL.Add(cellValue);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                string Errormsg = exception.Message;
                return null;
            }
            return DTRNumbers_3PLL;
        }

        private static string GetColumnName(string cellReference)
        {
            // Extract the column letters from cell reference, e.g. "D15" => "D"
            if (string.IsNullOrEmpty(cellReference))
                return null;

            string columnName = new string(cellReference.TakeWhile(c => !char.IsDigit(c)).ToArray());
            return columnName;
        }

        private static string GetCellValue(Cell cell, WorkbookPart workbookPart)
        {
            if (cell == null || cell.CellValue == null)
                return string.Empty;

            string value = cell.CellValue.InnerText;

            if (cell.DataType != null && cell.DataType == CellValues.SharedString)
            {
                var stringTable = workbookPart.SharedStringTablePart;
                if (stringTable != null)
                {
                    return stringTable.SharedStringTable.ElementAt(int.Parse(value)).InnerText;
                }
            }

            return value;
        }

        #endregion

        #endregion
    }
}