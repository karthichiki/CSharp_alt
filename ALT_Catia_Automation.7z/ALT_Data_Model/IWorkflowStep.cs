﻿
namespace ALT_Data_Model
{
    // Interface defining the structure of each workflow step
    public interface IWorkflowStep
    {
        //Preparation for workflow step
        bool Prepare();

        // Execute the workflow step
        bool Execute();

        //Finish the workflow
        bool Finish();
    }
}

