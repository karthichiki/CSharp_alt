﻿using ACNEHIWrapper;
using ALT_Data_Model.SectionCut_Data_Model;
using ALT_Logging;
using CatiaDotNet.CommonExtensions;
using CatiaDotNet.CommonServices;
using IGESDataProcessor;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using MECMOD;
using Newtonsoft.Json;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Windows;
using System.Windows.Media.Media3D;
using Test;

namespace ALT_Data_Model
{
    /// <summary>
    /// Data PreProcessing class to handle various data extraction and processing tasks related to CATIA models.
    /// </summary>
    public class DataPreProcessing
    {
        public DataPreProcessing()
        {

        }

        /// <summary>
        /// Export Equipment Location Data to JSON file
        /// </summary>
        /// <param name="destinationPath"> destination path </param>
        /// <returns> Status of export </returns>
        public string ExportEqtLocationData(string destinationPath)
        {
            List<CADConnector> connectors = new List<CADConnector>();
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Product product = null;
            INFITF.Window window = adapter.GetWindowByProductDescriptionToExtract("DEVICE LOCATION", ref product);
            if (window == null)
            {
                string errMsg = "Equipment Location Product is not Opened, Please Open and Try again";
                MessageBox.Show(errMsg, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return errMsg;
            }
                
            try
            {
                window.Activate();
                CADEqtLocation eqtLocation = new CADEqtLocation();
                eqtLocation.Name = product.get_Name();

                foreach (Product child in product.Products)
                {
                    if (child == null)
                        continue;

                    if (adapter.IsActiveProduct(child) == false)
                        continue;

                    Publication bundleCnctPub = child.GetPublication("BundleCnctPt1");
                    if (bundleCnctPub == null)
                        continue;

                    //Is ElbConnector
                    string ConnName = child.get_Name();
                    string prtNumber = child.get_PartNumber();
                    Matrix4d prdMatrix = adapter.GetGlobalMatrix4d(child);

                    object[] Abs_Position = new object[12];
                    Abs_Position = adapter.ConvertMatrixToArray(prdMatrix);

                    CADPosition position = new CADPosition();
                    position.X = (double)Abs_Position[9];
                    position.Y = (double)Abs_Position[10];
                    position.Z = (double)Abs_Position[11];

                    CADRotation rotation = new CADRotation();
                    rotation.M11 = (double)Abs_Position[0];
                    rotation.M12 = (double)Abs_Position[1];
                    rotation.M13 = (double)Abs_Position[2];
                    rotation.M21 = (double)Abs_Position[3];
                    rotation.M22 = (double)Abs_Position[4];
                    rotation.M23 = (double)Abs_Position[5];
                    rotation.M31 = (double)Abs_Position[6];
                    rotation.M32 = (double)Abs_Position[7];
                    rotation.M33 = (double)Abs_Position[8];

                    CADTransform transform = new CADTransform();
                    transform.Position = position;
                    transform.Rotation = rotation;

                    CADConnector connector = new CADConnector();
                    connector.Name = ConnName;
                    connector.PartNumber = prtNumber;
                    connector.Transform = transform;

                    connectors.Add(connector);
                }

                if(connectors == null || connectors.Count == 0)
                {
                    string errMsg = "Design mode not applied or connectors not found, please check";
                    MessageBoxOnTop.BringMessageBoxToTop(errMsg, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return errMsg;
                }

                eqtLocation.Connectors = connectors;

                // Serialize to JSON
                string jsonString = JsonConvert.SerializeObject(eqtLocation, Formatting.Indented);
                bool exists = System.IO.Directory.Exists(destinationPath);

                if (!exists)
                    System.IO.Directory.CreateDirectory(destinationPath);
                // Write JSON to file
                System.IO.File.WriteAllText(destinationPath + eqtLocation.Name +"_EqtLocation.json", jsonString);
            }
            catch (Exception exception)
            {
                string errorMsg = exception.Message;
                return errorMsg;
            }
            return string.Empty;
        }


        /// <summary>
        ///  Extract IGES data in Json format for all the cable trays in the assembly
        /// </summary>
        /// <param name="PathToStoreIGES"> destination path </param>
        /// <param name="Description_Key"></param>
        public void BulkExtractIgesData(string PathToStoreIGES)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            string configPath = adapter.GetConfigFolderPath();
            if (configPath == string.Empty)
            {
                MessageBoxOnTop.BringMessageBoxToTop("Application could not able to get the config file", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            Dictionary<string, object> configValues = adapter.CheckAndSetConfigDefaultValues(configPath);
            object returnObj;
            configValues.TryGetValue("CableTrayString",out returnObj);
            if (returnObj is null)
            {
                MessageBoxOnTop.BringMessageBoxToTop("Application could not able to get the config file", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string[] Description_Key = returnObj.ToString().Split(',');
            IList<Product> products = adapter.RootProduct.GetProductDescendantChildren();
            List<Product> TrayProducts = products.Where(x => x.IsPart() && Description_Key.Any(key => x.get_DescriptionRef().Trim().ToUpper().Contains(key.Trim()))).ToList();

            if (TrayProducts == null || TrayProducts.Count == 0)
            {
                string errMsg = "Design mode not applied or cabletrays not found, please check";
                MessageBoxOnTop.BringMessageBoxToTop(errMsg, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Check for the folder to store
            string FolderToStore = GetFolderPathToExtractIGESData(PathToStoreIGES);
            if (FolderToStore == string.Empty)
            {
                return;
            }
            foreach (Product EachProduct in TrayProducts)
            {
                ExtractToJsonFormat(EachProduct, FolderToStore);
            }
        }


        /// <summary>
        /// This function will extract IGES data in Json format to the given folder location
        /// </summary>
        /// <param name="EachProduct"> Product </param>
        /// <param name="FolderToStore"> destination folder </param>
        private void ExtractToJsonFormat(Product EachProduct, string FolderToStore)
        {
            alt_CATIA_Adapter.GetInstance().SetDisplayFileAlerts(false);

            string ShortenPath = GenerateUniqueIdentifier(EachProduct.GetFullPath());
            IGPro_IGESPartGeometryInfo iGPro_IGESPartGeometryInfo = new IGPro_IGESPartGeometryInfo();
            Product_cls product_Cls = new Product_cls();
            product_Cls.part_number = EachProduct.get_PartNumber().ToString();
            product_Cls.part_name = EachProduct.get_Name().ToString();
            product_Cls.full_Path = EachProduct.GetFullPath();
            product_Cls.part_description = EachProduct.get_DescriptionRef();

            Matrix4d ProductMatrix = alt_CATIA_Adapter.GetInstance().GetGlobalMatrix4d(EachProduct);

            Matrix3D ProductMatrixNew = alt_CATIA_Adapter.GetInstance().ConvertToMatrix3D(ProductMatrix);
            product_Cls.Transformation = ProductMatrixNew;
            bool gotIGESdata = IGESDataProcesser_cls.GetIGESPartGeometryInfo(EachProduct, ProductMatrixNew, iGPro_IGESPartGeometryInfo);

            product_Cls.IGESData = iGPro_IGESPartGeometryInfo;
            string JsonfilePath = FolderToStore + @"\" + ShortenPath + ".json";
            //string JsonfilePath = ShortenPath + ".json";

            string json = JsonConvert.SerializeObject(product_Cls);
            System.IO.File.WriteAllText(JsonfilePath, json);
        }

        /// <summary>
        /// This function will generate unique identifier based on the properties of the part
        /// </summary>
        /// <param name="partNumber"> Partnumber </param>
        /// <returns> UniqueIdentifier </returns>
        private string GenerateUniqueIdentifier(string partNumber)
        {
            // Combine properties into a single string
            string combinedProperties = $"{partNumber}";

            // Generate an MD5 hash
            using (MD5 md5 = MD5.Create())
            {
                byte[] hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(combinedProperties));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    sb.Append(b.ToString("x2"));
                }
                return sb.ToString();
            }
        }

        /// <summary>
        /// This function will Create or get folder path to store the IGES
        /// </summary>
        /// <param name="PathToStoreIGES"> destination path</param>
        /// <returns> Destination path </returns>
        private string GetFolderPathToExtractIGESData(string PathToStoreIGES)
        {
            string FolderToStorecheck = PathToStoreIGES;
            string FolderToStore = string.Empty;
            if (Directory.Exists(FolderToStorecheck))
            {
                FolderToStore = FolderToStorecheck;
            }
            else
            {
                try
                {
                    Directory.CreateDirectory(FolderToStorecheck);

                    FolderToStore = FolderToStorecheck;
                }
                catch (Exception ex)
                {
                    FolderToStore = string.Empty;
                    Console.WriteLine("Unable to create folder to store IGES files " + ex.Message);
                }
            }
            return FolderToStore;
        }

        /// <summary>
        /// Extract custom IGES data in Json format for selected part in the assembly
        /// </summary>
        /// <param name="PathToExtractIGES"> destination path </param>
        /// <param name="DirectionSelection"> direction </param>
        public void CustomExtractIgesData(string PathToExtractIGES, bool DirectionSelection = true)
        {
            // Ask user to select the product.
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Product product = CatiaSelection.GetCatiaSelection<Product>("Please select a Part in Assembly to Export as IGES");
            if (adapter.IsDesignModeApplied(product))
            {
                if (product == null || product.IsPart() == false)
                {
                    MessageBox.Show("Please select only part to export as IGES");
                    return;
                }

                // Check for the folder to store
                string FolderToStore = GetFolderPathToExtractIGESData(PathToExtractIGES);
                if (FolderToStore == string.Empty)
                {
                    return;
                }
                ExtractToJsonFormat(product, FolderToStore);
            }
            else
                MessageBox.Show("Please activate design mode for root product", "Design Mode");
        }

        /// <summary>
        /// Extract Section Cut Segments from Sketch
        /// </summary>
        /// <param name="destinationPath"> destination path</param>
        /// <returns> status of extract </returns>
        public string ExtractSectionCutSegments(string destinationPath)
        {
            // Ask user to select the Part.
            Product sectionCutProd = CatiaSelection.GetCatiaSelection<Product>("Please select a Part in Assembly to extract the section cuts segemnts.");
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (adapter.IsDesignModeApplied(sectionCutProd))
            {
                // Check for Swction Part
                bool IsCorrectPart = IsSectionCutPart(sectionCutProd);

                if (IsCorrectPart == false)
                {
                    MessageBox.Show("Please select section cut part only to extract segemnts.");
                    return "Nothing Extracted";
                }

                // Extract Section cut segments.
                return ExtractSegmentsFromSketch(sectionCutProd, destinationPath);
            }
            else
            {
                MessageBox.Show("Please activate design mode for selected product", "Design Mode");
                return string.Empty;
            }
        }

        /// <summary>
        /// Extract Segments From Sketch
        /// </summary>
        /// <param name="prod"> Product </param>
        /// <param name="destinationPath"> Destination path </param>
        /// <returns> status </returns>
        private string ExtractSegmentsFromSketch(Product prod, string destinationPath)
        {
            Matrix4d matrix4D = prod.GetGlobalMatrix4d();
            Matrix3D  matrix3D =  alt_CATIA_Adapter.GetInstance().ConvertToMatrix3D(matrix4D);
            List<SectionCut> sectionCuts = new List<SectionCut>();
            Part part = prod.GetPart();
            HybridBody hybridBody = GetPrincipleGeometricalSet(prod);
            if (hybridBody == null)
            {
                MessageBoxOnTop.BringMessageBoxToTop("\"PRINCIPLE SECTION\" or \"SECTION DE PRINCIPE\" geometrical set not found. Please check the selected part.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return "Nothing Extracted";
            }
            foreach (Sketch eachSketch in hybridBody.HybridSketches)
            {
                SectionCut sectionCut = new SectionCut(eachSketch, matrix3D, part);
                sectionCuts.Add(sectionCut);
            }
            string json = JsonConvert.SerializeObject(sectionCuts, Formatting.Indented);
            bool exists = System.IO.Directory.Exists(destinationPath);

            if (!exists)
                System.IO.Directory.CreateDirectory(destinationPath);

            System.IO.File.WriteAllText(destinationPath + @"\Sectioncuts.json", json);
            return string.Empty;
        }

        private HybridBody GetPrincipleGeometricalSet(Product prod)
        {
            HybridBody hybridBody = null;
            hybridBody = prod.GetPart().GetHybridBody("PRINCIPLE SECTION");
            if (hybridBody == null)
            {
                hybridBody = prod.GetPart().GetHybridBody("SECTION DE PRINCIPE");
            }
            return hybridBody;
        }



        /// <summary>
        /// Sketch Global Axis
        /// </summary>
        /// <param name="sketch"></param>
        /// <param name="X"></param>
        /// <param name="Y"></param>
        private void SketchGlobalAxis(Sketch sketch, double X, double Y)
        {
            object[] transformationMatrix = new object[9];
            sketch.GetAbsoluteAxisData(transformationMatrix);

            // Extract transformation values
            double xOrigin = (double)transformationMatrix[0];   // X of sketch origin in 3D
            double yOrigin = (double)transformationMatrix[1];  // Y of sketch origin in 3D
            double zOrigin = (double)transformationMatrix[2];  // Z of sketch origin in 3D

            double xDirX = (double)transformationMatrix[3];  // X direction vector X component
            double xDirY = (double)transformationMatrix[4];  // X direction vector Y component
            double xDirZ = (double)transformationMatrix[5];  // X direction vector Z component

            double yDirX = (double)transformationMatrix[6];  // Y direction vector X component
            double yDirY = (double)transformationMatrix[7];  // Y direction vector Y component
            double yDirZ = (double)transformationMatrix[8];  // Y direction vector Z component


            // Convert 2D sketch point to 3D global coordinates
            double globalX = xOrigin + X * xDirX + Y * yDirX;
            double globalY = yOrigin + X * xDirY + Y * yDirY;
            double globalZ = zOrigin + X * xDirZ + Y * yDirZ;

        }

        /// <summary>
        /// Check for Section Cut Part
        /// </summary>
        /// <param name="prod"> Product </param>
        /// <returns>Wether section cut part or not</returns>
        private bool IsSectionCutPart(Product prod)
        {

            if (prod == null)
                return false;

            if (!prod.IsPart())
                return false;
            

            MessageBoxResult result = MessageBoxResult.None;
            result = MessageBox.Show("Are you sure you have selected right section cut part?", "ALSTOM", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes) 
                return true;
            else 
                return false;
        }

        /// <summary>
        /// Extract Catalog Data
        /// </summary>
        /// <param name="catalogPath"> Catalog path </param>
        /// <param name="releaseFolderPath"> folder path</param>
        /// <returns> Extract status </returns>
        public string ExtractCatalogData(string catalogPath, string releaseFolderPath)
        {
            alt_Logging_class.AddMessage("ExtractCatalogData Started");
            alt_CATIA_Adapter alt_CATIA_Adapter = alt_CATIA_Adapter.GetInstance();

            CATIProduct BRS = alt_CATIA_Adapter.RootProduct as CATIProduct;
            if (BRS == null) return "";
            alt_Logging_class.AddMessage(BRS.get_Name() + " BRS");
            Array infoArray = new string[] { };
            double flag = 0.0;
            alt_Logging_class.AddMessage(catalogPath);
            BRS.GetCatalogInformation(catalogPath, out infoArray, out flag);
            alt_Logging_class.AddMessage(infoArray.Length + " infoArray");
            if (flag != 1) return flag.ToString();
            string res;
            try
            {
                res = ConvertToJson(infoArray);
            }
            catch (Exception ex)
            {
                // Log or handle error
                Console.WriteLine("Error during JSON conversion: " + ex.Message);
                alt_Logging_class.AddMessage("res came to exception");
                res = "2"; // or handle as needed
            }
            string jsonFilePath = releaseFolderPath + "\\" + "SLEEVE_ELEC.json";
            File.WriteAllText(jsonFilePath, res);
            alt_Logging_class.AddMessage("Json file created");
            return flag.ToString();
        }

        /// <summary>
        /// Convert To Json
        /// </summary>
        /// <param name="lines"> Array of lines </param>
        /// <returns> json value </returns>
        public static string ConvertToJson(Array lines)
        {
            //var result = new List<SleeveItem>();

            Dictionary<string, Dictionary<string, Dictionary<string, List<string>>>> fullCatalog = new Dictionary<string, Dictionary<string, Dictionary<string, List<string>>>>();
            Dictionary<string, Dictionary<string, List<string>>> subchapterDict = new Dictionary<string, Dictionary<string, List<string>>>();
            string rootChapter = "";
            foreach (string line in lines)
            {
                string[] parts = line.Split('|');
                rootChapter = parts.Length > 0 ? parts[0].Trim() : null;
                string subchapter = parts.Length > 1 ? parts[1].Trim() : null;
                string family = parts.Length > 1 ? parts[2].Trim() : null;
                string sleevePart = parts.Length > 1 ? parts[3].Trim() : null;
                Console.WriteLine(rootChapter + "=" + subchapter + "=" + family + "=" + sleevePart);

                if (subchapterDict.ContainsKey(subchapter) == false)
                {
                    Dictionary<string, List<string>> familyDict = new Dictionary<string, List<string>>();
                    List<string> newPartList = new List<string>();
                    newPartList.Add(sleevePart);
                    familyDict[family] = newPartList;
                    subchapterDict[subchapter] = familyDict;
                }
                else
                {
                    Dictionary<string, List<string>> familyDict = subchapterDict[subchapter];
                    if (familyDict.ContainsKey(family) == false)
                    {
                        List<string> newPartList = new List<string>();
                        newPartList.Add(sleevePart);
                        familyDict[family] = newPartList;
                    }
                    else
                    {
                        List<string> newPartList = familyDict[family];
                        newPartList.Add(sleevePart);
                    }
                }
            }
            fullCatalog.Add(rootChapter, subchapterDict);
            string jsonOutput = JsonConvert.SerializeObject(fullCatalog, Formatting.Indented);
            return jsonOutput;
        }

        /// <summary>
        /// extract Circle Segments
        /// </summary>
        /// <param name="product"> Product </param>
        /// <returns> Dictionary with CircleSegment</returns>
        public IDictionary<string, CircleSegment> ExtractCircleSegments(Product product)
        {
            var circleSegmentDict = new Dictionary<string, CircleSegment>();

            Matrix4d matrix4D = product.GetGlobalMatrix4d();
            Matrix3D matrix3D = alt_CATIA_Adapter.GetInstance().ConvertToMatrix3D(matrix4D);

            Part part = product.GetPart();
            HybridBody hybridBody = GetPrincipleGeometricalSet(product);
            if (hybridBody == null)
            {
                MessageBoxOnTop.BringMessageBoxToTop("\"PRINCIPLE SECTION\" or \"SECTION DE PRINCIPE\" geometrical set not found. Please check the selected part.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return circleSegmentDict;
            }
            foreach (Sketch eachSketch in hybridBody.HybridSketches)
            {
                SectionCut sectionCut = new SectionCut(eachSketch, matrix3D, part);
                foreach (var segment in sectionCut.Segments)
                {
                    if (segment is CircleSegment circleSegment)
                    {
                        string key = $"{sectionCut.Name}/{circleSegment.Name}";
                        if (!circleSegmentDict.ContainsKey(key))
                            circleSegmentDict.Add(key, circleSegment);
                    }
                }
            }

            return circleSegmentDict;
        }
    }
}
