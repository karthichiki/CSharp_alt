﻿using Newtonsoft.Json;
using System;

namespace ALT_Data_Model
{
    /// <summary>
    /// CAD Transform class to store the position and rotation of an object in 3D space.
    /// </summary>
    public class CADTransform: IEquatable<CADTransform>
    {
        [JsonProperty("position")]
        public CADPosition Position { get; set; }
        [JsonProperty("rotation")]
        public CADRotation Rotation { get; set; }

        public CADTransform()
        {
        }

        /// <summary>
        /// Check equality of two CADTransform objects by comparing their Position and Rotation properties.
        /// </summary>
        /// <param name="obj"> CADTransform object </param>
        /// <returns> equality status </returns>
        public override bool Equals(object obj)
        {
            return Equals(obj as CADTransform);
        }

        /// <summary>
        /// Check equality of two CADTransform objects by comparing their Position and Rotation properties.
        /// </summary>
        /// <param name="other"> CADTransform object </param>
        /// <returns> equality status </returns>
        public bool Equals(CADTransform other)
        {
            if (other == null) return false;
            //bool positionEqual = CheckPercentage(other);
            bool positionEqual = Position.Equals(other.Position);
            bool rotationEqual = Rotation.Equals(other.Rotation);
            //return Position.Equals(other.Position) && 
            //       Rotation.Equals(other.Rotation);
            return positionEqual && rotationEqual;
        }

        public bool CheckPercentage(CADTransform other)
        {

            if (other == null) return false;
            double tolerance = 0.5 / 100.0;
            bool positionEqual = Math.Abs(Position.X - other.Position.X) <= Math.Abs(Position.X * tolerance) &&
                                 Math.Abs(Position.Y - other.Position.Y) <= Math.Abs(Position.Y * tolerance) &&
                                 Math.Abs(Position.Z - other.Position.Z) <= Math.Abs(Position.Z * tolerance);
            //bool rotationEqual = Math.Abs(Rotation.M11 - other.Rotation.M11) <= Math.Abs(Rotation.M11 * tolerance) &&
            //                     Math.Abs(Rotation.M12 - other.Rotation.M12) <= Math.Abs(Rotation.M12 * tolerance) &&
            //                     Math.Abs(Rotation.M13 - other.Rotation.M13) <= Math.Abs(Rotation.M13 * tolerance) &&
            //                     Math.Abs(Rotation.M21 - other.Rotation.M21) <= Math.Abs(Rotation.M21 * tolerance) &&
            //                     Math.Abs(Rotation.M22 - other.Rotation.M22) <= Math.Abs(Rotation.M22 * tolerance) &&
            //                     Math.Abs(Rotation.M23 - other.Rotation.M23) <= Math.Abs(Rotation.M23 * tolerance) &&
            //                     Math.Abs(Rotation.M31 - other.Rotation.M31) <= Math.Abs(Rotation.M31 * tolerance) &&
            //                     Math.Abs(Rotation.M32 - other.Rotation.M32) <= Math.Abs(Rotation.M32 * tolerance) &&
            //                     Math.Abs(Rotation.M33 - other.Rotation.M33) <= Math.Abs(Rotation.M33 * tolerance);
            
            return positionEqual;
        }

        /// <summary>
        /// Generate a hash code for the CADTransform object based on its Position and Rotation properties.
        /// </summary>
        /// <returns> Hash code </returns>
        public override int GetHashCode()
        {
            return Position.GetHashCode() ^ Rotation.GetHashCode();
        }

        /// <summary>
        /// Convert the CADTransform object to an array of 12 elements.
        /// </summary>
        /// <returns> array with position </returns>
        public object[] ConvertTransformToArray()
        {
            object[] array = new object[12];

            array[0] = Rotation.M11;
            array[1] = Rotation.M12;
            array[2] = Rotation.M13;

            array[3] = Rotation.M21;
            array[4] = Rotation.M22;
            array[5] = Rotation.M23;

            array[6] = Rotation.M31;
            array[7] = Rotation.M32;
            array[8] = Rotation.M33;

            array[9] = Position.X;
            array[10] = Position.Y;
            array[11] = Position.Z;

            return array;
        }
    }
}
