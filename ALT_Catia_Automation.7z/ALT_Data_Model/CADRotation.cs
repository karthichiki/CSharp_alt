﻿using Newtonsoft.Json;
using System;

namespace ALT_Data_Model
{
    /// <summary>
    /// CAD Rotation class to store a 3x3 rotation matrix representing the orientation of an object in 3D space.
    /// </summary>
    public class CADRotation: IEquatable<CADRotation>
    {
        [JsonProperty("m11")]
        public double M11 { get; set; }

        [JsonProperty("m12")]
        public double M12 { get; set; }

        [JsonProperty("m13")]
        public double M13 { get; set; }

        [JsonProperty("m21")]
        public double M21 { get; set; }
        
        [JsonProperty("m22")]
        public double M22 { get; set; }

        [JsonProperty("m23")]
        public double M23 { get; set; }

        [JsonProperty("m31")]
        public double M31 { get; set; }

        [JsonProperty("m32")]
        public double M32 { get; set; }

        [JsonProperty("m33")]
        public double M33 { get; set; }

        public CADRotation()
        {
        }

        /// <summary>
        /// Check equality of two CADRotation objects with a tolerance for floating-point comparisons.
        /// </summary>
        /// <param name="obj"> rotation object </param>
        /// <returns> equality status </returns>
        public override bool Equals(object obj)
        {
            return Equals(obj as CADRotation);
        }

        /// <summary>
        /// Check equality of two CADRotation objects with a tolerance for floating-point comparisons.
        /// </summary>
        /// <param name="other"></param>
        /// <returns> equality status </returns>
        public bool Equals(CADRotation other)
        {
            if (other == null) return false;

            const double tolerance = 1e-10;
            return Math.Abs(M11 - other.M11) < tolerance &&
                   Math.Abs(M12 - other.M12) < tolerance &&
                   Math.Abs(M13 - other.M13) < tolerance &&
                   Math.Abs(M21 - other.M21) < tolerance &&
                   Math.Abs(M22 - other.M22) < tolerance &&
                   Math.Abs(M23 - other.M23) < tolerance &&
                   Math.Abs(M31 - other.M31) < tolerance &&
                   Math.Abs(M32 - other.M32) < tolerance &&
                   Math.Abs(M33 - other.M33) < tolerance;
        }

        /// <summary>
        /// Generate a hash code for the CADRotation object.
        /// </summary>
        /// <returns> hash code </returns>
        public override int GetHashCode()
        {
            int hashM11 = M11.GetHashCode();
            int hashM12 = M12.GetHashCode();
            int hashM13 = M13.GetHashCode();
            int hashM21 = M21.GetHashCode();
            int hashM22 = M22.GetHashCode();
            int hashM23 = M23.GetHashCode();
            int hashM31 = M31.GetHashCode();
            int hashM32 = M32.GetHashCode();
            int hashM33 = M33.GetHashCode();

            return hashM11 ^ hashM12 ^ hashM13 ^ hashM21 ^ hashM22 ^ hashM23 ^ hashM31 ^ hashM32 ^ hashM33;
        }
    }
}
