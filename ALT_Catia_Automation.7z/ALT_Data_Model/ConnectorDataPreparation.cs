﻿/// <summary>
/// class for .
/// </summary>
/// <remarks>
/// This class is used to .
/// </remarks>
/// 

using ALT_Logging;
using CatiaDotNet.CommonExtensions;
using CatiaDotNet.CommonServices;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Drawing.Diagrams;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using MECMOD;
using Microsoft.VisualBasic;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Xml.Linq;



namespace ALT_Data_Model
{
    /// <summary>
    /// Class for preparing connector data by extracting from CATIA, reading synoptic and EQT location files, and comparing data.
    /// </summary>
    public class ConnectorDataPreparation
    {
        #region Fields

        private string _harnessName = string.Empty;
        private CADEqtLocation _eqtLocation = null;
        readonly private List<CADConnector> _catiaConnectorList = null;
        private Dictionary<string, List<SynopticConnector>> _synopticConnectorDic = null;
        private Dictionary<int, List<CADConnector>> _groupedConnectorListDic = null;
        private static ConnectorDataPreparation _ConnDataPreparation;
        private List<string> _harnessNames = null;
        #endregion

        #region Properties

        public CADEqtLocation EqtLocation
        {
            get { return _eqtLocation; }
        }

        public List<CADConnector> ConnectorList
        {
            get { return _catiaConnectorList; }
        }

        public List<SynopticConnector> SynopticConnectorList
        {
            get
            {
                if (_synopticConnectorDic != null && _synopticConnectorDic.Count > 0)
                {
                    if (_synopticConnectorDic.ContainsKey(_harnessName))
                        return _synopticConnectorDic[_harnessName];
                }

                return null;
            }
        }

        public List<string> HarnessList
        {
            get
            {
                List<string> harnessList = new List<string>();
                if (_synopticConnectorDic != null && _synopticConnectorDic.Count > 0)
                {
                    alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                    List<string> descriptionList = adapter.GetOpenedHarnessListDescription();
                    if (descriptionList != null && descriptionList.Count > 0)
                    {
                        harnessList = _synopticConnectorDic.Keys.ToList().Where(harness => descriptionList.Any(description => description.ToUpper().Contains(harness.ToUpper()))).ToList();
                        if(harnessList.Count > 0)
                            harnessList.Sort();

                        return harnessList;
                    }
                }

                return null;
            }
        }
        #endregion

        #region Constructor
        private ConnectorDataPreparation()
        {
            _catiaConnectorList = new List<CADConnector>();
            _groupedConnectorListDic = new Dictionary<int, List<CADConnector>>();

        }
        #endregion

        #region Public Methods
        public static ConnectorDataPreparation GetInstance()
        {
            if (_ConnDataPreparation == null)
                _ConnDataPreparation = new ConnectorDataPreparation();

            return _ConnDataPreparation;
        }

        /// <summary>
        /// Reframes the CATIA view to focus on the specified object.
        /// </summary>
        /// <param name="objectName"> Product name </param>
        public void Reframe(string objectName)
        {
            CADConnector connector = ConnectorList.Find(c => c.Name == objectName);
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if(connector != null)
            {
                adapter.ReframeOn(connector.CatiaProduct);
            }
        }

        /// <summary>
        /// Reframes the CATIA view to focus on the specified product by its exact name match.
        /// </summary>
        /// <param name="objectName"> product name </param>
        public void ReframeFromCatiaProduct(string objectName)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Product product = adapter.TraverseProductRecursiveExactMatch(adapter.RootProduct, objectName);
            if (product != null)
            {
                adapter.ReframeOn(product);
            }
        }

        /// <summary>
        /// Centers the CATIA view on the specified object.
        /// </summary>
        /// <param name="objectName"> Product name </param>
        public void CentreGraph(string objectName)
        {
            CADConnector connector = ConnectorList.FirstOrDefault(c => c.Name == objectName);
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (connector != null)
            {
                adapter.CentreGraph(connector.CatiaProduct);
            }
        }

        /// <summary>
        /// Extracts connectors from the specified harness in CATIA and groups them.
        /// </summary>
        /// <param name="harnessName"> Harness name</param>
        /// <returns> List of connectors </returns>
        public List<CADConnector> ExtractConnectors(string harnessName)
        {
            string returnOutput = string.Empty;
            _harnessName = harnessName;
            _catiaConnectorList.Clear();
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            returnOutput = adapter.IsHarnessProductOpened(harnessName) ? returnOutput : "Harness Product " + harnessName + " is not available in CATIA, Please open and try again.";
            if (returnOutput == string.Empty)
            {
                alt_CATIA_Adapter.ResetInstance();
                adapter = alt_CATIA_Adapter.GetInstance();
                IList<Product> products = adapter.ExtractConnectors(_harnessName);
                foreach (Product product in products)
                {
                    CADConnector cadConnector = new CADConnector(product);
                    _catiaConnectorList.Add(cadConnector);
                }
                _groupedConnectorListDic = this.GroupConnectors(_catiaConnectorList, harnessName);
            }
            return _catiaConnectorList;
        }

        /// <summary>
        /// Groups connectors based on their module association.
        /// </summary>
        /// <param name="cADConnectors"> connector list </param>
        /// <param name="harnessName"> Hanrness name </param>
        /// <returns> Group of related connectors </returns>
        private Dictionary<int, List<CADConnector>> GroupConnectors(List<CADConnector> cADConnectors, string harnessName)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Product harnessProduct = adapter.TraverseProductRecursive(adapter.RootProduct, harnessName);
            IList<Product> children = CatiaProductExtensions.GetProductDescendantChildren((Product)harnessProduct.Parent);

            int groupIndex = 1;
            Dictionary<int, List<CADConnector>> groupedElements = new Dictionary<int, List<CADConnector>>();
            List<CADConnector>  ConnectorModules = cADConnectors.Where(x=>x.Description.ToUpper().EndsWith("MODULES")).ToList();
            foreach (CADConnector connectorModule in ConnectorModules)
            {
                List<CADConnector> ModuleRelatedConnector = cADConnectors.Where(y => y.Name.ToUpper().StartsWith(connectorModule.Name)).ToList();
                foreach (CADConnector EachConnector in ModuleRelatedConnector)
                {
                    EachConnector.GroupIndex = groupIndex;
                }
                //////////////////////////////////////////// to collect dependant products ::::::::::::::::::::::::::::::::
                List<Product> additionalProductsToAdd = children.Where(y => y.get_DescriptionInst().Contains("IPOH," + connectorModule.Name)).ToList(); /// check for description laer
                additionalProductsToAdd.AddRange(children.Where(y => y.get_Name().Contains(connectorModule.Name + "#BACKSHELL")).ToList());
                foreach (Product prd in additionalProductsToAdd)
                {
                    try
                    {
                        CADConnector cadConnector = new CADConnector(prd);
                        cadConnector.GroupIndex = groupIndex;
                        ModuleRelatedConnector.Add(cadConnector);
                    }
                    catch { }

                }
                //////////////////////////////////////////// ::::::::::::::::::::::::::::::::
                groupedElements.Add(groupIndex, ModuleRelatedConnector);
                groupIndex++;
            }

            //////////////////////////////////////////  Existing root name approach for grouping ::::::::::::::::::::::::::::::::
            List<CADConnector> ConnectorNonModule = cADConnectors.Where(x => !x.Description.ToUpper().EndsWith("MODULES")).ToList();
            foreach (CADConnector connectorModule in ConnectorNonModule)
            {
                List<Product> additionalProductsToAdd = children.Where(y => y.get_Name().Contains(connectorModule.Name + "#BACKSHELL")).ToList(); /// check for description laer
                if (additionalProductsToAdd.Count == 0) continue;
                additionalProductsToAdd.AddRange(children.Where(y => y.get_DescriptionInst().Contains("IPOH," + connectorModule.Name)).ToList());
                List<CADConnector> ModuleRelatedConnector = cADConnectors.Where(y => y.Name.ToUpper() == connectorModule.Name).ToList();
                foreach (CADConnector EachConnector in ModuleRelatedConnector)
                {
                    EachConnector.GroupIndex = groupIndex;
                }
                foreach (Product prd in additionalProductsToAdd)
                {
                    try
                    {
                        CADConnector cadConnector = new CADConnector(prd);
                        cadConnector.GroupIndex = groupIndex;
                        ModuleRelatedConnector.Add(cadConnector);
                    }
                    catch { }

                }

                //////////////////////////////////////////// ::::::::::::::::::::::::::::::::
                groupedElements.Add(groupIndex, ModuleRelatedConnector);
                groupIndex++;
            }

            return groupedElements;
        }

        /// <summary>
        /// Reads synoptic connectors from the specified file and populates the internal dictionary.
        /// </summary>
        /// <param name="synopticFilePath"></param>
        public void ReadSynopticConnectors(string synopticFilePath)
        {
            alt_ExcelReaderService excelReader = alt_ExcelReaderService.GetInstance();
            if (excelReader.FileExist(synopticFilePath))
                _synopticConnectorDic = excelReader.ReadSynopticFile(synopticFilePath);
        }

        /// <summary>
        /// Applies design mode in CATIA to enable editing of the model.
        /// </summary>
        public void ApplyDesignMode()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            adapter.Apply_DESIGN_MODE();
        }

        /// <summary>
        /// Reads equipment location connectors from the specified file and populates the internal EQT location object.
        /// </summary>
        /// <param name="eqtLocationFilePath"> EQT location file path </param>
        public void ReadEqtLocationConnectors(string eqtLocationFilePath)
        {
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            _eqtLocation = alt_JsonReaderService.ParseEqtLocationFile(eqtLocationFilePath);
            if (_eqtLocation.Connectors.Count == 0) _eqtLocation = null;
        }

        /// <summary>
        /// Compares connectors data between CATIA and synoptic, and returns a list of comparison results.
        /// </summary>
        /// <returns> List pf compared data</returns>
        public List<CADCompareData> CompareConnectorsData()
        {
            if(EqtLocation == null)
            {
                MessageBox.Show("Equipment Location Extraction is not Valid. Please Extract Equipment Location or Select a Valid Equipment Location File", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return null;
            }

            if (ConnectorList == null ||
               SynopticConnectorList == null)
                return null;

            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            string description = "";

            // to add description
            foreach (CADConnector connector in ConnectorList)
            {
                SynopticConnector result = _synopticConnectorDic
                                            .Where(kvp => kvp.Key == _harnessName)
                                            .SelectMany(kvp => kvp.Value)
                                            .FirstOrDefault(item => (item.DeviceAcronym + "_" + item.ConnectorName) == connector.Name);

                if (result != null && (result.IPOH == false || result.CM == false))
                {
                    description = "IPOH," + (result.IPOH ? "YES" : "NO") + Environment.NewLine + "CM," + (result.CM ? "YES" : "NO");
                    adapter.AddDescriptionToConnectors(description, connector.CatiaProduct);
                }
            }

            //parse synoptic
            List<CADCompareData> cadCompareDataList = new List<CADCompareData>();
            foreach (SynopticConnector synopticConnector in SynopticConnectorList)
            {
                if (synopticConnector == null)
                    continue;

                CheckDtrPartNumberMatching(synopticConnector);
                CADConnector connector = ConnectorList.Find(c => c.Name == synopticConnector.SynopticConnectorName);
                CADCompareData cadCompareData = new CADCompareData(connector, synopticConnector);
                cadCompareDataList.Add(cadCompareData);
            }

            //Parse Catia connectors
            foreach (CADConnector cadConnector in ConnectorList)
            {
                if (cadConnector == null)
                    continue;

                SynopticConnector connector = SynopticConnectorList.Find(c => c.SynopticConnectorName == cadConnector.Name);
                if (connector == null)
                {
                    //ElbConnector does not exist, to be deleted 
                    CADCompareData cadCompareData = new CADCompareData(cadConnector, connector);
                    cadCompareDataList.Add(cadCompareData);
                }
            }
            cadCompareDataList = UpdateModuleStatus(cadCompareDataList);

            return cadCompareDataList;
        }

        //////////////////////////////////////////////////////////////////////////:::::::::::::::::::::::::::
        /// <summary>
        /// Updates the status of modules in the comparison data list based on their group association and individual connector statuses.
        /// </summary>
        /// <param name="cadCompareDataList"> Compared data list</param>
        /// <returns> Updated status of compared data </returns>
        public List<CADCompareData> UpdateModuleStatus(List<CADCompareData> cadCompareDataList)
        {
            List <CADCompareData> updatedList = new List<CADCompareData>();
            bool foundToBeRepostioned = false;
            string visistedGroup = string.Empty;
            foreach (CADCompareData cADCompareData in cadCompareDataList)
            {
                foundToBeRepostioned = false;
                if (cADCompareData.GroupIndex == 0)
                { 
                    updatedList.Add(cADCompareData); 
                }
                else
                {
                    if (visistedGroup.Contains(cADCompareData.GroupIndex.ToString()))
                        continue;
                    visistedGroup = visistedGroup + cADCompareData.GroupIndex.ToString();
                    foreach (CADConnector cADConnector in _groupedConnectorListDic[cADCompareData.GroupIndex])
                    {
                        CADCompareData cadCompareData = cadCompareDataList.Find(c => c.CatiaConnector == cADConnector.Name);
                        if (cadCompareData != null)
                        {
                            if (cadCompareData.Status == ConnectorStatus.ToBeRepositioned)
                            {
                                foundToBeRepostioned = true;
                                foreach (CADConnector cADConnector1 in _groupedConnectorListDic[cADCompareData.GroupIndex])
                                {
                                    CADCompareData cadCompareData1 = cadCompareDataList.Find(c => c.CatiaConnector == cADConnector1.Name);
                                    if(cadCompareData1 == null) continue;
                                    cadCompareData1.Status = ConnectorStatus.ToBeRepositioned;
                                    CADConnector eqtConnector = EqtLocation.Connectors.Find(c => c.Name == cADConnector1.Name);
                                    if (eqtConnector != null) 
                                    {
                                        cadCompareData1.Action = "To be loaded from EQT Location";
                                    }
                                    updatedList.Add(cadCompareData1);
                                }
                                UpdateEQTLocationPostion(cadCompareData.CatiaConnector, cADCompareData.GroupIndex);
                                break;
                            }
                        }
                    }
                    if (!foundToBeRepostioned)
                    {
                        foreach (CADConnector cADConnector1 in _groupedConnectorListDic[cADCompareData.GroupIndex])
                        {
                            CADCompareData cadCompareData1 = cadCompareDataList.Find(c => c.CatiaConnector == cADConnector1.Name);
                            updatedList.Add(cadCompareData1);
                        }
                    }
                }

            }
            
            return updatedList;
        }

        /// <summary>
        /// Updates the positions of connectors in the EQT location based on the position of a specified connector.
        /// </summary>
        /// <param name="connectorName"> Connector name</param>
        /// <param name="indexOfGroup"> Harness name </param>
        public void UpdateEQTLocationPostion(string connectorName,int indexOfGroup)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Product activeProduct = adapter.TraverseProductRecursiveExactMatch(adapter.RootProduct,connectorName);
            Matrix4d activeProductMatrix = adapter.GetGlobalMatrix4d(activeProduct);
            
            //Product productEqtLocation = adapter.GetProductInWindow("DEVICE LOCATION", connectorName);
            //Matrix4d baseProductEqtLocationMatrix = adapter.GetGlobalMatrix4d(productEqtLocation);

            CADTransform requiredTransform = EqtLocation.Connectors.Find(c => c.Name == connectorName).Transform;
            Matrix4d baseProductEqtLocationMatrix = adapter.ConvertArrayToMatrix(requiredTransform.ConvertTransformToArray());
            int subIndexCount = -1;
            foreach (CADConnector cADConnector in _groupedConnectorListDic[indexOfGroup]) 
            {
                subIndexCount = subIndexCount + 1;
                //if (cADConnector.Name == connectorName) continue;
                Product dependantProduct = adapter.TraverseProductRecursiveExactMatch(adapter.RootProduct, cADConnector.Name);
                Matrix4d dependantProductMatrix = adapter.GetGlobalMatrix4d(dependantProduct);

                Matrix4d relativePartMatrix = activeProductMatrix.Inverted() * dependantProductMatrix;
                Matrix4d newPartMatrix = baseProductEqtLocationMatrix * relativePartMatrix;
                CADTransform newPartMatrixTransform = GetTransform(newPartMatrix);
                CADConnector connector = EqtLocation.Connectors.Find(c => c.Name == cADConnector.Name);
                if (connector != null)
                {
                    //EqtLocation.Connectors.Find(c => c.Name == cADConnector.Name).Transform = newPartMatrixTransform;
                    _groupedConnectorListDic[indexOfGroup][subIndexCount].Transform = newPartMatrixTransform;
                }
                else
                {
                    _groupedConnectorListDic[indexOfGroup][subIndexCount].Transform = newPartMatrixTransform;
                }
                
            }

        }

        /// <summary>
        /// get transformation with respect to a reference
        /// </summary>
        /// <returns></returns>
        public CADTransform GetFinalTransformation(Matrix4d dependantProductMatrix, Matrix4d activeProductMatrix, Matrix4d baseProductEqtLocationMatrix)
        {
            Matrix4d relativePartMatrix = activeProductMatrix.Inverted() * dependantProductMatrix;
            Matrix4d newPartMatrix = baseProductEqtLocationMatrix * relativePartMatrix;
            CADTransform newPartMatrixTransform = GetTransform(newPartMatrix);

            return newPartMatrixTransform;
        }

        /// <summary>
        /// Checks if the DTR part number of the synoptic connector matches the expected format and logs a warning if it doesn't.
        /// </summary>
        /// <param name="matrix4D"> 4d matrix </param>
        /// <returns> Cad transform </returns>
        public CADTransform GetTransform(Matrix4d matrix4D)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            object[] Abs_Position = new object[12];
            Abs_Position = adapter.ConvertMatrixToArray(matrix4D);

            CADPosition position = new CADPosition();
            position.X = (double)Abs_Position[9];
            position.Y = (double)Abs_Position[10];
            position.Z = (double)Abs_Position[11];

            CADRotation rotation = new CADRotation();
            rotation.M11 = (double)Abs_Position[0];
            rotation.M12 = (double)Abs_Position[1];
            rotation.M13 = (double)Abs_Position[2];
            rotation.M21 = (double)Abs_Position[3];
            rotation.M22 = (double)Abs_Position[4];
            rotation.M23 = (double)Abs_Position[5];
            rotation.M31 = (double)Abs_Position[6];
            rotation.M32 = (double)Abs_Position[7];
            rotation.M33 = (double)Abs_Position[8];

            CADTransform transform = new CADTransform();
            transform.Position = position;
            transform.Rotation = rotation;

            return transform;
        }


        //////////////////////////////////////////////////////////////////////////:::::::::::::::::::::::::::

        /// <summary>
        /// Inserts product into CATIA based on the synoptic connector information.
        /// </summary>
        /// <param name="connectorName"> Connector name </param>
        /// <returns> status of insertion </returns>
        public string InsertProduct(string connectorName)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            SynopticConnector synopticConnector = SynopticConnectorList.Find(c => c.SynopticConnectorName == connectorName);
            string dtrPartnumber = synopticConnector.PartNumber;
            object[] absPosition = null;
            Product product = adapter.InsertProduct(connectorName, this._harnessName, dtrPartnumber, ref absPosition);
            if (product == null)
            {
                if (absPosition == null) return "Part not found";
                Product addedProduct = null;
                string status = adapter.AddProductFromDMA(connectorName, dtrPartnumber + ":-", "", this._harnessName, absPosition, ref addedProduct);
                if (addedProduct != null)
                {
                    CADConnector cadConnector = new CADConnector(addedProduct);
                    if (_catiaConnectorList != null)
                        _catiaConnectorList.Add(cadConnector);
                }
                return status;
            }
            else
            {
                CADConnector cadConnector = new CADConnector(product);
                if (_catiaConnectorList != null)
                    _catiaConnectorList.Add(cadConnector);
                return string.Empty;
            }
        }

        /// <summary>
        /// Replaces an existing product in CATIA with a new one based on the synoptic connector information.
        /// </summary>
        /// <param name="connectorName"></param>
        /// <returns> replaced status </returns>
        public string ReplaceProduct(string connectorName)
        {
            SynopticConnector synopticConnector = SynopticConnectorList.Find(c => c.SynopticConnectorName == connectorName);
            CADConnector cadConnector = ConnectorList.Find(c => c.Name == connectorName);
            string strDTRNarmVsRev = synopticConnector.PartNumber + ":-";
            string strFilterationCriteriaMap = "";
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            CADTransform eqtConnectorTransform = cadConnector.Transform;
            string status = adapter.ReplaceProduct(connectorName, strDTRNarmVsRev, strFilterationCriteriaMap, this._harnessName, eqtConnectorTransform.ConvertTransformToArray());
            return status;
        }

        /// <summary>
        /// Replaces from EQT Location
        /// </summary>
        /// <param name="connectorName"></param>
        /// <returns> replaced status </returns>
        public string ReplaceProductFromEQTLocation(string connectorName)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            adapter.DeleteProduct(connectorName);
            CADConnector eqtLocationConnector = EqtLocation.Connectors.Find(c => c.Name == connectorName);
            string dtrPartnumber = eqtLocationConnector.PartNumber;
            object[] absPosition = null;
            Product product = adapter.InsertProduct(connectorName, this._harnessName, dtrPartnumber, ref absPosition);
            if (product != null) 
            { 
                return "SUCCESS";
            }
            else
            {
                return "FAILURE";
            }
                
        }

        /// <summary>
        /// Modifies the position of a connector in CATIA to match its position in the EQT location.
        /// </summary>
        /// <param name="connectorName"> Connector name</param>
        /// <returns> Status of operation </returns>
        public string ModifyConnectorPosition(string connectorName)
        {
            string returnRusult = string.Empty;
            CADConnector connector = ConnectorList.Find(c => c.Name == connectorName);
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            CADConnector connectorInEQTLocation = EqtLocation.Connectors.Find(c => c.Name == connectorName);
            CADTransform eqtConnectorTransform = null;
            if (connectorInEQTLocation != null) eqtConnectorTransform = connectorInEQTLocation.Transform;
            if (connector != null && eqtConnectorTransform != null)
            {
                if(connector.GroupIndex != 0) UpdateGroupLocation(connector.GroupIndex);
                else
                {
                    connector.CatiaProduct.Position.SetComponents(eqtConnectorTransform.ConvertTransformToArray());
                    adapter.RootProduct.Update();
                }
            }
            else
            {
                UpdateGroupLocation(connector.GroupIndex);
                returnRusult = "There is an issue while modifying the application.";
            }
            return returnRusult;
        }

        /// <summary>
        /// Add product from DMA based on the synoptic connector information.
        /// </summary>
        /// <param name="harnessName"> Harness name </param>
        /// <param name="name"> Product name </param>
        /// <returns> status of dma addition </returns>
        public string AddProductFromDMA(string harnessName, string name)
        {
            string dtrValue = SynopticConnectorList.Find(c => c.SynopticConnectorName == name).PartNumber;
            CADConnector connectorInEQTLocation = EqtLocation.Connectors.Find(c => c.Name == name);
            object[] Abs_Position = new object[12];
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (connectorInEQTLocation != null && connectorInEQTLocation.PartNumber.Substring(0, 4) == "FICT")
            {
                Abs_Position = SynopticConnectorList.Find(c => c.SynopticConnectorName == name).Transform.ConvertTransformToArray();
            }
            else
            {
                MessageBox.Show("Please select where you want to insert the part from dma", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                alt_WindowTracker.BringApplicationToFront("CNEXT");
                object[] inputObject = new object[1] { "Face" };
                object[] selectedPoint = new object[3];
                SelectedElement selectedProduct = adapter.SelectHybridshapeInCatia("Select a rib", inputObject, ref selectedPoint);
                Vector3d newPosition = new Vector3d(
                    Convert.ToDouble(selectedPoint[0]),
                    Convert.ToDouble(selectedPoint[1]),
                    Convert.ToDouble(selectedPoint[2])
                );
                Matrix4d prdMatrix = CatiaPosition.GetMatrix4d(newPosition, new Vector3d(1, 0, 0), new Vector3d(0, 1, 0), new Vector3d(0, 0, 1));
                Abs_Position = adapter.ConvertMatrixToArray(prdMatrix);
            }

            //string status = adapter.AddFromDMAForAccesssorization(dtrValue + ":-", "", harnessName, Abs_Position);
            Product insertedSupport = null;
            string status = adapter.AddProductFromDMA(name, dtrValue + ":-", "", harnessName, Abs_Position, ref insertedSupport);
            if (status.Contains("Success"))
            {
                MessageBox.Show("DTR imported successfully: " + dtrValue, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return "SUCCESS";
            }
            else
            {
                MessageBox.Show("DTR not found in dma: " + dtrValue, "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return "FAILURE";
            }
        }

        /// <summary>
        /// Gets the Neo type associated with the specified connector name from the synoptic connector list.
        /// </summary>
        /// <param name="name"> acronym name</param>
        /// <returns> neo type value </returns> 
        public string GetNeoType(string name)
        {
            string neoType = SynopticConnectorList.Find(c => c.SynopticConnectorName == name).NeoType;
            return neoType;
        }

        /// <summary>
        /// Adds a part from the catalog into CATIA based on the synoptic connector information.
        /// </summary>
        /// <param name="harnessName"> Harness name </param>
        /// <param name="name"> product name</param>
        /// <param name="dtrValue"> DTR value </param>
        /// <returns></returns>
        public string AddPartFromCatalog(string harnessName, string name, string dtrValue)
        {
            CADConnector connectorInEQTLocation = EqtLocation.Connectors.Find(c => c.Name == name);
            object[] Abs_Position = new object[12];
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            Product parent = adapter.TraverseProductRecursive(adapter.RootProduct, harnessName);
            if (connectorInEQTLocation != null)
            {
                Abs_Position = SynopticConnectorList.Find(c => c.SynopticConnectorName == name).Transform.ConvertTransformToArray();
            }
            else
            {
                MessageBox.Show("Please select where you want to insert the part from catalog", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
                alt_WindowTracker.BringApplicationToFront("CNEXT");
                object[] inputObject = new object[1] { "Face" };
                object[] selectedPoint = new object[3];
                SelectedElement selectedProduct = adapter.SelectHybridshapeInCatia("Select a rib", inputObject, ref selectedPoint);
                Vector3d newPosition = new Vector3d(
                    Convert.ToDouble(selectedPoint[0]),
                    Convert.ToDouble(selectedPoint[1]),
                    Convert.ToDouble(selectedPoint[2])
                );
                Matrix4d prdMatrix = CatiaPosition.GetMatrix4d(newPosition, new Vector3d(1, 0, 0), new Vector3d(0, 1, 0), new Vector3d(0, 0, 1));
                Abs_Position = adapter.ConvertMatrixToArray(prdMatrix);
            }
            CADConnector cadConnector = ConnectorList.Find(c => c.Name == name);
            if (cadConnector != null) 
            {
                adapter.DeleteProduct(name);
            }
            Product insertedSupport = adapter.InsertPartFromCatalog(parent, Abs_Position, dtrValue);
            if (insertedSupport == null)
            {
                MessageBox.Show("Part not found in catalog", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
                return "FAILURE";
            }
            Product ProductParentPrd = (Product)insertedSupport.Parent;
            ((Product)ProductParentPrd.ReferenceProduct.Products.GetItem(insertedSupport.get_Name())).set_Name(name);
            SynopticConnector result = SynopticConnectorList.Find(c => c.SynopticConnectorName == name);
            if (result != null && (result.IPOH == false || result.CM == false))
            {
                string description = "IPOH," + (result.IPOH ? "YES" : "NO") + Environment.NewLine + "CM," + (result.CM ? "YES" : "NO");
                adapter.AddDescriptionToConnectors(description, insertedSupport);
            }
            insertedSupport.Update();
            return "SUCCESS";
        }

        /// <summary>
        /// Updates the locations of all connectors in a specified group to match their positions in the EQT location.
        /// </summary>
        /// <param name="index"> group index </param>
        private void UpdateGroupLocation(int index)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            foreach (CADConnector cADConnector in _groupedConnectorListDic[index])
            {
                CADTransform eqtConnectorTransform = cADConnector.Transform;
                cADConnector.CatiaProduct.Position.SetComponents(eqtConnectorTransform.ConvertTransformToArray());
                adapter.RootProduct.Update();

            }
        }

        /// <summary>
        /// Checks if the part number of the synoptic connector matches the part numbers in CATIA and EQT location, and sets the action status accordingly.
        /// </summary>
        /// <param name="synopConn"> synoptic connector object </param>
        public void CheckDtrPartNumberMatching(SynopticConnector synopConn)
        {
            try
            {
                CADConnector cadConnector = null;
                CADConnector eqCadConnector = null;
                cadConnector = ConnectorList.Find(c => c.Name == synopConn.SynopticConnectorName);
                if (cadConnector != null)
                {
                    eqCadConnector = EqtLocation.Connectors.FirstOrDefault(c => c.Name == synopConn.SynopticConnectorName);
                    if (eqCadConnector != null)
                    { // both exist in catia and eqt location
                        synopConn.Transform = eqCadConnector.Transform;

                        if (string.IsNullOrEmpty(synopConn.PartNumber))
                        {
                            if(eqCadConnector.PartNumber.Substring(0, 4) == "FICT" && cadConnector.PartNumber.Substring(0,3) == "DTR")
                            {
                                synopConn.ConnectorActionStatus = ConnectorLocation.ReplaceFromEQTLOcation;
                            }
                            else if (eqCadConnector.PartNumber.Substring(0, 3) == "DTR" && cadConnector.PartNumber.Substring(0, 3) == "DTR")
                            {
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromCatalog;
                            }
                            else
                            {
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromEQTLOcation;
                            }
                                
                        }
                        else
                        {
                            if (cadConnector.PartNumber == synopConn.PartNumber) //// Removed comparision with EQT location, dont think its required
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromEQTLOcation;
                            else
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromDMA;
                        }
                    }
                    else
                    { // exist in catia but not in eqt location
                        synopConn.Transform = cadConnector.Transform;

                        if (string.IsNullOrEmpty(synopConn.PartNumber))
                            synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromEQTLOcation;
                        else
                        {
                            if (cadConnector.PartNumber == synopConn.PartNumber)
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromEQTLOcation;
                            else
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromDMA;
                        }
                    }
                }
                else
                {
                    eqCadConnector = EqtLocation.Connectors.Find(c => c.Name == synopConn.SynopticConnectorName);

                    if (eqCadConnector == null)
                    { // doesn't exist in catia and eqt location
                        if (synopConn.PartNumber == "")
                        {
                            synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromCatalog;
                        }
                        else
                        {
                            synopConn.ConnectorActionStatus = ConnectorLocation.AddFromDMA;
                            return;
                        }

                    }
                    else
                    { // doesn't exist in catia but exist in eqt location
                        synopConn.Transform = eqCadConnector.Transform;

                        if (string.IsNullOrEmpty(synopConn.PartNumber)) 
                            synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromCatalog;
                        else
                        {
                            if (eqCadConnector.PartNumber == synopConn.PartNumber)
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromEQTLOcation;
                            else if(eqCadConnector.PartNumber.Substring(0,4) == "FICT")
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromDMA;
                            else
                                synopConn.ConnectorActionStatus = ConnectorLocation.LoadFromDMA;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                string errorMsg = exception.Message;
            }
        }

        /// <summary>
        /// Starts the command for GH extraction in CATIA.
        /// </summary>
        public void StartCommandGHExtraction()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            adapter.StartCommandGHExtraction();
        }

        #endregion

        #region Private Methods
        #endregion
    }
}