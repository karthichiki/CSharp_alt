﻿using System;
using System.Collections.Generic;
using System.IO;
using ALT_Data_Model.Accessories_Data_Model;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Logging;
using Newtonsoft.Json;


namespace ALT_Data_Model
{
    /// <summary>
    /// convert excel files to json files
    /// </summary>
    public class alt_ExcelToJsonConvertor
    {
        private Dictionary<string, List<SynopticConnector>> _synopticConnectorDic = null;
        private Dictionary<string, List<FAF_Extract>> _fafExtractDic = null;
        private Dictionary<string, List<PPL_Cables>> _pplCables = null;
        private Dictionary<string, List<PPL_Cables>> _pplNAMCables = null;
        private Dictionary<string, List<PPL_Cables>> _pplSpecificCables = null;
        private Dictionary<string, List<PPL_Electrical>> _pplElectricals = null;
        private Dictionary<string, List<CorrugatedSleeve>> _corrugatedSleeve = null;
        private Dictionary<string, List<Divisible>> _divisible = null;
        private Dictionary<string, List<Electrical_Insulation_Sleeve>> _electricalInsulationSleeve = null;
        private Dictionary<string, List<EMC>> _emc = null;
        private Dictionary<string, List<ExpandableSleeve>> _expandableSleeve = null;
        private Dictionary<string, List<Flame_Retardant_Sleeve>> _flameRetardantSleeve = null;
        private Dictionary<string, List<Heat_Shrinkable_Sleeve>> _heatShrinkableSleeve = null;
        private Dictionary<string, List<WrapAroundGripSleeve>> _wrapAroundGripSleeve = null;
        private Dictionary<string, List<WrapAroundSleeve>> _wrapAroundSleeve = null;
        private Dictionary<string, List<PL3_Global>> _3pl_Projet = null;
        private Dictionary<string, List<CableGland>> _cableGland = null;
        private Dictionary<string, List<Coupler>> _straightSwivelCouplerLT = null;
        private Dictionary<string, List<Coupler>> _straightCouplerLT = null;
        private Dictionary<string, List<Coupler>> _straightSwivelCouplerST = null;
        private Dictionary<string, List<Coupler>> _straightCouplerST = null;
        private Dictionary<string, List<Coupler>> _straightCouplerStrainReliefLT = null;
        private Dictionary<string, List<Coupler>> _straightCouplerStrainReliefST = null;
        private Dictionary<string, List<Coupler>> _strSwivelCouplerSTExtBody = null;
        private Dictionary<string, List<Coupler>> _straightFemaleCoupler = null;
        private Dictionary<string, List<Coupler>> _deg90CouplerLT = null;
        private Dictionary<string, List<Coupler>> _deg90SwivelCouplerLT = null;
        private Dictionary<string, List<Coupler>> _deg90CouplerST = null;
        private Dictionary<string, List<Coupler>> _deg90SwivelCouplerST = null;
        private Dictionary<string, List<Coupler>> _deg45CouplerLT = null;
        private Dictionary<string, List<Coupler>> _deg45SwivelCouplerLT = null;
        private Dictionary<string, List<Coupler>> _deg45CouplerST = null;
        private Dictionary<string, List<Coupler>> _deg45SwivelCouplerST = null;
        private Dictionary<string, List<BlindPlug>> _blindPlug = null;
        private Dictionary<string, List<ReducerExtentionWithSeal>> _reducerExtender = null;
        private Dictionary<string, List<FlatSeal>> _flatSeal = null;
        private Dictionary<string, List<FirewallCoupler>> _firewallCoupler = null;
        private Dictionary<string, List<EmcAdapter>> _emcAdapter = null;
        private Dictionary<string, List<SwivelAdapter>> _swiveledAdapter = null;
        private Dictionary<string, List<string>> _frontPage = null;
        private Dictionary<string, List<CombinedCouplers>> _tcoupler = null;
        private Dictionary<string, List<YCoupler>> _ycoupler = null;
        private Dictionary<string, List<CombinedCouplers>> _straightcoupler = null;
        private Dictionary<string, List<CombinedCouplers>> _reducer = null;
        private Dictionary<string, List<TerminalSleev>> _terminalSleev = null;
        private Dictionary<string, PL3_Connector> _3pl_Projet_Connector = null;
        private Dictionary<string, List<Tapes_Labels>> _tapesLabels = null;

        /// <summary>
        /// Convert excel files to json files
        /// </summary>
        /// <param name="synopticPath"> synoptic file path </param>
        /// <param name="extrctFAFPath"> Faf file path </param>
        /// <param name="pplCablesPath"> ppl cable file path </param>
        /// <param name="pplElectricals"> ppl electrical file path </param>
        /// <param name="pl3FilePath"> 3pl file path </param>
        /// <param name="pl3_ProjetFilePath"> 3pl projet file path </param>
        /// <param name="folderName"> folder path </param>
        /// <param name="resourceDirectory"> directory path </param>
        /// <returns></returns>
        public string ConvertExcelToJson(string synopticPath, string extrctFAFPath, string pplCablesPath, string pplElectricals, string pl3FilePath, string pl3_ProjetFilePath, string folderName, string resourceDirectory)
        {
            string timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
            var log = timestamp + $"--- Start converting excels to json.";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");

            alt_ExcelReaderService excelReader = alt_ExcelReaderService.GetInstance();
            if (synopticPath != "")
            {
                string filename = Path.GetFileNameWithoutExtension(synopticPath);
                timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
                log = timestamp + $"--- Converting " + filename + " to json.";
                alt_Logging_class.AddMessage(log);

                string jsonFilePath = Path.Combine(resourceDirectory, Path.GetFileNameWithoutExtension(synopticPath) + ".json");
                if (excelReader.FileExist(synopticPath))
                    _synopticConnectorDic = excelReader.ReadSynopticFile(synopticPath);
                string synoptic_json = JsonConvert.SerializeObject(_synopticConnectorDic, Formatting.Indented);
                File.WriteAllText(jsonFilePath, synoptic_json);

            }

            if (extrctFAFPath != "")
            {
                string filename = Path.GetFileNameWithoutExtension(extrctFAFPath);
                timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
                log = timestamp + $"--- Converting " + filename + " to json.";
                alt_Logging_class.AddMessage(log);

                string fafjsonFilePath = Path.Combine(resourceDirectory, filename + ".json");
                if (excelReader.FileExist(extrctFAFPath))
                    _fafExtractDic = excelReader.ExtractFAF(extrctFAFPath);
                string fafjson = JsonConvert.SerializeObject(_fafExtractDic, Formatting.Indented);
                File.WriteAllText(fafjsonFilePath, fafjson);
            }
            if (pplCablesPath != "")
            {

                string filename = Path.GetFileNameWithoutExtension(pplCablesPath);
                timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
                log = timestamp + $"--- Converting " + filename + " to json.";
                alt_Logging_class.AddMessage(log);

                string pplCablejsonFilePath = Path.Combine(resourceDirectory, filename + ".json");
                if (excelReader.FileExist(pplCablesPath))
                    _pplCables = excelReader.PPL_EN_Cables(pplCablesPath);

                if (excelReader.FileExist(pplCablesPath))
                    _pplNAMCables = excelReader.PPL_NAM_Cables(pplCablesPath);

                if (excelReader.FileExist(pplCablesPath))
                    _pplSpecificCables = excelReader.PPL_Specific_Cables(pplCablesPath);

                var combinedDicts = new
                {
                    Standard_EN_cables = _pplCables,
                    Standard_NAM_cables = _pplNAMCables,
                    Specific_cables_DTREN = _pplSpecificCables
                };

                string ppl_Cablejson = JsonConvert.SerializeObject(combinedDicts, Formatting.Indented);
                File.WriteAllText(pplCablejsonFilePath, ppl_Cablejson);
            }
            if (pplElectricals != "")
            {

                string filename = Path.GetFileNameWithoutExtension(pplElectricals);
                timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
                log = timestamp + $"--- Converting " + filename + " to json.";
                alt_Logging_class.AddMessage(log);

                string pplElectricaljsonFilePath = Path.Combine(resourceDirectory, filename + ".json");
                if (excelReader.FileExist(pplElectricals))
                    _pplElectricals = excelReader.PPL_Electrical(pplElectricals);

                string ppl_Electricaljson = JsonConvert.SerializeObject(_pplElectricals, Formatting.Indented);
                File.WriteAllText(pplElectricaljsonFilePath, ppl_Electricaljson);
            }
            if (pl3FilePath != "")
            {
                string filename = Path.GetFileNameWithoutExtension(pl3FilePath);
                timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
                log = timestamp + $"--- Converting " + filename + " to json.";
                alt_Logging_class.AddMessage(log);

                string pl3jsonFilePath = Path.Combine(resourceDirectory, filename + ".json");
                if (excelReader.FileExist(pl3FilePath))
                    _corrugatedSleeve = excelReader.CorrugatedSleeve(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _divisible = excelReader.Divisible(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _electricalInsulationSleeve = excelReader.ElectricalInsulationSleeve(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _emc = excelReader.EMC(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _expandableSleeve = excelReader.ExpandableSleeve(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _flameRetardantSleeve = excelReader.FlameRetardantSleeve(pl3FilePath);
                if (excelReader.FileExist(pl3FilePath))
                    _heatShrinkableSleeve = excelReader.HeatShrinkableSleeve(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _wrapAroundGripSleeve = excelReader.WrapAroundGripSleeve(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _wrapAroundSleeve = excelReader.WrapAroundSleeve(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                    _tapesLabels = excelReader.ReadTapesFile(pl3FilePath);

                if (excelReader.FileExist(pl3FilePath))
                {
                    _cableGland = excelReader.ReadCableGland(pl3FilePath);
                    _straightSwivelCouplerLT = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT SWIVEL COUPLER LT");
                    _straightCouplerLT = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT COUPLER LT");
                    _straightSwivelCouplerST = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT SWIVEL COUPLER ST");
                    _straightCouplerST = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT COUPLER ST");
                    _straightCouplerStrainReliefLT = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT COUPLER STRAIN REL LT");
                    _straightCouplerStrainReliefST = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT COUPLER STRAIN REL ST");
                    _strSwivelCouplerSTExtBody = excelReader.ReadCoupler(pl3FilePath, "STR SWIVEL COUPLER ST EXT-BODY");
                    _straightFemaleCoupler = excelReader.ReadCoupler(pl3FilePath, "STRAIGHT FEMALE COUPLER");
                    _deg90CouplerLT = excelReader.ReadCoupler(pl3FilePath, "90dg COUPLER LT");
                    _deg90SwivelCouplerLT = excelReader.ReadCoupler(pl3FilePath, "90dg SWIVEL COUPLER LT");
                    _deg90CouplerST = excelReader.ReadCoupler(pl3FilePath, "90dg COUPLER ST");
                    _deg90SwivelCouplerST = excelReader.ReadCoupler(pl3FilePath, "90dg SWIVEL COUPLER ST");
                    _deg45CouplerLT = excelReader.ReadCoupler(pl3FilePath, "45dg COUPLER LT");
                    _deg45SwivelCouplerLT = excelReader.ReadCoupler(pl3FilePath, "45dg SWIVEL COUPLER LT");
                    _deg45CouplerST = excelReader.ReadCoupler(pl3FilePath, "45dg COUPLER ST");
                    _deg45SwivelCouplerST = excelReader.ReadCoupler(pl3FilePath, "45dg SWIVEL COUPLER ST");
                    _blindPlug = excelReader.ReadBlindPlug(pl3FilePath);
                    _reducerExtender = excelReader.ReadReducerExtender(pl3FilePath);
                    _flatSeal = excelReader.ReadSeal(pl3FilePath);
                    _firewallCoupler = excelReader.ReadFireWallCoupler(pl3FilePath);
                    _emcAdapter = excelReader.ReadEMCAdapter(pl3FilePath);
                    _swiveledAdapter = excelReader.ReadSwiveledAdapter(pl3FilePath);
                    _frontPage = excelReader.ReadFrontPagetoJson(pl3FilePath);
                    _tcoupler = excelReader.ReadCouplerCombination(pl3FilePath, "DTR T coupler", new List<string>() { "DTR Y coupler", "DTR reducer", "DTR Straight coupler" });
                    _ycoupler = excelReader.ReadYCoupler(pl3FilePath, new List<string>() { "DTR Y coupler", "DTR reducer", "DTR Straight coupler" });
                    _reducer = excelReader.ReadCouplerCombination(pl3FilePath, "DTR reducer", new List<string>() { "DTR Y coupler", "DTR Straight coupler", "DTR T coupler" });
                    _straightcoupler = excelReader.ReadCouplerCombination(pl3FilePath, "DTR Straight coupler", new List<string>() { "DTR Y coupler", "DTR reducer", "DTR T coupler" });
                    _terminalSleev = excelReader.ReadTerminalSleev(pl3FilePath);
                }

                var combinedDicts = new
                {
                    CorrugatedSleeve = _corrugatedSleeve,
                    Divisible = _divisible,
                    ElectricalInsulationSleeve = _electricalInsulationSleeve,
                    EMC = _emc,
                    ExpandableSleeve = _expandableSleeve,
                    FlameRetardantSleeve = _flameRetardantSleeve,
                    HeatShrinkableSleeve = _heatShrinkableSleeve,
                    WrapAroundGripSleeve = _wrapAroundGripSleeve,
                    WrapAroundSleeve = _wrapAroundSleeve,
                    CableGland = _cableGland,
                    StraightSwivelCouplerLT = _straightSwivelCouplerLT,
                    StraightCouplerLT = _straightCouplerLT,
                    StraightSwivelCouplerST = _straightSwivelCouplerST,
                    StraightCouplerST = _straightCouplerST,
                    StraightCouplerStrainReliefLT = _straightCouplerStrainReliefLT,
                    StraightCouplerStrainReliefST = _straightCouplerStrainReliefST,
                    StrSwivelCouplerSTExtBody = _strSwivelCouplerSTExtBody,
                    StraightFemaleCoupler = _straightFemaleCoupler,
                    Deg90CouplerLT = _deg90CouplerLT,
                    Deg90SwivelCouplerLT = _deg90SwivelCouplerLT,
                    Deg90CouplerST = _deg90CouplerST,
                    Deg90SwivelCouplerST = _deg90SwivelCouplerST,
                    Deg45CouplerLT = _deg45CouplerLT,
                    Deg45SwivelCouplerLT = _deg45SwivelCouplerLT,
                    Deg45CouplerST = _deg45CouplerST,
                    Deg45SwivelCouplerST = _deg45SwivelCouplerST,
                    BlindPlug = _blindPlug,
                    ReducerExtender = _reducerExtender,
                    FlatSeal = _flatSeal,
                    FirewallCoupler = _firewallCoupler,
                    EmcAdapter = _emcAdapter,
                    SwiveledAdapter = _swiveledAdapter,
                    FrontPage = _frontPage,
                    Tcoupler = _tcoupler,
                    Ycoupler = _ycoupler,
                    Straightcoupler = _straightcoupler,
                    Reducer = _reducer,
                    TerminalSleev = _terminalSleev,
                    ColorRingSleeve = _tapesLabels
                };

                string pl3json = JsonConvert.SerializeObject(combinedDicts, Formatting.Indented);
                File.WriteAllText(pl3jsonFilePath, pl3json);
            }
            if (pl3_ProjetFilePath != "")
            {

                string filename = Path.GetFileNameWithoutExtension(pl3_ProjetFilePath);
                timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
                log = timestamp + $"--- Converting " + filename + " to json.";
                alt_Logging_class.AddMessage(log);

                string pl3ProjetjsonFilePath = Path.Combine(resourceDirectory, filename + ".json");
                if (excelReader.FileExist(pl3_ProjetFilePath))
                    _3pl_Projet = excelReader.pl3_Global_File(pl3_ProjetFilePath);

                string pl3_Projetjson = JsonConvert.SerializeObject(_3pl_Projet, Formatting.Indented);
                File.WriteAllText(pl3ProjetjsonFilePath, pl3_Projetjson);

                string pl3ProjetConnectorListjsonFilePath = Path.Combine(resourceDirectory, filename + "_ConnectorList.json");
                if (excelReader.FileExist(pl3_ProjetFilePath))
                    _3pl_Projet_Connector = excelReader.pl3_Connector_File(pl3_ProjetFilePath);

                string pl3_ProjetConnectorListjson = JsonConvert.SerializeObject(_3pl_Projet_Connector, Formatting.Indented);
                File.WriteAllText(pl3ProjetConnectorListjsonFilePath, pl3_ProjetConnectorListjson);
            }
            DeleteMyTempExcelFolder(folderName, resourceDirectory);

            timestamp = DateTime.Now.ToString("yyyy-MM-dd, T HH:mm:ss");
            log = timestamp + $"--- End converting excels to json.";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");

            return resourceDirectory;
        }

        /// <summary>
        /// Delete temporary excel folder
        /// </summary>
        /// <param name="folderName"></param>
        /// <param name="resourceDirectory"></param>
        public void DeleteMyTempExcelFolder(string folderName, string resourceDirectory)
        {
            string folderToDelete = Path.Combine(resourceDirectory, folderName);

            if (Directory.Exists(folderToDelete))
            {
                try
                {
                    Directory.Delete(folderToDelete, true);
                    Console.WriteLine($"Folder '{folderToDelete}' has been deleted successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error while deleting the folder: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine($"Folder '{folderToDelete}' does not exist.");
            }
        }


    }
}
