﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using ALT_Data_Model;
using ALT_Data_Model.Electrical;
using ALT_Data_Model.UnityDataModel;
using ALT_Logging;
using CatiaDotNet.CommonExtensions;
using CatiaDotNet.CommonServices;
using HybridShapeTypeLib;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using MECMOD;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Globalization;
using ALT_XML_Adapter;
using ALT_XML_Adapter.XmlData;
using ALT_Data_Model.SectionCut_Data_Model;
using System.IO;

namespace ALT_Harness_Definition
{
    public class alt_Harness_Definition
    {
        #region Fields

        private static alt_Harness_Definition _instance;
        readonly MultiBranchableDataPrepation _multiBranchableDataPrepation = null;

        private Product _catiaProduct;
        private CATIEhiGeoBundle _geomBundle;
        private Extremity _firstExtremity;
        private Extremity _secondExtremity;
        private string _corrugatedSleeveNominalDiameter;
        private double _diameter;
        private double _branchWithSleeveDiameter;
        private double _bendRadius;
        private List<int> _rgbColor;
        private List<IntermediateWayPoint> _intermediateWayPoints;
        private string _corrugatedSleeveDTRNumber;
        private string _catalogPath;
        private UnityData _unityData;
        private List<string> _ignoredPathPoints = null;

        #endregion

        #region Properties
        #endregion

        #region Constructor
        private alt_Harness_Definition()
        {
            _multiBranchableDataPrepation = MultiBranchableDataPrepation.GetInstance();
            GetPathPointsToIgnore();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// Singleton
        /// </summary>
        /// <returns></returns>
        public static alt_Harness_Definition GetInstance()
        {
            if (_instance == null)
                _instance = new alt_Harness_Definition();

            return _instance;
        }

        /// <summary>
        /// Set this Class instance to null
        /// </summary>
        public static void ResetInstance()
        {
            _instance = null;
        }

        /// <summary>
        /// Init branchable selected input parameters
        /// </summary>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public string InitBranchable(List<string> parameters)
        {
            Init(parameters);
            return PrepareUnityData();
        }

        /// <summary>
        /// Generate Branchable
        /// </summary>
        /// <param name="unityData"></param>
        public string GenerateBranchable(UnityData unityData)
        {
            string createdBranchInfo = CreateBranchable(unityData);
            _multiBranchableDataPrepation.ResetSelection();

            return createdBranchInfo;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Initialize by adding value to Properties of this class
        /// </summary>
        /// <param name="parameters"></param>
        private void Init(List<string> parameters)
        {
            try
            {
                _catiaProduct = _multiBranchableDataPrepation.CatiaProduct;
                Product geomPrd = (Product)_catiaProduct.Parent;
                _geomBundle = (CATIEhiGeoBundle)geomPrd;

                _firstExtremity = _multiBranchableDataPrepation.FirstExtremity;
                _secondExtremity = _multiBranchableDataPrepation.SecondExtremity;
                _intermediateWayPoints = _multiBranchableDataPrepation.IntermediateWayPoints;
                _corrugatedSleeveNominalDiameter = _multiBranchableDataPrepation.CorrugatedSleeveExternalDiameter;
                _corrugatedSleeveDTRNumber = _multiBranchableDataPrepation.CorrugatedSleeveDTRNumber;

                DefineColor(parameters[2]);
                try
                {
                    ManageRequiredDiameter(parameters[0], _corrugatedSleeveNominalDiameter);
                }
                catch (Exception)
                {
                    alt_Logging_class.AddMessage("--- Error while considering Diameter.");
                }
                try
                {
                    _bendRadius = Convert.ToDouble(parameters[1]);
                }
                catch (Exception)
                {
                    alt_Logging_class.AddMessage("--- Error while setting bendRadius.");
                }
                _catalogPath = parameters[3];

                var log = $"--- Init Branch properties: ";
                alt_Logging_class.AddMessage(log);
                log = $"------ Branch Diameter: {_diameter.ToString()}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Branch Sleeve Diameter: {_corrugatedSleeveNominalDiameter}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Branch Full Diameter: {_branchWithSleeveDiameter.ToString()}";
                alt_Logging_class.AddMessage(log);
                log = $"------ Branch Sleeve Part : {_corrugatedSleeveDTRNumber}";
                alt_Logging_class.AddMessage(log);
                log = $"--- End Init Branch Properties: ";
                alt_Logging_class.AddMessage(log);
                alt_Logging_class.AddMessage("");

            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Create catia branchable
        /// </summary>
        /// <param name="unityData"></param>
        private string CreateBranchable(UnityData unityData)
        {
            try
            {
                alt_Logging_class.AddMessage("--- Start creating branchable");
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();

                CATIEhiMultiBranchable mbbns = (CATIEhiMultiBranchable)_catiaProduct;
                if (mbbns == null || _geomBundle == null)
                    return string.Empty;

                _unityData = unityData;

                CATIEhiBranchable ehiBranchable = EhiMultiBranchable.AddBranchable(mbbns);
                CATIEhiBundleSegment bundleSegment = EhiBranchable.GetBundleSegmentCount(ehiBranchable, 0);
                alt_Logging_class.AddMessage("------ Branchable name: " + EhiBranchable.GetName(ehiBranchable));
                alt_Logging_class.AddMessage("------ Bundle segment name: " + EhiBundleSegment.GetName(bundleSegment));
                ehiBranchable.SetBendRadius(_bendRadius / 1000.0);
                ehiBranchable.SetSlack(0);
                EhiBundleSegment.SetBendRadius(bundleSegment, _bendRadius);
                EhiBundleSegment.SetDiameter(bundleSegment, _diameter);

                CheckExtremitiesInversion();
                AddExtremityToSpline(ehiBranchable, _firstExtremity);
                CreateSpline(ehiBranchable);                
                AddExtremityToSpline(ehiBranchable, _secondExtremity);

                HybridShapeSpline spline = EhiBranchable.GetElecCurve(ehiBranchable);
                spline.Compute();
                double flag = 0;
                _geomBundle.ComputeMultiBranchable(mbbns, out flag);

                if (_rgbColor != null && _rgbColor.Count > 2)
                    ehiAdapter.SetBundleSegmentColor(bundleSegment, _rgbColor[0], _rgbColor[1], _rgbColor[2]);

                List<double> offsets = new List<double> 
                { 
                    _firstExtremity.SleeveOffset, 
                    _secondExtremity.SleeveOffset 
                };

                if (!string.IsNullOrEmpty(_corrugatedSleeveDTRNumber))
                    ehiAdapter.AddSleeve(_catalogPath, ehiBranchable, null, _catiaProduct, _corrugatedSleeveDTRNumber, offsets);

                Product gbnProduct = (Product)_geomBundle;
                gbnProduct.Update();

                alt_Logging_class.AddMessage("--- End creating branchable");
                alt_Logging_class.AddMessage("");
                return SentCreatedBranchToUnity(ehiBranchable);

            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);

                return "Error while creating branch";
            }
        }

        /// <summary>
        /// Check if extrimities tangent have been changed in Unity side
        /// </summary>
        private void CheckExtremitiesInversion()
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            if (_unityData?.data?.branch?.startPoint != null)
            {
                var startPoint = _unityData.data.branch.startPoint;
                var startVector = new Vector3d(startPoint.tangency.x, 
                                               startPoint.tangency.y, 
                                               startPoint.tangency.z);
                var extremityDirection = new Vector3d(_firstExtremity.TangentDirection[0],
                                                       _firstExtremity.TangentDirection[1],
                                                       _firstExtremity.TangentDirection[2]);

                _firstExtremity.IsInverted = adapter.AreVectorInverted(extremityDirection, startVector);
            }

            if (_unityData?.data?.branch?.endPoint != null)
            {
                var endPoint = _unityData.data.branch.endPoint;
                var endVector = new Vector3d(endPoint.tangency.x,
                                               endPoint.tangency.y,
                                               endPoint.tangency.z);
                var extremityDirection = new Vector3d(_secondExtremity.TangentDirection[0],
                                                       _secondExtremity.TangentDirection[1],
                                                       _secondExtremity.TangentDirection[2]);

                _secondExtremity.IsInverted = adapter.AreVectorInverted(extremityDirection, endVector);
            }
        }
        /// <summary>
        /// Add extremity to spline
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="extremity"></param>
        private void AddExtremityToSpline(CATIEhiBranchable ehiBranchable, Extremity extremity)
        {
            if (null == ehiBranchable)
                return;

            try
            {
                if (extremity is ElbConnector elbConnector)
                {
                    EhiElbConnector ehiElbConnector = new EhiElbConnector(elbConnector.GetReference(), elbConnector.GetReferenceFace());
                    EhiBranchable.AddElbSingleConnectorAfter(ehiBranchable, ehiElbConnector, !extremity.IsInverted);
                }
                else if (extremity is ElbSupport elbSupport)
                {
                    AddSupportAsExtremity(ehiBranchable, elbSupport.SupportProduct);
                }
                else if (extremity is DerivationPoint derPoint)
                {
                    try
                    {
                        if (null != derPoint.RefPoint)
                        {
                            Part mbbnsPart = EhiBranchable.GetPart(ehiBranchable);
                            HybridShapeSpline elecCurve = EhiBranchable.GetElecCurve(ehiBranchable);                            
                            if(derPoint.EhiPointProduct == null)
                            {
                                double tangencyNorm = 0;
                                int invertValue = 0;
                                int crvCstType = 0;

                                elecCurve.SetPointAfter(elecCurve.GetNbControlPoint(), derPoint.RefPoint);
                                if (derPoint.LinkedBranchCurve != null)
                                {
                                    elecCurve.SetPointConstraintFromCurve(elecCurve.GetNbControlPoint(), derPoint.LinkedBranchCurve, tangencyNorm, invertValue, crvCstType);
                                    elecCurve.InvertDirection(elecCurve.GetNbControlPoint());
                                }
                            }
                            else
                            {
                                Publication pointPub = CatiaProductExtensions.GetPublication(derPoint.EhiPointProduct, "Point.1");
                                Reference refPoint = pointPub.Valuation as Reference;
                                Vector3d tangent = new Vector3d(derPoint.TangentDirection[0], derPoint.TangentDirection[1], derPoint.TangentDirection[2]);
                                if(extremity.IsInverted)
                                    EhiBranchable.AddPointAfter(ehiBranchable, refPoint, -tangent, true);
                                else
                                    EhiBranchable.AddPointAfter(ehiBranchable, refPoint, tangent, true);
                            }
                        }
                    }
                    catch{ }
                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Create spline by adding points or supports
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="unityData"></param>
        private void CreateSpline(CATIEhiBranchable ehiBranchable)
        {
            var log = $"------ Start adding path points to the spline of branch: ";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");

            PathPoint addedPathPoint = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            for (int nCount = 1; nCount < _unityData.data.branch.pathPoints.Count - 1; nCount++)
            {
                PathPoint pathPoint = _unityData.data.branch.pathPoints[nCount];
                if (pathPoint == null)
                    continue;

                if (IsIgnoredPoint(pathPoint.parentObjectType))
                    continue;

                bool isSectionCut = false;
                PathPoint prevPathPoint = addedPathPoint ?? _unityData.data.branch.pathPoints[nCount - 1];
                Vector3d prevPoint = new Vector3d(prevPathPoint.position.x, prevPathPoint.position.y, prevPathPoint.position.z);
                Vector3d currentPoint = new Vector3d(pathPoint.position.x, pathPoint.position.y, pathPoint.position.z);

                log = $"--------- Position: {pathPoint.position.x}; {pathPoint.position.y}; {pathPoint.position.z}";
                alt_Logging_class.AddMessage(log);
                log = $"--------- Type: {pathPoint.parentObjectType}";
                alt_Logging_class.AddMessage(log);
                log = $"--------- PartDescription: {pathPoint.partDescription}";
                alt_Logging_class.AddMessage(log);
                log = $"--------- Is support: {pathPoint.isSupport}";
                alt_Logging_class.AddMessage(log);
                log = pathPoint?.tangency != null ? $"--------- Tangency: {pathPoint.tangency.x}; {pathPoint.tangency.y}; {pathPoint.tangency.z}" : "------ Tangency: null";
                alt_Logging_class.AddMessage(log);

                Product elbSupport = null;
                if (IsMiddlePoint(pathPoint.parentObjectType))
                {
                    IntermediateWayPoint interPoint = GetIntermediatePointByCoords(currentPoint.X, currentPoint.Y, currentPoint.Z);
                    if (interPoint != null)
                    {
                        if (interPoint.IntermediateWayPointType == IntermediateWayPointType.EhiSupport)
                            elbSupport = interPoint.SupportProduct;
                        else
                        {
                            pathPoint.CopyFromIntermediatePoint(interPoint);
                            elbSupport = InsertSupport(pathPoint, _branchWithSleeveDiameter / 2, "CABLE_TRAY_TYPE_1");
                        }
                        if (elbSupport != null)
                            AddSupportToBranch(ehiBranchable, elbSupport, prevPoint);
                    }
                }
                else
                {
                    if (pathPoint.isSupport.ToUpper() == "FALSE")
                    {

                        elbSupport = InsertFictivePoint(pathPoint);
                        if (elbSupport != null)
                        {
                            Vector3d tangent = new Vector3d(pathPoint.tangency.x, pathPoint.tangency.y, pathPoint.tangency.z);
                            Publication pointPublication = CatiaProductExtensions.GetPublication(elbSupport, "Point.1");
                            Reference refPoint = (Reference)pointPublication.Valuation;
                            EhiBranchable.AddPointAfter(ehiBranchable, refPoint, tangent, true);
                        }
                    }
                    else
                    {
                        if (IsCableTray(pathPoint.partDescription))
                        {
                            elbSupport = InsertSupport(pathPoint, _branchWithSleeveDiameter / 2, "CABLE_TRAY_TYPE_1");
                            AddSupportToBranch(ehiBranchable, elbSupport, prevPoint);
                        }
                        else
                        {
                            if (IsSectionCut(pathPoint.parentObjectType))
                            {
                                elbSupport = InsertDummySupport(pathPoint);
                                if (pathPoint.partDescription == null)
                                    DefineSupportDescription(elbSupport, pathPoint);
                                else
                                    elbSupport.set_DescriptionInst(pathPoint.partDescription);

                                AddSupportToBranch(ehiBranchable, elbSupport, prevPoint);
                                isSectionCut = true;
                            }
                        }
                    }
                }

                if (elbSupport != null)
                {
                    log = $"--------- Is Added to spline: {true.ToString()}";
                    alt_Logging_class.AddMessage(log);
                    log = $"--------- Support name: {elbSupport.get_Name()}";
                    alt_Logging_class.AddMessage(log);
                    if (isSectionCut)
                    {
                        log = $"--------- Linked sketch circle: {elbSupport.get_DescriptionInst()}";
                        alt_Logging_class.AddMessage(log);
                    }
                    addedPathPoint = pathPoint;
                }
                else
                {
                    log = $"--------- Is Added to spline: {false.ToString()}";
                    alt_Logging_class.AddMessage(log);
                }
                alt_Logging_class.AddMessage("");
            }

            log = $"------ End adding path points to the spline of branch: ";
            alt_Logging_class.AddMessage(log);
        }

        /// <summary>
        /// Add support as branch extremity
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="supportProduct"></param>
        private void AddSupportAsExtremity(CATIEhiBranchable ehiBranchable, Product supportProduct)
        {
            PathPoint prevPathPoint;
            bool isPrevious = true;
            HybridShapeSpline spline = EhiBranchable.GetElecCurve(ehiBranchable);
            int nbCtrl = spline.GetNbControlPoint();
            if (nbCtrl > 0)
                prevPathPoint = _unityData.data.branch.pathPoints[_unityData.data.branch.pathPoints.Count - 2];
            else
            {
                prevPathPoint = _unityData.data.branch.pathPoints[1];
                isPrevious = false;
            }
            Vector3d prevPoint = new Vector3d(prevPathPoint.position.x, prevPathPoint.position.y, prevPathPoint.position.z);
            AddSupportToBranch(ehiBranchable, supportProduct, prevPoint, isPrevious);
        }

        /// <summary>
        /// Add support to branchable route
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="elbSupport"></param>
        /// <param name="prevPoint"></param>
        private void AddSupportToBranch(CATIEhiBranchable ehiBranchable, Product elbSupport, Vector3d prevPoint, bool isPrevious = true)
        {
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

            if (elbSupport != null)
            {
                HybridShapeSpline spline = EhiBranchable.GetElecCurve(ehiBranchable);
                int nbCtrl = spline.GetNbControlPoint();

                int supportMode = 0;
                if (adapter.IsInvertedSupport(prevPoint, elbSupport, isPrevious) == true)
                    supportMode = 1;

                ehiBranchable.AddSupport(elbSupport, supportMode, nbCtrl, 1);
            }
        }

        /// <summary>
        /// Init data to send to Unity
        /// </summary>
        /// <returns></returns>
        private string PrepareUnityData()
        {
            string jsonData = "";
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            try
            {
                //Check and inverse exgtremity between derivation and connector
                if (_firstExtremity.ExtremityType == ExtremityType.Derivation &&
                    (_secondExtremity.ExtremityType == ExtremityType.Connector ||
                     _secondExtremity.ExtremityType == ExtremityType.Support))
                {
                    var temp = _firstExtremity;
                    _firstExtremity = _secondExtremity;
                    _secondExtremity = temp;
                }

                Branch branch = new Branch(_firstExtremity, _secondExtremity, _intermediateWayPoints,
                _branchWithSleeveDiameter, _bendRadius, "A");

                Data data = new Data(_catiaProduct.get_Name());
                data.branch = branch;

                UnityData unityData = new UnityData("CreateBranchInput");
                unityData.data = data;

                jsonData = alt_JsonReaderService.SerializeUnityData(unityData);

                alt_Logging_class.AddMessage(jsonData);
                alt_Logging_class.AddMessage("");
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return jsonData;
        }

        /// <summary>
        /// Init data to sent to unity for created branch
        /// </summary>
        /// <param name="points"></param>
        /// <param name="branchPath"></param>
        /// <returns></returns>
        private string PrepareUnityPersistData(List<PathPointPersist> points, string branchPath)
        {
            string jsonData = "";
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            try
            {
                DataPersist dataPersist = new DataPersist(points, branchPath, _rgbColor);
                dataPersist.bendRadius = _bendRadius;
                dataPersist.diameter = _diameter;
                dataPersist.cableClass = "A";
                UnityDataPersist unityData = new UnityDataPersist("PersistenceBranchInput");
                unityData.data.Add(dataPersist);

                jsonData = alt_JsonReaderService.SerializeUnityDataPersist(unityData);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return jsonData;
        }

        /// <summary>
        /// Define branchable color
        /// </summary>
        /// <param name="colorRGB"></param>
        private void DefineColor(string colorRGB)
        {
            _rgbColor = new List<int>();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            List<int> colorList = ehiAdapter.GetHarnessColor(_catiaProduct);
            if(colorList != null && colorList.Count > 2)
                _rgbColor = colorList;
            else
            {
                var colors = colorRGB.Split(',');
                foreach(string color in colors)
                {
                    _rgbColor.Add(int.Parse(color));
                }
            }
        }

        /// <summary>
        /// Insert support in product structure
        /// </summary>
        /// <param name="position"></param>
        /// <param name="lastPosition"></param>
        /// <param name="branchable"></param>
        private Product InsertSupport(PathPoint pathPoint, double distToSurface, string partName)
        {
            Product insertedSupport = null;
            try
            {
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                alt_XmlServices xmlService = alt_XmlServices.GetInstance();

                Product geomPrd = (Product)_geomBundle;
                EhiSupport ehiSupport = xmlService.GetEhiSupportByName(partName);
                if(ehiSupport != null)
                {
                    Vector3d supportCenter = new Vector3d(ehiSupport.Center.X, ehiSupport.Center.Y, ehiSupport.Center.Z);
                    Vector3d position = new Vector3d(pathPoint.position.x, pathPoint.position.y, pathPoint.position.z);
                    Vector3d supportlocalTangent = new Vector3d(ehiSupport.Tangent.X, ehiSupport.Tangent.Y, ehiSupport.Tangent.Z);
                    insertedSupport = adapter.InsertEhiSupport(position, pathPoint.TangentDirection(), pathPoint.NormalDirection(),
                        supportCenter, supportlocalTangent, geomPrd, ehiSupport.PartName, distToSurface);
                }              
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return insertedSupport;
        }

        /// <summary>
        /// Add fictive as point in spline
        /// </summary>
        /// <param name="branchable"></param>
        /// <param name="currentPosition"></param>
        private Product InsertFictivePoint(PathPoint pathPoint)
        {
            Product fictivePoint = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            try
            {
                Vector3d position = new Vector3d(pathPoint.position.x, pathPoint.position.y, pathPoint.position.z);
                Vector3d tangent = new Vector3d(pathPoint.tangency.x, pathPoint.tangency.y, pathPoint.tangency.z);
                Product geomPrd = (Product)_geomBundle;

                fictivePoint = adapter.InsertEhiPoint(position, tangent, geomPrd, "FICTIVE POINT TYPE 2.CATPart");
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return fictivePoint;
        }

        /// <summary>
        /// Insert DummySupport
        /// </summary>
        /// <returns></returns>
        private Product InsertDummySupport(PathPoint pathPoint)
        {
            Product dummySupport = null;
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            try
            {
                Vector3d position = new Vector3d(pathPoint.position.x, pathPoint.position.y, pathPoint.position.z);
                Vector3d tangent = new Vector3d(pathPoint.tangency.x, pathPoint.tangency.y, pathPoint.tangency.z);
                Product geomPrd = (Product)_geomBundle;
                dummySupport = adapter.InsertDummySupport(position, tangent, geomPrd, "DUMMY SUPPORT 20 X 20.CATPart");
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return dummySupport;
        }

        /// <summary>
        /// Define product description
        /// </summary>
        /// <param name="pathPoint"></param>
        private void DefineSupportDescription(Product product, PathPoint pathPoint)
        {
            Vector3d circleCenter = new Vector3d(pathPoint.position.x, pathPoint.position.y, pathPoint.position.z);
            string circlePath = SectionCutJsonHelper.GetCircleNameByCenter(circleCenter);
            if (string.IsNullOrEmpty(circlePath))
                return;

            product.set_DescriptionInst(circlePath);
        }

        /// <summary>
        /// Get IntermediatePoint By comparing Coords
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <param name="z"></param>
        /// <param name="tolerance"></param>
        /// <returns></returns>
        private IntermediateWayPoint GetIntermediatePointByCoords(double x, double y, double z, double tolerance = 0.01)
        {
            foreach (IntermediateWayPoint interPoint in _intermediateWayPoints)
            {
                if (interPoint.Coordinates == null || interPoint.Coordinates.Count < 2)
                    continue;

                if (Math.Abs(interPoint.Coordinates[0] - x) <= tolerance 
                    && Math.Abs(interPoint.Coordinates[1] - y) <= tolerance
                    && Math.Abs(interPoint.Coordinates[2] - z) <= tolerance)
                    return interPoint;
            }

            return null;
        }

        /// <summary>
        /// If the decimal point is a comma (","), it will be replaced with a dot ("."), and the value will be returned as a proper decimal number using InvariantCulture.
        /// </summary>
        /// <param name="branchDiameter"></param>
        /// <param name="sleeveDiameter"></param>
        private void ManageRequiredDiameter(string branchDiameter, string sleeveDiameter)
        {
            if (!string.IsNullOrEmpty(branchDiameter))
                //_diameter = double.Parse(branchDiameter, CultureInfo.InvariantCulture);
            double.TryParse(branchDiameter.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out _diameter);
            double slvDiameter = 0;
            if (!string.IsNullOrEmpty(sleeveDiameter) && sleeveDiameter.ToUpper() != "NA")
                double.TryParse(sleeveDiameter.Replace(',','.'), NumberStyles.Any, CultureInfo.InvariantCulture, out slvDiameter);

            _branchWithSleeveDiameter = slvDiameter != 0 ? slvDiameter : _diameter;
        }

        /// <summary>
        /// Check if we have cable tray or not using description
        /// </summary>
        /// <param name="partDescription"></param>
        /// <returns></returns>
        private bool IsCableTray(string partDescription)
        {
            if(string.IsNullOrEmpty(partDescription))
                return false;

            if (partDescription.ToUpper() == "CABLE TRAY" ||
                partDescription.ToUpper() == "TRAY" ||
                partDescription.ToUpper() == "CABLETRAY")
                return true;

            return false;
        }

        /// <summary>
        /// Check if path point is section cut
        /// </summary>
        /// <param name="partDescription"></param>
        /// <returns></returns>
        private bool IsSectionCut(string partDescription)
        {
            if (string.IsNullOrEmpty(partDescription))
                return false;

            if (partDescription.ToUpper() == "SECTIONCUTMIDDLEPOINTNODE")
                return true;

            return false;
        }

        /// <summary>
        /// check if point should be ignored
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private bool IsIgnoredPoint(string type)
        {
            if (string.IsNullOrEmpty(type))
                return true;

            if (_ignoredPathPoints == null || _ignoredPathPoints.Count == 0)
                return type.ToUpper() == "TANGENCYNODE";

            return _ignoredPathPoints.Contains(type.ToUpper());
        }

        /// <summary>
        /// check if it's a forced way point
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        private bool IsMiddlePoint(string type)
        {
            if (string.IsNullOrEmpty(type))
                return true;

            if (type.ToUpper() == "MIDDLEPOINTNODE")
                return true;

            return false;
        }

        /// <summary>
        /// Sent created branch info to unity
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <returns></returns>
        private string SentCreatedBranchToUnity(CATIEhiBranchable ehiBranchable)
        {
            string unityDataPersist = string.Empty;
            try
            {
                List<PathPointPersist> pathPoints = new List<PathPointPersist>();
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

                Product geomPrd = (Product)_geomBundle;
                string branchPath = geomPrd.get_Name() + "\\" + _catiaProduct.get_Name() + "\\" + EhiBranchable.GetName(ehiBranchable);

                HybridShapeSpline elecCurve = EhiBranchable.GetElecCurve(ehiBranchable);
                int nbCtrl = elecCurve.GetNbControlPoint();
                for (int i = 1; i <= nbCtrl; i++)
                {
                    Reference refPoint = elecCurve.GetPoint(i);
                    if (refPoint == null)
                        continue;

                    Vector3d localCoords = adapter.GetPointFromReference(refPoint);
                    Vector3d globalCoords = adapter.TransformToGlobalCoordinates(localCoords, _catiaProduct);

                    List<double> coords = new List<double>();
                    coords.Add(globalCoords.X);
                    coords.Add(globalCoords.Y);
                    coords.Add(globalCoords.Z);
                    PathPointPersist pathPoint = new PathPointPersist(coords);
                    pathPoints.Add(pathPoint);
                }

                unityDataPersist = PrepareUnityPersistData(pathPoints, branchPath);
            }
            catch
            {
                unityDataPersist = "Error Getting data from created branch";
            }

            return unityDataPersist;
        }

        /// <summary>
        /// Get list of pathpoint type to be ignored from json file
        /// </summary>
        private void GetPathPointsToIgnore()
        {
            try
            {
                string folderPath = AppDomain.CurrentDomain.BaseDirectory;
                string jsonFilePath = Path.Combine(folderPath, "Resources", "SplineFilter.json");
                _ignoredPathPoints = PathPointFilterJsonHelper.GetIgnoredPathPoints(jsonFilePath);
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
            }
        }

        #endregion
    }
}
