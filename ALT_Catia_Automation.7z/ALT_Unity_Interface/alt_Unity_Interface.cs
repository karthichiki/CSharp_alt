﻿/// <summary>
/// Utility class for .
/// </summary>
/// <remarks>
/// This class is used to .
/// </remarks>
/// 
/// 

using ALT_Data_Model;
using ALT_Data_Model.UnityDataModel;
using ALT_Harness_Definition;
using ALT_Utilities;
using System;
using System.Diagnostics;
using System.IO;
using System.Security.Policy;
using WebSocketSharp;


namespace ALT_Unity_Interface
{
    public class alt_Unity_Interface
    {
        readonly Uri serverUri = new Uri("ws://127.0.0.1:2024/test");
        bool _connect_Disconnect = false;
        public WebSocket _webSocketClient = null;

        /// <summary>
        /// Initialize web socket
        /// </summary>
        /// <param name="JsonData"></param>
        public void InitWebSocket(string JsonData)
        {
            if (_connect_Disconnect == false)
            {
                try
                {
                    _webSocketClient = new WebSocket(serverUri.ToString());
                    _webSocketClient.OnMessage += WsDataReceived;
                    _webSocketClient.OnOpen += WsConnected;
                    _webSocketClient.OnError += WsOnError;
                    _webSocketClient.OnClose += WsDisconnect;
                    _webSocketClient.Connect();
                    _connect_Disconnect = true;

                    _webSocketClient.Send(JsonData);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    _connect_Disconnect = false;
                }
            }
            else
            {
                //User is already connected
                _webSocketClient.Send(JsonData);
            }
        }

        /// <summary>
        /// Run unity automatically with creation log file
        /// </summary>
        public void RunUnityApplication()
        {
            try
            {
                string projectFolderPath = Directory.GetParent(Directory.GetCurrentDirectory())?.Parent?.FullName
                                           ?? throw new InvalidOperationException("Cannot resolve project folder path.");

                string exePath = Path.Combine(projectFolderPath, "Unity_ReleaseBuild", "EFR_Trident_Unity.exe");

                if (!File.Exists(exePath))
                {
                    alt_PopupMessageUtil.ShowMessage("Unity Executable Path " + exePath + " does not exists!!!", "Error", MessageType.Error);
                    return;
                }

                string hatBaselinePath = Environment.GetEnvironmentVariable("HAT_User_Baseline_Path", EnvironmentVariableTarget.User)
                                         ?? throw new InvalidOperationException("HAT_User_Baseline_Path is not set.");
                
                if (!Directory.Exists(hatBaselinePath))
                {
                    alt_PopupMessageUtil.ShowMessage("User Base Line Directory Path " + hatBaselinePath + " does not exists in the environment variable named 'HAT_User_Baseline_Path'!!!", "Error", MessageType.Error);
                    return;
                }

                string hatZonePath = Environment.GetEnvironmentVariable("HAT_User_Zone_Path", EnvironmentVariableTarget.User)
                                         ?? throw new InvalidOperationException("HAT_User_Zone_Path is not set.");

                if (!(Directory.Exists(hatBaselinePath) && (Directory.Exists(hatZonePath))))
                {
                    alt_PopupMessageUtil.ShowMessage("User Base Line Directory Path " + hatBaselinePath + " does not exists in the environment variable named 'HAT_User_Baseline_Path'!!!", "Error", MessageType.Error);
                    return;
                }
                string logFilePath = Path.Combine(hatBaselinePath,"HAT_Data", "Unity_Data", "Logs", "player.log");
                if (!File.Exists(logFilePath))
                {
                    using (File.Create(logFilePath)) { } // create empty log file
                }
                //ALT_Logging.alt_Logging_class.AddError($"RunUnityApplication :: hatBaselinePath {hatBaselinePath}");
                //ALT_Logging.alt_Logging_class.AddError($"RunUnityApplication :: hatZonePath {hatZonePath}");
                //ALT_Logging.alt_Logging_class.AddError($"RunUnityApplication :: logFilePath {logFilePath}");
                var startInfo = new ProcessStartInfo
                {
                    EnvironmentVariables = { ["HAT_User_Baseline_Path"] = hatBaselinePath, ["HAT_User_Zone_Path"] = hatZonePath },
                    FileName = exePath,
                    Arguments = $"-logFile \"{logFilePath}\"",
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to start Unity application: {ex.Message}");
                alt_PopupMessageUtil.ShowMessage($"Failed to start Unity application: {ex.Message}","Error", MessageType.Error);
            }
        }

        /// <summary>
        /// Event for OnClose
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WsDisconnect(object sender, CloseEventArgs e)
        {
            Console.Write("Connection Close");
            if (_connect_Disconnect == true)
                _connect_Disconnect = false;
        }

        /// <summary>
        /// Event for OnError
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WsOnError(object sender, WebSocketSharp.ErrorEventArgs e)
        {
            Console.WriteLine(e.Exception);
        }

        /// <summary>
        /// Event for OnOpen
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WsConnected(object sender, EventArgs e)
        {
            Console.WriteLine("Client connected on ws://127.0.0.1:2024/test");
        }

        /// <summary>
        /// Event for OnMessage
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WsDataReceived(object sender, MessageEventArgs e)
        {
            Console.WriteLine("Message Received: " + e.Data.ToString());
            alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();

            try
            {
                UnityData unityData = alt_JsonReaderService.DeserializeUnityData(e.Data.ToString());
                if (unityData != null && unityData.cmd != null)
                {
                    if (unityData.cmd == "CreateBranchOutput")
                    {
                        alt_Harness_Definition harnessDefinition = alt_Harness_Definition.GetInstance();
                        string JsonData = harnessDefinition.GenerateBranchable(unityData);
                        InitWebSocket(JsonData);
                    }
                    else
                        Console.WriteLine("Message sent is not a user creating out branch...");
                }
                else
                    Console.WriteLine("Error in parsing input Json data...");

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}
