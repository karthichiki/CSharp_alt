﻿using ALT_Data_Model;
using ALT_Data_Preparation;
using CatiaDotNet;
using CatiaDotNet.CommonExtensions;
using INFITF;
using Newtonsoft.Json;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;

namespace App_Tests
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CompareExtremities();
        }

        static void CompareExtremities()
        {
            ConnectorDataPreparation connectorDataPreparation = ConnectorDataPreparation.GetInstance();
            connectorDataPreparation.ExtractConnectors("H_A00+ROFcA_001");
            //connectorDataPreparation.ReadEqtLocationConnectors("C:\\Users\\guruprasad.h.n\\Desktop\\Alstom_Resources\\Equipment Location\\EqtLocation.json");
            //connectorDataPreparation.ReadSynopticConnectors("C:\\Users\\guruprasad.h.n\\Downloads\\LNVG_extract_SYN_revH3_BSL4.xlsx");

            ALT_Data_Validation_Service.alt_Data_Validation_Service service = ALT_Data_Validation_Service.alt_Data_Validation_Service.GetInstance();
            List<CADCompareData> compareList = service.CompareConnectorsData();
        }

        private static void ExportEqtLocationData()
        {
            List<CADConnector> connectors = new List<CADConnector>();

            try 
            {                
                Catia catia = Catia.GetCatia();
                catia.CatchCatia();
                ProductDocument RootDocument = (ProductDocument)Catia.ActiveDocument;
                Product rootProduct = RootDocument.Product;
                if (rootProduct == null)
                    return;

                CADEqtLocation eqtLocation = new CADEqtLocation();
                eqtLocation.Name = rootProduct.get_Name();

                foreach(Product child in rootProduct.Products)
                {
                    if (child == null)
                        continue;

                    if(IsActiveProduct(child) == false)
                        continue;

                    Publication bundleCnctPub = child.GetPublication("BundleCnctPt1");
                    if (bundleCnctPub == null)
                        continue;

                    //Is ElbConnector
                    string ConnName = child.get_Name();
                    string prtNumber = child.get_PartNumber();
                    Matrix4d prdMatrix = GetGlobalMatrix4d(child);

                    object[] Abs_Position = new object[12];
                    Abs_Position = ConvertMatrixToArray(prdMatrix);

                    CADPosition position = new CADPosition();
                    position.X = (double)Abs_Position[9];
                    position.Y = (double)Abs_Position[10];
                    position.Z = (double)Abs_Position[11];

                    CADRotation rotation = new CADRotation();
                    rotation.M11 = (double)Abs_Position[0];
                    rotation.M12 = (double)Abs_Position[1];
                    rotation.M13 = (double)Abs_Position[2];
                    rotation.M21 = (double)Abs_Position[3];
                    rotation.M22 = (double)Abs_Position[4];
                    rotation.M23 = (double)Abs_Position[5];
                    rotation.M31 = (double)Abs_Position[6];
                    rotation.M32 = (double)Abs_Position[7];
                    rotation.M33 = (double)Abs_Position[8];

                    CADTransform transform = new CADTransform();
                    transform.Position = position;
                    transform.Rotation = rotation;

                    CADConnector connector = new CADConnector();
                    connector.Name = ConnName;
                    connector.PartNumber = prtNumber;
                    connector.Transform = transform;

                    connectors.Add(connector);                    
                }
                eqtLocation.Connectors = connectors;

                // Serialize to JSON
                string jsonString = JsonConvert.SerializeObject(eqtLocation, Formatting.Indented);

                // Write JSON to file
                System.IO.File.WriteAllText("C:\\Users\\marouchi.ramzi\\Documents\\Projects\\Alstom\\Data\\EqtLocation.json", jsonString);
            }
            catch (Exception exception)
            {
                string errorMsg = exception.Message;
            }
        }

        public static bool IsActiveProduct(Product iPrd)
        {
            return null != iPrd.GetPart();
        }

        private static IList<Product> GetFathers(Product product)
        {
            IList<Product> fathers = new List<Product>();
            if (null == product || null == product.Parent)
            {
                return fathers;
            }
            Queue<Product> queue = new Queue<Product>();

            queue.Enqueue(product);

            while (queue.Count > 0)
            {
                Product currentProduct = queue.Dequeue();
                if (currentProduct.Parent is Products)
                {
                    Products products = currentProduct.Parent as Products;
                    if (products.Parent is Product)
                    {
                        currentProduct = products.Parent as Product;
                        queue.Enqueue(currentProduct);
                        fathers.Add(currentProduct);
                    }
                }
                else if (currentProduct.Parent is Product)
                {
                    Product parentProduct = currentProduct.Parent as Product;
                    if (parentProduct.GetHashCode() != currentProduct.GetHashCode())
                    {
                        queue.Enqueue(parentProduct);
                        fathers.Add(parentProduct);
                    }
                }
            }
            return fathers;
        }

        private static Vector3d GetOrigin(Position iPosition)
        {
            Object[] components = new Object[12];
            iPosition.GetComponents(components);

            return new Vector3d(
                Convert.ToDouble(components[9]),
                Convert.ToDouble(components[10]),
                Convert.ToDouble(components[11])
                );
        }

        private static Vector3d GetFirstAxis(Position iPosition)
        {
            Object[] components = new Object[12];
            iPosition.GetComponents(components);

            return new Vector3d(
                Convert.ToDouble(components[0]),
                Convert.ToDouble(components[1]),
                Convert.ToDouble(components[2])
                );
        }

        private static Vector3d GetSecondAxis(Position iPosition)
        {
            Object[] components = new Object[12];
            iPosition.GetComponents(components);

            return new Vector3d(
                Convert.ToDouble(components[3]),
                Convert.ToDouble(components[4]),
                Convert.ToDouble(components[5])
                );
        }

        private static Vector3d GetThirdAxis(Position iPosition)
        {
            Object[] components = new Object[12];
            iPosition.GetComponents(components);

            return new Vector3d(
                Convert.ToDouble(components[6]),
                Convert.ToDouble(components[7]),
                Convert.ToDouble(components[8])
                );
        }

        private static Matrix4d GetMatrix4d(Vector3d iOrigin, Vector3d iFirstAxis,
                                Vector3d iSecondAxis, Vector3d iThirdAxis)
        {
            return new Matrix4d(
                m00: iFirstAxis.X,
                m01: iSecondAxis.X,
                m02: iThirdAxis.X,
                m03: iOrigin.X,

                m10: iFirstAxis.Y,
                m11: iSecondAxis.Y,
                m12: iThirdAxis.Y,
                m13: iOrigin.Y,

                m20: iFirstAxis.Z,
                m21: iSecondAxis.Z,
                m22: iThirdAxis.Z,
                m23: iOrigin.Z,

                m30: 0,
                m31: 0,
                m32: 0,
                m33: 1.0d
                );
        }

        private static Matrix4d GetMatrix4d(Position iPosition)
        {
            Object[] components = new Object[12];
            iPosition.GetComponents(components);

            return GetMatrix4d(GetOrigin(iPosition), GetFirstAxis(iPosition),
               GetSecondAxis(iPosition), GetThirdAxis(iPosition));
        }

        private static Matrix4d GetGlobalMatrix4d(Product product)
        {
            List<Product> fathers = GetFathers(product).Reverse().ToList();


            Matrix4d globalMatrix = Matrix4d.Identity;
            foreach (var father in fathers)
            {

                globalMatrix = globalMatrix * GetMatrix4d(father.Position);
            }
            globalMatrix = globalMatrix * GetMatrix4d(product.Position);

            return globalMatrix;
        }

        private static object[] ConvertMatrixToArray(Matrix4d matrix)
        {
            object[] Abs_Position = new object[12];
            Abs_Position[0] = matrix.M11;
            Abs_Position[1] = matrix.M21;
            Abs_Position[2] = matrix.M31;

            Abs_Position[3] = matrix.M12;
            Abs_Position[4] = matrix.M22;
            Abs_Position[5] = matrix.M32;

            Abs_Position[6] = matrix.M13;
            Abs_Position[7] = matrix.M23;
            Abs_Position[8] = matrix.M33;

            Abs_Position[9] = matrix.M14;
            Abs_Position[10] = matrix.M24;
            Abs_Position[11] = matrix.M34;


            return Abs_Position;

        }
    }
}
