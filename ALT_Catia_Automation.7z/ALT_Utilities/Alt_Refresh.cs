﻿using ALT_Data_Model;
using System.Collections.Generic;

namespace ALT_Utilities
{
    public static class alt_Refresh
    {
        /// <summary>
        /// Refreshes the status of connectors for the specified harness.
        /// </summary>
        /// <param name="harnessName">The name of the harness for which to refresh connector statuses. Cannot be null or empty.</param>
        /// <returns>A list of <see cref="CADCompareData"/> objects representing the comparison results of the connector data.
        /// The list will be empty if no connectors are found or compared.</returns>
        public static List<CADCompareData> RefreshConnectorsStatus(string harnessName)
        {
            ConnectorDataPreparation connectorDataPreparation = ConnectorDataPreparation.GetInstance();
            connectorDataPreparation.ExtractConnectors(harnessName);
            return connectorDataPreparation.CompareConnectorsData();
        }

        /// <summary>
        /// Retrieves the current list of harnesses from the connector data preparation instance.
        /// </summary>
        /// <returns>A list of strings representing the harnesses. The list may be empty if no harnesses are available.</returns>
        public static List<string> RefreshHarnessList()
        {
            ConnectorDataPreparation connectorDataPreparation = ConnectorDataPreparation.GetInstance();
            return connectorDataPreparation.HarnessList;
        }

    }
}
