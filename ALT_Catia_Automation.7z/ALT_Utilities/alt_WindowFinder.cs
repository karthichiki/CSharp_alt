﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Automation;

namespace ALT_Utilities
{
    class alt_WindowFinder
    {
        private const int MaxTitleLength = 255;
        private const int WM_COMMAND = 0x0111;
        private const int BN_CLICKED = 245;
        private const int IDOK = 1;
        private const int BM_CLICK = 0x00F5; // Button click message

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, string className, string windowTitle);

        //[DllImport("user32.dll", CharSet = CharSet.Auto)]
        //public static extern int SendMessage(IntPtr hWnd, uint Msg, int wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern int SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

        //[DllImport("user32.dll", CharSet = CharSet.Auto)]
        //public static extern void SendInput(uint nInputs, [MarshalAs(UnmanagedType.LPArray), In] INPUT[] pInputs, int cbSize);

        [DllImport("user32.dll")]
        private static extern bool PostMessage(IntPtr hWnd, int Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool IsWindowEnabled(IntPtr hWnd);


        ////////////////////////////////////////////////////////////////
        [DllImport("user32.dll")]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        private static extern void SetCursorPos(int X, int Y);

        [DllImport("user32.dll", SetLastError = true)]
        private static extern void mouse_event(int dwFlags, int dx, int dy, int dwData, int dwExtraInfo);

        private const int MOUSEEVENTF_LEFTDOWN = 0x02;
        private const int MOUSEEVENTF_LEFTUP = 0x04;

        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int Left, Top, Right, Bottom;
        }

        ////////////////////////////////////////////////////////////////
        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
        /// <summary>
        /// Searches for a top-level window whose title contains the specified substring.
        /// </summary>
        /// <remarks>This method enumerates all top-level windows and stops the search as soon as a
        /// matching window is found. The search is case-sensitive and matches any part of the window title that
        /// contains the specified substring.</remarks>
        /// <param name="titleSubstring">The substring to search for in the titles of top-level windows. This value cannot be <see langword="null"/>.</param>
        /// <returns>A handle to the first top-level window whose title contains the specified substring, or <see
        /// cref="IntPtr.Zero"/> if no such window is found.</returns>
        public static IntPtr FindWindowContaining(string titleSubstring)
        {
            IntPtr foundWindow = IntPtr.Zero;

            EnumWindows((hWnd, lParam) =>
            {
                StringBuilder windowText = new StringBuilder(MaxTitleLength);
                GetWindowText(hWnd, windowText, MaxTitleLength);

                if (windowText.ToString().Contains(titleSubstring))
                {
                    foundWindow = hWnd;
                    return false; // Stop enumeration
                }

                return true; // Continue enumeration
            }, IntPtr.Zero);

            return foundWindow;
        }
        /// <summary>
        /// Simulates a click on the "OK" button of a specified window, if the button is found and enabled.
        /// </summary>
        /// <remarks>This method searches for a button with the text "OK" within the specified window and
        /// simulates a click  on it if the button is enabled. If the button is not found or is disabled, no action is
        /// performed.</remarks>
        /// <param name="hWnd">A handle to the parent window containing the "OK" button. This handle must be valid.</param>
        public static void ClickOkButton(IntPtr hWnd)
        {
            IntPtr hWndButton = FindWindowEx(hWnd, IntPtr.Zero, "Button", "OK");
            if (hWndButton != IntPtr.Zero)
            {
                if (IsWindowEnabled(hWndButton))
                {
                    SendMessage(hWndButton, BM_CLICK, IntPtr.Zero, IntPtr.Zero);
                }
                StringBuilder buttonText = new StringBuilder(256);
                GetWindowText(hWnd, buttonText, buttonText.Capacity);
                //SendMessage(hWndButton, WM_COMMAND, (BN_CLICKED << 16) | IDOK, hWndButton);
                SendMessage(hWndButton, BM_CLICK, IntPtr.Zero, IntPtr.Zero);

            }

        }
        /// <summary>
        /// Automates the process of locating and clicking the "OK" button within a specific dialog box  of a window
        /// whose title contains "CATIA V5".
        /// </summary>
        /// <remarks>This method scans all open windows to find a window with a title containing "CATIA
        /// V5".  Within this window, it searches for a dialog box named "Measure Inertia" and attempts to locate  and
        /// click the "OK" button within the dialog. The "OK" button is clicked only if it is enabled  and not
        /// offscreen. If the target window, dialog, or button is not found, appropriate messages  are logged to the
        /// console.  This method uses UI Automation and may require appropriate permissions to interact with the  user
        /// interface. A delay is introduced before invoking the button click to ensure stability.</remarks>
        public void ClickOKButtonAutomation()
        {
            AutomationElement rootElement = AutomationElement.RootElement;
            AutomationElementCollection windows = rootElement.FindAll(TreeScope.Children, Condition.TrueCondition);

            Console.WriteLine("Scanning all open windows...");
            AutomationElement targetWindow = null;

            foreach (AutomationElement window in windows)
            {
                string windowTitle = window.Current.Name;
                Console.WriteLine("Found Window: " + windowTitle);

                // If this is the expected pop-up window, store it
                if (windowTitle.Contains("CATIA V5")) // Update this condition
                {
                    targetWindow = window;
                    Console.WriteLine("Target pop-up found: " + windowTitle);
                    break;
                }
            }

            if (targetWindow != null)
            {
                // Find the "OK" button and click it
                AutomationElement subDialogBox = targetWindow.FindFirst(TreeScope.Descendants,
                    new PropertyCondition(AutomationElement.NameProperty, "Measure Inertia"));

                if (subDialogBox != null)
                {
                    Console.WriteLine("Dialog found!");

                    // Find the "OK" button within the dialog
                    AutomationElement okButton = subDialogBox.FindFirst(TreeScope.Descendants,
                        new PropertyCondition(AutomationElement.NameProperty, "OK"));

                    if (okButton != null)
                    {
                        Console.WriteLine("OK button found!");

                        if (okButton.Current.IsEnabled && !okButton.Current.IsOffscreen)
                        {
                            InvokePattern invokePattern = okButton.GetCurrentPattern(InvokePattern.Pattern) as InvokePattern;
                            System.Threading.Thread.Sleep(5000); // Adjust the delay as needed
                            invokePattern.Invoke();
                            Console.WriteLine("OK button clicked!");
                        }
                        else
                        {
                            Console.WriteLine("OK button is either disabled or offscreen.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("OK button not found.");
                    }
                }
                else
                {
                    Console.WriteLine("Dialog not found.");
                }
            }
            else
            {
                Console.WriteLine("No matching pop-up found.");
            }
        }
    }
}
