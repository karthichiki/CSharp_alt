﻿using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;

namespace ALT_Utilities
{
    public class alt_Utilities
    {
        [DllImport("User32.dll")]
        public static extern IntPtr SetForegroundWindow(IntPtr point);
        [DllImport("user32.dll")]
        public static extern bool PostMessage(IntPtr hwnd, int uMsg, int wParam, int lParam);
        const int WM_KEYDOWN = 0x100;
        const int WM_KEYUP = 0x101;
        const int VK_ESCAPE = 0x1B;

        /// <summary>
        /// Converts a list of CAD comparison data into a list of table data for display or processing.
        /// </summary>
        /// <remarks>This method processes each non-null item in the input list and maps its properties to
        /// a new  <see cref="TableData"/> object. The resulting list can be used for populating tables or other UI
        /// elements. The <see cref="TableData.IsChecked"/> property is initialized to <see langword="false"/> by
        /// default.</remarks>
        /// <param name="comparedData">A list of <see cref="CADCompareData"/> objects representing the comparison data.  Each item in the list
        /// contains information about connectors and their statuses.</param>
        /// <returns>A list of <see cref="TableData"/> objects, where each item corresponds to an entry in the input list. If
        /// <paramref name="comparedData"/> is <see langword="null"/>, an empty list is returned.</returns>
        public List<TableData> GetDataForTable(List<CADCompareData> comparedData)
        {
            var tableData = new List<TableData>();
            if (comparedData == null) return tableData;

            // Calculate the difference between corresponding elements in both lists
            foreach (CADCompareData cadCompareData in comparedData)
            {
                if(cadCompareData == null) continue;
                tableData.Add(new TableData
                {
                    ConnectorSynoptic = cadCompareData.SynopticConnector,
                    ConnectorHarness = cadCompareData.CatiaConnector,
                    Action = cadCompareData.Action,
                    IsChecked = false,// Default value for the checkbox
                    Status = cadCompareData.Status.ToString()
                });
            }

            return tableData;
        }


        /// <summary>
        /// Brings the specified application to the foreground if it is running.
        /// </summary>
        /// <remarks>If the specified process is not running, the method does nothing. The method attempts
        /// to bring the main window of the process to the foreground and sends an Escape key press to the
        /// window.</remarks>
        /// <param name="strProcess">The name of the process to bring to the foreground. This should be the name of the executable without the
        /// file extension (e.g., "notepad" for Notepad.exe).</param>
        public void BringApplicationToFront(string strProcess)
        {
            Process catiaProcess = Process.GetProcessesByName(strProcess).FirstOrDefault();
            if (catiaProcess != null)
            {
                IntPtr catiaProcessHandle = catiaProcess.MainWindowHandle;
                SetForegroundWindow(catiaProcessHandle);
                PostMessage(catiaProcessHandle, WM_KEYDOWN, VK_ESCAPE, 0);
                PostMessage(catiaProcessHandle, WM_KEYUP, VK_ESCAPE, 0);
            }
        }

        /// <summary>
        /// Displays a message box with an OK and Cancel button, prompting the user to confirm an action.
        /// </summary>
        /// <remarks>The message box includes a message instructing the user to press OK after completing
        /// a specific task.</remarks>
        /// <returns><see langword="true"/> if the user clicks the OK button; otherwise, <see langword="false"/>.</returns>
        public bool ShowMessageBox()
        {
            // Show the message box with an OK button
            MessageBoxResult result = MessageBox.Show("Press okay after deleting connector ", "Title", MessageBoxButton.OKCancel);

            // Check if the OK button was clicked
            if (result == MessageBoxResult.OK)
                return true;

            return false;
        }
    }
}