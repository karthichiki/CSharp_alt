﻿/// <summary>
/// Utility class for all the pop up messages.
/// </summary>
/// <remarks>
/// 
/// </remarks>
/// 
/// 

using System.Windows;

namespace ALT_Utilities
{
    public static class alt_PopupMessageUtil
    {

        // Method to display a message box for various types of information
        /// <summary>
        /// Displays a message box with the specified message, title, and message type.
        /// </summary>
        /// <remarks>The message box includes an "OK" button and uses the specified <paramref
        /// name="messageType"/> to determine the icon displayed. The title is prefixed with "Alstom - Hyperautomation :
        /// " for branding purposes.</remarks>
        /// <param name="message">The content of the message to display in the message box.</param>
        /// <param name="title">The title of the message box window.</param>
        /// <param name="messageType">The type of the message, which determines the icon displayed in the message box.</param>
        public static void ShowMessage(string message, string title, MessageType messageType)
        {
            MessageBoxImage icon = GetIconForMessageType(messageType);
            MessageBoxButton buttons = MessageBoxButton.OK;
            MessageBox.Show(message, "Alstom - Hyperautomation : " + title, buttons, icon);
        }

        /// <summary>
        /// Displays a message box with "Yes" and "No" buttons, allowing the user to make a choice.
        /// </summary>
        /// <remarks>This method must be called from the UI thread or within a dispatcher context, as it
        /// interacts with the application's main window.</remarks>
        /// <param name="message">The message to display in the message box.</param>
        /// <param name="title">The title of the message box.</param>
        /// <param name="messageType">The type of message, which determines the icon displayed in the message box.</param>
        /// <returns>A <see cref="MessageBoxResult"/> indicating the user's choice.  Returns <see cref="MessageBoxResult.Yes"/>
        /// if the user selects "Yes", or <see cref="MessageBoxResult.No"/> if the user selects "No".</returns>
        public static MessageBoxResult ShowMessageYesNo(string message, string title, MessageType messageType)
        {
            MessageBoxImage icon = GetIconForMessageType(messageType);
            MessageBoxButton buttons = MessageBoxButton.YesNo;
            MessageBoxResult result = MessageBoxResult.None;
            Application.Current.Dispatcher.Invoke(() =>
            {
                result = MessageBox.Show(Application.Current.MainWindow, message, "Alstom - Hyperautomation : " + title, buttons, icon);
            });
            
            return result;
        }

        // Helper method to get the appropriate MessageBoxImage for each MessageType
        /// <summary>
        /// Maps a <see cref="MessageType"/> to its corresponding <see cref="MessageBoxImage"/>.
        /// </summary>
        /// <param name="messageType">The type of message to determine the appropriate icon for.</param>
        /// <returns>A <see cref="MessageBoxImage"/> that corresponds to the specified <paramref name="messageType"/>. Returns
        /// <see cref="MessageBoxImage.None"/> if the <paramref name="messageType"/> is not recognized.</returns>
        private static MessageBoxImage GetIconForMessageType(MessageType messageType)
        {
            switch (messageType)
            {
                case MessageType.Information:
                    return MessageBoxImage.Information;
                case MessageType.Warning:
                    return MessageBoxImage.Warning;
                case MessageType.Error:
                    return MessageBoxImage.Error;
                case MessageType.Question:
                    return MessageBoxImage.Question;
                default:
                    return MessageBoxImage.None;
            }
        }
    }

    // Enum to define different message types
    /// <summary>
    /// Specifies the type of a message, such as informational, warning, error, or question.
    /// </summary>
    /// <remarks>This enumeration is commonly used to categorize messages based on their severity or purpose.
    /// It can be used in logging, user notifications, or other scenarios where message classification is
    /// required.</remarks>
    public enum MessageType
    {
        Information,
        Warning,
        Error,
        Question
    }
}

