﻿using ALT_XML_Adapter.XmlData;
using System;
using System.IO;
using System.Xml.Serialization;

namespace ALT_XML_Adapter
{
    public class alt_XmlServices
    {
        #region Fields

        private Fictives fictiveData;
        private static alt_XmlServices _instance;

        #endregion

        #region Constructor
        private alt_XmlServices()
        {
            string folderPath = AppDomain.CurrentDomain.BaseDirectory;
            string xmlFilePath = Path.Combine(folderPath, "Resources", "Supports.xml");
            LoadXml(xmlFilePath);
        }

        #endregion

        #region Public Methods
        public static alt_XmlServices GetInstance()
        {
            if (_instance == null)
                _instance = new alt_XmlServices();

            return _instance;
        }

        /// <summary>
        /// ResetInstance.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public static void ResetInstance()
        {
            _instance = null;
        }

        /// <summary>
        /// Check if xml file exist or not
        /// </summary>
        /// <param name="XMLPath"></param>
        /// <returns></returns>
        public bool FileExist(string XMLPath)
        {
            try
            {
                if (File.Exists(XMLPath) == true)
                    return true;
            }
            catch
            {
                return false;
            }

            return false;
        }

        /// <summary>
        /// Load xml file
        /// </summary>
        /// <param name="xmlPath"></param>
        /// <exception cref="FileNotFoundException"></exception>
        public void LoadXml(string xmlPath)
        {
            if (string.IsNullOrEmpty(xmlPath) || !FileExist(xmlPath))
            {
                throw new FileNotFoundException("The specified XML file was not found.");
            }

            XmlSerializer serializer = new XmlSerializer(typeof(Fictives));
            using (StreamReader reader = new StreamReader(xmlPath))
            {
                fictiveData = (Fictives)serializer.Deserialize(reader);
            }
        }

        /// <summary>
        /// Get Ehi support bu name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        public EhiSupport GetEhiSupportByName(string name)
        {
            if (fictiveData?.Supports == null)
            {
                throw new InvalidOperationException("XML data has not been loaded. LoadXml file first.");
            }

            return fictiveData.Supports.Find(support => support.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Get Ehi point by name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        /// <exception cref="InvalidOperationException"></exception>
        public EhiPoint GetEhiPointByName(string name)
        {
            if (fictiveData?.Points == null)
            {
                throw new InvalidOperationException("XML data has not been loaded. Call LoadXml() first.");
            }

            return fictiveData.Points.Find(point => point.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        #endregion

        #region Private Methods
        #endregion
    }
}
