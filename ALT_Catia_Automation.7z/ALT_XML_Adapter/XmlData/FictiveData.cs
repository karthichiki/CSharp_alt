﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ALT_XML_Adapter.XmlData
{
    [XmlRoot("Fictives")]
    public class Fictives
    {
        [XmlArray("Supports")]
        [XmlArrayItem("EhiSupport")]
        public List<EhiSupport> Supports { get; set; }

        [XmlArray("Points")]
        [XmlArrayItem("EhiPoint")]
        public List<EhiPoint> Points { get; set; }
    }

    public class EhiSupport
    {
        [XmlAttribute("Name")]
        public string Name { get; set; }

        [XmlElement("PartName")]
        public string PartName { get; set; }

        [XmlElement("Center")]
        public Point Center { get; set; }

        [XmlElement("Tangent")]
        public Point Tangent { get; set; }
    }

    public class EhiPoint
    {
        [XmlAttribute("Name")]
        public string Name { get; set; }

        [XmlElement("PartName")]
        public string PartName { get; set; }

        [XmlElement("Center")]
        public Point Center { get; set; }
    }

    public class Point
    {
        [XmlElement("X")]
        public double X { get; set; }

        [XmlElement("Y")]
        public double Y { get; set; }

        [XmlElement("Z")]
        public double Z { get; set; }
    }
}
