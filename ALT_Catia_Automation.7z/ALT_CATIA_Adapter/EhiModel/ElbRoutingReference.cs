﻿using INFITF;
using System.Collections.Generic;

namespace Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel
{
    public class ElbRoutingReference
    {
        public Reference ElbReference { get; private set; }

        public bool IsDummySupport { get; private set; }

        public IList<int> Indices { get; private set; }

        public IList<Reference> PointsReferences { get; private set; }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="routingReference"></param>
        /// <param name="isDummySupport"></param>
        public ElbRoutingReference(Reference routingReference, bool isDummySupport)
        {
            ElbReference = routingReference;
            IsDummySupport = isDummySupport;
            Indices = new List<int>();
            PointsReferences = new List<Reference>();
        }
    }
}
