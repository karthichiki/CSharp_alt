﻿using ACNEHIWrapper;
using CatiaDotNet.CommonServices;
using System.Collections.Generic;
using System.Reflection;
using System;
using ProductStructureTypeLib;
using INFITF;
using CatiaDotNet.CommonExtensions;
using MECMOD;

namespace Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel
{
    public static class EhiMultiBranchable
    {
        /// <summary>
        /// Add branchable to multibranchable
        /// </summary>
        /// <param name="iEhiMultiBranchable"></param>
        /// <returns></returns>
        public static CATIEhiBranchable AddBranchable(CATIEhiMultiBranchable iEhiMultiBranchable)
        {
            CATIEhiBranchable ehiBranchable;
            iEhiMultiBranchable.AddBranchable(out ehiBranchable);
            return ehiBranchable;
        }

        /// <summary>
        /// Get Branchable list
        /// </summary>
        /// <param name="iEhiMultiBranchable"></param>
        /// <returns></returns>
        public static IList<CATIEhiBranchable> GetBranchables(this CATIEhiMultiBranchable iEhiMultiBranchable)
        {
            IList<CATIEhiBranchable> branches = new List<CATIEhiBranchable>();
            try
            {
                Array branchables;
                iEhiMultiBranchable.ListBranchables(out branchables);
                foreach (CATIEhiBranchable branch in branchables)
                    branches.Add(branch);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return branches;
        }

        /// <summary>
        /// Compute multibranchable
        /// </summary>
        /// <param name="multiBranchablePrd"></param>
        public static void ComputeMultiBranchable(Product multiBranchablePrd)
        {
            try
            {
                double flag = 0;
                CATIEhiMultiBranchable multiBranchable = (CATIEhiMultiBranchable)multiBranchablePrd;
                Product geomPrd = (Product)multiBranchablePrd.Parent;
                CATIEhiGeoBundle geomBundle = (CATIEhiGeoBundle)geomPrd;
                geomBundle.ComputeMultiBranchable(multiBranchable, out flag);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Create External Reference
        /// </summary>
        /// <param name="iEhiMultiBranchable"></param>
        /// <param name="iPoint"></param>
        /// <returns></returns>
        public static Reference CreateExtrenalReference(this CATIEhiMultiBranchable iEhiMultiBranchable, Reference iPoint)
        {
            AnyObject copiedPoint = null;
            Part mbbnsPart = CatiaProductExtensions.GetPart(iEhiMultiBranchable as Product);
            HybridBody orCreateHybridBody = CatiaPartExtensions.GetOrCreateHybridBody(mbbnsPart, "External References");
            mbbnsPart.UpdateObject(orCreateHybridBody);
            iEhiMultiBranchable.CreateExternalReference(iPoint, orCreateHybridBody, out copiedPoint);
            return (Reference)copiedPoint;
        }

        /// <summary>
        /// Update multibranchable part
        /// </summary>
        /// <param name="iMultiBranchable"></param>
        public static void Update(this CATIEhiMultiBranchable iMultiBranchable)
        {
            if (iMultiBranchable == null)
                return;

            try
            {
                (iMultiBranchable as Product).Update();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }
    }
}
