﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using CatiaDotNet.CommonExtensions;
using CatiaDotNet.CommonServices;
using HybridShapeTypeLib;
using INFITF;
using MECMOD;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel
{
    public static class EhiBranchable
    {
        /// <summary>
        /// Get part from multibranchable
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static Part GetPart(this CATIEhiBranchable iEhiBranchable)
        {
            Part part = null;
            try 
            {
                CATIEhiMultiBranchable multiBranchable = null;
                iEhiBranchable.GetMultiBranchable(out multiBranchable);
                part = CatiaProductExtensions.GetPart(multiBranchable as Product);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return part;
        }

        /// <summary>
        /// Get Product mutlibranchable Product
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static Product GetProduct(this CATIEhiBranchable iEhiBranchable)
        {
            Product product = null;
            try
            {
                CATIEhiMultiBranchable multiBranchable = null;
                iEhiBranchable.GetMultiBranchable(out multiBranchable);
                product = (Product)multiBranchable;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return product;
        }

        /// <summary>
        /// Get Multibranchable from branchable
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static CATIEhiMultiBranchable GetMultiBranchable(this CATIEhiBranchable iEhiBranchable)
        {
            CATIEhiMultiBranchable multiBranchable = null;
            try
            {             
                iEhiBranchable.GetMultiBranchable(out multiBranchable);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return multiBranchable;
        }

        /// <summary>
        /// Get spline from electrical curve
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static HybridShapeSpline GetElecCurve(CATIEhiBranchable iEhiBranchable)
        {
            HybridShapeSpline spline = null;
            try
            {
                CATBaseDispatch elecCurve = null;
                iEhiBranchable.GetElecCurve(out elecCurve);
                spline = (HybridShapeSpline)elecCurve;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return spline;
        }

        /// <summary>
        /// Get branchable name
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static string GetName(CATIEhiBranchable iEhiBranchable)
        {            
            string branchName = string.Empty;
            CATICkeInst ckeInstance = null;
            try
            {
                CATIElecAttrAccess elecAttrAccess = (CATIElecAttrAccess)iEhiBranchable;
                elecAttrAccess.Get("Elec_Ref_Des", out ckeInstance);
                ckeInstance.AsString(ref branchName);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return branchName;
        }

        /// <summary>
        /// Get list of bundle segments from branchable
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static IList<CATIEhiBundleSegment> GetBundleSegments(this CATIEhiBranchable iEhiBranchable)
        {
            IList<CATIEhiBundleSegment> segments = new List<CATIEhiBundleSegment>();
            try
            {
                Array bundleSegments;
                iEhiBranchable.ListBundleSegments(out bundleSegments);
                foreach (CATIEhiBundleSegment bundleSegment in bundleSegments)
                    segments.Add(bundleSegment);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return segments;
        }

        /// <summary>
        /// Get bundle segment index from list of bundlesegments
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="count"></param>
        /// <returns></returns>
        public static CATIEhiBundleSegment GetBundleSegmentCount(this CATIEhiBranchable iEhiBranchable, int count)
        {
            CATIEhiBundleSegment segment = null;
            try
            {
                Array bundleSegments;
                iEhiBranchable.ListBundleSegments(out bundleSegments);
                if (bundleSegments == null || bundleSegments.Length == 0)
                    return segment;

                segment = (CATIEhiBundleSegment) bundleSegments.GetValue(count);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return segment;
        }

        /// <summary>
        /// Get Branchable extremities
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <returns></returns>
        public static IList<ElbRoutingReference> GetExtremities(CATIEhiBranchable ehiBranchable)
        {
            IList<ElbRoutingReference> ElbRoutingReferences = null;
            try
            {
                ElbRoutingReferences = new List<ElbRoutingReference>
                {
                    GetFirstExtremityRouting(ehiBranchable),
                    GetSecondExtremityRouting(ehiBranchable)
                };
            }
            catch { }

            return ElbRoutingReferences;
        }

        /// <summary>
        /// Extract support list from routing
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <returns></returns>
        public static IList<string> GetLinkedSupportList(CATIEhiBranchable ehiBranchable, IList<CATIEhiBundleSegment> ehiSegments)
        {
            List<string> SupportList = new List<string>();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            try
            {
                if (ehiSegments == null || ehiSegments.Count == 0)
                    ehiSegments = GetBundleSegments(ehiBranchable);

                foreach(CATIEhiBundleSegment ehiSegment in ehiSegments)
                {
                    if(ehiSegment == null)
                        continue;

                    IList<string> supportlist = EhiBundleSegment.GetLinkedSupportList(ehiSegment);
                    SupportList.AddRange(supportlist);
                }
            }
            catch { }

            return SupportList;
        }

        /// <summary>
        /// Get first extremity from branch
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static ElbRoutingReference GetFirstExtremityRouting(CATIEhiBranchable iEhiBranchable)
        {
            IList<ElbRoutingReference> list = new List<ElbRoutingReference>();
            IList<Reference> list2 = new List<Reference>();
            try
            {
                HybridShapeSpline elecCurve = GetElecCurve(iEhiBranchable);
                int nbControlPoint = elecCurve.GetNbControlPoint();

                Array objects = null;
                Array positionOnCurve = null;
                iEhiBranchable.ListObjectsInRoute(out objects, out positionOnCurve);
                int num = 0;
                for (int i = 1; i <= nbControlPoint; i++)
                {
                    if (num < positionOnCurve.Length && (int)positionOnCurve.GetValue(num) == i)
                    {
                        AnyObject anyObject = (AnyObject)objects.GetValue(num);
                        if (anyObject != null && anyObject is Reference reference)
                        {
                            int refIndex = CatiaPartExtensions.GetRefIndex(list2, reference);
                            if (list2.Count > 0 && refIndex == -1)
                                break;

                            if (refIndex < 0)
                            {
                                ((ICollection<int>)new List<int>()).Add(i);
                                ElbRoutingReference elbRoutingReference = new ElbRoutingReference(reference, isDummySupport: false);
                                elbRoutingReference.Indices.Add(i);
                                elbRoutingReference.PointsReferences.Add(elecCurve.GetPoint(i));
                                list.Add(elbRoutingReference);
                                list2.Add(reference);
                            }
                            else
                            {
                                list[refIndex].Indices.Add(i);
                                list[refIndex].PointsReferences.Add(elecCurve.GetPoint(i));
                            }

                            num++;
                        }
                    }
                    else
                    {
                        ((ICollection<int>)new List<int>()).Add(i);
                        ElbRoutingReference elbRoutingReference2 = new ElbRoutingReference(elecCurve.GetPoint(i), isDummySupport: true);
                        elbRoutingReference2.Indices.Add(i);
                        elbRoutingReference2.PointsReferences.Add(elecCurve.GetPoint(i));
                        list.Add(elbRoutingReference2);
                        list2.Add(elecCurve.GetPoint(i));
                    }
                }

                return list[0];
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return null;
        }

        /// <summary>
        /// Get second extremity from branch
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static ElbRoutingReference GetSecondExtremityRouting(CATIEhiBranchable iEhiBranchable)
        {
            IList<ElbRoutingReference> list = new List<ElbRoutingReference>();
            IList<Reference> list2 = new List<Reference>();
            try
            {
                HybridShapeSpline elecCurve = GetElecCurve(iEhiBranchable);
                int nbControlPoint = elecCurve.GetNbControlPoint();

                Array objects = null;
                Array positionOnCurve = null;
                iEhiBranchable.ListObjectsInRoute(out objects, out positionOnCurve);
                int num = nbControlPoint-1;
                for (int i = nbControlPoint; i >= 1; i--)
                {
                    if (num < positionOnCurve.Length && (int)positionOnCurve.GetValue(num) == i)
                    {
                        AnyObject anyObject = (AnyObject)objects.GetValue(num);
                        if (anyObject != null && anyObject is Reference reference)
                        {
                            int refIndex = CatiaPartExtensions.GetRefIndex(list2, reference);
                            if (list2.Count > 0 && refIndex == -1)
                                break;

                            if (refIndex < 0)
                            {
                                ((ICollection<int>)new List<int>()).Add(i);
                                ElbRoutingReference elbRoutingReference = new ElbRoutingReference(reference, isDummySupport: false);
                                elbRoutingReference.Indices.Add(i);
                                elbRoutingReference.PointsReferences.Add(elecCurve.GetPoint(i));
                                list.Add(elbRoutingReference);
                                list2.Add(reference);
                            }
                            else
                            {
                                list[refIndex].Indices.Add(i);
                                list[refIndex].PointsReferences.Add(elecCurve.GetPoint(i));
                            }

                            num--;
                        }
                    }
                    else
                    {
                        ((ICollection<int>)new List<int>()).Add(i);
                        ElbRoutingReference elbRoutingReference2 = new ElbRoutingReference(elecCurve.GetPoint(i), isDummySupport: true);
                        elbRoutingReference2.Indices.Add(i);
                        elbRoutingReference2.PointsReferences.Add(elecCurve.GetPoint(i));
                        list.Add(elbRoutingReference2);
                        list2.Add(elecCurve.GetPoint(i));
                    }
                }

                return list[0];
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return null;
        }

        #region Branch Parameters

        /// <summary>
        /// Get slack
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <returns></returns>
        public static double GetSlack(this CATIEhiBranchable ehiBranchable)
        {
            double slack = double.MinValue;
            try
            {
                if (!(GetElecCurve(ehiBranchable) is CATIElecAttrAccess elecAttrAccess))
                    return slack;

                CATICkeInst ckeInstance = null;
                elecAttrAccess.Get("Elec_Di_Slack", out ckeInstance);
                ckeInstance.AsReal(out slack);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return slack;
        }

        /// <summary>
        /// Set branchable slack
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="iValue"></param>
        public static void SetSlack(this CATIEhiBranchable ehiBranchable, double iValue)
        {
            try 
            {
                if (GetElecCurve(ehiBranchable) is CATIElecAttrAccess elecAttrAccess)
                    elecAttrAccess.SetDouble("Elec_Di_Slack", iValue);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Get branchable bend raduis ratio state
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <returns></returns>
        public static bool GetBendRadiusRatioState(this CATIEhiBranchable ehiBranchable)
        {
            bool bendRadiusRatioState = false;
            try
            {
                if (!(ehiBranchable is CATIElecAttrAccess elecAttrAccess))
                    return bendRadiusRatioState;

                CATICkeInst ckeInstance = null;
                elecAttrAccess.Get("Elec_BendRadiusRatioMode", out ckeInstance);
                ckeInstance.AsBoolean(out bendRadiusRatioState);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return bendRadiusRatioState;
        }

        /// <summary>
        /// Set bend raduis ratio state
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="iValue"></param>
        public static void SetBendRadiusRatioState(this CATIEhiBranchable ehiBranchable, bool iValue)
        {
            try
            {
                if (ehiBranchable is CATIElecAttrAccess elecAttrAccess)
                    elecAttrAccess.SetBool("Elec_BendRadiusRatioMode", iValue);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Get branchable bend raduis
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <returns></returns>
        public static double GetBendRadius(this CATIEhiBranchable ehiBranchable)
        {
            double bendRadius = double.MinValue;
            try 
            {
                if (!(GetElecCurve(ehiBranchable) is CATIElecAttrAccess elecAttrAccess))
                    return bendRadius;

                CATICkeInst ckeInstance = null;
                elecAttrAccess.Get("Elec_Bend_Radius", out ckeInstance);
                ckeInstance.AsReal(out bendRadius);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return bendRadius;
        }

        /// <summary>
        /// Set branchable bend raduis
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="iValue"></param>
        public static void SetBendRadius(this CATIEhiBranchable ehiBranchable, double iValue)
        {
            try 
            {
                if (GetElecCurve(ehiBranchable) is CATIElecAttrAccess elecAttrAccess)
                {
                    if (!ehiBranchable.GetBendRadiusRatioState())
                        elecAttrAccess.SetDouble("Elec_Bend_Radius", iValue / 1000.0);
                    else if (ehiBranchable is CATIElecAttrAccess elecAttrAccess2)
                    {
                        //string iAttributeName = "Elec_BendRadiusRatio";
                        //elecAttrAccess2.set(ref iAttributeName, ehiBranchable.ComputeRatioFromBendRadius(iValue));
                    }
                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + 
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        #endregion

        #region Branch Routing

        /// <summary>
        /// Get branchable routing
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static IList<ElbRoutingReference> GetBranchableRouting(CATIEhiBranchable iEhiBranchable)
        {
            IList<ElbRoutingReference> list = new List<ElbRoutingReference>();
            IList<Reference> list2 = new List<Reference>();
            try
            {
                HybridShapeSpline elecCurve = GetElecCurve(iEhiBranchable);
                int nbControlPoint = elecCurve.GetNbControlPoint();

                Array objects = null;
                Array positionOnCurve = null;
                iEhiBranchable.ListObjectsInRoute(out objects, out positionOnCurve);
                int num = 0;
                for (int i = 1; i <= nbControlPoint; i++)
                {
                    if (num < positionOnCurve.Length && (int)positionOnCurve.GetValue(num) == i)
                    {
                        AnyObject anyObject = (AnyObject)objects.GetValue(num);
                        if (anyObject != null && anyObject is Reference reference)
                        {
                            int refIndex = CatiaPartExtensions.GetRefIndex(list2, reference);
                            if (refIndex < 0)
                            {
                                ((ICollection<int>)new List<int>()).Add(i);
                                ElbRoutingReference elbRoutingReference = new ElbRoutingReference(reference, isDummySupport: false);
                                elbRoutingReference.Indices.Add(i);
                                elbRoutingReference.PointsReferences.Add(elecCurve.GetPoint(i));
                                list.Add(elbRoutingReference);
                                list2.Add(reference);
                            }
                            else
                            {
                                list[refIndex].Indices.Add(i);
                                list[refIndex].PointsReferences.Add(elecCurve.GetPoint(i));
                            }

                            num++;
                        }
                    }
                    else
                    {
                        ((ICollection<int>)new List<int>()).Add(i);
                        ElbRoutingReference elbRoutingReference2 = new ElbRoutingReference(elecCurve.GetPoint(i), isDummySupport: true);
                        elbRoutingReference2.Indices.Add(i);
                        elbRoutingReference2.PointsReferences.Add(elecCurve.GetPoint(i));
                        list.Add(elbRoutingReference2);
                        list2.Add(elecCurve.GetPoint(i));
                    }
                }

                return list;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return new List<ElbRoutingReference>();
        }

        /// <summary>
        /// Get branchable routing object index
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="iObject"></param>
        /// <returns></returns>
        public static int GetRoutingObjectIndex(this CATIEhiBranchable iEhiBranchable, Reference iObject)
        {
            try
            {
                IList<ElbRoutingReference> branchableRouting = GetBranchableRouting(iEhiBranchable);
                for (int i = 0; i <= branchableRouting.Count; i++)
                {
                    if (branchableRouting[i].ElbReference.Equals(iObject))
                        return i;
                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return -1;
        }

        /// <summary>
        /// Get branchable routing object
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="iObjectIndex"></param>
        /// <returns></returns>
        public static Reference GetRoutingObject(this CATIEhiBranchable iEhiBranchable, int iObjectIndex)
        {
            try
            {
                IList<ElbRoutingReference> branchableRouting = GetBranchableRouting(iEhiBranchable);
                if (iObjectIndex < branchableRouting.Count && iObjectIndex >= 0)
                    return branchableRouting[iObjectIndex].ElbReference;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return null;
        }

        /// <summary>
        /// Get branchable last routing object
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static Reference GetLastRountingObject(this CATIEhiBranchable iEhiBranchable)
        {
            try
            {
                return iEhiBranchable.GetRoutingObject(iEhiBranchable.GetNbRoutingObjects() - 1);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return null;
        }

        /// <summary>
        /// Get number branchable routing object
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static int GetNbRoutingObjects(this CATIEhiBranchable iEhiBranchable)
        {
            try
            {
                return GetBranchableRouting(iEhiBranchable).Count;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return 0;
        }

        /// <summary>
        /// Get RoutingObjectCurveIndices of input object
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="iObject"></param>
        /// <returns></returns>
        public static IList<int> GetRoutingObjectCurveIndices(this CATIEhiBranchable iEhiBranchable, Reference iObject)
        {
            if (iEhiBranchable == null || iObject == null)
                return null;

            try
            {
                IList<ElbRoutingReference> ElbRoutingReferences = GetBranchableRouting(iEhiBranchable);
                foreach (ElbRoutingReference item in ElbRoutingReferences)
                {
                    if (iObject is Product && item.ElbReference.Equals(iObject))
                        return item.Indices;

                    if (!(iObject is Product) && item.Indices.Count == 1 && (item.PointsReferences[0].Equals(iObject) || (item.PointsReferences[0].Parent as Reference).Equals(iObject)))
                        return item.Indices;
                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }

            return null;
        }
        #endregion

        #region Insert Object

        /// <summary>
        /// Add signle connector after 
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="iConnector"></param>
        /// <param name="iInvertDirection"></param>
        public static void AddElbSingleConnectorAfter(this CATIEhiBranchable iEhiBranchable, EhiElbConnector iConnector, bool iInvertDirection)
        {
            if (iEhiBranchable == null || iConnector == null)
                return;

            try
            {
                int nbCtrl = GetElecCurve(iEhiBranchable).GetNbControlPoint();
                if (nbCtrl > 0)
                {
                    InsertElbSingleConnectorAfter(iEhiBranchable, iConnector, !iInvertDirection);
                    return;
                }

                AnyObject copiedPoint = null;
                AnyObject copiedElem = null;
                CATIEhiMultiBranchable multiBranchable = GetMultiBranchable(iEhiBranchable);

                Part mbbnsPart = GetPart(iEhiBranchable);
                HybridBody orCreateHybridBody = CatiaPartExtensions.GetOrCreateHybridBody(mbbnsPart, "External References");
                mbbnsPart.UpdateObject(orCreateHybridBody);

                multiBranchable.CreateExternalReference(iConnector.GetReference(), orCreateHybridBody, out copiedPoint);
                GetElecCurve(iEhiBranchable).SetPointAfter(0, (Reference)copiedPoint);

                multiBranchable.CreateExternalReference(iConnector.GetReferenceFace(), orCreateHybridBody, out copiedElem);
                HybridShapeDirection ipIADirTangency = (GetPart(iEhiBranchable).HybridShapeFactory as HybridShapeFactory).AddNewDirection((Reference)copiedElem);
                int iInverseTangency = (!iInvertDirection) ? 1 : (-1);
                GetElecCurve(iEhiBranchable).SetPointConstraintExplicit(1, ipIADirTangency, 0.0, iInverseTangency, null, 0.0);
                mbbnsPart.Update();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Insert single connector after
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="iConnector"></param>
        /// <param name="iRefObject"></param>
        /// <param name="iInvertDirection"></param>
        public static void InsertElbSingleConnectorAfter(this CATIEhiBranchable iEhiBranchable, EhiElbConnector iConnector, bool iInvertDirection)
        {
            if (iEhiBranchable == null || iConnector == null)
                return;

            try
            {
                int nbCtrl = GetElecCurve(iEhiBranchable).GetNbControlPoint();
                AnyObject copiedPoint = null;
                AnyObject copiedElem = null;
                CATIEhiMultiBranchable multiBranchable = GetMultiBranchable(iEhiBranchable);

                Part mbbnsPart = GetPart(iEhiBranchable);
                HybridBody orCreateHybridBody = CatiaPartExtensions.GetOrCreateHybridBody(mbbnsPart, "External References");
                mbbnsPart.UpdateObject(orCreateHybridBody);

                multiBranchable.CreateExternalReference(iConnector.GetReference(), orCreateHybridBody, out copiedPoint);
                multiBranchable.CreateExternalReference(iConnector.GetReferenceFace(), orCreateHybridBody, out copiedElem);
                GetElecCurve(iEhiBranchable).SetPointAfter(nbCtrl, (Reference)copiedPoint);
                HybridShapeDirection ipIADirTangency = (GetPart(iEhiBranchable).HybridShapeFactory as HybridShapeFactory).AddNewDirection((Reference)copiedElem);
                int iInverseTangency = (!iInvertDirection) ? 1 : (-1);
                GetElecCurve(iEhiBranchable).SetPointConstraintExplicit(nbCtrl + 1, ipIADirTangency, 0.0, iInverseTangency, null, 0.0);
                mbbnsPart.Update();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Replace point by support
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="pos"></param>
        /// <param name="iSupport"></param>
        /// <param name="iDirectMode"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void ReplaceBySupport(this CATIEhiBranchable iEhiBranchable, int pos, Product iSupport, int iDirectMode = 0)
        {
            if (iEhiBranchable == null || iSupport == null)
            {
                throw new ArgumentNullException();
            }

            try
            {
                HybridShapeSpline splineBr = GetElecCurve(iEhiBranchable);
                splineBr.RemoveControlPoint(pos);
                iEhiBranchable.AddSupport(iSupport, iDirectMode, pos, 0);
                splineBr.Compute();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Replace by point in spline
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="iPoint"></param>
        /// <param name="iRefObject"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void ReplaceByPoint(this CATIEhiBranchable iEhiBranchable, Reference iPoint, int pos)
        {
            if (iEhiBranchable == null || iPoint == null)
                throw new ArgumentNullException();

            try
            {
                CATIEhiMultiBranchable multiBranchable = GetMultiBranchable(iEhiBranchable);
                Part mbbnsPart = GetPart(iEhiBranchable);
                HybridShapeSpline splineBr = GetElecCurve(iEhiBranchable);
                if(splineBr.GetConstraintType(pos) == 2)
                {
                    Reference refCurveCst = null;
                    double tangencyNorm = 0;
                    int invertValue, crvCstType = 0;
                    splineBr.GetPointConstraintFromCurve(1, out refCurveCst, out tangencyNorm, out invertValue, out crvCstType);
                    splineBr.SetPointAfter(pos, iPoint);
                    splineBr.RemoveControlPoint(pos);
                    if (refCurveCst != null)
                        splineBr.SetPointConstraintFromCurve(1, refCurveCst, tangencyNorm, invertValue, crvCstType);
                }
                else if(splineBr.GetConstraintType(pos) == 1)
                {
                    splineBr.GetPointConstraintExplicit(pos, out HybridShapeDirection dirTangent, out double tangencyNorm, out int inverseTangency, out HybridShapeDirection dirCurv, out double curvRadius);
                    splineBr.SetPointAfter(pos, iPoint);
                    splineBr.RemoveControlPoint(pos);
                    if (dirTangent != null)
                        splineBr.SetPointConstraintExplicit(pos, dirTangent, tangencyNorm, inverseTangency, dirCurv, curvRadius);
                }
                else
                {
                    splineBr.SetPointAfter(pos, iPoint);
                    splineBr.RemoveControlPoint(pos);
                }

                splineBr.Compute();
                mbbnsPart.Update();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Add point to spline
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <param name="refPoint"></param>
        /// <param name="tangent"></param>
        /// <param name="createExtrenalRef"></param>
        /// <exception cref="ArgumentNullException"></exception>
        public static void AddPointAfter(this CATIEhiBranchable iEhiBranchable, Reference refPoint, Vector3d tangent, bool createExtrenalRef)
        {
            if (iEhiBranchable == null || refPoint == null)
                throw new ArgumentNullException();

            try
            {
                Reference pointToAdd = null;
                CATIEhiMultiBranchable multiBranchable = GetMultiBranchable(iEhiBranchable);
                Part mbbnsPart = GetPart(iEhiBranchable);
                HybridShapeSpline elecCurve = GetElecCurve(iEhiBranchable);

                if(createExtrenalRef)
                    pointToAdd = EhiMultiBranchable.CreateExtrenalReference(multiBranchable, refPoint);
                else
                    pointToAdd = refPoint;

                elecCurve.SetPointAfter(elecCurve.GetNbControlPoint(), pointToAdd);
                int pos = elecCurve.GetNbControlPoint();

                elecCurve.GetPointConstraintExplicit(pos, out _, out double tangencyNorm, out int inverseTangency, out HybridShapeDirection dirCurv, out double curvRadius);
                HybridShapeDirection direction = ((HybridShapeFactory)mbbnsPart.HybridShapeFactory).AddNewDirectionByCoord(tangent.X, tangent.Y, tangent.Z);
                elecCurve.SetPointConstraintExplicit(pos, direction, tangencyNorm, inverseTangency, dirCurv, curvRadius);

                elecCurve.Compute();
                mbbnsPart.Update();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." + currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Add point to spline by coordinates
        /// </summary>
        /// <param name="ehiBranchable"></param>
        /// <param name="coordinates"></param>
        /// <param name="tangent"></param>
        /// <param name="pointName"></param>
        public static void AddPointAfterByCoords(CATIEhiBranchable ehiBranchable, Vector3d coordinates, Vector3d tangent, string pointName)
        {
            try
            {
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();

                // 1.Add point to spline
                CATIEhiMultiBranchable multiBranchable = GetMultiBranchable(ehiBranchable);
                Part mbbnsPart = GetPart(ehiBranchable);
                Product geomPrd = (Product)multiBranchable.Parent;

                Vector3d localCoordinates = adapter.TransformToLocalCoordinates(coordinates, (Product)geomPrd);
                HybridBody hybridBody = mbbnsPart.GetOrCreateHybridBody("HyperAutomation");
                Reference pointRef = adapter.CreatePointByCoordinates(mbbnsPart, localCoordinates, hybridBody, pointName);

                HybridShapeSpline elecCurve = GetElecCurve(ehiBranchable);
                int bsPtIdx = elecCurve.GetNbControlPoint();
                elecCurve.SetPointAfter(bsPtIdx, pointRef);

                // 2.Add point tangent
                bsPtIdx = elecCurve.GetNbControlPoint();
                elecCurve.GetPointConstraintExplicit(bsPtIdx, out _, out double tangencyNorm, out int inverseTangency, out HybridShapeDirection dirCurv, out double curvRadius);
                HybridShapeDirection direction = ((HybridShapeFactory)mbbnsPart.HybridShapeFactory).AddNewDirectionByCoord(tangent.X, tangent.Y, tangent.Z);
                elecCurve.SetPointConstraintExplicit(bsPtIdx, direction, tangencyNorm, inverseTangency, dirCurv, curvRadius);

                elecCurve.Compute();
                mbbnsPart.Update();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }
        #endregion

    }
}
