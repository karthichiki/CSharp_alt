﻿using ALT_Logging;
using CatiaDotNet.CommonServices;
using INFITF;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel
{
    public class EhiElbConnector
    {
        #region Fields

        private Reference _referenceFace = null;
        private Reference _referencePoint = null;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="referencePoint"></param>
        /// <param name="referenceFace"></param>
        public EhiElbConnector(Reference referencePoint, Reference referenceFace)
        {
            _referencePoint = referencePoint;
            _referenceFace = referenceFace;
        }
        #endregion

        #region Properties

        #endregion

        #region Public Methods

        public Reference GetReference()
        {
            return _referencePoint;
        }
        public Reference GetReferenceFace()
        {
            return _referenceFace;
        }
        #endregion

        #region Private Methods      
        #endregion
    }
}
