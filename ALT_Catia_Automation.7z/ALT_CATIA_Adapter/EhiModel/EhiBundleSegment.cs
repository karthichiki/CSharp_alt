﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using CatiaDotNet.CommonServices;
using HybridShapeTypeLib;
using INFITF;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel
{
    public static class EhiBundleSegment
    {
        /// <summary>
        /// Get bundle segment electrical curve
        /// </summary>
        /// <param name="ehiBundleSegment"></param>
        /// <returns></returns>
        public static HybridShapeSpline GetElecCurve(CATIEhiBundleSegment ehiBundleSegment)
        {
            HybridShapeSpline spline = null;
            try 
            {
                CATBaseDispatch elecCurve = null;
                ehiBundleSegment.GetElecCurve(out elecCurve);
                spline = (HybridShapeSpline)elecCurve;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return spline;
        }

        /// <summary>
        /// Get bundle segment diameter
        /// </summary>
        /// <param name="ehiBundleSegment"></param>
        /// <returns></returns>
        public static double GetDiameter(this CATIEhiBundleSegment ehiBundleSegment)
        {
            double diameter = double.MinValue;

            try 
            {
                if (!(ehiBundleSegment is CATIElecAttrAccess elecAttrAccess))
                    return double.MinValue;

                CATICkeInst ckeInstance = null;
                elecAttrAccess.Get("Elec_Diameter", out ckeInstance);
                ckeInstance.AsReal(out diameter);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return diameter;
        }

        /// <summary>
        /// Set bundle segment diameter
        /// </summary>
        /// <param name="ehiBundleSegment"></param>
        /// <param name="iValue"></param>
        public static void SetDiameter(this CATIEhiBundleSegment ehiBundleSegment, double iValue)
        {
            try 
            {
                if (ehiBundleSegment is CATIElecAttrAccess elecAttrAccess)
                    elecAttrAccess.SetDouble("Elec_Diameter", iValue / 1000.0);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Get bundle segment bend raduis
        /// </summary>
        /// <param name="ehiBundleSegment"></param>
        /// <returns></returns>
        public static double GetBendRadius(this CATIEhiBundleSegment ehiBundleSegment)
        {
            double bendRadius = double.MinValue;
            try 
            {
                //if (!(GetElecCurve(ehiBundleSegment) is CATIElecAttrAccess elecAttrAccess))
                //    return bendRadius;
                CATIElecAttrAccess elecAttrAccess = ehiBundleSegment as CATIElecAttrAccess;
                CATICkeInst ckeInstance = null;
                elecAttrAccess.Get("Elec_Bend_Radius", out ckeInstance);
                ckeInstance.AsReal(out bendRadius);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return bendRadius;
        }

        /// <summary>
        /// Set bundle segment bend raduis
        /// </summary>
        /// <param name="ehiBundleSegment"></param>
        /// <param name="iValue"></param>
        public static void SetBendRadius(this CATIEhiBundleSegment ehiBundleSegment, double iValue)
        {
            try
            {
                if (GetElecCurve(ehiBundleSegment) is CATIElecAttrAccess elecAttrAccess)
                    elecAttrAccess.SetDouble("Elec_Bend_Radius", iValue / 1000.0);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
        }

        /// <summary>
        /// Get bundle segment name
        /// </summary>
        /// <param name="iEhiBranchable"></param>
        /// <returns></returns>
        public static string GetName(this CATIEhiBundleSegment ehiBundleSegment)
        {
            string branchName = string.Empty;
            CATICkeInst ckeInstance = null;
            try
            {
                CATIElecAttrAccess elecAttrAccess = (CATIElecAttrAccess)ehiBundleSegment;
                elecAttrAccess.Get("Elec_Ref_Des", out ckeInstance);
                ckeInstance.AsString(ref branchName);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return branchName;
        }

        public static CATIEhiBranchable GetBranchable(this CATIEhiBundleSegment ehiBundleSegment)
        {
            CATIEhiBranchable branchable = null;
            try
            {
                ehiBundleSegment.GetBranchable(out branchable);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return branchable;
        }

        /// <summary>
        /// Get linked support list
        /// </summary>
        /// <param name="ehiBundleSegment"></param>
        /// <returns></returns>
        public static IList<string> GetLinkedSupportList(CATIEhiBundleSegment ehiBundleSegment)
        {
            List<string> SupportList = new List<string>();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            try
            {
                ehiBundleSegment.ListLinkedSupports(out Array oSupports);
                foreach (Product product in oSupports)
                {
                    if (product == null)
                        continue;

                    SupportList.Add(product.get_Name());
                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return SupportList;
        }
    }
}
