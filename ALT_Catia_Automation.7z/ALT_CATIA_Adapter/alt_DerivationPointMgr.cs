﻿using ACNEHIWrapper;
using ALT_Logging;
using CatiaDotNet.CommonExtensions;
using HybridShapeTypeLib;
using INFITF;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using MECMOD;
using OpenTK;
using ProductStructureTypeLib;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ALT_CATIA_Adapter
{
    public class alt_DerivationPointMgr
    {
        #region Fields

        private Product _derPointProduct = null;
        private CATIEhiGeoBundle _geomBundle = null;
        private Vector3d _tangentDirection;

        private Edge _selectedEdge = null;
        private bool _isEhiSupport = false;
        private Reference _derPoint;
        private Reference _branchCurve;
        private Vector3d _pointCoords;
        IList<(CATIEhiBranchable, int)> _branches = null;

        private alt_CATIA_Adapter _adapter = null;
        private alt_CATIAEhi_Adapter _ehiAdapter = null;

        #endregion

        #region Constructor

        public alt_DerivationPointMgr(SelectedElement selectedEdge, bool isEhiSupport)
        {
            _isEhiSupport = isEhiSupport;
            _selectedEdge = (Edge)selectedEdge.Value;
            _derPointProduct = selectedEdge.LeafProduct as Product;
            _adapter = alt_CATIA_Adapter.GetInstance();
            _ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            _branches = new List<(CATIEhiBranchable, int)>();

            RetrieveProperties();
        }

        #endregion

        #region Properties
        public Product DerPointProduct
        {
            get { return _derPointProduct; }
        }

        public Reference DervivationPoint
        {
            get { return _derPoint; }
        }

        public Reference LinkedBranchCurve
        {
            get { return _branchCurve; }
        }

        public Vector3d TangentDirection
        {
            get { return _tangentDirection; }
        }
        #endregion

        #region Public Methods

        /// <summary>
        /// Add support in selected derivation point
        /// </summary>
        /// <returns></returns>
        public bool ManageDerivationPoint()
        {
            var log = $"--- Start creating derivation point: ";
            alt_Logging_class.AddMessage(log);

            double flagCompute = 0;
            CATIEhiMultiBranchable multiBranchable = (CATIEhiMultiBranchable)_derPointProduct;
            if (null == multiBranchable)
                return false;

            log = $"------ Tangent direction: {_tangentDirection.X}; {_tangentDirection.Y}; {_tangentDirection.Z}";
            alt_Logging_class.AddMessage(log);

            log = $"------ First branch found: {EhiBranchable.GetName(_branches[0].Item1)}";
            alt_Logging_class.AddMessage(log);
            log = $"------ Der point index: {_branches[0].Item2}";
            alt_Logging_class.AddMessage(log);

            log = $"------ Second branch found: {EhiBranchable.GetName(_branches[1].Item1)}";
            alt_Logging_class.AddMessage(log);
            log = $"------ Der point index: {_branches[1].Item2}";
            alt_Logging_class.AddMessage(log);

            try
            {
                DefineTangent(_branches[0].Item1);

                Product geomPrd = (Product)_geomBundle;
                Product insertedSupport = _adapter.InsertEhiPoint(_pointCoords, _tangentDirection, geomPrd, GetPartName());
                if (insertedSupport == null)
                {
                    log = $"------ Support not inserted: {insertedSupport.get_PartNumber()}";
                    alt_Logging_class.AddMessage(log);
                    return false;
                }

                log = $"------ Support inserted: {insertedSupport.get_PartNumber()}";
                alt_Logging_class.AddMessage(log);

                if (_isEhiSupport)
                {
                    HybridShapeSpline splineBr = EhiBranchable.GetElecCurve(_branches[0].Item1);
                    EhiBranchable.ReplaceBySupport(_branches[0].Item1, _branches[0].Item2, insertedSupport);
                    _geomBundle.ComputeMultiBranchable(multiBranchable, out flagCompute);
                    _derPoint = splineBr.GetPoint(splineBr.GetNbControlPoint());
                    if (_derPoint == null)
                    {
                        log = $"------ Support wrongly added to route: {insertedSupport.get_PartNumber()}";
                        alt_Logging_class.AddMessage(log);
                        return false;
                    }

                    log = $"------ Support correctly added to route: {insertedSupport.get_PartNumber()}";
                    alt_Logging_class.AddMessage(log);

                    //Add projected point to second branch
                    EhiBranchable.ReplaceByPoint(_branches[1].Item1, _derPoint, _branches[1].Item2);
                    _geomBundle.ComputeMultiBranchable(multiBranchable, out flagCompute);
                }
                else
                {
                    Publication pointPub = CatiaProductExtensions.GetPublication(insertedSupport, "Point.1");
                    Reference refPoint = pointPub.Valuation as Reference;
                    _derPoint = EhiMultiBranchable.CreateExtrenalReference(multiBranchable, refPoint);
                    EhiBranchable.ReplaceByPoint(_branches[0].Item1, _derPoint, _branches[0].Item2);
                    _geomBundle.ComputeMultiBranchable(multiBranchable, out flagCompute);

                    EhiBranchable.ReplaceByPoint(_branches[1].Item1, _derPoint, _branches[1].Item2);
                    _geomBundle.ComputeMultiBranchable(multiBranchable, out flagCompute);
                }

                _branchCurve = EhiBranchable.GetElecCurve(_branches[0].Item1) as Reference;
                log = $"--- End creating derivation point: ";
                alt_Logging_class.AddMessage(log);
                alt_Logging_class.AddMessage("");
            }
            catch (Exception ex)
            {
                string Msg = ex.Message;
                return false;
            }

            return true;
        }

        /// <summary>
        /// Check if selected derivation is linked to branchables
        /// </summary>
        /// <returns></returns>
        public bool CheckLinckedBranches()
        {
            bool isFound = false;
            CATIEhiMultiBranchable multiBranchable = (CATIEhiMultiBranchable)_derPointProduct;
            if (null == multiBranchable)
                return false;

            GetLinkedBranchesInOrder(multiBranchable);
            if (_branches != null && _branches.Count > 1)
                isFound = true;

            return isFound;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Get branches linked to derivation point
        /// </summary>
        /// <param name="multiBranchable"></param>
        /// <returns></returns>
        private void GetLinkedBranchesInOrder(CATIEhiMultiBranchable multiBranchable)
        {
            _branches.Clear();
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            foreach (CATIEhiBranchable branch in EhiMultiBranchable.GetBranchables(multiBranchable))
            {
                if (branch == null)
                    continue;

                string name = EhiBranchable.GetName(branch);

                HybridShapeSpline spline = EhiBranchable.GetElecCurve(branch);
                try
                {
                    Reference firstPoint = spline.GetPoint(1);
                    Vector3d firstLocalCoords = adapter.GetPointFromReference(firstPoint);
                    Vector3d firstGlobalCoords = adapter.TransformToGlobalCoordinates(firstLocalCoords, _derPointProduct);
                    if (adapter.ComparePointByCoords(firstGlobalCoords, _pointCoords))
                        _branches.Add((branch, 1));
                    else
                    {
                        Reference lastPoint = spline.GetPoint(spline.GetNbControlPoint());
                        Vector3d lastLocalCoords = adapter.GetPointFromReference(lastPoint);
                        Vector3d lastGlobalCoords = adapter.TransformToGlobalCoordinates(lastLocalCoords, _derPointProduct);
                        if (adapter.ComparePointByCoords(lastGlobalCoords, _pointCoords))
                            _branches.Add((branch, spline.GetNbControlPoint()));
                    }
                }
                catch { continue; }
                
            }

            //return branches in good order
            if (_branches != null && _branches.Count > 1)
            {
                if (_branches[0].Item2 == 1)
                {
                    var temp = _branches[0];
                    _branches[0] = _branches[1];
                    _branches[1] = temp;
                }
            }
        }

        /// <summary>
        /// Define branch order to insert support
        /// </summary>
        /// <param name="branches"></param>
        /// <param name="support"></param>
        private void DefineTangent(CATIEhiBranchable branch)
        {
            try 
            {
                HybridShapeSpline spline = EhiBranchable.GetElecCurve(branch);
                Vector3d firstExtremity = _adapter.GetPointFromReference(spline.GetPoint(1));
                Vector3d secondExtremity = _adapter.GetPointFromReference(spline.GetPoint(spline.GetNbControlPoint()));
                Vector3d tangentPoint = secondExtremity + _tangentDirection;
                Vector3d line = secondExtremity - firstExtremity;
                Vector3d P1P = tangentPoint - firstExtremity;
                double t = Vector3d.Dot(P1P, line) / Vector3d.Dot(line, line);
                if (t < 1)
                    _tangentDirection = -_tangentDirection;
            }
            catch { }
        }

        /// <summary>
        /// Get support name
        /// </summary>
        /// <returns></returns>
        private string GetPartName()
        {
            if(_isEhiSupport)
                return "FICTIVE SUPPORT FOR CABLE TRAY - TYPE 2.CATPart";
            else
                return "FICTIVE POINT TYPE 2.CATPart";
        }

        /// <summary>
        /// Retrieve derivation properties
        /// </summary>
        private void RetrieveProperties()
        {
            try
            {
                Product geomPrd = (Product)_derPointProduct.Parent;
                geomPrd.ApplyWorkMode(CatWorkModeType.DESIGN_MODE);
                _geomBundle = (CATIEhiGeoBundle)geomPrd;

                Vector3d localCoords = _adapter.GetCenterFromReference(_selectedEdge);
                Vector3d globalCoords = _adapter.TransformToGlobalCoordinates(localCoords, _derPointProduct);
                _pointCoords = _adapter.Round(globalCoords, 3);

                IList<Vector3d> edgePoints = _adapter.GetPointsOnCurve(_selectedEdge).Distinct().ToList();
                Vector3d firstPoint = _adapter.TransformToGlobalCoordinates(edgePoints[0], _derPointProduct);
                Vector3d secondPoint = _adapter.TransformToGlobalCoordinates(edgePoints[1], _derPointProduct);

                Vector3d normal = _adapter.GetPlaneDirectionFromPoints(_pointCoords, firstPoint, secondPoint);
                _tangentDirection = _adapter.Round(normal, 3);
            }
            catch { }
        }
        #endregion

    }
}
