﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using ALT_Logging;
using CatiaDotNet.CommonExtensions;
using CatiaDotNet.CommonServices;
using HybridShapeTypeLib;
using INFITF;
using KnowledgewareTypeLib;
using MECMOD;
using Newtonsoft.Json;
using OpenTK;
using ProductStructureTypeLib;
using SPATypeLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Media.Media3D;

namespace Infrastructure_Layer.ALT_CATIA_Adapter
{
    public class alt_CATIA_Adapter
    {
        #region Fields

        private Application _catiaApp;
        private Selection _selection;
        private Window _activeWindow;
        private ProductDocument _rootDocument;
        private Product _rootProduct;
        private SPAWorkbench _spaworkbench;

        private static alt_CATIA_Adapter _instance;

        #endregion

        #region Properties
        public Application Catia_App
        {
            get { return _catiaApp; }
            set { _catiaApp = value; }
        }
        public ProductDocument RootDocument
        {
            get { return _rootDocument; }
            set { _rootDocument = value; }
        }
        public Product RootProduct
        {
            get { return _rootProduct; }
            set { _rootProduct = value; }
        }
        public Window ActiveEditor
        {
            get { return _activeWindow; }
            set { _activeWindow = value; }
        }
        public Selection Selection
        {
            get { return _selection; }
            set { _selection = value; }
        }
        public SPAWorkbench Spaworkbench
        {
            get { return _spaworkbench; }
            set { _spaworkbench = value; }
        }

        public Viewer3D GetCurrentViewer()
        {
            Viewer3D currentViewer = null;
            if (_catiaApp != null)
                currentViewer = _catiaApp.ActiveWindow.ActiveViewer as Viewer3D;
            return currentViewer;
        }

        #endregion

        #region Constructor
        private alt_CATIA_Adapter()
        {
            Initialize();
        }

        #endregion

        #region Public Methods
        public static alt_CATIA_Adapter GetInstance()
        {
            if (_instance == null)
                _instance = new alt_CATIA_Adapter();

            return _instance;
        }

        /// <summary>
        /// ResetInstance.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public static void ResetInstance()
        {
            _instance = null;
        }

        /// <summary>
        /// InitCheck.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public int InitCheck()
        {
            if (_catiaApp == null)
                return 1;
            else if (_activeWindow == null)
                return 2;
            else if (_rootDocument == null)
                return 3;
            else if (_rootProduct == null)
                return 4;
            else
                return 0;
        }

        /// <summary>
        /// ExtractConnectors.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public IList<Product> ExtractConnectors(string filteredName)
        {
            //IList<Product> Connectors = new List<Product>();
            //ProductDocument rootDoc = (ProductDocument)_catiaApp.ActiveDocument;
            //Product rootProduct = rootDoc.Product;
            //if (rootProduct == null)
            //    return Connectors;
            //Selection selection = rootDoc.Selection;
            //selection.Clear();
            //selection.Search("Electrical.'Single Insert Connector',all");
            //if (_selection.Count > 0)
            //{
            //    for (int i = 1; i <= selection.Count; i++)
            //    {
            //        Product product = selection.Item(i).Value as Product;
            //        Connectors.Add(product);
            //    }
            //}
            //selection.Clear();

            IList<Product> Connectors = new List<Product>();
            Product product = TraverseProductRecursive(_rootProduct, filteredName);
            IList<Product> children = CatiaProductExtensions.GetProductDescendantChildren((Product)product.Parent);
            foreach (Product child in children)
            {
                    try
                    {
                        if (CheckPublications(child, "BundleCnctPt1") || CheckPublications(child, "BundleCnctPt2"))
                        {
                            Connectors.Add(child);
                        }
                    }
                    catch { continue; }
            }
            return Connectors;
        }

        /// <summary>
        /// Extract dummu supports from parent product
        /// </summary>
        /// <param name="filteredName"></param>
        /// <returns></returns>
        public IList<Product> ExtractDummySupports(Product parentProduct)
        {
            IList<Product> dummySupports = new List<Product>();

            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            foreach (Product child in parentProduct.Products)
            {
                if (child == null)
                    continue;

                if (ehiAdapter.IsSupport(child) && child.get_PartNumber().ToUpper().Contains("DUMMY"))
                    dummySupports.Add(child);
            }
            return dummySupports;
        }

        public void StartCommandGHExtraction()
        {
            _catiaApp.StartCommand("IGEGHExport"); /// working
            
        }


        /// <summary>
        /// SetDisplayFileAlerts.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void SetDisplayFileAlerts(bool setFileAlerts)
        {
            _catiaApp.DisplayFileAlerts = setFileAlerts;
        }

        /// <summary>
        /// ApplyDesignMode.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string ApplyDesignMode(string productName)
        {
            try
            {
                if (_rootProduct != null && productName != null)
                {
                    Product product = TraverseProductRecursive(_rootProduct, productName);
                    Product parent = product?.Parent as Product;
                    if (parent == null) parent = product;
                    ApplyDesignModeProduct(parent);
                    _rootProduct.Update();
                    return "Applied";
                }
            }
            catch 
            {  }
            return "Could not apply Design Mode";
        }

        /// <summary>
        /// Check if design mode is activated in input proudct
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool IsDesignModeApplied(Product product = null)
        {
            double flag = 0;
            if(product == null)
                product = _rootProduct;

            CATIProduct catiProduct = product as CATIProduct;
            catiProduct.GetWorkMode(product, out flag);
            if (flag == 2)
                return true;

            return false;
        }

        /// <summary>
        /// AddDescriptionToConnectors.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void AddDescriptionToConnectors( string description, Product connector)
        {
            connector.set_DescriptionInst(description);
        }

        /// <summary>
        /// ApplyDesignModeProduct.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private static void ApplyDesignModeProduct(Product product)
        {
            product.ApplyWorkMode(CatWorkModeType.DESIGN_MODE);
        }

        /// <summary>
        /// CheckPublications.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public bool CheckPublications(Product product, string checkString)
        {
            if (CatiaProductExtensions.GetPublication(product, checkString) != null)
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Update formula value
        /// </summary>
        /// <param name="protection"></param>
        /// <param name="rootProduct"></param>
        public void UpdateProtectionFromula(CATIEhiProtection protection, Product mbbns, List<string> supports)
        {
            if (protection == null)
                return;

            var log = $"--- Start updating protection";
            alt_Logging_class.AddMessage(log);

            string formula = GetFromulaValue(protection, mbbns.get_PartNumber());
            log = $"------ Formula value: {formula}";
            alt_Logging_class.AddMessage(log);
            if (string.IsNullOrEmpty(formula))
                return;

            if(supports == null || supports.Count == 0)
                log = $"------ Supports list in route branch is empty! No formula update";

            try
            {
                Product rootProduct = (Product)mbbns.Parent;
                foreach (string supportName in supports)
                {
                    List<Relation> relations = GetRelationsByName(rootProduct, supportName);
                    if (relations == null || relations.Count == 0)
                    {
                        log = $"------ Missing relation for support: {supportName} ";
                        alt_Logging_class.AddMessage(log);
                    }
                    else
                    {
                        foreach (Relation relation in relations)
                        {
                            log = $"------ Relation found for support: {supportName} ";
                            alt_Logging_class.AddMessage(log);
                            log = $"------ Relation name: {relation.get_Name()} ";
                            alt_Logging_class.AddMessage(log);
                            relation.Modify(formula);
                            log = $"------ Relation formula Updated.";
                            alt_Logging_class.AddMessage(log);
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                string msg = exception.Message;
            }

            log = $"--- End updating protection";
            alt_Logging_class.AddMessage(log);
            alt_Logging_class.AddMessage("");
        }

        /// <summary>
        /// Get relation by name
        /// </summary>
        /// <param name="product"></param>
        /// <param name="relationName"></param>
        /// <returns></returns>
        public List<Relation> GetRelationsByName(Product product, string relationName)
        {
            List<Relation> relationsList = new List<Relation>();
            Relations relations = product.Relations;
            if(relations == null || relations.Count == 0)
                return null;

            for (int nCount = 1; nCount <= relations.Count; nCount++)
            {
                Relation relation = relations.Item(nCount);
                if (relation == null)
                    continue;

                if (relation.get_Name().Contains(relationName))
                    relationsList.Add(relation);
            }

            return relationsList;
        }

        /// <summary>
        /// Get formula value
        /// </summary>
        /// <param name="protection"></param>
        /// <returns></returns>
        public string GetFromulaValue(CATIEhiProtection protection, string partNumber)
        {
            string formula = string.Empty;
            try
            {
                HybridBody protBody = (HybridBody)protection.Parent;
                string protName = protBody.get_Name();

                HybridBody geomBody = (HybridBody)protBody.Parent;
                string geomSet = geomBody.get_Name();

                formula = $"`{partNumber}\\{geomSet}\\{protName}\\Inner diameter`*0.5 + `{partNumber}\\{geomSet}\\{protName}\\Thickness`";
            }
            catch (Exception exception)
            {
                string msg = exception.Message;
            }

            return formula;
        }

        /// <summary>
        /// TraverseProductRecursive.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product TraverseProductRecursive(Product product, string productName)
        {
            if (product.get_Name().ToUpper().Contains(productName.ToUpper()))
            {
                return product;
            }

            Products subProducts = product.Products;

            if (subProducts != null && subProducts.Count > 0)
            {
                foreach (Product subProduct in subProducts)
                {
                    Product retProduct = TraverseProductRecursive(subProduct, productName);
                    if (retProduct != null)
                    {
                        return retProduct;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// TraverseProductRecursiveDescription.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product TraverseProductRecursiveDescription(Product product, string description)
        {
            if (product.get_DescriptionRef().ToUpper().Contains(description.ToUpper()))
            {
                return product;
            }

            Products subProducts = product.Products;

            if (subProducts != null && subProducts.Count > 0)
            {
                foreach (Product subProduct in subProducts)
                {
                    Product retProduct = TraverseProductRecursiveDescription(subProduct, description);
                    if (retProduct != null)
                    {
                        return retProduct;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// TraverseProductRecursiveExactMatch.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product TraverseProductRecursiveExactMatch(Product product, string productName)
        {
            if (product.get_Name().ToUpper() == productName.ToUpper())
            {
                return product;
            }

            Products subProducts = product.Products;

            if (subProducts != null && subProducts.Count > 0)
            {
                foreach (Product subProduct in subProducts)
                {
                    Product retProduct = TraverseProductRecursiveExactMatch(subProduct, productName);
                    if (retProduct != null)
                    {
                        return retProduct;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// TraverseProductRecursiveMatchDescription.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product TraverseProductRecursiveMatchDescription(Product product, string productName)
        {
            if (product.get_DescriptionRef().ToUpper().Contains(productName.ToUpper()))
            {
                string a = product.get_DescriptionInst();
                string b = product.get_DescriptionRef();
                return product;
            }
            

            Products subProducts = product.Products;

            if (subProducts != null && subProducts.Count > 0)
            {
                foreach (Product subProduct in subProducts)
                {
                    Product retProduct = TraverseProductRecursiveMatchDescription(subProduct, productName);
                    if (retProduct != null)
                    {
                        return retProduct;
                    }
                }
            }

            return null;
        }

        /// <summary>
        /// ConvertMatrixToArray.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public object[] ConvertMatrixToArray(Matrix4d matrix)
        {
            object[] Abs_Position = new object[12];

            Abs_Position[0] = matrix.M11;
            Abs_Position[1] = matrix.M21;
            Abs_Position[2] = matrix.M31;
            Abs_Position[3] = matrix.M12;
            Abs_Position[4] = matrix.M22;
            Abs_Position[5] = matrix.M32;
            Abs_Position[6] = matrix.M13;
            Abs_Position[7] = matrix.M23;
            Abs_Position[8] = matrix.M33;
            Abs_Position[9] = matrix.M14;
            Abs_Position[10] = matrix.M24;
            Abs_Position[11] = matrix.M34;

            return Abs_Position;
        }

        /// <summary>
        /// ConvertMatrixToArray.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Matrix4d ConvertArrayToMatrix(object[] Abs_Position)
        {
            Matrix4d matrix = new Matrix4d();

            matrix.M11 = (double)Abs_Position[0];
            matrix.M21 = (double)Abs_Position[1];
            matrix.M31 = (double)Abs_Position[2];
            matrix.M12 = (double)Abs_Position[3];
            matrix.M22 = (double)Abs_Position[4];
            matrix.M32 = (double)Abs_Position[5];
            matrix.M13 = (double)Abs_Position[6];
            matrix.M23 = (double)Abs_Position[7];
            matrix.M33 = (double)Abs_Position[8];
            matrix.M14 = (double)Abs_Position[9];
            matrix.M24 = (double)Abs_Position[10];
            matrix.M34 = (double)Abs_Position[11];

            return matrix;
        }

        /// <summary>
        /// Apply new position for the input product
        /// </summary>
        /// <param name="position"></param>
        /// <param name="product"></param>
        /// <param name="parentProduct"></param>
        public void ApplyPositionTransorm(Vector3d position, Product product, Product parentProduct)
        {
            if (product != null && parentProduct != null)
            {
                object[] Abs_Position = new object[12];
                Abs_Position = ConvertMatrixToArray(CatiaProductExtensions.GetGlobalMatrix4d(product));

                // Set new position
                Abs_Position[9] = position.X;
                Abs_Position[10] = position.Y;
                Abs_Position[11] = position.Z;

                //Apply transform
                product.Position.SetComponents(Abs_Position);
                parentProduct.Update();
            }
        }

        /// <summary>
        /// ReframeOn.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void ReframeOn(CATBaseDispatch iObject)
        {
            if (iObject == null)
                return;

            _selection.Clear();
            _selection.Add(iObject as AnyObject);
            _catiaApp.StartCommand("Reframe On");
        }

        /// <summary>
        /// SelectElementsInCatia.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product SelectElementsInCatia(string displayMessage)
        {
            Selection.Clear();
            object[] SelFilfer = new object[1] { "Product" };
            string Status = Selection.SelectElement2(SelFilfer, displayMessage , false);
            if (Status != "Normal")
                return null;

            if(Selection.Count > 0)
            {
                Product selectedItem = (Product)_selection.Item(1).Value;
                return selectedItem;
            }

            Selection.Clear();
            return null;
        }

        /// <summary>
        /// Allow multiselection in catia
        /// </summary>
        /// <param name="displayMessage"></param>
        /// <returns></returns>
        public Product[] MultiSelectElementsInCatia(string displayMessage, object[] SelFilfer)
        {
            Selection.Clear();
            string Status = Selection.SelectElement3(SelFilfer, displayMessage, true, CATMultiSelectionMode.CATMultiSelTriggWhenUserValidatesSelection, true);
            if (Status != "Normal")
                return null;

            if (Selection.Count > 0)
            {
                List<Product> selectedItems = new List<Product>();
                for (int count = 1; count <= Selection.Count; count++)
                {
                    Product selectedItem = (Product)Selection.Item(count).Value;
                    if (selectedItem != null)
                        selectedItems.Add(selectedItem);
                }

                return selectedItems.ToArray();
            }

            Selection.Clear();
            return null;
        }

        /// <summary>
        /// Selection of Face or Edge in CATIA for Force way Point
        /// </summary>
        /// <param name="displayMessage"></param>
        /// <param name="elements"></param>
        /// <param name="clickedPoint"></param>
        /// <returns></returns>
        public SelectedElement SelectHybridshapeInCatia(string displayMessage, object[] elements, ref object[] clickedPoint)
        {
            Selection.Clear();
            string Status = Selection.SelectElement2(elements, displayMessage, false);
            if (Status != "Normal")
                return null;

            if (Selection.Count > 0)
            {
                SelectedElement selectedItem = _selection.Item(1);

                if(selectedItem.Type == "Edge" || selectedItem.Type == "Face")
                    Selection.Item2(1).GetCoordinates(clickedPoint);

                return selectedItem;
            }
            Selection.Clear();
            return null;
        }

        /// <summary>
        /// Select Extremity In Catia
        /// </summary>
        /// <param name="displayMessage"></param>
        /// <returns></returns>
        public SelectedElement SelectExtremityInCatia(string displayMessage)
        {
            Selection.Clear();            
            object[] SelFilfer = new object[4] { "Edge", "Point", "HybridShapeProject", "Product" };
            string Status = Selection.SelectElement2(SelFilfer, displayMessage, false);
            if (Status != "Normal")
                return null;

            if (Selection.Count > 0)
            {
                SelectedElement selectedItem = _selection.Item(1);
                return selectedItem;
            }
            Selection.Clear();
            return null;
        }

        /// <summary>
        /// Create Reference of Product From Name
        /// </summary>
        /// <param name="product_gnd"></param>
        /// <param name="objectPath"></param>
        /// <returns></returns>
        public Reference GetAssemblyReference(Product product_gnd, string objectPath)
        {
            Selection.Clear();
            Product rootProduct = _rootProduct;
            string leafName = GetProductLeafName(Selection, product_gnd);
            string prodRelativePath = leafName + objectPath;

            Reference refToObjectInAssemblyContext = null;
            try
            {
                refToObjectInAssemblyContext = rootProduct.CreateReferenceFromName(prodRelativePath);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
            return refToObjectInAssemblyContext;
        }

        /// <summary>
        /// Get LeafProduct Name
        /// </summary>
        /// <param name="sel"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        private static string GetProductLeafName(Selection sel, Product product)
        {
            if (product is null) return "";

            sel.Clear();
            sel.Add(product);
            string leafName = sel.Item(1).Reference.DisplayName;
            if (leafName.EndsWith("/"))
                leafName = leafName.Substring(0, leafName.Length - 1);
            return leafName;
        }

        /// <summary>
        /// CentreGraph.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void CentreGraph(CATBaseDispatch iObject)
        {
            if (iObject == null)
                return;

            _selection.Clear();
            _selection.Add(iObject as AnyObject);
            _catiaApp.StartCommand("CATCafCenterGraphHdr");
        }

        /// <summary>
        /// CentreGraph.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public double DistanceBtwVector3d(Vector3d v1, Vector3d v2)
        {
            double dx = v1.X - v2.X;
            double dy = v1.Y - v2.Y;
            double dz = v1.Z - v2.Z;
            return Math.Sqrt(dx * dx + dy * dy + dz * dz);
        }

        /// <summary>
        ///Check whether the vectors are pointing in the same direction.
        /// </summary>
        /// <param name="vectorA"></param>
        /// <param name="vectorB"></param>
        /// <returns></returns>
        public bool AreVectorCollinear(Vector3d vectorA, Vector3d vectorB)
        {
            // Calculate the cross product
            Vector3d crossProduct = Vector3d.Cross(vectorA, vectorB);

            // Check if the cross product is zero
            return crossProduct.LengthSquared == 0;
        }

        /// <summary>
        /// InsertProduct.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product InsertProduct(string referenceName, string harnessName, string dtrPartNumber, ref object[] AbsPosition)
        {
            Product insertedProduct = null;
            try
            {
                Product mbbnsProduct = TraverseProductRecursive(_rootProduct, harnessName);
                if (mbbnsProduct != null)
                {
                    Product gbnParent = (Product)mbbnsProduct.Parent;
                    string gbnName = gbnParent.get_Name();
                    insertedProduct = InsertReferencebyCopyPaste(referenceName, gbnParent, dtrPartNumber, ref AbsPosition);
                    if (insertedProduct != null) SetProductInstanceName(referenceName, insertedProduct);
                }
            }
            catch
            {
                return null;
            } 
            return insertedProduct;
        }

        /// <summary>
        /// deletePrioduct in the loaded harness
        /// </summary>
        public void DeleteProduct(string connectorName)
        {
            Product Connector = TraverseProductRecursiveExactMatch(this.RootProduct, connectorName);
            Selection.Add(Connector);
            Selection.Delete();
            this.RootProduct.Update();
        }

        /// <summary>
        /// ReplaceProduct.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string ReplaceProduct(string connectorName, string dtr, string filter, string harnessName, object[] absPosition)
        {
            Selection selectionFromSearchProd = this.RootDocument.Selection;
            Product Connector = TraverseProductRecursiveExactMatch(this.RootProduct, connectorName);
            string defination = Connector.get_Definition();
            string rivision = Connector.get_Revision();
            string description = Connector.get_DescriptionRef();
            double status = 100;
            string returnString = string.Empty;
            try
            {
                Product mbbnsProduct = TraverseProductRecursive(_rootProduct, harnessName);
                if (mbbnsProduct != null)
                {
                    Product gbnParent = (Product)mbbnsProduct.Parent;
                    string gbnName = gbnParent.get_Name();
                    ACNEHIWrapper.CATIEhiGeoBundle DTR = gbnParent as ACNEHIWrapper.CATIEhiGeoBundle;
                    try
                    {
                        try { 
                            DTR.GetPartsFromDMA(dtr, filter, out status); 
                        } // 1 is for success , 999 is for failure :: default failure when part not found in dma
                        catch { return 404.ToString() + "_" + dtr + "_Failure"; }
                        returnString = status.ToString() + "_" + dtr;
                        if (status == 1) {
                            Product addedProduct = this.RootProduct.Products.Item(this.RootProduct.Products.Count);
                            selectionFromSearchProd.Clear();
                            selectionFromSearchProd.Add(addedProduct);
                            selectionFromSearchProd.Cut();
                            selectionFromSearchProd.Clear();
                            Selection.Clear();
                            Selection.Add(gbnParent);
                            Selection.Paste();
                            Selection.Clear();
                            Selection.Add(Connector);
                            Selection.Delete();
                            this.RootProduct.Update();
                            Product ConnectorProduct = gbnParent.Products.Item(gbnParent.Products.Count);
                            try
                            {
                                ConnectorProduct.set_Name(connectorName);
                                Product ProductParentPrd = (Product)ConnectorProduct.Parent;
                                ((Product)ProductParentPrd.ReferenceProduct.Products.GetItem(ConnectorProduct.get_Name())).set_Name(connectorName);
                                ConnectorProduct.set_PartNumber(dtr.Split(':')[0]); /// add dtr part number to connector
                                CheckDTR(connectorName); // log dtr for verification
                                ConnectorProduct.Update();
                            }
                            catch
                            {
                                Console.WriteLine("Set Part name for Multi-branchable returns with error: " + connectorName);
                            }
                            ConnectorProduct.set_DescriptionRef(description);
                            ConnectorProduct.set_Revision(rivision);
                            ConnectorProduct.Position.SetComponents(absPosition);
                            this.RootProduct.Update();
                            returnString = returnString + "_Success";
                        }
                        else {
                            return returnString + "_Failure"; 
                        }
                    }
                    catch (Exception ex)
                    {
                        returnString = dtr;
                        return returnString;
                    }
                }
            }
            catch
            {
                returnString = dtr;
                return returnString;
            }
            return returnString;
        }

        /// <summary>
        /// Get Connector By Name
        /// </summary>
        /// <param name="name"></param>
        public void CheckDTR(string name)
        {
            Product Connector = TraverseProductRecursiveExactMatch(this.RootProduct, name);
            ALT_Logging.alt_Logging_class.AddMessage("DTR for " + name + " is: " + Connector.get_PartNumber());
        }

        /// <summary>
        /// Set Name for Connector
        /// </summary>
        /// <param name="prodName"></param>
        /// <param name="dtr"></param>
        public void ChangeNameWithDTR(string prodName, string dtr)
        {
            Product Connector = TraverseProductRecursiveExactMatch(this.RootProduct, prodName);
            Connector.set_PartNumber(dtr);
            Connector.Update();
        }

        /// <summary>
        /// AddProductFromDMA.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string AddProductFromDMA(string connectorName, string dtr, string filter, string harnessName, object[] absPosition, ref Product addedProd)
        {
            Selection selectionFromSearchProd = this.RootDocument.Selection;
            double status = 100;
            string returnString = string.Empty;
            try
            {
                Product mbbnsProduct = TraverseProductRecursive(_rootProduct, harnessName);
                if (mbbnsProduct != null)
                {
                    Product gbnParent = (Product)mbbnsProduct.Parent;
                    string gbnName = gbnParent.get_Name();
                    ACNEHIWrapper.CATIEhiGeoBundle DTR = gbnParent as ACNEHIWrapper.CATIEhiGeoBundle;
                    try
                    {
                        try { 
                            DTR.GetPartsFromDMA(dtr, filter, out status); 
                        } // 1 is for success , 999 is for failure :: default failure when part not found in dma
                        catch { return 404.ToString() + "_" + dtr + "_Failure"; }
                        returnString = status.ToString() + "_" + dtr;
                        if (status == 1)
                        {
                            Product addedProduct = this.RootProduct.Products.Item(this.RootProduct.Products.Count);
                            selectionFromSearchProd.Clear();
                            selectionFromSearchProd.Add(addedProduct);
                            selectionFromSearchProd.Cut();
                            selectionFromSearchProd.Clear();
                            Selection.Clear();
                            Selection.Add(gbnParent);
                            Selection.Paste();
                            this.RootProduct.Update();
                            Product ConnectorProduct = gbnParent.Products.Item(gbnParent.Products.Count);
                            try
                            {
                                ConnectorProduct.set_Name(connectorName);
                                Product ProductParentPrd = (Product)ConnectorProduct.Parent;
                                ((Product)ProductParentPrd.ReferenceProduct.Products.GetItem(ConnectorProduct.get_Name())).set_Name(connectorName);
                                ConnectorProduct.Update();
                            }
                            catch
                            {
                                Console.WriteLine("Set Part name for Multi-branchable returns with error: " + connectorName);
                            }
                            ConnectorProduct.Position.SetComponents(absPosition);
                            this.RootProduct.Update();
                            addedProd = gbnParent.Products.Item(gbnParent.Products.Count);
                            returnString = returnString + "_Success";
                        }
                        else
                        {
                            return returnString + "_Failure";
                        }
                    }
                    catch (Exception ex)
                    {
                        returnString = dtr;
                        return returnString;
                    }
                }
            }
            catch
            {
                returnString = dtr;
                return returnString;
            }
            return returnString;
        }

        /// <summary>
        /// AddProductFromDMA.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string AddFromDMAForAccesssorization(string dtr, string filter, string harnessName, object[] absPosition)
        {
            Selection selectionFromSearchProd = this.RootDocument.Selection;
            double status = 100;
            Product mbbnsProduct = TraverseProductRecursive(_rootProduct, harnessName);
            string returnString = string.Empty;
            if (mbbnsProduct != null)
            {
                Product gbnParent = (Product)mbbnsProduct.Parent;
                string gbnName = gbnParent.get_Name();
                ACNEHIWrapper.CATIEhiGeoBundle DTR = gbnParent as ACNEHIWrapper.CATIEhiGeoBundle;
                try
                {
                    // 1 is for success , 999 is for failure :: default failure when part not found in dma
                    DTR.GetPartsFromDMA(dtr, filter, out status);
                } 
                catch { return 404.ToString() + "_" + dtr + "_Failure"; }
                if (status == 1)
                {
                    Product addedProduct = this.RootProduct.Products.Item(this.RootProduct.Products.Count);
                    selectionFromSearchProd.Clear();
                    selectionFromSearchProd.Add(addedProduct);
                    selectionFromSearchProd.Cut();
                    selectionFromSearchProd.Clear();
                    Selection.Clear();
                    Selection.Add(gbnParent);
                    Selection.Paste();
                    this.RootProduct.Update();
                    Product addedAccessory= gbnParent.Products.Item(gbnParent.Products.Count);
                    addedAccessory.Position.SetComponents(absPosition);
                    this.RootProduct.Update();
                    returnString = returnString + "_Success";
                }
                else
                {
                    return returnString + "_Failure";
                }
            }

            return returnString;
        }

        /// <summary>
        /// GetWindowByName.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        static Window GetWindowByName(string windowName)
        {
            Window window = null;
            alt_CATIA_Adapter adapter = GetInstance();
            foreach (Window currentWin in adapter.Catia_App.Windows)
            {
                ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                Product rootProduct = rootDoc.Product;
                string name = rootProduct.get_Name();

                string nameWind = currentWin.get_Name();
                if (nameWind.ToUpper().Contains(windowName.ToUpper()))
                {
                    window = currentWin;
                    break;
                }
            }
            return window;
        }

        /// <summary>
        /// GetWindowByProductDescription.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Window GetWindowByProductDescription(string descriptionKey)
        {
            Window productWindow = null;
            foreach (Window currentWin in _catiaApp.Windows)
            {
                ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                Product rootProduct = rootDoc.Product;
                Product descriptionFoundProduct = TraverseProductRecursiveDescription(rootProduct, descriptionKey);
                //if (rootProduct == null)
                //    continue;
                //string description = rootProduct.get_DescriptionRef();
                if (descriptionFoundProduct == null)
                    continue;
                string description = descriptionFoundProduct.get_DescriptionRef();
                if (description.Contains(descriptionKey.ToUpper()))
                {
                    productWindow = currentWin;
                    break;
                }
            }
            return productWindow;
        }

        /// <summary>
        /// GetWindowByProductDescriptionToExtract.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Window GetWindowByProductDescriptionToExtract(string descriptionKey, ref Product product)
        {
            Window productWindow = null;
            foreach (Window currentWin in _catiaApp.Windows)
            {
                ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                Product rootProduct = TraverseProductRecursiveMatchDescription(rootDoc.Product, descriptionKey);
                if(rootProduct == null)
                    rootProduct = TraverseProductRecursiveMatchDescription(rootDoc.Product, "EQT LOCATION");

                if (rootProduct == null)
                    continue;

                string description = rootProduct.get_DescriptionRef();
                if (description.Contains(descriptionKey.ToUpper()))
                {
                    productWindow = currentWin;
                    product = rootProduct;
                    break;
                }
            }
            return productWindow;
        }

        /// <summary>
        /// IsHarnessProductOpened.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public bool IsHarnessProductOpened(string harnessName)
        {
            bool isOpened = false;
            //Window productWin = GetWindowByProductDescription(harnessName);
            Window productWin = GetWindowBySearchCriteria(harnessName);
            if (productWin != null)
            {
                productWin.Activate();
                isOpened = true;
            }

            return isOpened;
        }

        /// <summary>
        /// GetWindowBySearchCriteria.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Window GetWindowBySearchCriteria(string descriptionKey)
        {
            Window productWindow = null;
            foreach (Window currentWin in _catiaApp.Windows)
            {
                ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                Product rootProduct = rootDoc.Product;
                if (rootProduct == null)
                    continue;

                IList<Product> children = CatiaProductExtensions.GetProductDescendantChildren(rootProduct);
                List<Product> harnessProducts = children.Where(y => y.get_Definition().Contains("HARNESS")).ToList();
                if (harnessProducts.Count > 0)
                {
                    foreach (Product harnessProduct in harnessProducts)
                    {
                        Product parent = (Product)harnessProduct.Parent;
                        string description = parent.get_DescriptionRef();
                        if (description.ToUpper().Contains(descriptionKey.ToUpper()))
                        {
                            productWindow = currentWin;
                            return productWindow;
                        }

                    }
                }

            }
            return productWindow;
        }

        /// <summary>
        /// InsertReferencebyCopyPaste.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product InsertReferencebyCopyPaste(string referenceName, Product parent, string dtrPartNumber, ref object[] AbsPosition)
        {
            //Get Active Window
            Window activeWinddow = Catia_App.ActiveWindow;

            int nbChildrenBeforeInsertion = parent.Products.Count;
            Window winsearched = null;
            Selection selectionFromSearchProd = null;
            object[] absPosition = null;
            Part partToInsert = GetReferenceToInsert(referenceName, ref winsearched, ref selectionFromSearchProd, ref absPosition, dtrPartNumber);
            if (partToInsert != null)
                Console.WriteLine("part searched: " + partToInsert.get_Name());
            else
            {
                AbsPosition = absPosition;
                Console.WriteLine("part searched: " + referenceName + "Not Found");
                return null;
            }

            if (winsearched != null)
            {
                winsearched.Activate();
                selectionFromSearchProd.Add(partToInsert);
                selectionFromSearchProd.Copy();
                selectionFromSearchProd.Clear();

                activeWinddow.Activate();
                Selection.Clear();
                Selection.Add(parent);
                Selection.Paste();
                Selection.Clear();
            }
            else
            {
                Selection.Add(partToInsert);
                Selection.Copy();
                Selection.Clear();
                Selection.Add(parent);
                Selection.Paste();
            }

            //GET PRODUCT Inserted
            int nbChildrenAfterInsertion = parent.Products.Count;
            if (nbChildrenAfterInsertion > nbChildrenBeforeInsertion)
            {
                Product insertedProduct = parent.Products.Item(parent.Products.Count);
                insertedProduct.Position.SetComponents(absPosition);
                return insertedProduct;
            }
            else
            {
                //MessageBox.Show("Issue during insertion process");
                return null;
            }
        }

        /// <summary>
        /// GetReferenceToInsert.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Part GetReferenceToInsert(string referenceName, ref Window window, ref Selection windowSelection, ref object[] AbsPosition, string dtrPartNumber)
        {
            Part part = null;
            window = null;
            windowSelection = null;
            AbsPosition = null;

            try
            {
                window = GetWindowByProductDescription("DEVICE LOCATION");
                if (window == null)
                    window = GetWindowByProductDescription("EQT LOCATION");

                if (window == null)
                    return null;

                ProductDocument eqtLocationDoc = (ProductDocument)window.Parent;
                windowSelection = eqtLocationDoc.Selection;

                Product product = eqtLocationDoc.Product;
                Product ConnectorProduct = TraverseProductRecursiveExactMatch(product, referenceName);
                if(ConnectorProduct == null) return null;
                AbsPosition = ConvertMatrixToArray(CatiaProductExtensions.GetGlobalMatrix4d(ConnectorProduct));
                part = ConnectorProduct.GetPart();
                if (ConnectorProduct.get_PartNumber().Substring(0, 4) != "FICT" && ConnectorProduct.get_PartNumber() != dtrPartNumber)
                {
                    if(dtrPartNumber != "") return null;

                }
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return part;
        }

        /// <summary>
        /// Add Part from catalog
        /// </summary>
        /// <param name="absPosition"></param>
        /// <param name="parentProduct"></param>
        /// <returns></returns>
        public Product AddPartFromCatalog(string partName, ref object[] absPosition, Product parentProduct)
        {
            Product insertedProduct = null;
            try
            {                
                string docFullName = GetPartFullPathByCATIAEnv(partName);
                Document openedDoc = Catia_App.Documents.Open(docFullName);
                insertedProduct = parentProduct.Products.AddExternalComponent(openedDoc);
                insertedProduct.Position.SetComponents(absPosition);
                Catia_App.Documents.Item(openedDoc.get_Name()).Close();
                return insertedProduct;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            return insertedProduct;
        }

        /// <summary>
        /// Get part name from catia env: localTrigram
        /// </summary>
        /// <param name="partName"></param>
        /// <returns></returns>
        public string GetPartFullPathByCATIAEnv(string partName)
        {
            string Trigram = GetEnvVariable("localTrigram");
            string localTrigram = Trigram != string.Empty ? Trigram : "QAL";
            string initialTrigramFolderName = "DMAGS_" + localTrigram;
            string UserProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string CatalogLocation = @"CatiaV5\Catalog\Lib_ELEC_Catalog";
            string docFullName = Path.Combine(UserProfile, initialTrigramFolderName, CatalogLocation, partName);
            return docFullName;
        }

        /// <summary>
        /// SetProductInstanceName.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        void SetProductInstanceName(string name, Product product)
        {
            try
            {
                product.set_Name(name);
                Product ProductParentPrd = (Product)product.Parent;
                ((Product)ProductParentPrd.ReferenceProduct.Products.GetItem(product.get_Name())).set_Name(name);
                product.Update();
            }
            catch
            {
                Console.WriteLine("Set Part name for Connector returns with error: " + name);
            }
        }

        /// <summary>
        /// GetOpenedHarnessListDescription.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public List<string> GetOpenedHarnessListDescription()
        {
            List<string> openedHarnesDescriptions = new List<string>();

            foreach (Window currentWin in _catiaApp.Windows)
            {
                currentWin.Activate();
                ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                Product rootProduct = rootDoc.Product;
                if (rootProduct == null)
                    continue;

                IList<Product> children = CatiaProductExtensions.GetProductDescendantChildren(rootProduct);
                List<Product> harnessProducts = children.Where(y => y.get_Definition().Contains("HARNESS")).ToList();
                
                if(harnessProducts.Count > 0)
                {
                    foreach (Product harnessProduct in harnessProducts)
                    {
                        string description = harnessProduct.get_DescriptionRef();
                        openedHarnesDescriptions.Add(description);
                    }
                }

            }
            return openedHarnesDescriptions;
        }

        /// <summary>
        /// GetOpenedMultiBranchableList.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public List<string> GetOpenedMultiBranchableList()
        {
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            List<string> multiBranchableList = new List<string>();
            foreach (Window currentWin in _catiaApp.Windows)
            {
                ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                Product rootProduct = rootDoc.Product;
                if (rootProduct == null)
                    continue;

                Product geomRootProduct = GetRootNRDGeomBundleProduct(rootProduct);
                if(geomRootProduct != null)
                {
                    foreach(Product product in geomRootProduct.Products)
                    {
                        if (product == null)
                            continue;

                        if(ehiAdapter.IsMultiBranchable(product))
                        {
                            multiBranchableList.Add(product.get_Name());
                            break;
                        }
                    }
                }                
            }

            return multiBranchableList;
        }

        /// <summary>
        /// Get multibranchable from geometrical bundle
        /// </summary>
        /// <param name="gbnProduct"></param>
        /// <returns></returns>
        public Product GetMultiBranchableFromGBN(Product gbnProduct)
        {
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            foreach (Product child in gbnProduct.Products)
            {
                if (child == null)
                    continue;

                if (ehiAdapter.IsMultiBranchable(child))
                    return child;

            }

            return null;
        }

        /// <summary>
        /// IsActiveProduct.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public bool IsActiveProduct(Product iPrd)
        {
            
            return null != iPrd.GetPart();
        }

        /// <summary>
        /// GetGlobalMatrix4d.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Matrix4d GetGlobalMatrix4d(Product iPrd)
        {
            return CatiaProductExtensions.GetGlobalMatrix4d(iPrd);
        }

        /// <summary>
        /// GetGlobalMatrix4d.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Product GetProductInWindow(string descriptionKey, string connectorName)
        {
            Product foundPart = null;
            alt_CATIA_Adapter adapter = GetInstance();
            foreach (Window currentWin in adapter.Catia_App.Windows)
            {
                try
                {
                    ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                    Product traverseToFindDescription = TraverseProductRecursiveDescription(rootDoc.Product, descriptionKey);
                    string description = traverseToFindDescription.get_DescriptionRef();
                    if (description.Contains(descriptionKey.ToUpper()))
                    {
                        foundPart = TraverseProductRecursiveExactMatch(rootDoc.Product, connectorName);
                        return foundPart;
                    }
                    
                }
                catch { continue; }

            }
            return null;
        }

        /// <summary>
        /// ConvertToMatrix3D.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Matrix3D ConvertToMatrix3D(Matrix4d openTkMatrix)
        {
            Matrix3D result = new Matrix3D();
            result.M11 = Math.Round(openTkMatrix.M11, 3);
            result.M12 = Math.Round(openTkMatrix.M21, 3);
            result.M13 = Math.Round(openTkMatrix.M31, 3);
            result.M21 = Math.Round(openTkMatrix.M12, 3);
            result.M22 = Math.Round(openTkMatrix.M22, 3);
            result.M23 = Math.Round(openTkMatrix.M32, 3);
            result.M31 = Math.Round(openTkMatrix.M13, 3);
            result.M32 = Math.Round(openTkMatrix.M23, 3);
            result.M33 = Math.Round(openTkMatrix.M33, 3);
            result.OffsetX = Math.Round(openTkMatrix.M14, 3);
            result.OffsetY = Math.Round(openTkMatrix.M24, 3);
            result.OffsetZ = Math.Round(openTkMatrix.M34, 3);

            return result;
        }

        /// <summary>
        /// Apply Design Mode to all windows in CATIA.
        /// </summary>
        /// <param name="productsToBeInDeisgnmode"></param>
        public void Apply_DESIGN_MODE()
        {
            foreach (Window currentWin in _catiaApp.Windows)
            {
                try
                {
                    ProductDocument rootDoc = (ProductDocument)currentWin.Parent;
                    Product rootProduct = rootDoc.Product;
                    rootProduct.ApplyWorkMode(CatWorkModeType.DESIGN_MODE);
                }
                catch (Exception ex)
                {
                    MethodBase currentMethod = MethodBase.GetCurrentMethod();
                    TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                        currentMethod.Name + " - " + ex.Message);
                }
            }           
        }

        /// <summary>
        /// Identify geomtry type from input reference
        /// </summary>
        /// <param name="reference"></param>
        /// <returns></returns>
        public CatMeasurableName GetGeometryFromReference(Reference reference)
        {
            if (reference == null)
                return CatMeasurableName.CatMeasurableUnknown;

            Measurable pointmeasurable = GetSPAWorkbench().GetMeasurable(reference);
            return pointmeasurable.GeometryName;
        }

        /// <summary>
        /// Check if reference is a point
        /// </summary>
        /// <param name="reference"></param>
        /// <returns></returns>
        public bool IsReferencePoint(Reference reference)
        {
            return GetGeometryFromReference(reference) == CatMeasurableName.CatMeasurablePoint;
        }

        /// <summary>
        /// Check if we have projection of point
        /// </summary>
        /// <param name="reference"></param>
        /// <returns></returns>
        public bool IsProjectionOfPoint(HybridShapeProject project)
        {
            if (project == null)
                return false;

            Reference elementToProject = project.ElemToProject;
            return GetGeometryFromReference(elementToProject) == CatMeasurableName.CatMeasurablePoint;
        }

        /// <summary>
        /// Check if reference is a circle
        /// </summary>
        /// <param name="reference"></param>
        /// <returns></returns>
        public bool IsReferenceCircle(Reference reference)
        {
            return GetGeometryFromReference(reference) == CatMeasurableName.CatMeasurableCircle;
        }

        /// <summary>
        /// Get point coordiantes from reference point
        /// </summary>
        /// <param name="RefPoint"></param>
        /// <returns></returns>
        public Vector3d GetPointFromReference(Reference RefPoint)
        {
            Measurable pointmeasurable = GetSPAWorkbench().GetMeasurable(RefPoint);
            object[] point = new object[3];
            pointmeasurable.GetPoint(point);

            return new Vector3d(Convert.ToDouble(point[0]), 
                                Convert.ToDouble(point[1]),
                                Convert.ToDouble(point[2]));
        }

        /// <summary>
        /// Get center point from Arc reference
        /// </summary>
        /// <param name="RefCircle"></param>
        /// <returns></returns>
        public Vector3d GetCenterFromReference(Reference RefCircle)
        {
            Measurable pointmeasurable = GetSPAWorkbench().GetMeasurable(RefCircle);
            object[] direction = new object[3];
            pointmeasurable.GetCenter(direction);

            return new Vector3d(Convert.ToDouble(direction[0]),
                                Convert.ToDouble(direction[1]),
                                Convert.ToDouble(direction[2]));
        }

        /// <summary>
        /// Get first, middle and last point from a curve
        /// </summary>
        /// <param name="curve"></param>
        /// <returns></returns>
        public List<Vector3d> GetPointsOnCurve(Reference curve)
        {
            object[] Points = new object[9];
            Measurable measurable = GetSPAWorkbench().GetMeasurable(curve);
            measurable.GetPointsOnCurve(Points);
            return new List<Vector3d>() {
                new Vector3d(Convert.ToDouble(Points[0]), Convert.ToDouble (Points[1]), Convert.ToDouble (Points[2])),
                new Vector3d(Convert.ToDouble (Points[3]), Convert.ToDouble (Points[4]), Convert.ToDouble (Points[5])),
                new Vector3d(Convert.ToDouble (Points[6]), Convert.ToDouble (Points[7]), Convert.ToDouble (Points[8]))};
        }

        /// <summary>
        /// GetDirectionFromReference.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Vector3d GetDirectionFromReference(Reference RefLine)
        {
            Measurable pointmeasurable = GetSPAWorkbench().GetMeasurable(RefLine);
            object[] direction = new object[3];
            pointmeasurable.GetDirection(direction);

            return new Vector3d(Convert.ToDouble(direction[0]),
                                Convert.ToDouble(direction[1]),
                                Convert.ToDouble(direction[2]));
        }

        /// <summary>
        /// Get plane direction from selected reference plane
        /// </summary>
        /// <param name="iPlane"></param>
        /// <returns></returns>
        public Vector3d GetPlaneDirectionFromReference(Reference iPlane)
        {
            object[] planeInfos = new object[9];
            Measurable measurablePlane = GetSPAWorkbench().GetMeasurable(iPlane);
            measurablePlane.GetPlane(planeInfos);

            Vector3d firstDirection = new Vector3d((double)planeInfos[3], 
                                                   (double)planeInfos[4],
                                                   (double)planeInfos[5]);

            Vector3d secondDirection = new Vector3d((double)planeInfos[6],
                                                    (double)planeInfos[7],
                                                    (double)planeInfos[8]);

            return Vector3d.Cross(firstDirection, secondDirection).Normalized();
        }

        /// <summary>
        /// Get plane normal from three non aligned points
        /// </summary>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        /// <param name="p3"></param>
        /// <returns></returns>
        public Vector3d GetPlaneDirectionFromPoints(Vector3d p1, Vector3d p2, Vector3d p3)
        {
            // Calculate two vectors from the three points
            Vector3d v1 = p2 - p1;
            Vector3d v2 = p3 - p1;

            // Compute the normal to the plane using the cross product
            return Vector3d.Cross(v1, v2).Normalized();            
        }

        /// <summary>
        /// GetPlaneOriginFromReference.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Vector3d GetPlaneOriginFromReference(Reference iPlane)
        {
            object[] planeInfos = new object[9];
            Measurable measurablePlane = GetSPAWorkbench().GetMeasurable(iPlane);
            measurablePlane.GetPlane(planeInfos);

            Vector3d origin = new Vector3d((double)planeInfos[0],
                                                   (double)planeInfos[1],
                                                   (double)planeInfos[2]);

            return origin;
        }

        /// <summary>
        /// Get plane equation from refernce
        /// </summary>
        /// <param name="iPlane"></param>
        /// <returns></returns>
        public Vector4d GetPlaneEquationFromReference(Reference iPlane)
        {
            object[] planeInfos = new object[9];
            Measurable measurablePlane = GetSPAWorkbench().GetMeasurable(iPlane);
            measurablePlane.GetPlane(planeInfos);
            Vector3d origin = new Vector3d((double)planeInfos[0], (double)planeInfos[1], (double)planeInfos[2]);
            Vector3d firstDirection = new Vector3d((double)planeInfos[3], (double)planeInfos[4], (double)planeInfos[5]);
            Vector3d secondDirection = new Vector3d((double)planeInfos[6], (double)planeInfos[7], (double)planeInfos[8]);
            Vector3d normal = Vector3d.Cross(firstDirection, secondDirection).Normalized();

            // Plane coefficients A, B, C (normal vector components)
            double A = normal.X;
            double B = normal.Y;
            double C = normal.Z;

            // Compute D using the plane equation
            double D = -(A * origin.X + B * origin.Y + C * origin.Z);

            // Return the plane as a Vector4
            return new Vector4d(A, B, C, D);
        }

        /// <summary>
        /// Check if point belongs to a plane
        /// </summary>
        /// <param name="plane"></param>
        /// <param name="point"></param>
        /// <returns></returns>
        public bool IsPointBelongToPlane(Vector4d plane, Vector3d point)
        {
            // Plane equation: Ax + By + Cz + D = 0
            double A = plane.X;
            double B = plane.Y;
            double C = plane.Z;
            double D = plane.W;

            // Compute the result of the plane equation for the given point
            double result = A * point.X + B * point.Y + C * point.Z + D;

            // Check if the result is approximately zero (to handle floating-point errors)
            return Math.Abs(result) <= 0.001; // Adjust tolerance as needed
        }

        /// <summary>
        /// Project point in a plane
        /// </summary>
        /// <param name="point"></param>
        /// <param name="plane"></param>
        /// <returns></returns>
        public Vector3d ProjectPointOnPlane(Vector3d point, Vector4d plane)
        {
            Vector3d normal = new Vector3d(plane.X, plane.Y, plane.Z);
            double d = (Vector3d.Dot(point, normal) + plane.W) / Vector3d.Dot(normal, normal);
            return point - d * normal;
        }

        /// <summary>
        /// Projects point B onto the line defined by point A and direction V.
        /// </summary>
        public Vector3d ProjectPointOnLine(Vector3d A, Vector3d B, Vector3d V)
        {
            // Compute projection scalar
            double t = Vector3d.Dot(B - A, V) / Vector3d.Dot(V, V);

            // Return projected point
            return A + t * V;
        }

        /// <summary>
        /// Calculate perpendicular distance between plane and point
        /// </summary>
        /// <param name="plane"></param>
        /// <param name="point"></param>
        /// <returns></returns>
        public double CalculateDistanceFromPointToPlane(Vector4d plane, Vector3d point)
        {
            // Extract plane coefficients
            double A = plane.X;
            double B = plane.Y;
            double C = plane.Z;
            double D = plane.W;

            // Extract point coordinates
            double x0 = point.X;
            double y0 = point.Y;
            double z0 = point.Z;

            // Calculate the numerator: |Ax0 + By0 + Cz0 + D|
            double numerator = Math.Abs(A * x0 + B * y0 + C * z0 + D);

            // Calculate the denominator: sqrt(A^2 + B^2 + C^2)
            double denominator = Math.Sqrt(A * A + B * B + C * C);

            // Return the distance
            return numerator / denominator;
        }

        /// <summary>
        /// Checi if point is between two other 2 points by BoundingBox
        /// </summary>
        /// <param name="extremity1"></param>
        /// <param name="extremity2"></param>
        /// <param name="point"></param>
        /// <returns></returns>
        public bool IsPointInBoundingBox(Vector3d extremity1, Vector3d extremity2, Vector3d point)
        {
            // Calculate the bounding box
            double minX = Math.Min(extremity1.X, extremity2.X);
            double maxX = Math.Max(extremity1.X, extremity2.X);
            double minY = Math.Min(extremity1.Y, extremity2.Y);
            double maxY = Math.Max(extremity1.Y, extremity2.Y);
            double minZ = Math.Min(extremity1.Z, extremity2.Z);
            double maxZ = Math.Max(extremity1.Z, extremity2.Z);

            // Check if the point lies within the bounding box
            return point.X >= minX && point.X <= maxX &&
                   point.Y >= minY && point.Y <= maxY &&
                   point.Z >= minZ && point.Z <= maxZ;
        }

        /// <summary>
        /// Compare two points by coordinates
        /// </summary>
        /// <param name="pointA"></param>
        /// <param name="pointB"></param>
        /// <param name="tolerance"></param>
        /// <returns></returns>
        public bool ComparePointByCoords(Vector3d pointA, Vector3d pointB, double tolerance = 0.01)
        {
            if (Math.Abs(pointA.X - pointB.X) <= tolerance
                && Math.Abs(pointA.Y - pointB.Y) <= tolerance
                && Math.Abs(pointA.Z - pointB.Z) <= tolerance)
                return true;

            return false;
        }

        /// <summary>
        /// Insert Ehi point in parent product
        /// </summary>
        /// <param name="position"></param>
        /// <param name="tangentDirection"></param>
        /// <param name="parent"></param>
        /// <param name="partName"></param>
        /// <returns></returns>
        public Product InsertEhiPoint(Vector3d position, Vector3d tangentDirection, Product parent, string partName)
        {
            Product insertedSupport = null;
            try
            {
                //Calculate new axis system
                // Choose an arbitrary vector for the cross product calculation:
                // If xAxis is not predominantly aligned with the X-axis (|xAxis.X| < 0.9), use the Y-axis unit vector.
                // Otherwise, use the Z-axis unit vector to avoid collinearity.
                Vector3d xAxis = Vector3d.Normalize(-tangentDirection);
                Vector3d arbitrary = (Math.Abs(xAxis.X) < 0.9) ? Vector3d.UnitY : Vector3d.UnitZ;
                Vector3d zAxis = Vector3d.Normalize(Vector3d.Cross(xAxis, arbitrary));
                Vector3d yAxis = Vector3d.Normalize(Vector3d.Cross(zAxis, xAxis));

                //Calculate new position 
                Matrix4d prdMatrix = CatiaPosition.GetMatrix4d(position, xAxis, yAxis, zAxis);

                //Apply transform matrix
                insertedSupport = InsertPart(parent, prdMatrix, partName);
                SetShowObject(insertedSupport, false);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return insertedSupport;
        }

        /// <summary>
        /// Insert dummy support
        /// </summary>
        /// <param name="position"></param>
        /// <param name="tangentDirection"></param>
        /// <param name="parent"></param>
        /// <param name="partName"></param>
        /// <returns></returns>
        public Product InsertDummySupport(Vector3d position, Vector3d tangentDirection, Product parent, string partName)
        {
            Product insertedSupport = null;
            try
            {
                //Calculate new axis system
                Vector3d xAxis = Vector3d.Normalize(-tangentDirection);
                Vector3d arbitrary = (Math.Abs(xAxis.X) < 0.9) ? Vector3d.UnitY : Vector3d.UnitZ;
                Vector3d zAxis = Vector3d.Normalize(Vector3d.Cross(xAxis, arbitrary));
                Vector3d yAxis = Vector3d.Normalize(Vector3d.Cross(zAxis, xAxis));

                //Calculate new position 
                Matrix4d prdMatrix = CatiaPosition.GetMatrix4d(position, yAxis, zAxis, xAxis);

                //Apply transform matrix
                insertedSupport = InsertPart(parent, prdMatrix, partName);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return insertedSupport;
        }

        /// <summary>
        /// Insert Ehi support in parent product
        /// </summary>
        /// <param name="position"></param>
        /// <param name="tangentDirection"></param>
        /// <param name="normalDirection"></param>
        /// <param name="origin"></param>
        /// <param name="parent"></param>
        /// <param name="partName"></param>
        /// <param name="distToSurface"></param>
        /// <returns></returns>
        public Product InsertEhiSupport(Vector3d position, Vector3d tangentDirection, Vector3d normalDirection,
            Vector3d origin, Vector3d localTangent, Product parent, string partName, double distToSurface)
        {
            Product insertedSupport = null;
            try
            {
                //Calculate new axis system
                Vector3d firstVector = normalDirection.Normalized();
                Vector3d secondVector = tangentDirection.Normalized();
                Vector3d thirdVector = Vector3d.Cross(firstVector, secondVector).Normalized();
                if (AreVectorCollinear(localTangent, Vector3d.UnitX))
                {
                    var temp = secondVector;
                    secondVector = thirdVector;
                    thirdVector = -temp;
                }

                //Calculate new position 
                Vector3d offset = firstVector * (-distToSurface);
                Vector3d newPosition = position + offset;
                Matrix4d prdMatrix = CatiaPosition.GetMatrix4d(newPosition, thirdVector, secondVector, firstVector);

                Vector3d refOrigin = Vector3d.TransformPosition(origin, Matrix4d.Transpose(prdMatrix));
                newPosition = newPosition + newPosition - refOrigin;
                prdMatrix = CatiaPosition.GetMatrix4d(newPosition, thirdVector, secondVector, firstVector);
                insertedSupport = InsertPart(parent, prdMatrix, partName);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return insertedSupport;
        }

        /// <summary>
        /// Insert product under parent
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="prdMatrix"></param>
        /// <param name="partName"></param>
        /// <returns></returns>
        public Product InsertPart(Product parent, Matrix4d prdMatrix, string partName)
        {
            Product insertedSupport = null;
            try
            {
                //Apply transform matrix
                object[] Abs_Position = new object[12];
                Abs_Position = ConvertMatrixToArray(prdMatrix);
                insertedSupport = AddPartFromCatalog(partName, ref Abs_Position, parent);
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return insertedSupport;
        }

        /// <summary>
        /// Insert product under parent
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="prdMatrix"></param>
        /// <param name="partName"></param>
        /// <returns></returns>
        public Product InsertPartFromCatalog(Product parent, object[] abs_Position, string partName)
        {
            Product insertedProduct = null;
            try
            {
          
                string Trigram = GetEnvVariable("localTrigram");
                string localTrigram = Trigram != string.Empty ? Trigram : "QAL";
                string initialTrigramFolderName = "DMAGS_" + localTrigram;
                string UserProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                string CatalogLocation = @"CatiaV5\Catalog\Lib_ELEC_Catalog";
                string docFullName = Path.Combine(UserProfile, initialTrigramFolderName, CatalogLocation);
                ///// loop through all the files in the directory ///
                bool foundInCatalog = false;
                foreach (string f in Directory.GetFiles(docFullName))
                {
                    if (f.Contains(partName))
                    {
                        docFullName = Path.Combine(docFullName, f);
                        foundInCatalog = true;
                        break;
                    }
                }
                if (!foundInCatalog)
                {
                    return null;
                }
                Product gbnParent = (Product)parent.Parent;
                Document openedDoc = Catia_App.Documents.Open(docFullName);
                insertedProduct = gbnParent.Products.AddExternalComponent(openedDoc);
                insertedProduct.Position.SetComponents(abs_Position);
                Catia_App.Documents.Item(openedDoc.get_Name()).Close();
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return insertedProduct;
        }

        /// <summary>
        /// Check inserted support orientation
        /// </summary>
        /// <param name="position"></param>
        /// <param name="ElbSupport"></param>
        /// <returns></returns>
        public bool IsInvertedSupport(Vector3d position, Product ElbSupport, bool isPreviousInPath = false)
        {
            bool inverted = false;

            //Entry Plane
            Publication entryPlanePub = CatiaProductExtensions.GetPublication(ElbSupport, "EHISUPPORT-RefPlane1.1");
            if (entryPlanePub == null)
                return inverted;

            Vector4d entryPlaneEquation = GetPlaneEquationFromReference((Reference)entryPlanePub.Valuation);

            //OutPlane
            Publication outPlanePub = CatiaProductExtensions.GetPublication(ElbSupport, "EHISUPPORT-RefPlane2");
            if (outPlanePub == null)
                return inverted;

            Vector4d outPlaneEquation = GetPlaneEquationFromReference((Reference)outPlanePub.Valuation);

            double distancePointToEntryPlane = CalculateDistanceFromPointToPlane(entryPlaneEquation, position);
            double distancePointToOutPlane = CalculateDistanceFromPointToPlane(outPlaneEquation, position);

            if (isPreviousInPath)
            {
                if (distancePointToEntryPlane > distancePointToOutPlane)
                    inverted = true;
            }
            else
            {
                if (distancePointToEntryPlane < distancePointToOutPlane)
                    inverted = true;
            }

            return inverted;
        }

        /// <summary>
        /// GetSPAWorkbench.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public SPAWorkbench GetSPAWorkbench()
        {
            if (_spaworkbench == null)
                _spaworkbench = RootDocument.GetWorkbench("SPAWorkbench") as SPAWorkbench;

            return _spaworkbench;
        }

        /// <summary>
        /// CreateExternalReference.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Reference CreateExternalReference(Reference reference, Product iTrgtPartInstance)
        {
            Reference result = null;
            Part part = iTrgtPartInstance.GetPart();


            // Create external in target part
            HybridBody orCreateHybridBody = part.GetOrCreateHybridBody("External References");
            part.UpdateObject(orCreateHybridBody);

            int nbExternalReferences = orCreateHybridBody.HybridShapes.Count;

            Selection.Clear();

            // Copy source body
            Selection.Add(reference);
            Selection.Copy();
            Selection.Clear();

            // Paste the copied body
            Selection.Add(part);
            Selection.PasteSpecial("CATPrtResult");
            Selection.Clear();

            if (nbExternalReferences + 1 == orCreateHybridBody.HybridShapes.Count)
            {
                // Get resulting shape
                HybridShape resultingShape = orCreateHybridBody.HybridShapes.Item(orCreateHybridBody.HybridShapes.Count);
                if (null != resultingShape)
                    result = part.CreateReferenceFromObject(resultingShape);
            }

            return result;
        }

        /// <summary>
        /// GetColorObject.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void GetColorObject(AnyObject anyObject, out int red, out int green, out int blue)
        {
            Selection.Clear();
            Selection.Add(anyObject);
            Selection.VisProperties.GetRealColor(out red, out green, out blue);
            Selection.Clear();
        }

        /// <summary>
        /// SetColorObject.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void SetColorObject(AnyObject anyObject, int r, int g, int b, int heritage)
        {
            Selection.Clear();
            Selection.Add(anyObject);
            Selection.VisProperties.SetRealColor(r, g, b, heritage);
            Selection.Clear();
        }

        /// <summary>
        /// SetShowObject.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void SetShowObject(AnyObject anyObject, bool show = true)
        {
            Selection.Clear();
            Selection.Add(anyObject);
            if(show)
                Selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyShowAttr);
            else
                Selection.VisProperties.SetShow(CatVisPropertyShow.catVisPropertyNoShowAttr);
            Selection.Clear();
        }

        /// <summary>
        /// TransformToGlobalCoordinates.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Vector3d TransformToGlobalCoordinates(Vector3d localCoords, Product product)
        {
            Matrix4d globalMatrix = CatiaProductExtensions.GetGlobalMatrix4d(product);
            return Vector3d.TransformPosition(localCoords, Matrix4d.Transpose(globalMatrix));
        }

        /// <summary>
        /// TransformToLocalCoordinates.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Vector3d TransformToLocalCoordinates(Vector3d globalPoint, Product product)
        {
            Matrix4d globalMatrix = CatiaProductExtensions.GetGlobalMatrix4d(product);
            Matrix4d inverseMatrix = globalMatrix.Inverted();
            return Vector3d.TransformPosition(globalPoint, Matrix4d.Transpose(inverseMatrix));
        }

        /// <summary>
        /// Calculate math round for vector3d to get clear data
        /// </summary>
        /// <param name="vector"></param>
        /// <param name="decimalNumber"></param>
        /// <returns></returns>
        public Vector3d Round(Vector3d vector, int decimalNumber)
        {
            return new Vector3d(
                Math.Round(vector.X, decimalNumber),
                Math.Round(vector.Y, decimalNumber),
                Math.Round(vector.Z, decimalNumber)
            );
        }

        /// <summary>
        /// Check if vector are inverted
        /// </summary>
        /// <param name="firstVector"></param>
        /// <param name="secondVector"></param>
        /// <param name="tolerance"></param>
        /// <returns></returns>
        public bool AreVectorInverted(Vector3d firstVector, Vector3d secondVector, float tolerance = 0.0001f)
        {
            firstVector.Normalize();
            secondVector.Normalize();
            double dot = Vector3d.Dot(firstVector, secondVector);

            return dot < -tolerance;
        }

        /// <summary>
        /// CreatePointByCoordinates.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public Reference CreatePointByCoordinates(Part inputPart, Vector3d pointCoordinates, HybridBody GS, string pointname)
        {
            HybridShapePointCoord createdPoint = ((HybridShapeFactory)inputPart.HybridShapeFactory).AddNewPointCoord(pointCoordinates.X, pointCoordinates.Y, pointCoordinates.Z);
            if (GS != null)
            {
                GS.AppendHybridShape(createdPoint);
                createdPoint.set_Name(pointname);
            }
            inputPart.UpdateObject(createdPoint);
            return inputPart.CreateReferenceFromObject(createdPoint);
        }

        /// <summary>
        /// Get environnement variable
        /// </summary>
        /// <param name="Variable"></param>
        /// <returns></returns>
        public string GetEnvVariable(string Variable)
        {
            return _catiaApp.SystemService.Environ(Variable);

        }

        /// <summary>
        /// Get selected element by product path
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="selectedElem"></param>
        /// <returns></returns>
        public Reference GetElemReferenceByName(alt_CATIA_Adapter adapter, SelectedElement selectedElem)
        {
            Product product = (Product)selectedElem.LeafProduct;
            string name = selectedElem.Reference.DisplayName;
            Reference face = adapter.GetAssemblyReference(product, "/!" + name);
            return face;
        }

        /// <summary>
        /// Check if we have planar face or not
        /// </summary>
        /// <param name="face"></param>
        /// <returns></returns>
        public bool IsPlanarFace(Face face)
        {
            if (face is PlanarFace)
                return true;
            else
                return false;
        }

        /// <summary>
        /// Get the configuration Path.
        /// </summary>
        /// <param name="Variable"></param>
        public string GetConfigFolderPath()
        {
            try
            {

                // Get user profile directory(language - independent)
                string userRoot = Environment.GetEnvironmentVariable("USERPROFILE");

                // Base path where folders will be created
                string basePath = Path.Combine(userRoot, "Harness_Assistant_Data");
                if (Directory.Exists(basePath) == false)
                {
                    Directory.CreateDirectory(basePath);
                }

                // config path where config file is created
                string configPath = Path.Combine(basePath, "Config");
                if (Directory.Exists(configPath) == false)
                {
                    Directory.CreateDirectory(configPath);
                }
                return configPath;
            }
            catch
            {

                return string.Empty;
            }
        }

        /// <summary>
        /// Set CATIA config default data if not available.
        /// </summary>
        /// <param name="Variable"></param>
        public Dictionary<string, object> CheckAndSetConfigDefaultValues(string config_Path)
        {
            string configPath = Path.Combine(config_Path, "Config.json");
            Dictionary<string, object> defaultConfig;
            if (!System.IO.File.Exists(configPath))
            {

                // If file dose not exist.
                defaultConfig = new Dictionary<string, object>();
                defaultConfig.Add("CableTrayString", "TRAY, CABLE TRAY");

                // Convert to formatted JSON
                string jsonContent = JsonConvert.SerializeObject(defaultConfig, Newtonsoft.Json.Formatting.Indented);

                // Write to file
                System.IO.File.WriteAllText(configPath, jsonContent);
                return defaultConfig;
            }
            else
            {

                // If file exist.
                string json = System.IO.File.ReadAllText(configPath);

                try
                {
                    defaultConfig = JsonConvert.DeserializeObject<Dictionary<string, object>>(json)
                             ?? new Dictionary<string, object>();

                    if (!defaultConfig.ContainsKey("CableTrayString"))
                    {
                        //Console.WriteLine("Team1 not found. Adding it...");
                        defaultConfig["CableTrayString"] = "TRAY, CABLE TRAY";

                        System.IO.File.WriteAllText(configPath, JsonConvert.SerializeObject(defaultConfig, Formatting.Indented));

                    }
                    return defaultConfig;
                }
                catch
                {
                    return null;
                }
            }
        }


        #endregion

        #region Private Methods

        /// <summary>
        /// Initialize.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private void Initialize()
        {
            _catiaApp = GetApplication();
            _rootDocument = GetActiveProductDocument();
            _rootProduct = GetActiveProduct();
            _activeWindow = GetActiveWindow();
            _selection = GetSelection();
        }

        /// <summary>
        /// GetApplication.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private Application GetApplication()
        {
            try
            {
                return (INFITF.Application)Marshal.GetActiveObject("Catia.Application");
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// GetActiveProductDocument.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private ProductDocument GetActiveProductDocument()
        {
            ProductDocument proddoc;
            if (_catiaApp == null)
            {
                return null;
            }

            try
            {
                proddoc = (ProductDocument)_catiaApp.ActiveDocument;
            }
            catch
            {
                proddoc = null;
            }
            return proddoc;
        }

        /// <summary>
        /// GetActiveProduct.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private Product GetActiveProduct()
        {
            Product product;
            if (RootDocument == null)
            {
                return null;
            }
            try
            {
                product = (Product)RootDocument.Product;
                return product;

            }
            catch
            {
                product = null;
            }
            return product;
        }

        /// <summary>
        /// GetActiveWindow.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private Window GetActiveWindow()
        {
            Window window;
            if (null == Catia_App)
                return null;
            try
            {
                window = (Window)Catia_App.ActiveWindow;

            }
            catch
            {
                window = null;
            }
            return window;
        }

        /// <summary>
        /// GetSelection.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private Selection GetSelection()
        {
            Selection selection;
            if (_rootProduct == null)
            {
                return null;
            }
            try
            {
                selection = (Selection)RootDocument.Selection;
            }
            catch
            {
                selection = null;
            }
            return selection;
        }

        /// <summary>
        /// GetRootNRDGeomBundleProduct.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private Product GetRootNRDGeomBundleProduct(Product rootProduct = null)
        {
            if (rootProduct == null)
                rootProduct = _rootProduct;
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();
            foreach (Product product in rootProduct.Products)
            {
                try
                {
                    string partNumber = product.get_PartNumber();
                    string nomenclature = product.get_Nomenclature();

                    if (ehiAdapter.IsGeometricalBundle(product))
                        return product;
                }
                catch (Exception e)
                {
                    string errorMsg = e.Message;
                    continue;
                }
            }
            foreach (Product product in rootProduct.Products)
            {
                var returnedProduct = GetRootNRDGeomBundleProduct(product);
                if (returnedProduct != null)
                    return returnedProduct;
            }
            return null;
        }

        public HybridShapePointOnCurve AddPointOnCurveWithRefByDistance(Part part, Reference edgeReference, Reference pointReference, double distance, HybridBody hybridBody = null)
        {
            HybridShapeFactory currentHbSF = (HybridShapeFactory)part.HybridShapeFactory;
            short pointres = currentHbSF.GetGeometricalFeatureType(pointReference);
            short edgeres = currentHbSF.GetGeometricalFeatureType(edgeReference);
            if (pointres == 1 && (edgeres == 2 || edgeres == 3 || edgeres == 4))
            {
                HybridShapePointOnCurve createdPoint = currentHbSF.AddNewPointOnCurveWithReferenceFromDistance(edgeReference, pointReference, distance, false);
                createdPoint.set_Name($"Point at {(distance == 0 ? Guid.NewGuid().ToString() : distance.ToString())}");
                createdPoint.DistanceType = 1;
                hybridBody.AppendHybridShape(createdPoint);
                part.InWorkObject = createdPoint;
                part.Update();
                return createdPoint;
            }

            return null;
        }

        /// <summary>
        /// SelectElementsInCatia.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public SelectedElement SelectRibInCatia(string displayMessage)
        {
            Selection.Clear();
            object[] SelFilfer = new object[1] { "Rib" };
            string Status = Selection.SelectElement2(SelFilfer, displayMessage, false);
            if (Status != "Normal")
                return null;

            if (Selection.Count > 0)
            {
                SelectedElement selectedItem = _selection.Item(1);
                return selectedItem;
            }

            Selection.Clear();
            return null;
        }

        /// <summary>
        /// SelectElementsInCatia.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public HybridBody SelectHbyInCatia(string displayMessage)
        {
            Selection.Clear();
            object[] SelFilfer = new object[1] { "HybridBody" };
            string Status = Selection.SelectElement2(SelFilfer, displayMessage, false);
            if (Status != "Normal")
                return null;

            if (Selection.Count > 0)
            {
                HybridBody selectedItem = (HybridBody)_selection.Item(1).Value;
                return selectedItem;
            }

            Selection.Clear();
            return null;
        }
        #endregion

    }
}
