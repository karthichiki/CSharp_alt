﻿using ProductStructureTypeLib;
using System;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using PARTITF;
using INFITF;
using System.Collections.Generic;
using CatiaDotNet.CommonServices;
using System.Reflection;
using ACNEHIWrapper;
using CatiaDotNet.CommonExtensions;
using ALT_Logging;
using System.Windows.Forms;
using Infrastructure_Layer.ALT_CATIA_Adapter.EhiModel;
using System.Linq;
using MECMOD;

namespace ALT_CATIA_Adapter
{
    public class alt_CATIAEhi_Adapter
    {
        #region Fields

        private static alt_CATIAEhi_Adapter _instance;

        #endregion

        #region Properties

        #endregion

        #region Constructor
        private alt_CATIAEhi_Adapter()
        {
        }

        #endregion

        #region Public Methods
        public static alt_CATIAEhi_Adapter GetInstance()
        {
            if (_instance == null)
                _instance = new alt_CATIAEhi_Adapter();

            return _instance;
        }

        public static void ResetInstance()
        {
            _instance = null;
        }

        /// <summary>
        /// IsMultiBranchable.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public bool IsMultiBranchable(Product product)
        {
            try
            {
                CATIEhiMultiBranchable ehiMultiBranchable = (CATIEhiMultiBranchable)product;
                if (ehiMultiBranchable != null)
                    return true;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return false;
        }

        /// <summary>
        /// IsGeometricalBundle.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public bool IsGeometricalBundle(Product product)
        {
            try
            {
                CATIEhiGeoBundle ehiGeomBundle = (CATIEhiGeoBundle)product;
                if (ehiGeomBundle != null)
                    return true;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }
            
            return false;
        }

        /// <summary>
        /// IsConnector.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public bool IsConnector(Product product)
        {
            try
            {
                CATIElbSingleConnector elbConnector = (CATIElbSingleConnector)product;
                if (elbConnector != null)
                    return true;
            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return false;
        }

        /// <summary>
        /// Check is product is a support
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool IsSupport(Product product)
        {
            try
            {
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                bool isSupport = adapter.CheckPublications(product, "EHISUPPORT-RefPoint1");
                if (isSupport) return true;

            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return false;
        }

        /// <summary>
        /// Check is product is a FictivePoint
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool IsFictivePointType(Product product)
        {
            try
            {
                if(product.get_PartNumber().ToUpper().Contains("FICTIVE POINT TYPE 2"))
                    return true;

            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return false;
        }

        /// <summary>
        /// Check if selected product is a section cut
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        public bool IsSectionCut(Product product)
        {
            try
            {
                string description = product.get_DescriptionRef();
                if (description.ToUpper().Contains("PRINCIPLE SECTION"))
                    return true;

            }
            catch (Exception ex)
            {
                MethodBase currentMethod = MethodBase.GetCurrentMethod();
                TracesSrv.writeError("Error executing " + currentMethod.DeclaringType.Namespace + "." +
                    currentMethod.Name + " - " + ex.Message);
            }

            return false;
        }

        /// <summary>
        /// SetBundleSegmentColor.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void SetBundleSegmentColor(CATIEhiBundleSegment bundleSegment, int red, int green, int blue)
        {
            try
            {
                //Get Rib
                CATBaseDispatch bnsRib = null;
                bundleSegment.GetRepresentation(out bnsRib);
                Rib rib = (Rib)bnsRib;

                //Apply Color
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                adapter.SetColorObject(rib, red, green, blue, 0);

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        /// <summary>
        /// GetHarnessColor.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public List<int> GetHarnessColor(Product multiBranchable)
        {
            List<int> colorList = new List<int>();
            try
            {
                CATIEhiMultiBranchable mbbns = (CATIEhiMultiBranchable)multiBranchable;
                Array bundleSegments;
                mbbns.ListBundleSegments(out bundleSegments);

                if (bundleSegments == null && bundleSegments.Length == 0)
                    return colorList;

                CATBaseDispatch bnsRib = null;
                CATIEhiBundleSegment bundleSegment = (CATIEhiBundleSegment)bundleSegments.GetValue(0);
                bundleSegment.GetRepresentation(out bnsRib);
                Rib rib = (Rib)bnsRib;

                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                int red, green, blue;
                adapter.GetColorObject(rib, out red, out green, out blue);

                colorList.Add(red);
                colorList.Add(green);
                colorList.Add(blue);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return colorList;
        }

        /// <summary>
        /// Find branchable from input rib
        /// </summary>
        /// <param name="multiBranchable"></param>
        /// <param name="rib"></param>
        /// <returns></returns>
        public CATIEhiBranchable FindBranchableFromRib(CATIEhiMultiBranchable multiBranchable, Rib rib)
        {
            Array branchables;
            multiBranchable.ListBranchables(out branchables);
            foreach (CATIEhiBranchable branch in branchables)
            {
                if (branch == null)
                    continue;

                Array bundleSegments;
                branch.ListBundleSegments(out bundleSegments);
                foreach (CATIEhiBundleSegment bns in bundleSegments)
                {
                    if (bns == null)
                        continue;

                    CATBaseDispatch bnsRibObj = null;
                    bns.GetRepresentation(out bnsRibObj);
                    if (bnsRibObj == null)
                        continue;

                    Rib bnsRib = bnsRibObj as Rib;
                    if (bnsRib.get_Name() != rib.get_Name())
                        continue;

                    if(bnsRib.IsEqual(rib))
                        return branch;
                }
            }

            return null;
        }

        /// <summary>
        /// Find bundle segment from input rib
        /// </summary>
        /// <param name="multiBranchable"></param>
        /// <param name="rib"></param>
        /// <returns></returns>
        public CATIEhiBundleSegment FindBundleSegmentFromRib(CATIEhiMultiBranchable multiBranchable, Rib rib)
        {
            Array branchables;
            multiBranchable.ListBranchables(out branchables);
            foreach (CATIEhiBranchable branch in branchables)
            {
                if (branch == null)
                    continue;

                Array bundleSegments;
                branch.ListBundleSegments(out bundleSegments);
                foreach (CATIEhiBundleSegment bns in bundleSegments)
                {
                    if (bns == null)
                        continue;

                    CATBaseDispatch bnsRibObj = null;
                    try
                    {
                        bns.GetRepresentation(out bnsRibObj);
                    }
                    catch { continue; }

                    if (bnsRibObj == null)
                        continue;

                    Rib bnsRib = bnsRibObj as Rib;

                    if (bnsRib.get_Name() != rib.get_Name())
                        continue;

                    if (bnsRib.IsEqual(rib))
                        return bns;
                }
            }
            return null;
        }

        /// <summary>
        /// Instanciate sleeve by segments of branchable
        /// </summary>
        /// <param name="catalogPath"></param>
        /// <param name="ehiBranchable"></param>
        /// <param name="corrugatedSleeveDTRNumber"></param>
        /// <returns></returns>
        public CATIEhiProtection InsertProtection(string catalogPath, CATIEhiBranchable ehiBranchable, IList<CATIEhiBundleSegment> segments,
            string corrugatedSleeveDTRNumber, List<double> sleevOffset = null)
        {
            double len = 0;
            double flag = 0.0;
            string oName = "";
            CATIEhiProtection prot = null;

            if (sleevOffset == null || sleevOffset.Count == 0)
            {
                sleevOffset = new List<double>();
                sleevOffset.Add(0);
                sleevOffset.Add(0);
            }

            alt_Logging_class.AddMessage("Protection Instatiation Started with Code ");
            alt_Logging_class.AddMessage("Catalog Path = " + catalogPath);
            alt_Logging_class.AddMessage("partNumber = " + corrugatedSleeveDTRNumber);

            
            if(segments == null || segments.Count == 0)
                segments = EhiBranchable.GetBundleSegments(ehiBranchable);

            alt_Logging_class.AddMessage("bundleSegment list size: " + segments.Count);
            try
            {
                object[] bundleSegmentsArray = new object[segments.Count];
                for (int i = 0; i < segments.Count; i++)
                    bundleSegmentsArray[i] = segments[i];

                ehiBranchable.InsertLightProtection(catalogPath, corrugatedSleeveDTRNumber, bundleSegmentsArray, sleevOffset[0], sleevOffset[1], out prot, ref oName, out flag);
                if (flag == 1.0)
                {
                    try
                    {
                        prot.ComputeLength(out len);
                        HybridBody protHybrid = prot as HybridBody;                        
                        if (protHybrid != null)
                        {
                            alt_Logging_class.AddMessage("Protection hybrid body is found: " + protHybrid.get_Name());
                            protHybrid.set_Name(oName + "." + DateTime.Now.ToString("ddMMyy_HHmmss"));
                        }
                    }
                    catch
                    {
                        MessageBox.Show("crashed at len and oName");
                    }

                    alt_Logging_class.AddMessage("Instatiated Protection Successfull = " + corrugatedSleeveDTRNumber + " with flag = " + flag.ToString() + " with length " + len + " catalog name = " + oName);
                }
                else
                    alt_Logging_class.AddMessage("Protection Instatiation Failed" + flag.ToString());
            }
            catch (Exception)
            {
                alt_Logging_class.AddMessage("InsertLightProtection crashed");
                return null;
            }

            return prot;
        }      

        /// <summary>
        /// Add sleeve to branchable
        /// </summary>
        /// <param name="catalogPath"></param>
        /// <param name="ehiBranchable"></param>
        /// <param name="ehiSegments"></param>
        /// <param name="corrugatedSleeveDTRNumber"></param>
        /// <param name="offsetValues"></param>
        /// <returns></returns>
        public bool AddSleeve(string catalogPath, CATIEhiBranchable ehiBranchable, IList<CATIEhiBundleSegment> ehiSegments, Product multiBranchable,
            string corrugatedSleeveDTRNumber, List<double> offsetValues = null)
        {
            CATIEhiProtection protection = null;
            try
            {
                alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
                if (multiBranchable != null)
                {
                    IList<string> supportList = EhiBranchable.GetLinkedSupportList(ehiBranchable, ehiSegments);
                    protection = InsertProtection(catalogPath, ehiBranchable, ehiSegments, corrugatedSleeveDTRNumber, offsetValues);
                    adapter.UpdateProtectionFromula(protection, multiBranchable, supportList.ToList());
                    Product gbnProduct = (Product)multiBranchable.Parent;
                    if(gbnProduct != null)
                        gbnProduct.Update();
                }
            }
            catch (Exception ex)
            {
                string errMsg = ex.Message;
                return false;
            }

            return protection != null;
        }

        #endregion

        #region Private Methods
        #endregion
    }
}
