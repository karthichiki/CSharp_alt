﻿/// <summary>
/// class for data validation.
/// </summary>
/// <remarks>
/// Any kind of data validation will be performed here in this class.
/// </remarks>
/// 

using ALT_Data_Model;
using System.Collections.Generic;
using System.Linq;

namespace ALT_Data_Validation_Service
{
    public class alt_Data_Validation_Service
    {
        #region Fields

        private static alt_Data_Validation_Service _instance;

        #endregion

        #region Properties

        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        private alt_Data_Validation_Service()
        {
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Singleton
        /// </summary>
        /// <returns></returns>
        public static alt_Data_Validation_Service GetInstance()
        {
            if (_instance == null)
                _instance = new alt_Data_Validation_Service();

            return _instance;
        }

        /// <summary>
        /// Connector data comparison.
        /// </summary>
        /// <value>
        /// Compare the supplied connector data.
        /// </value>
        public List<CADCompareData> CompareConnectorsData()
        {
            ConnectorDataPreparation ConnectorDataPreparation = ConnectorDataPreparation.GetInstance();
            if (ConnectorDataPreparation.ConnectorList == null ||
                ConnectorDataPreparation.SynopticConnectorList == null ||
                ConnectorDataPreparation.EqtLocation == null)
                return null;

            //parse synoptic
            List<CADCompareData> cadCompareDataList = new List<CADCompareData>();
            foreach (SynopticConnector synopticConnector in ConnectorDataPreparation.SynopticConnectorList)
            {
                if (synopticConnector == null)
                    continue;

                ConnectorDataPreparation.CheckDtrPartNumberMatching(synopticConnector);

                CADConnector connector = ConnectorDataPreparation.ConnectorList.FirstOrDefault(c => c.Name == synopticConnector.SynopticConnectorName);
                CADCompareData cadCompareData = new CADCompareData(connector, synopticConnector);
                cadCompareDataList.Add(cadCompareData);
            }

            //Parse Catia connectors
            foreach (CADConnector cadConnector in ConnectorDataPreparation.ConnectorList)
            {
                if (cadConnector == null)
                    continue;

                SynopticConnector connector = ConnectorDataPreparation.SynopticConnectorList.FirstOrDefault(c => c.SynopticConnectorName == cadConnector.Name);
                if (connector == null)
                {
                    //ElbConnector does not exist, to be deleted 
                    CADCompareData cadCompareData = new CADCompareData(cadConnector, connector);
                    cadCompareDataList.Add(cadCompareData);
                }
            }

            return cadCompareDataList;
        }

        #endregion

        #region Private Methods

        #endregion
    }
}
