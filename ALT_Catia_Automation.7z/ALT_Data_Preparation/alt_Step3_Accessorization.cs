﻿using ALT_Data_Model;
using ALT_Data_Model.Accessories_Data_Model;
using ALT_Data_Model.Electrical;
using ALT_Logging;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ALT_Data_Preparation
{
    public class alt_Step3_Accessorization : IWorkflowStep
    {
        private readonly alt_Logging_class _logging;
        readonly private ConnectorDataPreparation _connectorDataPreparation;
        readonly private MultiBranchableDataPrepation _multiBranchDataPreparation;
        readonly private alt_CATIA_Adapter _adapter;
        readonly private alt_ExcelReaderService _excelReaderService;
        readonly private AccessorizationDataPreparation _accessorizationDataPreparation;
        /// <summary>
        /// Initializes a new instance of the <see cref="alt_Step3_Accessorization"/> class,  setting up the necessary
        /// services and dependencies for the accessorization process.
        /// </summary>
        /// <remarks>This constructor initializes various singleton services required for data preparation
        /// and accessorization. The provided <paramref name="logging"/> instance is used to log  relevant information
        /// throughout the lifecycle of this class.</remarks>
        /// <param name="logging">An instance of the <see cref="alt_Logging_class"/> used for logging operations  during the accessorization
        /// process.</param>
        public alt_Step3_Accessorization(alt_Logging_class logging)
        {
            //_ui = ui;
            //_dataValidationService = dataValidationService;
            _logging = logging;
            _connectorDataPreparation = ConnectorDataPreparation.GetInstance();
            _multiBranchDataPreparation = MultiBranchableDataPrepation.GetInstance();
            _adapter = alt_CATIA_Adapter.GetInstance();
            _excelReaderService = alt_ExcelReaderService.GetInstance();
            _accessorizationDataPreparation = AccessorizationDataPreparation.GetInstance();
        }
        /// <summary>
        /// Prepares the object for use by performing any necessary initialization.
        /// </summary>
        /// <returns><see langword="true"/> if the preparation was successful; otherwise, <see langword="false"/>.</returns>
        public bool Prepare()
        {
            return true;
        }
        /// <summary>
        /// Executes the data comparison process and logs any detected inconsistencies.
        /// </summary>
        /// <remarks>This method performs a data comparison operation and logs an error if inconsistencies
        /// are detected.  Callers should ensure that any required preconditions for data consistency are met before
        /// invoking this method.</remarks>
        /// <returns><see langword="true"/> if the execution completes successfully; otherwise, the method may log an error or
        /// throw an exception.</returns>
        public bool Execute()
        {
            //_ui.PromptUser("Step 2: Starting data comparison...");
            //bool isDataConsistent = _dataValidationService.CompareData();
            //if (!isDataConsistent)
            {
                //_ui.ShowMessage("Data inconsistencies found. Please resolve them before continuing.");
                _logging.LogError("Data inconsistency detected.");
                //throw new InvalidOperationException("Data inconsistency detected.");
            }
            //_logging.LogInfo("Step 2: Data comparison completed successfully.");
            return true;
        }
        /// <summary>
        /// Marks the operation as complete and returns a value indicating the success of the operation.
        /// </summary>
        /// <returns><see langword="true"/> if the operation completed successfully; otherwise, <see langword="false"/>.</returns>
        public bool Finish()
        {
            return true;
        }

        /// <summary>
        /// Reads and processes accessory data for the front page based on the provided input.
        /// </summary>
        /// <param name="inputs">A list of strings where the first element specifies the input data required for processing.</param>
        /// <returns>A list of strings containing the processed accessory data for the front page.</returns>
        public List<string> Read_Accessory_File_FrontPage(List<string> inputs)
        {
            List<string> returnValues = new List<string>();
            returnValues = _accessorizationDataPreparation.ReadAccessoryFrontPage(inputs[0]);
            return returnValues;
        }

        /// <summary>
        /// Reads accessory data for cable glands from the specified input file.
        /// </summary>
        /// <remarks>This method processes the first file path provided in the <paramref name="inputs"/>
        /// list to retrieve cable gland data. Ensure that the file exists and contains valid data in the expected
        /// format.</remarks>
        /// <param name="inputs">A list of input file paths. The first element in the list must be the path to the file containing cable
        /// gland data.</param>
        /// <returns>A list of <see cref="CableGland"/> objects representing the cable gland data read from the file.</returns>
        public List<CableGland> Read_Accessory_File_CableGland(List<string> inputs)
        {
            return _accessorizationDataPreparation.ReadCableGland(inputs[0]);

        }

        /// <summary>
        /// Reads and retrieves a list of DTRs (Design Technical Requirements) based on the specified accessory type.
        /// </summary>
        /// <remarks>This method determines the appropriate DTRs to retrieve based on the accessory type
        /// provided in the second element of the <paramref name="inputs"/> list. Ensure that the <paramref
        /// name="inputs"/> list contains exactly two elements: the input identifier and the accessory type.</remarks>
        /// <param name="inputs">A list of strings where the first element specifies the input identifier, and the second element specifies
        /// the accessory type. Valid accessory types are "FIREWALL COUPLER" and "EMC ADAPTER".</param>
        /// <returns>A list of strings containing the DTRs associated with the specified accessory type.  Returns an empty list
        /// if the accessory type is not recognized.</returns>
        public List<string> Read_Accessory_File_DTRs(List<string> inputs)
        {
            List<string> returnValues = new List<string>();
            if (inputs[1] == "FIREWALL COUPLER")
            {
                returnValues = _accessorizationDataPreparation.ReadOnlyDTRs(inputs[0], "FIREWALL COUPLER");
            }
            else if (inputs[1] == "EMC ADAPTER")
            {
                returnValues = _accessorizationDataPreparation.ReadOnlyDTRs(inputs[0], "EMC ADAPTER");
            }
            return returnValues;
        }

        /// <summary>
        /// Imports DTR (Data Transfer Record) information from the specified DMA (Direct Memory Access) inputs.
        /// </summary>
        /// <param name="inputs">A list of strings representing the DMA inputs to process. Each input must be a valid identifier or data
        /// source.</param>
        /// <returns>A string containing the result of the import operation, which may include status information or a summary of
        /// the processed data.</returns>
        public string ImportDTRFromDMA(List<string> inputs)
        {
            return _accessorizationDataPreparation.ImportDTRFromDMA(inputs);
        }

        /// <summary>
        /// Retrieves a list of bundle segment identifiers.
        /// </summary>
        /// <remarks>This method returns the result of selecting a single bundle segment from the
        /// underlying data source. The returned list may be empty if no bundle segments are available.</remarks>
        /// <returns>A list of strings representing the identifiers of the selected bundle segment.  The list will be empty if no
        /// bundle segments are found.</returns>
        public List<string> SelectBundleSegment()
        {
            return _accessorizationDataPreparation.SelectSingleBundleSegment();
        }

        /// <summary>
        /// Selects and returns the identifier of a multi-branchable entity.
        /// </summary>
        /// <remarks>This method retrieves the identifier of a multi-branchable entity by delegating the
        /// operation          to the underlying data preparation layer. The returned value depends on the current state
        /// of          the data and the logic implemented in the data preparation layer.</remarks>
        /// <returns>A string representing the identifier of the selected multi-branchable entity.</returns>
        public string SelectMultiBranchable()
        {
            return _accessorizationDataPreparation.SelectMultiBranchable();
        }

        /// <summary>
        /// Selects and returns the identifier of the corrugated sleeve to be used.
        /// </summary>
        /// <remarks>The method delegates the selection process to an internal data preparation component.
        /// Ensure that the underlying data source is properly configured before calling this method.</remarks>
        /// <returns>A <see cref="string"/> representing the identifier of the selected corrugated sleeve.</returns>
        public string SelectCorrugatedSleev()
        {
            return _accessorizationDataPreparation.SelectSleeve();
        }

    }
}
