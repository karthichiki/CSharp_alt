﻿using ACNEHIWrapper;
using ALT_CATIA_Adapter;
using ALT_Data_Model;
using ALT_Data_Model.Electrical;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Harness_Definition;
using ALT_Logging;
using ALT_Utilities;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using static ALT_Data_Model.Electrical.CoveringDataPreparation;

namespace ALT_Data_Preparation
{
    // Step 1 - Input Excel file reading and JSON creation
    public class alt_Step1_InputProcessing : IWorkflowStep
    {
        private readonly alt_Logging_class _logging;
        readonly private ConnectorDataPreparation _connectorDataPreparation;
        readonly private MultiBranchableDataPrepation _multiBranchDataPreparation;
        readonly private alt_CATIA_Adapter _adapter;
        readonly private alt_ExcelReaderService _excelReaderService;
        readonly private CoveringDataPreparation _coveringDataPreparation;
        readonly private InsertSupportDataPreparation _insertSupportDataPreparation;
        readonly private PhysicalHarnessDataPreparation _PHDataPreparation;
        readonly private alt_JsonReaderService _jsonReader;

        /// <summary>
        /// This method is to initialize all the variables.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        public alt_Step1_InputProcessing(alt_Logging_class logging)
        {
            _logging = logging;
            _connectorDataPreparation = ConnectorDataPreparation.GetInstance();
            _multiBranchDataPreparation = MultiBranchableDataPrepation.GetInstance();
            _adapter = alt_CATIA_Adapter.GetInstance();
            _excelReaderService = alt_ExcelReaderService.GetInstance();
            _coveringDataPreparation = CoveringDataPreparation.GetInstance();
            _insertSupportDataPreparation = InsertSupportDataPreparation.GetInstance();
            _PHDataPreparation = PhysicalHarnessDataPreparation.GetInstance();
            _jsonReader = alt_JsonReaderService.GetInstance();
        }

        /// <summary>
        /// Prepares the object for use by performing any necessary initialization.
        /// </summary>
        /// <returns><see langword="true"/> if the preparation was successful; otherwise, <see langword="false"/>.</returns>
        public bool Prepare()
        {
            return true;
        }

        /// <summary>
        /// Executes the main operation of the workflow.
        /// </summary>
        /// <remarks>This method performs the necessary steps to process input data and execute the
        /// workflow.  It logs errors if required inputs are not provided and ensures the operation completes
        /// successfully.</remarks>
        /// <returns><see langword="true"/> if the operation completes successfully; otherwise, <see langword="false"/>.</returns>
        public bool Execute()
        {
            //_ui.PromptUser("Step 1: Please provide the input Excel file.");
            //var excelData = _ui.GetInputFile();
            //if (excelData == null)
            {
                _logging.LogError("No input file provided by the user.");
                //throw new InvalidOperationException("Excel input file is required.");
            }

            //var jsonData = _dataPreparation.ConvertExcelToJson(excelData);
            //_logging.LogInfo("Step 1: Excel data successfully converted to JSON.");

            return true;
        }

        /// <summary>
        /// Displays a file selection dialog and returns the path of the selected file.
        /// </summary>
        /// <remarks>The method uses an <see cref="OpenFileDialog"/> to allow the user to browse and
        /// select a file.  The <paramref name="filterstr"/> parameter determines the file types displayed in the
        /// dialog.</remarks>
        /// <param name="filterstr">The filter string used to specify the types of files that can be selected. For example, "Excel
        /// Files|*.xls;*.xlsx".</param>
        /// <returns>The full path of the selected file if a file is chosen; otherwise, an empty string.</returns>
        public string Browse_file(string filterstr)
        {
            OpenFileDialog fileDialog = new OpenFileDialog();
            string excelFilePath = null;
            fileDialog.Filter = filterstr;

            bool? fileDialogueSucces = fileDialog.ShowDialog();
            if (fileDialogueSucces == true)
            {
                excelFilePath = fileDialog.FileName;
                //SynopticTextBox.Text = fileDialog.FileName;
                return excelFilePath;
            }
            return string.Empty;
        }

        /// <summary>
        /// Reads synoptic connector data from the specified Excel file and returns a list of harness names.
        /// </summary>
        /// <remarks>This method processes the synoptic connector data in the specified Excel file and
        /// retrieves the harness names. Ensure the file format and structure are compatible with the expected input for
        /// successful data extraction.</remarks>
        /// <param name="excelFilePath">The full path to the Excel file containing the synoptic connector data. The file must exist and be
        /// accessible.</param>
        /// <returns>A list of harness names extracted from the Excel file. The list will be empty if no harness data is found.</returns>
        public List<string> Read_synoptic_connectors(string excelFilePath)
        {
            _connectorDataPreparation.ReadSynopticConnectors(excelFilePath);
            return _connectorDataPreparation.HarnessList;
        }


        /// <summary>
        /// Validates the specified Excel file to determine if it conforms to the expected synoptic file format.
        /// </summary>
        /// <remarks>This method delegates the validation logic to an internal service. The result
        /// indicates whether the file meets the required format.</remarks>
        /// <param name="excelFilePath">The full file path of the Excel file to validate. This parameter cannot be null or empty.</param>
        /// <returns>A string representation of a boolean value: <see langword="true"/> if the file is valid; otherwise, <see
        /// langword="false"/>.</returns>
        public string Validate_Synoptic_File(string excelFilePath)
        {
            bool correctFile = _excelReaderService.Validate_Synoptic_File(excelFilePath);
            return correctFile.ToString();
        }

        /// <summary>
        /// Validates the specified Excel file to ensure it meets the required format and structure.
        /// </summary>
        /// <remarks>This method delegates the validation logic to an internal service. The validation
        /// checks ensure that the file adheres to the expected format and structure required for further
        /// processing.</remarks>
        /// <param name="excelFilePath">The full file path of the Excel file to validate. The path must not be null or empty.</param>
        /// <returns>A string representation of a boolean value: <see langword="true"/> if the file is valid; otherwise, <see
        /// langword="false"/>.</returns>
        public string Validate_Extract_faf_File(string excelFilePath)
        {
            bool correctFile = _excelReaderService.Validate_Extract_faf_File(excelFilePath);
            return correctFile.ToString();
        }


        /// <summary>
        /// Validates the specified Excel file to determine if it conforms to the expected format for PPL cables.
        /// </summary>
        /// <remarks>This method delegates the validation logic to an internal service. The result
        /// indicates whether the file meets the required structure and content for PPL cables.</remarks>
        /// <param name="excelFilePath">The full file path of the Excel file to validate. The file path must not be null or empty.</param>
        /// <returns>A string representation of a boolean value: <see langword="true"/> if the file is valid; otherwise, <see
        /// langword="false"/>.</returns>
        public string Validate_PPL_Cables_File(string excelFilePath)
        {
            bool correctFile = _excelReaderService.Validate_PPL_Cables_File(excelFilePath);
            return correctFile.ToString();
        }

        /// <summary>
        /// Validates the specified PPL Electrical Excel file to ensure it meets the required format and structure.
        /// </summary>
        /// <remarks>This method delegates the validation logic to an internal service. The validation
        /// checks ensure that the file adheres to the expected format and structure required for processing.</remarks>
        /// <param name="excelFilePath">The full file path of the Excel file to validate. The file must exist and be accessible.</param>
        /// <returns>A string representation of a boolean value: <see langword="true"/> if the file is valid; otherwise, <see
        /// langword="false"/>.</returns>
        public string Validate_PPL_Electrical_File(string excelFilePath)
        {
            bool correctFile = _excelReaderService.Validate_PPL_Electrical_File(excelFilePath);
            return correctFile.ToString();
        }

        /// <summary>
        /// Validates the format and structure of a 3PL Excel file.
        /// </summary>
        /// <remarks>This method delegates the validation logic to an internal service. The validation
        /// checks may include verifying the file's structure, required columns, and data integrity specific to 3PL
        /// requirements.</remarks>
        /// <param name="excelFilePath">The full file path of the Excel file to validate. The file must exist and be accessible.</param>
        /// <returns>A string representation of a boolean value: <see langword="true"/> if the file is valid; otherwise, <see
        /// langword="false"/>.</returns>
        public string Validate_3PL_File(string excelFilePath)
        {
            bool correctFile = _excelReaderService.Validate_3PL_File(excelFilePath);
            return correctFile.ToString();
        }


        /// <summary>
        /// Validates the format and content of a 3PL project Excel file.
        /// </summary>
        /// <remarks>This method delegates the validation logic to an internal service. The validation
        /// checks may include verifying the file's structure, required fields, and data integrity.</remarks>
        /// <param name="excelFilePath">The full file path of the Excel file to validate. The file must exist and be accessible.</param>
        /// <returns>A string representation of a boolean value: <see langword="true"/> if the file is valid; otherwise, <see
        /// langword="false"/>.</returns>
        public string Validate_3PL_Projet_File(string excelFilePath)
        {
            bool correctFile = _excelReaderService.Validate_3PL_Projet_File(excelFilePath);
            return correctFile.ToString();
        }

        /// <summary>
        /// Applies design mode settings to the root product.
        /// </summary>
        /// <remarks>This method configures the root product to operate in design mode, which may alter
        /// its behavior or appearance to facilitate design-time operations.</remarks>
        public void ApplyDesignModeToRootProduct()
        {
            _connectorDataPreparation.ApplyDesignMode();           
        }

        /// <summary>
        /// Extracts a list of connectors associated with the specified harness name.
        /// </summary>
        /// <param name="harnessName">The name of the harness for which to extract connectors. Cannot be null or empty.</param>
        /// <returns>A list of <see cref="CADConnector"/> objects representing the connectors associated with the specified
        /// harness.  Returns an empty list if no connectors are found.</returns>
        public List<CADConnector> ExtractConnectors(string harnessName)
        {
            return _connectorDataPreparation.ExtractConnectors(harnessName);
        }


        /// <summary>
        /// Applies the design mode configuration for the specified harness.
        /// </summary>
        /// <param name="harnessName">The name of the harness for which the design mode configuration should be applied.  This value cannot be
        /// <see langword="null"/> or empty.</param>
        /// <returns>A string representing the result of applying the design mode configuration.  The exact format and content of
        /// the result depend on the implementation of the underlying adapter.</returns>
        public string ApplyDesignMode(string harnessName)
        {
            return _adapter.ApplyDesignMode(harnessName);
        }

        /// <summary>
        /// Reframes the data for the specified product.
        /// </summary>
        /// <param name="productName">The name of the product used to reframe the data. Cannot be null or empty.</param>
        public void Reframe(string productName)
        {
             _connectorDataPreparation.Reframe(productName);
        }

        /// <summary>
        /// Reframes the connector data based on the specified CATIA product name.
        /// </summary>
        /// <param name="productName">The name of the CATIA product used to reframe the connector data. Cannot be null or empty.</param>
        public void ReframeFromCatiaProduct(string productName)
        {
            _connectorDataPreparation.ReframeFromCatiaProduct(productName);
        }

        /// <summary>
        /// This method is to select multi branchable.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        public string SelectMultiBranchable()
        {
            return _multiBranchDataPreparation.SelectMultiBranchable();
        }

        /// <summary>
        /// Sets the derivation type for the specified extremity number.
        /// </summary>
        /// <remarks>This method updates the derivation type for the specified extremity in the underlying
        /// data preparation process. Ensure that both parameters are valid and non-empty strings to avoid unexpected
        /// behavior.</remarks>
        /// <param name="derivationType">The type of derivation to be applied. This value cannot be null or empty.</param>
        /// <param name="extremityNumber">The identifier of the extremity for which the derivation type is being set. This value cannot be null or
        /// empty.</param>
        public void SetDerivationType(string derivationType, string extremityNumber)
        {
            _multiBranchDataPreparation.SetDerivationType(derivationType, extremityNumber);
        }

        /// <summary>
        /// Validates the selected multibranchable against the provided synoptic file path.
        /// </summary>
        /// <param name="multibranchableName"></param>
        /// <param name="synopticFilePath"></param>
        /// <returns></returns>
        public bool ValidateSelectedMultiBranchable(string multibranchableName, string synopticFilePath)
        {
            return _multiBranchDataPreparation.ValidateSelectedMultiBranchable(multibranchableName, synopticFilePath);
        }

        /// <summary>
        /// Reads supplier data from the specified JSON file and returns it as a dictionary.
        /// </summary>
        /// <remarks>This method delegates the actual data reading and processing to an internal data
        /// preparation component. Ensure that the JSON file adheres to the expected schema for successful
        /// deserialization.</remarks>
        /// <param name="jsonPath">The file path to the JSON file containing supplier data. The path must be a valid and accessible file path.</param>
        /// <returns>A dictionary where the keys are supplier names and the values are lists of <see cref="PPL_Electrical"/>
        /// objects representing the supplier's data.</returns>
        public Dictionary<string,List<PPL_Electrical>> ReadSupplierData(string jsonPath)
        {
            return _multiBranchDataPreparation.ReadSupplierData(jsonPath);
        }

        /// <summary>
        /// Calculates the bend radius for electrical components based on the specified diameter and supplier data.
        /// </summary>
        /// <param name="diameter">The diameter of the electrical component as a string. Must be a valid, non-null, and non-empty value.</param>
        /// <returns>A list of <see cref="PPL_Electrical"/> objects representing the calculated bend radius for the given
        /// diameter.</returns>
        public List<PPL_Electrical> BendRadiusUsingSupplier(string diameter)
        {
            return _multiBranchDataPreparation.CalculateBendRadiusUsingSupplier(diameter);
        }


        /// <summary>
        /// Initializes branch information using the provided parameters.
        /// </summary>
        /// <remarks>This method resets the current harness definition instance and reinitializes it
        /// before delegating the branch initialization process to the harness definition. Ensure that the <paramref
        /// name="parameters"/> list contains all required values for successful initialization.</remarks>
        /// <param name="parameters">A list of strings representing the parameters required to initialize the branch information.</param>
        /// <returns>A string indicating the result of the initialization process. The exact format and meaning of the result
        /// depend on the implementation of the underlying branch initialization logic.</returns>
        public string InitBranchInfo(List<string> parameters)
        {
            alt_Harness_Definition.ResetInstance();
            alt_Harness_Definition harnessDefinition = alt_Harness_Definition.GetInstance();
            return harnessDefinition.InitBranchable(parameters);
        }

        /// <summary>
        /// Selects the first extremity from the specified FAF path.
        /// </summary>
        /// <remarks>This method delegates the selection process to an internal data preparation
        /// component. Ensure the specified FAF path is valid and accessible.</remarks>
        /// <param name="extract_FAF_Path">The path to the FAF file from which the first extremity will be selected.  This parameter cannot be null or
        /// empty.</param>
        /// <returns>The first <see cref="Extremity"/> found in the specified FAF file.</returns>
        public Extremity SelectFirstExtremity(string extract_FAF_Path)
        {
            return _multiBranchDataPreparation.SelectFirstExtremity(extract_FAF_Path);
        }

        /// <summary>
        /// Selects intermediate waypoints based on the specified selection parameter.
        /// </summary>
        /// <remarks>This method delegates the selection process to an internal data preparation
        /// component. Ensure that the <paramref name="selectionParameter"/> is valid and meaningful for the  underlying
        /// selection logic.</remarks>
        /// <param name="selectionParameter">A string that specifies the criteria for selecting intermediate waypoints.  The value cannot be null or
        /// empty.</param>
        public void SelectIntermediateWayPoint(string selectionParameter)
        {
            _multiBranchDataPreparation.SelectInterMediateWayPoints(selectionParameter);
        }

        /// <summary>
        /// Selects the second extremity from the specified FAF path.
        /// </summary>
        /// <remarks>This method delegates the selection process to an internal data preparation
        /// component. Ensure that the provided path is valid and accessible.</remarks>
        /// <param name="extract_FAF_Path">The path to the FAF (Feature Attribute File) from which the second extremity is to be selected.</param>
        /// <returns>The second extremity extracted from the specified FAF path.</returns>
        public Extremity SelectSecondExtremity(string extract_FAF_Path)
        {
            return _multiBranchDataPreparation.SelectSecondExtremity(extract_FAF_Path);
        }

        /// <summary>
        /// Centers the graph for the specified product.
        /// </summary>
        /// <remarks>This method adjusts the graph's position to ensure it is centered based on the
        /// provided product name.</remarks>
        /// <param name="productName">The name of the product for which the graph should be centered. Cannot be null or empty.</param>
        public void CentreGraph(string productName)
        {
            _connectorDataPreparation.CentreGraph(productName);
        }

        /// <summary>
        /// Reads and processes equipment location connectors from a JSON file.
        /// </summary>
        /// <remarks>This method delegates the processing of the JSON file to an internal data preparation
        /// component.  Ensure the file at <paramref name="jsonPath"/> exists and contains valid JSON data in the
        /// expected format.</remarks>
        /// <param name="jsonPath">The file path to the JSON file containing the equipment location connector data.  The path must not be null
        /// or empty.</param>
        public void ReadEqtLocationConnectors(string jsonPath)
        {
             _connectorDataPreparation.ReadEqtLocationConnectors(jsonPath);
        }

        /// <summary>
        /// Retrieves the list of harness names.
        /// </summary>
        /// <returns>A list of strings representing the harness names. The list will be empty if no harnesses are available.</returns>
        public List<string> GetHarnessList()
        {
             return _connectorDataPreparation.HarnessList;
        }

        /// <summary>
        /// Compares connector data and returns a list of comparison results.
        /// </summary>
        /// <remarks>This method performs a comparison of connector data and provides the results in a
        /// structured format. The comparison logic is determined by the underlying data preparation process.</remarks>
        /// <returns>A list of <see cref="CADCompareData"/> objects representing the comparison results. The list will be empty
        /// if no differences are found.</returns>
        public List<CADCompareData> CompareConnectorsData()
        {  
             return _connectorDataPreparation.CompareConnectorsData();
        }

        /// <summary>
        /// Inserts a product using the specified connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector to use for inserting the product. Cannot be null or empty.</param>
        /// <returns>A string representing the result of the product insertion operation.</returns>
        public string InsertProduct(string connectorName)
        {
             return _connectorDataPreparation.InsertProduct(connectorName);
        }

        /// <summary>
        /// Replaces the product associated with the specified connector.
        /// </summary>
        /// <remarks>This method delegates the product replacement operation to an internal data
        /// preparation component. Ensure that the specified <paramref name="connectorName"/> corresponds to a valid
        /// connector.</remarks>
        /// <param name="connectorName">The name of the connector whose associated product is to be replaced.  This value cannot be <see
        /// langword="null"/> or empty.</param>
        /// <returns>A string representing the result of the product replacement operation.  The exact format and content of the
        /// returned string depend on the implementation.</returns>
        public string ReplaceProduct(string connectorName)
        {
            return _connectorDataPreparation.ReplaceProduct(connectorName);
        }


        /// <summary>
        /// Retrieves the updated status of connectors for the specified harness.
        /// </summary>
        /// <param name="harnessName">The name of the harness for which to refresh connector statuses. Cannot be null or empty.</param>
        /// <returns>A list of <see cref="CADCompareData"/> objects representing the updated status of connectors. The list will
        /// be empty if no connectors are found for the specified harness.</returns>
        public List<CADCompareData> RefreshConnectorsStatus(string harnessName)
        {
            return alt_Refresh.RefreshConnectorsStatus(harnessName);
        }
        /// <summary>
        /// Retrieves the latest list of harness names.
        /// </summary>
        /// <returns>A list of strings representing the names of all available harnesses.  The list will be empty if no harnesses
        /// are available.</returns>
        public List<string> RefreshHarnessList()
        {
            return alt_Refresh.RefreshHarnessList();
        }
        
        /// <summary>
        /// Modifies the position of the specified connector.
        /// </summary>
        /// <param name="connectorName">The name of the connector whose position is to be modified. Cannot be null or empty.</param>
        /// <returns>A string representing the result of the modification operation.</returns>
        public string ModifyConnectorPosition(string connectorName)
        {
            return _connectorDataPreparation.ModifyConnectorPosition(connectorName);
        }

        /// <summary>
        /// Replace
        /// </summary>
        /// <param name="connectorName">The name of the connector whose position is to be modified. Cannot be null or empty.</param>
        /// <returns>A string representing the result of the modification operation.</returns>
        public string ReplaceFromEQTLocation(string connectorName)
        {
            return _connectorDataPreparation.ReplaceProductFromEQTLocation(connectorName);
        }

        /// <summary>
        /// Adds a product using data provided in the specified input list.
        /// </summary>
        /// <param name="inputs">A list of strings containing the input data required to add the product.  The list must contain at least two
        /// elements: the first element represents the product identifier,  and the second element represents the
        /// product details.</param>
        /// <returns>A string representing the result of the operation, such as a confirmation message or an identifier  for the
        /// added product.</returns>
        public string AddProductFromDMA(List<string> inputs)
        {
            return _connectorDataPreparation.AddProductFromDMA(inputs[0], inputs[1]);
        }

        /// <summary>
        /// Retrieves the Neo type corresponding to the specified input.
        /// </summary>
        /// <param name="input">The input string used to determine the Neo type. Cannot be null or empty.</param>
        /// <returns>The Neo type as a string, based on the provided input.</returns>
        public string GetNeoType(string input)
        {
            return _connectorDataPreparation.GetNeoType(input);
        }

        /// <summary>
        /// Adds a part to the catalog using the specified input values.
        /// </summary>
        /// <param name="inputs">A list of strings containing the input values required to add the part.  The list must contain exactly three
        /// elements: the part identifier, the catalog identifier, and the part details.</param>
        /// <returns>A string representing the result of the operation. The exact format and meaning of the result depend on the
        /// implementation.</returns>
        public string AddPartFromCatalog(List<string> inputs)
        {
             return _connectorDataPreparation.AddPartFromCatalog(inputs[0], inputs[1], inputs[2]);
        }

        /// <summary>
        /// Marks the operation as complete and indicates its success.
        /// </summary>
        /// <returns><see langword="true"/> if the operation completed successfully; otherwise, <see langword="false"/>.</returns>
        public bool Finish()
        {
            return true;
        }
        /// <summary>
        /// Calculates and sets the bend radius for a specified cable based on the provided parameters.
        /// </summary>
        /// <param name="multibranchableName">The name of the multibranchable object associated with the cable.</param>
        /// <param name="jsonFilePaths">An object containing file paths to the necessary JSON configuration files.</param>
        /// <param name="connector1Name">The name of the first connector associated with the cable.</param>
        /// <param name="connector2Name">The name of the second connector associated with the cable.</param>
        /// <param name="projectType">The type of project for which the cable is being used.</param>
        /// <param name="cableType">The type of cable for which the bend radius is being calculated.</param>
        /// <returns>A <see cref="PPL_Cables"/> object containing the calculated bend radius and other related cable data.</returns>
        public PPL_Cables SetBendRadius(string multibranchableName, FilePaths jsonFilePaths, string connector1Name, string connector2Name, string projectType, string cableType)
        {
            return _multiBranchDataPreparation.CalculateBendRadius(multibranchableName, jsonFilePaths, connector1Name, connector2Name, projectType, cableType);
        }

        /// <summary>
        /// Executes the command to initiate the extraction process for Grasshopper data.
        /// </summary>
        /// <remarks>This method triggers the start of the Grasshopper data extraction process by invoking
        /// the appropriate connector logic. Ensure that the connector is properly initialized before calling this
        /// method.</remarks>
        public void RunCommand()
        {
            _connectorDataPreparation.StartCommandGHExtraction();
        }



        /// <summary>
        /// Marks the corrugated data as unchecked in the current processing context.
        /// </summary>
        /// <remarks>This method delegates the operation to the underlying data preparation component. It
        /// is typically used to reset or clear the checked state of corrugated data.</remarks>
        public void Corrugated_Unchecked()
        {
            _multiBranchDataPreparation.CorrugatedUnchecked();
        }

        /// <summary>
        /// Handles the selection of a corrugated item based on the specified sleeve and diameter.
        /// </summary>
        /// <remarks>This method delegates the selection process to the underlying data preparation logic.
        /// Ensure that both <paramref name="sleeve"/> and <paramref name="diameter"/> are valid and non-empty
        /// strings.</remarks>
        /// <param name="sleeve">The identifier of the sleeve to be selected. Cannot be null or empty.</param>
        /// <param name="diameter">The diameter of the corrugated item to be selected. Cannot be null or empty.</param>
        public void CorrugatedSelected(string sleeve, string diameter)
        {
            _multiBranchDataPreparation.CorrugatedSelected(sleeve, diameter);
        }

        /// <summary>
        /// Updates the specified zone with the provided update information.
        /// </summary>
        /// <remarks>This method delegates the update operation to an internal data preparation component.
        /// Ensure that the zone identifier and update information are valid and conform to the expected
        /// format.</remarks>
        /// <param name="zone">The identifier of the zone to be updated. Cannot be <see langword="null"/> or empty.</param>
        /// <param name="update">The update information to apply to the specified zone. Cannot be <see langword="null"/> or empty.</param>
        public void UpdateZoneForCovering(string zone, string update)
        {
            _coveringDataPreparation.UpdateZoneForCovering(zone, update);
        }

        /// <summary>
        /// Reads and returns a collection of covering zones from the specified JSON file.
        /// </summary>
        /// <param name="zoneFilePath">The file path to the JSON file containing covering zone data. Must not be null or empty.</param>
        /// <returns>An <see cref="ObservableCollection{T}"/> of <see cref="CoveringZoneModel"/> objects representing the
        /// covering zones defined in the specified file. Returns an empty collection if the file contains no zones.</returns>
        public ObservableCollection<CoveringZoneModel> ReadCoveringZones(string zoneFilePath)
        {
            ObservableCollection<CoveringZoneModel> zones = alt_JsonReaderService.GetInstance().CoveringReadZones(zoneFilePath);
            return zones;
        }
        /// <summary>
        /// Selects a multi-branchable item for covering.
        /// </summary>
        /// <returns>A string representing the selected multi-branchable item.</returns>
        public string SelectMultiBranchableForCovering()
        {
            return _coveringDataPreparation.SelectMultiBranchable();
        }

        /// <summary>
        /// Selects and returns the identifier of the current bundle segment.
        /// </summary>
        /// <remarks>The returned value corresponds to the bundle segment currently determined by the
        /// underlying data preparation logic.</remarks>
        /// <returns>A <see cref="string"/> representing the identifier of the selected bundle segment.</returns>
        public string SelectBundleSegment()
        {
            return _coveringDataPreparation.SelectBundleSegment();
        }

        /// <summary>
        /// Applies protection sleeves to the specified bundle segments using the provided catalog path.
        /// </summary>
        /// <remarks>This method iterates through the provided bundle segments and applies the specified
        /// sleeves to each segment. If a bundle segment does not have a sleeve specified, it is skipped. The method
        /// uses an adapter to interact  with the underlying system for applying the sleeves.</remarks>
        /// <param name="catalogPath">The file path to the catalog containing the sleeve definitions.</param>
        /// <param name="selectedBundleSegments">A grouping of bundle segments, where each segment includes information about the sleeve to be applied  and
        /// the associated bundle segment data.</param>
        /// <returns>A string indicating the result of the operation:  <see langword="1"/> if all sleeves were successfully
        /// applied;  <see langword="2"/> if one or more sleeves failed to apply.</returns>
        public string CreateProtectionForBundleSegments(string catalogPath, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments)
        {
            Dictionary<string, bool> results = new Dictionary<string, bool>();
            alt_CATIAEhi_Adapter ehiAdapter = alt_CATIAEhi_Adapter.GetInstance();

            foreach (CoveringDataPreparation.SelectedBundleSegment bundleSegment in selectedBundleSegments)
            {
                if (string.IsNullOrEmpty(bundleSegment.Sleeve))
                    continue;

                List<CATIEhiBundleSegment> ehiSegments = new List<CATIEhiBundleSegment>
                {
                    bundleSegment.CATIEhiBundleSegment
                };
                bool result = ehiAdapter.AddSleeve(catalogPath, bundleSegment.Branchable, ehiSegments, _coveringDataPreparation.CatiaProduct,
                    bundleSegment.Sleeve.Split('-')[0].Trim(),null);

                if(!results.ContainsKey(bundleSegment.bundleSegmentName))
                    results.Add(bundleSegment.bundleSegmentName, result);
            }

            return results.Values.Contains(false) ? "2" : "1";
        }

        /// <summary>
        /// Clears the current selection, resetting any selected items to their default state.
        /// </summary>
        /// <remarks>This method removes all selections, ensuring no items remain selected.  It is
        /// typically used to reset the selection state in scenarios where a new operation  or context requires a clean
        /// slate.</remarks>
        public void ClearSelection()
        {
            _coveringDataPreparation.ClearSelection();
        }

   
   
        /// <summary>
        /// Reads and parses a JSON file containing sleeve catalog data.
        /// </summary>
        /// <param name="FilePath">The full path to the JSON file to be read. The file must exist and contain valid sleeve catalog data.</param>
        /// <returns>A <see cref="SleeveCatalog"/> object representing the parsed data from the JSON file.</returns>
        public SleeveCatalog ReadSleeveElecJson(string FilePath)
        {
            return _jsonReader.ReadSleeveJson(FilePath);
        }

        /// <summary>
        /// Reads and parses a 3PL JSON file from the specified file path.
        /// </summary>
        /// <param name="FilePath">The full path to the JSON file to be read. The file must exist and be accessible.</param>
        /// <returns>An instance of <see cref="PL3_Combined"/> representing the parsed data from the JSON file.</returns>
        public PL3_Combined Read3PLJson(string FilePath)
        {
            return _jsonReader.Read3PLJson(FilePath);
        }
        /// <summary>
        /// Reads a JSON file containing 3PL project data and returns the parsed data as a dictionary.
        /// </summary>
        /// <param name="FilePath">The full path to the JSON file to be read. The file must exist and contain valid JSON data.</param>
        /// <returns>A dictionary where the keys are strings representing project identifiers, and the values are lists of  <see
        /// cref="PL3_Global"/> objects containing the associated project data.</returns>
        public Dictionary<string, List<PL3_Global>> Read3PLProjetJson(string FilePath)
        {
            return _jsonReader.Read3PLProjetJson(FilePath);
        }

        /// <summary>
        /// Reads a JSON file containing 3PL project connector data and returns a dictionary of connectors.
        /// </summary>
        /// <param name="FilePath">The path to the JSON file to be read. The file must exist and contain valid JSON data.</param>
        /// <returns>A dictionary where the keys are strings representing connector identifiers, and the values are  <see
        /// cref="PL3_Connector"/> objects representing the corresponding connectors.</returns>
        public Dictionary<string, PL3_Connector> Read3PLProjetConnectorJson(string FilePath)
        {
            return _jsonReader.Read3PLProjetConnectorJson(FilePath);
        }

        /// <summary>
        /// Selects a multi-branchable item for support insertion.
        /// </summary>
        /// <returns>A string representing the selected multi-branchable item for support insertion.</returns>
        public string SelectMultiBranchableForSupportInsertion()
        {
            return _insertSupportDataPreparation.SelectMultiBranchable();
        }

        /// <summary>
        /// Inserts the specified support into the system, with an option to repeat the operation.
        /// </summary>
        /// <remarks>This method delegates the insertion process to an internal data preparation
        /// component. Ensure that <paramref name="supportName"/> is valid and non-empty before calling this
        /// method.</remarks>
        /// <param name="supportName">The name of the support to be inserted. Cannot be null or empty.</param>
        /// <param name="repeat">A value indicating whether the operation should be repeated.          <see langword="true"/> to repeat the
        /// operation; otherwise, <see langword="false"/>.</param>
        public void InsertSelectedSupport(string supportName, bool repeat)
        {
            _insertSupportDataPreparation.InsertSelectedSupport(supportName, repeat);
        }

        /// <summary>
        /// Selects and returns the identifier of the section cut part.
        /// </summary>
        /// <returns>A <see cref="string"/> representing the identifier of the selected section cut part.</returns>
        public string SelectSectionCutPart()
        {
            return _insertSupportDataPreparation.SelectSectionCutPart();
        }

        /// <summary>
        /// Updates the positions of the supports based on the current state of the data.
        /// </summary>
        /// <remarks>This method delegates the operation to an internal data preparation component.  It
        /// ensures that the positions of the supports are recalculated and updated as needed.</remarks>
        public void UpdateSupportsPosition()
        {
            _insertSupportDataPreparation.UpdateSupportsPosition();
        }   


        /// <summary>
        /// Extracts the physical harness data from the specified JSON file paths and processes it into the given
        /// destination path.
        /// </summary>
        /// <remarks>This method relies on the underlying data preparation logic to read and process the
        /// physical harness data. Ensure that the input file paths in <paramref name="jsonfilePaths"/> are valid and
        /// accessible.</remarks>
        /// <param name="destinationPath">The directory path where the processed physical harness data will be stored. This path must be valid and
        /// writable.</param>
        /// <param name="jsonfilePaths">An object containing the file paths to the JSON files that provide the input data for the physical harness
        /// extraction.</param>
        /// <returns>A string representing the result of the extraction process. The content of the string depends on the
        /// implementation of the extraction logic.</returns>
        public string ExtractPhycialHarness(string destinationPath, FilePaths jsonfilePaths)
        {
            string returnString = _PHDataPreparation.ReadPhysicalHarness(destinationPath, jsonfilePaths);
            return returnString;
        }
        /// <summary>
        /// Extracts the physical harness data for CORRUG and saves it to the specified destination path.
        /// </summary>
        /// <remarks>This method relies on the underlying data preparation logic to perform the
        /// extraction. Ensure that the provided file paths in <paramref name="jsonfilePaths"/> are valid and
        /// accessible.</remarks>
        /// <param name="destinationPath">The file path where the extracted data will be saved. This must be a valid, writable path.</param>
        /// <param name="jsonfilePaths">An object containing the file paths to the JSON files required for the extraction process.</param>
        /// <returns>A string representing the result of the extraction process. The content of the string depends on the
        /// implementation of the extraction logic.</returns>
        public string ExtractPhycialHarnessCORRUG(string destinationPath, FilePaths jsonfilePaths)
        {
            string returnString = _PHDataPreparation.ReadPhysicalHarnessCORRUG(destinationPath, jsonfilePaths);
            return returnString;
        }
        /// <summary>
        /// Extracts and processes data related to the physical harness Harting from the specified JSON file paths.
        /// </summary>
        /// <param name="destinationPath">The destination path where the processed data will be stored.</param>
        /// <param name="jsonfilePaths">An object containing the file paths to the JSON files used for data extraction.</param>
        /// <returns>A string representing the result of the data extraction and processing operation.</returns>
        public string ExtractPhycialHarnessHarting(string destinationPath, FilePaths jsonfilePaths)
        {
            string returnString = _PHDataPreparation.ReadPhysicalHarnessHarting(destinationPath, jsonfilePaths);
            return returnString;
        }
        /// <summary>
        /// Selects the branchable entity for support data updation.
        /// </summary>
        /// <returns>A <see cref="string"/> representing the selected branchable entity.</returns>
        public string SelectBranchableForSupportUpdation()
        {
            return _insertSupportDataPreparation.SelectBranchable();
        }
        /// <summary>
        /// Retrieves a reference string for support data preparation.
        /// </summary>
        /// <returns>A string representing the reference for support data preparation.</returns>
        public string SelectReferenceSupportSupportUpdation()
        {
            return _insertSupportDataPreparation.SelectReferenceSupport();
        }
        /// <summary>
        /// Retrieves a string representation of the supports selected for updating.
        /// </summary>
        /// <remarks>This method delegates the selection process to an internal data preparation
        /// component. The returned string contains the selected supports, formatted as determined by the underlying
        /// implementation.</remarks>
        /// <returns>A string representing the selected supports for updating. The format and content of the string depend on the
        /// internal selection logic.</returns>
        public string SelectSupportsForSupportUpdation()
        {
            return _insertSupportDataPreparation.SelectSupports();
        }
        /// <summary>
        /// Updates the position of line supports based on the current alignment configuration.
        /// </summary>
        /// <remarks>This method delegates the alignment operation to an internal data preparation
        /// component.  The returned string provides information about the outcome of the alignment process.</remarks>
        /// <returns>A string representing the result of the alignment operation. The exact value depends on the  implementation
        /// of the alignment logic.</returns>
        public string UpdateLineSupportPosition()
        {
            return _insertSupportDataPreparation.AlignSupportsPosition();
        }

        /// <summary>
        /// Inserts support data for all section cuts in the current context.
        /// </summary>
        /// <remarks>This method prepares and inserts the necessary support data for all section cuts. It
        /// delegates the operation to an internal data preparation component.</remarks>
        public void InsertSupportsForAllSectionsCuts()
        {
            _insertSupportDataPreparation.InsertSupportsForAllSectionsCuts();
        }
    }    
}
