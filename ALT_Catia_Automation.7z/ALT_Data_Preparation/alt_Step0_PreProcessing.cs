﻿using ALT_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Logging;
using ALT_Utilities;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Controls;

namespace ALT_Data_Preparation
{
    public class alt_Step0_PreProcessing
    {
        private readonly alt_Logging_class _logging;
        private DataPreProcessing _DataPreProcessing;
        private alt_ExcelToJsonConvertor _excelToJsonConvertor;
        private alt_JsonReaderService alt_JsonReaderService = alt_JsonReaderService.GetInstance();

        public alt_Step0_PreProcessing(alt_Logging_class logging)
        {
            _logging = logging;
            _DataPreProcessing = new DataPreProcessing();
            _excelToJsonConvertor = new alt_ExcelToJsonConvertor();
        }

        /// <summary>
        /// ExportEqtLocation.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string ExportEqtLocation()
        {
            string destinationPath = GetCatiaFolderPath()+ "EQT_Location\\";
            return _DataPreProcessing.ExportEqtLocationData(destinationPath);
        }


        /// <summary>
        /// This method is to convert Excel to Json format.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public string ConvertExcelToJson(string synopticPath, string extrctFAFPath, string pplCablesPath, string pplElectricals, string pl3FilePath,string pl3_ProjetFilePath, string folderName)
        {
            return _excelToJsonConvertor.ConvertExcelToJson(synopticPath, extrctFAFPath, pplCablesPath, pplElectricals, pl3FilePath, pl3_ProjetFilePath, folderName, GetCatiaFolderPath());
        }

        /// <summary>
        /// This method is the extract into IGES json format for a given description parts in the active assembly.
        /// </summary>
        public void BulkExtractIgesData()
        {
            string destinationPath = GetUnityFolderPath() + "\\IGES\\";           
            _DataPreProcessing.BulkExtractIgesData(destinationPath);
        }


        /// <summary>
        /// This method extract into IGES to json format for a given description parts in the active assembly based on user selection.
        /// </summary>
        /// <param name="DirectionSelectionCheckBox"></param>
        public void CustomExtractIgesData()
        {
            string destinationPath = GetUnityFolderPath() + "\\IGES\\";
            _DataPreProcessing.CustomExtractIgesData(destinationPath);
        }

        /// <summary>
        /// This method is the extract into IGES json format for a given description parts in the active assembly.
        /// </summary>
        public string ExtractSectionCutSegments()
        {
            string destinationPath = GetUnityFolderPath() + "\\SectionCuts\\";
            return _DataPreProcessing.ExtractSectionCutSegments(destinationPath);
        }

        /// <summary>
        /// This method is to get the HAT User Zone Path from environment variable.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        private string GetUnityFolderPath()
        {
            string envValue = Environment.GetEnvironmentVariable("HAT_User_Zone_Path", EnvironmentVariableTarget.User);
            string ProjectFolderPath = Path.Combine(envValue, "Unity_Data", "Ref_Data");
            return ProjectFolderPath;
        }

        /// <summary>
        /// This method is to get the HAT User Baseline Path from environment variable.
        /// </summary>
        /// <returns></returns>
        public string GetCatiaFolderPath()
        {
            string envValue = Environment.GetEnvironmentVariable("HAT_User_Baseline_Path", EnvironmentVariableTarget.User);
            string ProjectFolderPath = envValue + "\\HAT_Data\\Catia_Data\\Json_Data\\";
            return ProjectFolderPath;
        }

        /// <summary>
        /// This method is to Initialize Input Processing.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        public FilePaths InitializeInputProcessing(TextBox synopticTextBox, TextBox extractFAFTextBox, TextBox ppl_CableTextBox, TextBox pplElectricalTextBox, TextBox pl3Textbox, TextBox pl3_Projet_Textbox)
        {
            FilePaths filePaths = new FilePaths();
            string CatiaFolderPath = GetCatiaFolderPath();
            if (!Directory.Exists(CatiaFolderPath))
            {
                return filePaths;
            }

            DirectoryInfo directory = new DirectoryInfo(CatiaFolderPath);
            FileInfo[] files = directory.GetFiles();
            if (files.Length == 0) return filePaths;
            var sortedFiles = files.OrderByDescending(f => f.LastWriteTime);
            List<string> synopticfileNames = new List<string>();
            List<string> extractFAFfileNames = new List<string>();
            List<string> ppl_CablefileNames = new List<string>();
            List<string> ppl_electricalfileNames = new List<string>();
            List<string> pl3_Names = new List<string>();
            List<string> pl3_Projet_Names = new List<string>();
            List<string> paths = new List<string>();
            foreach (FileInfo file in sortedFiles)
            {
                if (File.Exists(file.FullName))
                {
                    if (alt_JsonReaderService.IsaSynopticJson(file.FullName))
                    {
                        synopticfileNames.Add(file.FullName);
                        continue;
                    }
                    else if (alt_JsonReaderService.IsaExtractFAFJson(file.FullName))
                    {
                        extractFAFfileNames.Add(file.FullName);
                        continue;
                    }
                    else if (alt_JsonReaderService.IsaPPLCableJson(file.FullName))
                    {
                        ppl_CablefileNames.Add(file.FullName);
                        continue;
                    }
                    else if (alt_JsonReaderService.IsaPPLElectricalJson(file.FullName))
                    {
                        ppl_electricalfileNames.Add(file.FullName);
                        continue;
                    }
                    else if (alt_JsonReaderService.isa3PLJson(file.FullName))
                    {
                        pl3_Names.Add(file.FullName);
                        continue;
                    }
                    else if (alt_JsonReaderService.isa3PL_ProjetJson(file.FullName))
                    {
                        pl3_Projet_Names.Add(file.FullName);
                        pl3_Projet_Names.Add(file.FullName.Replace(".json", "_ConnectorList.json"));
                        continue;
                    }
                }
            }
            if (synopticfileNames.Count > 0)
            {
                synopticTextBox.Text = Path.GetFileNameWithoutExtension(synopticfileNames[0]);
                filePaths.Synoptic_File_Path = synopticfileNames[0];
                DeleteOldJson(synopticfileNames);
            }
            if (extractFAFfileNames.Count > 0)
            {
                extractFAFTextBox.Text = Path.GetFileNameWithoutExtension(extractFAFfileNames[0]);
                filePaths.Extract_FAF_Path = extractFAFfileNames[0];
                DeleteOldJson(extractFAFfileNames);
            }
            if (ppl_CablefileNames.Count > 0)
            {
                ppl_CableTextBox.Text = Path.GetFileNameWithoutExtension(ppl_CablefileNames[0]);
                filePaths.PPL_Cable_Path = ppl_CablefileNames[0];
                DeleteOldJson(ppl_CablefileNames);
            }
            if (ppl_electricalfileNames.Count > 0)
            {
                pplElectricalTextBox.Text = Path.GetFileNameWithoutExtension(ppl_electricalfileNames[0]);
                filePaths.PPL_Electrical_Path = ppl_electricalfileNames[0];
                DeleteOldJson(ppl_electricalfileNames);
            }
            if (pl3_Names.Count > 0)
            {
                pl3Textbox.Text = Path.GetFileNameWithoutExtension(pl3_Names[0]);
                filePaths.PL3_Path = pl3_Names[0];
                DeleteOldJson(pl3_Names);
            }
            if (pl3_Projet_Names.Count > 0)
            {
                pl3_Projet_Textbox.Text = Path.GetFileNameWithoutExtension(pl3_Projet_Names[0]);
                filePaths.PL3_Projet_Path = pl3_Projet_Names[0];
                pl3_Projet_Names.Remove(pl3_Projet_Names[0]);
                DeleteOldJson(pl3_Projet_Names);
            }
            return filePaths;
        }

        private void DeleteOldJson(List<string> synopticfileNames)
        {
            
            try
            {

                for (int i = 1; i < synopticfileNames.Count; i++)
                {
                    if (File.Exists(synopticfileNames[i]))
                    {
                        File.Delete(synopticfileNames[i]);
                        alt_Logging_class.AddMessage($"Deleted: {synopticfileNames[i]}");
                    }
                    else
                    {
                        Console.WriteLine($" {synopticfileNames[i]} Directory does not exist.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }


        /// <summary>
        /// This method is to Delete Temp Excel Folder.
        /// </summary>
        /// <value>
        /// 
        /// </value>
        public void DeleteMyTempExcelFolder(string folderName)
        {
           _excelToJsonConvertor.DeleteMyTempExcelFolder(folderName, GetCatiaFolderPath());
        }

        /// <summary>
        /// This method is the extract into IGES json format for a given description parts in the active assembly.
        /// </summary>
        public string ExtractCatalogData(string Catalog_Location)
        {
            return _DataPreProcessing.ExtractCatalogData(Catalog_Location, GetCatiaFolderPath());
        }
    }
}

