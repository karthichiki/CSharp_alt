﻿using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Model;
using ALT_Data_Preparation;
using ALT_Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ApplicationLayer;
using Path = System.IO.Path;
using Microsoft.Xaml.Behaviors;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for InputProcessing.xaml
    /// </summary>
    public partial class InputProcessing : UserControl
    {
        private alt_Automation_Orchestrator orchestrator;
        private alt_Utilities utils;
        private List<string> filteredItems;
        private MenuItem reframeItem, addItem, modifyItems, deleteItem, addSelectedItem, modifySelectedItem, deleteSelectedItem, UpdateAllSelectedItems, AddItemFromDMA, AddItemFromCatalog, ReplaceFromEQTL;
        private List<string> equipmentFiles;
        private List<CADCompareData> _connectorCompareDataList = null;
        private CheckBox _headerCheckBox;
        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        private List<string> harnessList = new List<string>();
        private bool _isFromCombobox = false;
        public InputProcessing()
        {
            InitializeComponent();
            DataGridTable.IsReadOnly = true;
            utils = new alt_Utilities();
            ContextualMenu();
            _connectorCompareDataList = new List<CADCompareData>();
            orchestrator = new alt_Automation_Orchestrator();
        }

        /// <summary>
        /// context menu for datagrid
        /// </summary>
        private void ContextualMenu()
        {

            // Create ContextMenu

            ContextMenu contextMenu = new ContextMenu();

            // Create and add MenuItems to the ContextMenu

            reframeItem = new MenuItem { Header = "Reframe" };
            reframeItem.Click += ReframeItem_Click;
            contextMenu.Items.Add(reframeItem);
            reframeItem.Visibility = Visibility.Visible;

            addItem = new MenuItem { Header = "Add" };
            addItem.Click += AddItem_Click;
            contextMenu.Items.Add(addItem);
            addItem.Visibility = Visibility.Collapsed;

            modifyItems = new MenuItem { Header = "Modify" };
            modifyItems.Click += ModifyItems_Click;
            contextMenu.Items.Add(modifyItems);
            modifyItems.Visibility = Visibility.Collapsed;

            deleteItem = new MenuItem { Header = "Delete" };
            deleteItem.Click += DeleteSelected_Click;
            contextMenu.Items.Add(deleteItem);
            deleteItem.Visibility = Visibility.Collapsed;

            addSelectedItem = new MenuItem { Header = "Add Selected" };
            addSelectedItem.Click += AddSelected_Click;
            contextMenu.Items.Add(addSelectedItem);
            addSelectedItem.Visibility = Visibility.Collapsed;

            modifySelectedItem = new MenuItem { Header = "Modify Selected" };
            modifySelectedItem.Click += UpdateSelected_Click;
            contextMenu.Items.Add(modifySelectedItem);
            modifySelectedItem.Visibility = Visibility.Collapsed;

            deleteSelectedItem = new MenuItem { Header = "Delete Selected" };
            deleteSelectedItem.Click += DeleteSelected_Click;
            contextMenu.Items.Add(deleteSelectedItem);
            deleteSelectedItem.Visibility = Visibility.Collapsed;

            UpdateAllSelectedItems = new MenuItem { Header = "Update All Selected" };
            UpdateAllSelectedItems.Click += UpdateAllSelectedItems_Click; ;
            contextMenu.Items.Add(UpdateAllSelectedItems);
            UpdateAllSelectedItems.Visibility = Visibility.Collapsed;

            AddItemFromDMA = new MenuItem { Header = "AddItemFromDMA" };
            AddItemFromDMA.Click += AddFromDMA_Click;
            contextMenu.Items.Add(AddItemFromDMA);
            AddItemFromDMA.Visibility = Visibility.Collapsed;

            AddItemFromCatalog = new MenuItem { Header = "AddItemFromCatalog" };
            AddItemFromCatalog.Click += AddFromCatalog_Click;
            contextMenu.Items.Add(AddItemFromCatalog);
            AddItemFromCatalog.Visibility = Visibility.Collapsed;

            ReplaceFromEQTL = new MenuItem { Header = "ReplaceFromEQTL" };
            ReplaceFromEQTL.Click += ReplaceFromEQTLocation_Click;
            contextMenu.Items.Add(ReplaceFromEQTL);
            ReplaceFromEQTL.Visibility = Visibility.Collapsed;

            //itemProperties = new MenuItem { Header = "Properties" }; AddItemFromDMA
            //itemProperties.Click += Properties_Click;
            //contextMenu.Items.Add(itemProperties);
            //itemProperties.Visibility = Visibility.Visible;

            // Assign the ContextMenu to the ComboBox

            DataGridTable.ContextMenu = contextMenu;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <exception cref="NotImplementedException"></exception>
        private void UpdateAllSelectedItems_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// XXX.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private void Properties_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Delete selected connector from harness
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void DeleteSelected_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start deleting connector to harness");
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[2];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    string harnessName = HarnessComboBox.Text;

                    if (cellContent is TextBlock textBlock)
                    {
                        string cellValue = textBlock.Text;
                        await Task.Run(() =>
                        {
                            utils.BringApplicationToFront("CNEXT");
                            orchestrator.Step_1_process<alt_Step1_InputProcessing>("Reframe", cellValue);
                            orchestrator.Step_1_process<alt_Step1_InputProcessing>("CentreGraph", cellValue);
                        });
                        alt_PopupMessageUtil.ShowMessage("Please delete the selected connector: " + cellValue, "", MessageType.Information);
                        await RefreshConnectorStatus(harnessName);
                    }
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End deleting connector to harness");
            });
        }

        /// <summary>
        /// Replace connector in harness with synoptic dtr
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void UpdateSelected_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start replacing connector to harness");
                string returnResult = string.Empty;
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[1];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    if (cellContent is TextBlock textBlock)
                    {
                        string connectorName = textBlock.Text;
                        string harnessName = HarnessComboBox.Text;
                        await Task.Run(() =>
                        {
                            returnResult = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReplaceProduct", connectorName) as string;
                        });
                        await RefreshConnectorStatus(harnessName);
                    }
                }

                if (returnResult.Contains("_"))
                {
                    string[] splitElements = returnResult.Split('_');
                    if (splitElements[0] == 404.ToString())
                    {
                        alt_PopupMessageUtil.ShowMessage("DTR not found in dma: " + splitElements[1].Split(':')[0], "", MessageType.Information);
                    }
                    else
                    {
                        ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "DTR successfully inserted: " + splitElements[1].Split(':')[0]);
                    }
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1,50, "Failure while inserting the DTR: " + returnResult.Split(':')[0]);
                }
            });
        }

        /// <summary>
        /// XXX.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private void AddSelected_Click(object sender, RoutedEventArgs e)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Reframe selected connector in harness in catia
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ReframeItem_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                //StartProcess();
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[2];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);

                    if (cellContent is TextBlock textBlock)
                    {
                        string cellValue = textBlock.Text;
                        await Task.Run(() =>
                        {
                            orchestrator.Step_1_process<alt_Step1_InputProcessing>("Reframe", cellValue);
                        });
                    }
                }
                else
                {
                    alt_PopupMessageUtil.ShowMessage("Reframe On failed please reload the data and try again.", "Warning", MessageType.Warning);
                }
            });
            //EndProcess();

        }

        /// <summary>
        /// Add connector from Eqt location to harness
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void AddItem_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start adding connector to harness");
                string returnResult = string.Empty;
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[1];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    if (cellContent is TextBlock textBlock)
                    {
                        string connectorName = textBlock.Text;
                        string harnessName = HarnessComboBox.Text;
                        await Task.Run(() =>
                        {
                            returnResult = orchestrator.Step_1_process<alt_Step1_InputProcessing>("InsertProduct", connectorName) as string;
                        });
                        await RefreshConnectorStatus(harnessName);

                    }
                }
                if (returnResult.Contains("_"))
                {
                    string[] splitElements = returnResult.Split('_');
                    if (splitElements[0] == 404.ToString())
                    {
                        alt_PopupMessageUtil.ShowMessage("DTR not found in dma: " + splitElements[1].Split(':')[0], "", MessageType.Information);
                    }
                    else
                    {
                        ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "DTR successfully inserted: " + splitElements[1].Split(':')[0]);
                        ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: DTR inserted");
                    }
                }
                else if (returnResult == "Part not found")
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "Part not found in EQT Location product");
                    //ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Connector Added to harness");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End adding connector to harness");
                    //ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Connector Added to harness");
                }
            });
        }

        /// <summary>
        /// Modify connector position in harness
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ModifyItems_Click(object sender, RoutedEventArgs e)
        {
            string harnessName = HarnessComboBox.Text;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Modifying Connector...");
                
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[1];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    if (cellContent is TextBlock textBlock)
                    {
                        string connectorName = textBlock.Text;
                        
                        string returnResult = string.Empty;
                        await Task.Run(() =>
                        {
                            returnResult = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ModifyConnectorPosition", connectorName) as string;
                            
                        });
                        
                    }
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Modifying connector");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Connector Modified");
                await RefreshConnectortatus(harnessName);
            });
        }


        /// <summary>
        /// Add connector from DMA to harness
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void AddFromDMA_Click(object sender, RoutedEventArgs e)
        {
            string harnessName = HarnessComboBox.Text;

            await mainWindow.ShowOverlayAsync(async () =>
            {
                string importStatus = string.Empty;
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Modifying Connector...");
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[1];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    if (cellContent is TextBlock textBlock)
                    {
                        List<string> inputs = new List<string>();
                        inputs.Add(HarnessComboBox.Text);
                        inputs.Add(textBlock.Text);
                        ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Starting importing DTR from DMA");
                        await mainWindow.ShowOverlayAsync(async () =>
                        {
                            await Task.Run(() =>
                            {
                                 importStatus = orchestrator.Step_1_process<alt_Step1_InputProcessing>("AddProductFromDMA", inputs) as string;
                            });
                        });

                    }
                }
                if (importStatus == "SUCCESS")
                {
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Successfully imported DTR from DMA:");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Importing DTR failed:");
                }
                await RefreshConnectortatus(harnessName);
            });
        }

        /// <summary>
        /// Add connector from local Catalog to harness
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void AddFromCatalog_Click(object sender, RoutedEventArgs e)
        {
            string harnessName = HarnessComboBox.Text;

            await mainWindow.ShowOverlayAsync(async () =>
            {
                string importStatus = string.Empty;
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Modifying Connector...");
                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[1];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    if (cellContent is TextBlock textBlock)
                    {
                        List<string> inputs = new List<string>();
                        inputs.Add(HarnessComboBox.Text);
                        inputs.Add(textBlock.Text);
                        string neoType = string.Empty;
                        await mainWindow.ShowOverlayAsync(async () =>
                        {
                            await Task.Run(() =>  
                            {
                                neoType = orchestrator.Step_1_process<alt_Step1_InputProcessing>("GetNeoType", inputs[1]) as string;
                            });
                        });
                        string dtr = GetDTRBasedOnNeoType(neoType);
                        if (dtr == string.Empty)
                        {
                            alt_PopupMessageUtil.ShowMessage("Operation cancelled by user or DTR not found", "Warning", MessageType.Warning);
                            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(100, "Operation Cancelled");
                            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Operation Cancelled:");
                            return;
                        }
                        inputs.Add(dtr);
                        ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Starting importing DTR from Catalog");
                        await mainWindow.ShowOverlayAsync(async () =>
                        {
                            await Task.Run(() =>
                            {
                                importStatus = orchestrator.Step_1_process<alt_Step1_InputProcessing>("AddPartFromCatalog", inputs) as string;
                            });
                        });

                    }
                }

                if (importStatus == "SUCCESS")
                {
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Successfully imported DTR from Catalog:");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Importing DTR failed:");
                }
                await RefreshConnectortatus(harnessName);
            });
        }

        /// <summary>
        /// Get DTR based on NeoType in the synoptic file
        /// </summary>
        /// <param name="neotype"> neo type name</param>
        /// <returns> Corresponding DTR </returns>
        private string GetDTRBasedOnNeoType(string neotype)
        {
            string userInput = string.Empty;

            if (neotype.ToUpper() == "Connective Device".ToUpper())
            {
                return "DTR0000340192";
            }
            else if (neotype.ToUpper() == "Connective Device Modular".ToUpper())
            {
                return "DTR0000418274";
            }
            else if (neotype.ToUpper() == "Connective Device Modular Frame".ToUpper())
            {
                userInput = AskUser("Please enter the number that is required to be added: \n1 - DTR0000418295 (6B) \n2 - DTR0000418296 (10B) \n3 - DTR0000418297 (16B) \n4 - DTR0000418298 (24B) ");
                if (userInput == "1") return "DTR0000418295";
                else if (userInput == "2") return "DTR0000418296";
                else if (userInput == "3") return "DTR0000418297";
                else if (userInput == "4") return "DTR0000418298";
                else return string.Empty;
            }
            else if (neotype.ToUpper() == "Device".ToUpper())
            {
                return "DTR0000340192";
            }
            else if (neotype.ToUpper() == "Device Lug".ToUpper())
            {
                userInput = AskUser("Please enter the number that is required to be added: \n1 - Small(FICT-DC-00012) \n2 - Big(FICT-DC-00013)");
                if (userInput == "1") return "FICTIVE LUG TYPE 1";
                else if (userInput == "2") return "FICTIVE LUG TYPE 2";
                else return string.Empty;
            }
            else if (neotype.ToUpper() == "Fictive Connector".ToUpper())
            {
                return "DTR0000547328";
            }
            else if (neotype.ToUpper() == "Ground Block".ToUpper())
            {
                return "AND0001444534"; //// mapped to DTR0000547328
            }
            else if (neotype.ToUpper() == "Ground Block Lug".ToUpper())
            {
                userInput = AskUser("Please enter the number that is required to be added: \n1 - Small(FICT-DC-00012) \n2 - Big(FICT-DC-00013)");
                if (userInput == "1") return "FICTIVE LUG TYPE 1";
                else if (userInput == "2") return "FICTIVE LUG TYPE 2";
                else return string.Empty;
            }
            else if (neotype.ToUpper() == "Ground Shielding Block".ToUpper())
            {
                userInput = AskUser("Please enter the number that is required to be added: \n1 - Small(FICT-DC-00012) \n2 - Big(FICT-DC-00013) \n3 - DTR0000547328");
                if (userInput == "1") return "FICTIVE LUG TYPE 1";
                else if (userInput == "2") return "FICTIVE LUG TYPE 2";
                else if (userInput == "3") return "AND0001444534"; //// mapped to DTR0000547328
                else return string.Empty;
            }
            else if (neotype.ToUpper() == "Production Break".ToUpper())
            {
                return "DTR0000340192";
            }
            else if (neotype.ToUpper() == "Production Break Modular".ToUpper())
            {
                return "DTR0000418274";
            }
            else if (neotype.ToUpper() == "Production Break Modular Frame".ToUpper())
            {
                userInput = AskUser("Please enter the number that is required to be added: \n1 - DTR0000418295 (6B) \n2 - DTR0000418296 (10B) \n3 - DTR0000418297 (16B) \n4 - DTR0000418298 (24B) ");
                if (userInput == "1") return "DTR0000418295";
                else if (userInput == "2") return "DTR0000418296";
                else if (userInput == "3") return "DTR0000418297";
                else if (userInput == "4") return "DTR0000418298";
                else return string.Empty;
            }
            else if (neotype.ToUpper() == "SUPPLIER : Connective Device".ToUpper())
            {
                return "DTR0000340192";
            }
            else if (neotype.ToUpper() == "Terminal Block Lug".ToUpper())
            {
                userInput = AskUser("Please enter the number that is required to be added: \n1 - wire section >= 10mm² \n2 - wire section < 10mm²");
                if (userInput == "1")
                {
                    userInput = AskUser("Please enter the number that is required to be added: \n1 - Small(FICT-DC-00012) \n2 - Big(FICT-DC-00013)");
                    if (userInput == "1") return "FICTIVE LUG TYPE 1";
                    else if (userInput == "2") return "FICTIVE LUG TYPE 2";
                    else return string.Empty;
                }
                else if (userInput == "2")
                {
                    return "AND0001444534"; /// mapped to DTR0000547328
                }
                else return string.Empty;

            }

            return string.Empty;
        }


        /// <summary>
        /// Replace From EQT Location Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ReplaceFromEQTLocation_Click(object sender, RoutedEventArgs e)
        {
            string harnessName = HarnessComboBox.Text;
            string returnResult = string.Empty;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Replacing Connector from EQT Location...");

                if (DataGridTable.SelectedCells.Count > 0)
                {
                    var selectedCell = DataGridTable.SelectedCells[1];
                    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);
                    if (cellContent is TextBlock textBlock)
                    {
                        string connectorName = textBlock.Text;
                        await Task.Run(() =>
                        {
                            returnResult = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReplaceFromEQTLocation", connectorName) as string;

                        });

                    }
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Replacing Connector from EQT Location");

                if(returnResult == "SUCCESS") ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Connector Replaced");
                else ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Failure while replacing connector from EQT Location");
                
                await RefreshConnectortatus(harnessName);
            });
        }
        /// <summary>
        /// Prompt user for input
        /// </summary>
        /// <param name="input"> The options for user to click</param>
        /// <returns>  Entered value </returns>
        public static string AskUser(string input)
        {
            var dialog = new InputDialog(input);
            bool? result = dialog.ShowDialog();

            if (result == true)
            {
                return dialog.ResponseText;
            }
            else
            {
                return null;
            }
        }


        /// <summary>
        /// Read synoptic excel file and list harness in combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SynopticSelectionButton_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                object excelFilePath = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Browse_file", "Excel Source File | *.xlsx");
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start reading synoptic excel file");
                List<string> HarnessList = new List<string>();
                SynopticTextBox.Text = excelFilePath.ToString();

                await Task.Run(() =>
                {
                    HarnessList = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Read_synoptic_connectors", excelFilePath) as List<string>;
                });
                if (HarnessList == null)
                {
                    alt_PopupMessageUtil.ShowMessage("No Harness Opened in CATIA, Please Open Correct Product and click on \"RefreshHarnessList\" Button", "Warning", MessageType.Warning);
                    HarnessBorder.Visibility = Visibility.Visible;
                    RefreshHarnessListButton.Visibility = Visibility.Visible;
                    return;
                }

                if (HarnessList.Count > 0)
                    HarnessList.Sort();

                HarnessComboBox.ItemsSource = HarnessList;
                filteredItems = HarnessList.Distinct().ToList();
                harnessList = filteredItems;
                //if (filteredItems.Count == 0)
                //{
                //    MessageBox.Show("No Harness Opened in CATIA, Please Open Correct Product and click on \"RefreshHarnessList\" Button", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                //    RefreshHarnessListButton.Visibility = Visibility.Visible;
                //    return;
                //}
                HarnessBorder.Visibility = Visibility.Visible;
                HarnessLabel.Visibility = Visibility.Visible;
                HarnessComboBox.Visibility = Visibility.Visible;

                // Update the ComboBox's ItemsSource with the filtered items
                HarnessComboBox.ItemsSource = filteredItems;

                // Open the drop-down to show suggestions
                HarnessComboBox.IsDropDownOpen = true;
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End reading synoptic excel file");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Select harness name and extract connectors");
            });
        }

        /// <summary>
        /// List harness in combobox
        /// </summary>
        /// <param name="filteredItems"> filter value </param>
        private void ListHarnessInComboBox(List<string> filteredItems)
        {
            HarnessLabel.Visibility = Visibility.Visible;
            HarnessComboBox.Visibility = Visibility.Visible;
            HarnessComboBox.ItemsSource = filteredItems;
            HarnessComboBox.IsDropDownOpen = true;
        }

        /// <summary>
        /// No harness opened message
        /// </summary>
        private void NoHarnessOpenedMessage()
        {
            MessageBox.Show("No Harness Opened in CATIA, Please Open Correct Product and click on \"RefreshHarnessList\" Button", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            HarnessBorder.Visibility = Visibility.Visible;
            RefreshHarnessListButton.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Read harness product and extract connectors
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ReadHarnessProductButton_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting connectors from Harness product");

                string selectedHarnessText = HarnessComboBox.Text;
                object returnMsg = null;
                List<CADConnector> cADConnectors = new List<CADConnector>();
   
                await Task.Run(() =>
                {
                    cADConnectors = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ExtractConnectors", selectedHarnessText) as List<CADConnector>;
                });
                string releaseFolderDirectory = orchestrator.step_0_process<alt_Step0_PreProcessing>("GetCatiaFolderPath") as string;
                string[] equipmentFilePaths = Directory.GetFiles(releaseFolderDirectory + "EQT_Location", "*.json");

                equipmentFiles = new List<string>();

                foreach (string file in equipmentFilePaths)
                {
                    equipmentFiles.Add(Path.GetFileName(file).Replace(".json", ""));
                }
                EquipmentBorder.Visibility = Visibility.Visible;
                EquipmentLabel.Visibility = Visibility.Visible;
                EquipmentComboBox.Visibility = Visibility.Visible;
                EquipmentComboBox.ItemsSource = equipmentFiles;
                if (equipmentFiles.Count > 0)
                {
                    EquipmentComboBox.IsDropDownOpen = true;
                }
                else
                {
                    alt_PopupMessageUtil.ShowMessage("Please Extract EQT Location from Preprocessing and try again", "Warning", MessageType.Warning);
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting connectors from Harness product");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Please select equipment location json file");
            });
        }

        /// <summary>
        /// Read equipment location json file and list in combobox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void EquipmentProductSelectionButton_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start reading equipment location Json file");
                string releaseFolderDirectory = orchestrator.step_0_process<alt_Step0_PreProcessing>("GetCatiaFolderPath") as string;
                string equipmentLocation = releaseFolderDirectory+ "EQT_Location\\" + EquipmentComboBox.SelectedItem.ToString() + ".json";
                if (File.Exists(equipmentLocation))
                {
                    await Task.Run(() =>
                    {
                        orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadEqtLocationConnectors", equipmentLocation);
                    });
                }

                CompareButton.Visibility = Visibility.Visible;
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End reading equipment location Json file");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Please select compare button to verify connector status");
            });
        }

        /// <summary>
        /// Header checkbox click event to select/deselect all rows
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HeaderCheckBox_Click(object sender, RoutedEventArgs e)
        {
            var headerCheckBox = sender as CheckBox;
            bool isChecked = headerCheckBox.IsChecked ?? false;
            // Loop through all rows and update their IsChecked property
            foreach (TableData item in DataGridTable.Items)
            {
                item.IsChecked = isChecked;

                // Refresh the DataGrid to reflect changes
                DataGridTable.Items.Refresh();
            }
        }

        /// <summary>
        /// Compare extracted connector from synoptic and equipment location json file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void CompareButton_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start comparing extracted connector info");
                if (_connectorCompareDataList != null)
                    _connectorCompareDataList.Clear();

                await Task.Run(() =>
                {
                    _connectorCompareDataList = orchestrator.Step_1_process<alt_Step1_InputProcessing>("CompareConnectorsData") as List<CADCompareData>;
                });
                DataGridTable.Visibility = Visibility.Visible;

                DataGridTable.ItemsSource = utils.GetDataForTable(_connectorCompareDataList);
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End comparing extracted connector info");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Please check compare result in above grid");
            });
        }

        /// <summary>
        /// Checkbox checked event to update the row's IsChecked property
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RowCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            TableData selectedRow = (TableData)checkBox.DataContext;

            selectedRow.IsChecked = true;
        }

        /// <summary>
        /// Checkbox unchecked event to update the row's IsChecked property
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RowCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            TableData selectedRow = (TableData)checkBox.DataContext;

            // You can handle the unchecked event here if needed
            selectedRow.IsChecked = false;
            _headerCheckBox.IsChecked = false;
        }

        /// <summary>
        /// Harness combobox selection changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HarnessComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _isFromCombobox = true;
            HarnessComboBox.ItemsSource = harnessList;
            if (HarnessComboBox.SelectedItem != null)
            {
                // Make the Button visible after a selection is made
                HarnessBorder.Visibility = Visibility.Visible;
                ReadHarnessProductButton.Visibility = Visibility.Visible;
                RefreshHarnessListButton.Visibility = Visibility.Visible;
                
            }

            
        }

        /// <summary>
        /// XXX.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>

        //private async void HarnessComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    await mainWindow.ShowOverlayAsync(async () =>
        //    {
        //        ComboBox comboBox = sender as ComboBox;
        //        string input = HarnessComboBox.Text;
        //        List<string> harnessList = new List<string>();
        //        // Filter the list of items based on the input text
        //        await Task.Run(() =>
        //        {
        //            harnessList = orchestrator.Step_1_process<alt_Step1_InputProcessing>("GetHarnessList") as List<string>;
        //        });
        //        if (harnessList == null) return;
        //        if (harnessList.Count == 0) return;

        //        var filteredItems = harnessList.Distinct().Where(item => item.StartsWith(input, StringComparison.InvariantCultureIgnoreCase)).ToList();
        //        // Update the ComboBox's ItemsSource with the filtered items
        //        HarnessComboBox.ItemsSource = filteredItems;

        //        // Open the drop-down to show suggestions
        //        //HarnessComboBox.IsDropDownOpen = true;

        //        if (HarnessComboBox.SelectedItem != null)
        //        {
        //            // Make the Button visible after a selection is made
        //            HarnessBorder.Visibility = Visibility.Visible;
        //            ReadHarnessProductButton.Visibility = Visibility.Visible;
        //            RefreshHarnessListButton.Visibility = Visibility.Visible;
        //        }
        //    });
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridTable_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            // Ensure that there are selected cells
            //if (DataGridTable.SelectedCells.Count > 0)
            //{
            //    // Get the first selected cell
            //    var selectedCell = DataGridTable.SelectedCells[0];

            //    // Get the cell's content
            //    var cellContent = selectedCell.Column.GetCellContent(selectedCell.Item);

            //    if (cellContent is TextBlock)
            //    {
            //        // Cast to TextBlock and retrieve the text value
            //        string cellValue = (cellContent as TextBlock).Text;

            //        // Display the value in a message box or use it elsewhere
            //        MessageBox.Show($"Selected Cell Value: {cellValue}");
            //    }
            //}
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridTextColumn_Closed(object sender, RoutedEventArgs e)
        {

        }

        /// <summary>
        /// Refresh connector status after adding/replacing/deleting/modifying connector in harness
        /// </summary>
        /// <param name="harnessName"> Harness name </param>
        /// <returns></returns>
        internal async Task RefreshConnectorStatus(string harnessName)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start refreshing data");
                string input = HarnessComboBox.Text;
                _connectorCompareDataList.Clear();
                await Task.Run(() =>
                {
                    _connectorCompareDataList = orchestrator.Step_1_process<alt_Step1_InputProcessing>("RefreshConnectorsStatus", input) as List<CADCompareData>;
                });
                DataGridTable.ItemsSource = utils.GetDataForTable(_connectorCompareDataList);
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End refreshing data");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Data Refreshed");
            });
        }

        /// <summary>
        /// harness combobox text changed event for filtering the items
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HarnessComboBox_TextChanged(object sender, TextChangedEventArgs e)
        {   
            if(_isFromCombobox)
            {
                _isFromCombobox = false;
                return; // Prevent recursion when updating the ItemsSource
            }
            string typedText = HarnessComboBox.Text;

            if (typedText != null && filteredItems != null)
            {
                // Filter the items based on the typed text
                var filteredList = filteredItems.Where(item => item.ToLower().Contains(typedText.ToLower())).ToList();

                // Update the ComboBox's ItemsSource
                UpdateComboboxItemSource(typedText, filteredList);
            }
        }

        /// <summary>
        /// Filter combobox items based on typed text
        /// </summary>
        /// <param name="typedText"> Typed value  </param>
        /// <param name="filteredList"> list of harness </param>
        private void UpdateComboboxItemSource(string typedText, List<string> filteredList)
        {
            HarnessComboBox.ItemsSource = filteredList;

            // Keep the typed text in the ComboBox and set dropdown open
            HarnessComboBox.IsDropDownOpen = true;
            HarnessComboBox.Text = typedText;

            // Set the caret position using the internal TextBox
            var textBox = GetComboBoxTextBox(HarnessComboBox);
            if (textBox != null)
            {
                textBox.CaretIndex = typedText.Length;  // Set the caret to the end of the text
            }
        }

        /// <summary>
        /// Open context menu on right click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridTable_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {
            var selectedRow = DataGridTable.SelectedItem as TableData;
            List<string> actions = new List<string>();
            bool isAllUnchecked = false;
            int checkedCount = CheckHowManyAreChecked(ref actions, ref isAllUnchecked);


            if (selectedRow == null) return;
            string actionValue = "";
            if (checkedCount == 0)
            {
                actionValue = selectedRow.Status;
                if (selectedRow.Action == null)
                { 
                    menuOptions(actionValue);
                    return;
                }

                if (selectedRow.Action == "To be loaded from DMA") menuOptions("AddItemFromDMA");
                else if (selectedRow.Action == "To be added from catalog") menuOptions("AddItemFromCatalog");
                else if(selectedRow.Action.Contains("DTR mismatching") && actionValue == "ToBeAdded") menuOptions("AddItemFromDMA");
                else if (selectedRow.Action.Contains("DTR mismatching: To be replaced from EQT Location")) menuOptions("ReplaceFromEQTL");
                else menuOptions(actionValue);

            }
            else if (actions.Distinct().ToList().Count == 1)
            {
                actionValue = actions[0];
                selectedMenuOptions(actionValue);
            }
            else
            {
                reframeItem.Visibility = Visibility.Visible;
                addItem.Visibility = Visibility.Collapsed;
                modifyItems.Visibility = Visibility.Collapsed;
                deleteItem.Visibility = Visibility.Collapsed;
                addSelectedItem.Visibility = Visibility.Collapsed;
                modifySelectedItem.Visibility = Visibility.Collapsed;
                deleteSelectedItem.Visibility = Visibility.Collapsed;
                UpdateAllSelectedItems.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// control visibility of context menu based on status
        /// </summary>
        /// <param name="actionValue"> action value like tobeadded etc</param>
        private void menuOptions(string actionValue)
        {
            switch (actionValue)
            {
                case "OK":
                    reframeItem.Visibility = Visibility.Visible;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeAdded":
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Visible;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeRepositioned":
                    reframeItem.Visibility = Visibility.Visible;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Visible;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeReplaced":
                    reframeItem.Visibility = Visibility.Visible;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Visible;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeDeleted":
                    reframeItem.Visibility = Visibility.Visible;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Visible;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "AddItemFromDMA":
                    AddItemFromDMA.Visibility = Visibility.Visible;
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "AddItemFromCatalog":
                    AddItemFromCatalog.Visibility = Visibility.Visible;
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    ReplaceFromEQTL.Visibility = Visibility.Collapsed;
                    break;
                case "ReplaceFromEQTL":
                    ReplaceFromEQTL.Visibility = Visibility.Visible;
                    AddItemFromCatalog.Visibility = Visibility.Collapsed;
                    reframeItem.Visibility = Visibility.Visible;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    AddItemFromDMA.Visibility = Visibility.Collapsed;
                    break;
            }
        }


        /// <summary>
        /// control visibility of context menu based on status
        /// </summary>
        /// <param name="actionValue"> action value like tobeadded etc</param>
        private void selectedMenuOptions(string actionValue)
        {
            switch (actionValue)
            {
                case "OK":
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeAdded":
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Visible;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Collapsed;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeRepositioned":
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Visible;
                    deleteSelectedItem.Visibility = Visibility.Visible;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeReplaced":
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Visible;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    break;
                case "ToBeDeleted":
                    reframeItem.Visibility = Visibility.Collapsed;
                    addItem.Visibility = Visibility.Collapsed;
                    modifyItems.Visibility = Visibility.Collapsed;
                    deleteItem.Visibility = Visibility.Collapsed;
                    addSelectedItem.Visibility = Visibility.Collapsed;
                    modifySelectedItem.Visibility = Visibility.Collapsed;
                    deleteSelectedItem.Visibility = Visibility.Visible;
                    UpdateAllSelectedItems.Visibility = Visibility.Collapsed;
                    break;
            }
        }

        /// <summary>
        /// Count how many rows are checked in the datagrid
        /// </summary>
        /// <param name="actions"> action value populated</param>
        /// <param name="isUnchecked"> bool value if checked or no </param>
        /// <returns></returns>
        private int CountCheckedItems(ref List<string> actions, ref bool isUnchecked)
        {
            int checkedCount = 0;
            foreach (TableData item in DataGridTable.ItemsSource)
            {
                if (item != null && item.IsChecked)
                {
                    actions.Add(item.Status);
                    checkedCount++;
                }
                else { isUnchecked = true; }
            }

            return checkedCount;
        }

        /// <summary>
        /// Header checkbox loaded event to get the reference
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HeaderCheckBox_Loaded(object sender, RoutedEventArgs e)
        {
            _headerCheckBox = sender as CheckBox;
        }

        /// <summary>
        /// Count how many rows are checked in the datagrid
        /// </summary>
        /// <param name="actions"> action value</param>
        /// <param name="isUnchecked"> if checked or no</param>
        /// <returns></returns>
        private int CheckHowManyAreChecked(ref List<string> actions, ref bool isUnchecked)
        {
            int checkedItemsCount = CountCheckedItems(ref actions, ref isUnchecked);
            return checkedItemsCount;
        }

        /// <summary>
        /// Get internal textbox of combobox
        /// </summary>
        /// <param name="comboBox"> combobox </param>
        /// <returns></returns>
        private TextBox GetComboBoxTextBox(ComboBox comboBox)
        {
            return comboBox.Template.FindName("PART_EditableTextBox", comboBox) as TextBox;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        /// <summary>
        /// Equipment combobox selection changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EquipmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (EquipmentComboBox.SelectedItem != null)
            {
                // Make the Button visible after a selection is made
                EquipmentProductSelectionButton.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Equipment combobox text changed event for filtering the items
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EquipmentComboBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string typedText = HarnessComboBox.Text;

            // Filter the items based on the typed text
            var filteredList = equipmentFiles.Where(item => item.ToLower().Contains(typedText.ToLower())).ToList();

            // Update the ComboBox's ItemsSource
            EquipmentComboBox.ItemsSource = equipmentFiles;

            // Keep the typed text in the ComboBox and set dropdown open
            EquipmentComboBox.IsDropDownOpen = true;
            EquipmentComboBox.Text = typedText;

            // Set the caret position using the internal TextBox
            var textBox = GetComboBoxTextBox(EquipmentComboBox);
            if (textBox != null)
            {
                textBox.CaretIndex = typedText.Length;  // Set the caret to the end of the text
            }
        }

        /// <summary>
        /// Refresh harness list from CATIA if user opened/closed harness product
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void RefreshHarnessList_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            { 
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start refreshing opened harness list");
                List<string> HarnessList = new List<string>();
                await Task.Run(() =>
                {
                    HarnessList = orchestrator.Step_1_process<alt_Step1_InputProcessing>("RefreshHarnessList") as List<string>;
                });
                if(HarnessList != null)
                {
                    harnessList = HarnessList.Distinct().ToList();
                    ListHarnessInComboBox(harnessList);
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End refreshing opened harness list");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Please check compare result in above grid");
            });
        }

        /// <summary>
        /// Refresh connector status after adding/replacing/deleting/modifying connector in harness
        /// </summary>
        /// <param name="harnessName"></param>
        /// <returns></returns>
        private async Task RefreshConnectortatus(string harnessName)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start refresh operation");
            _connectorCompareDataList.Clear();
            await Task.Run(() =>
            {
                _connectorCompareDataList = orchestrator.Step_1_process<alt_Step1_InputProcessing>("RefreshConnectorsStatus", harnessName) as List<CADCompareData>;
            });
            //DataGridTable.Items.Clear();
            DataGridTable.ItemsSource = utils.GetDataForTable(_connectorCompareDataList);
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End refresh operation");
        }

        /// <summary>
        /// Extract EQT location json files from CATIA and store in local folder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ExtractEQTLocation_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the EQT connectors data.");
                await Task.Run(() =>
                {
                    orchestrator.step_0_process<alt_Step0_PreProcessing>("ExportEqtLocation");
                });
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the EQT connectors data");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: EQT connectors are stored in the default location.");
            });
        }
    }
}
