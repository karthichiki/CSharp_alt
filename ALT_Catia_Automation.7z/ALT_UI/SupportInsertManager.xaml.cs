﻿using ApplicationLayer;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ALT_Data_Preparation;
using ALT_Utilities;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for SupportInsertManager.xaml
    /// </summary>
    public partial class SupportInsertManager : UserControl
    {

        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        private alt_Automation_Orchestrator orchestrator;
        private alt_Utilities utils;
        public SupportInsertManager()
        {
            InitializeComponent();
            utils = new alt_Utilities();
            orchestrator = new alt_Automation_Orchestrator();
        }

        /// <summary>
        /// Event handler for the ImageButton click.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ImageButton_Click(object sender, RoutedEventArgs e)
        {
            if (MultibranchableTextBox.Text == string.Empty ||
                MultibranchableTextBox.Text == "No file selected")
            {
                alt_PopupMessageUtil.ShowMessage("Select the Multibranchable before inserting support.", "Warning", MessageType.Warning);
                return;
            }

            string selectedSupportName = string.Empty;
            if (sender is ImageButton imageButton)
            {
                selectedSupportName = imageButton.TextContent;
            }

            bool repeat = false;
            do
            {
                await mainWindow.ShowOverlayAsync(async () =>
                {
                    await Task.Run(() =>
                    {
                        orchestrator.Step_1_process<alt_Step1_InputProcessing>("InsertSelectedSupport", selectedSupportName, repeat);
                    });
                });

                var result = alt_PopupMessageUtil.ShowMessageYesNo(
                    "Do you want to place this support at a different location?",
                    "Repeat Insert",
                    MessageType.Question);

                repeat = (result == MessageBoxResult.Yes);
            }
            while (repeat);
        }

        /// <summary>
        /// Event handler for selecting the multibranchable part.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectMultibranchable_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Multibranchable");
            object returnMsg = null;
            await Task.Run(() =>
            {
                utils.BringApplicationToFront("CNEXT");
                returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectMultiBranchableForSupportInsertion");
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Multibranchable");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection Failed");
                return;
            }
            else
            {
                MultibranchableTextBox.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Multibranchable");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection is Successful");
        }

        /// <summary>
        /// Event handler for selecting the geometrical bundle.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectGeometricalBundle_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Multibranchable");
            object returnMsg = null;
            await Task.Run(() =>
            {
                utils.BringApplicationToFront("CNEXT");
                returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectMultiBranchableForSupportInsertion");
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Multibranchable");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection Failed");
                return;
            }
            else
            {
                MultiBranchableTxtBox.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Multibranchable");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection is Successful");
        }

        /// <summary>
        /// function to insert support for Geometrical bundle
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectGeometricalBundleInsertSupport_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Multibranchable");
            object returnMsg = null;
            await Task.Run(() =>
            {
                utils.BringApplicationToFront("CNEXT");
                returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectMultiBranchableForSupportInsertion");
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Multibranchable");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection Failed");
                return;
            }
            else
            {
                MultiBranchableTxtBoxInsertSupport.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Multibranchable");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection is Successful");
        }

        /// <summary>
        /// Selection of section cuts.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectSectionCuts_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the section cut part");
            object returnMsg = null;
            await Task.Run(() =>
            {
                utils.BringApplicationToFront("CNEXT");
                returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectSectionCutPart");
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the section cut part");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Section cut part selection Failed");
                return;
            }
            else
            {
                SectionCutsPartName.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Multibranchable");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection is Successful");
        }

        /// <summary>
        /// Function to update support position
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void UpdateSupportPosition_Click(object sender, RoutedEventArgs e)
        {
            if (SectionCutsPartName.Text == string.Empty ||
                SectionCutsPartName.Text == "No file selected" ||
                MultiBranchableTxtBox.Text == string.Empty ||
                MultiBranchableTxtBox.Text == "No file selected")

            {
                alt_PopupMessageUtil.ShowMessage("Select the Multibranchable and the sectionPart before updating support position.", "Warning", MessageType.Warning);
                return;
            }

            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateSupportsPosition");
                });
            });
        }


        /// <summary>
        /// Event handler for selecting the branchable.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectBranchable_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Branchable");
            object returnMsg = null;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectBranchableForSupportUpdation");
                });
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Branchable");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Section cut part selection Failed");
                return;
            }
            else
            {
                BranchableTxtBox.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Branchable");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Branchable selection is Successful");
        }

        /// <summary>
        /// Event handler for selecting the reference support.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ReferenceSupport_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Reference Support");
            object returnMsg = null;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectReferenceSupportSupportUpdation");
                });
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Reference Support");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Reference Support selection Failed");
                return;
            }
            else
            {
                ReferenceSupportTextBox.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Reference Support");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Reference Support selection is Successful");
        }

        /// <summary>
        /// Event handler for selecting the multiple supports.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ListofSupport_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Supports");
            object returnMsg = null;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectSupportsForSupportUpdation");
                });
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Supports");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Supports selection Failed");
                return;
            }
            else
            {
                List_of_Support_TextBox.Text = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Supports");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Supports selection is Successful");
        }

        /// <summary>
        /// Function to update line support position
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void LineSupportPosition_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start updating the Line Support Position");
            object returnMsg = null;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateLineSupportPosition");
                });
            });
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End updating the Line Support Position");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Updating the Line Support Position Failed");
                return;
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End updating the Line Support Position");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Updating the Line Support Position is Successful");
        }

        /// <summary>
        /// Function to insert supports for all section cuts
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void InsertSupportsforallsectioncuts_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    orchestrator.Step_1_process<alt_Step1_InputProcessing>("InsertSupportsForAllSectionsCuts");
                });
            });
        }
    }
}
