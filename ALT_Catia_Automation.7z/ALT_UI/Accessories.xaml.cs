﻿using ALT_Data_Model;
using ALT_Data_Model.Accessories_Data_Model;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Preparation;
using ALT_Logging;
using ALT_Utilities;
using ApplicationLayer;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for Accessories.xaml
    /// </summary>
    public partial class Accessories : UserControl
    {

        private alt_Automation_Orchestrator orchestrator;
        private alt_Utilities utils;
        private List<string> accessoriesList = null;
        private List<string> additionalAccessory = null;
        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        private string harnessName = string.Empty;
        private string bundleSegment = string.Empty;
        private List<string> accessoryList = null;
        private List<string> couplerList = null;
        private List<string> onlyDTRList = null;
        internal FilePaths jsonFilePaths = null;
        List<CableGland> cableGlandList = null;
        private Dictionary<string, string> mapSheets = new Dictionary<string, string>();
        
        private List<string> shortLongThread = null;
        private List<string> angle4590 = null;
        private List<string> finalList = null;
        private List<string> corrugatedConduitJunction = null;
        private List<CableGland> backShellMetalPlaceCableGland = null;
        private List<CableGland> oringFlatsealCableGland = null;
        private List<CableGland> cporcnpCableGland = null;
        private List<string> threadSizes = null;
        List<string> additionalComponentDTR = new List<string>();
        private string sleevdiameter = string.Empty;
        List<string> bundleSegmentDetails = new List<string>();
        private double harnessdiameter;
        public PL3_Combined _3PL { get; set; }
        public Dictionary<string, List<PL3_Global>> _3PL_Global { get; set; }
        alt_JsonReaderService alt_JsonReaderService;
        bool addSwivelAdapter = false;
        string importStatus = string.Empty;
        public Accessories()
        {
            InitializeComponent();
            utils = new alt_Utilities();
            orchestrator = new alt_Automation_Orchestrator();
            accessoriesList = new List<string>() { "Cable Gland", "Corrugated Conduit Junction", "Coupler" };
            additionalAccessory = new List<string>() { "BLIND PLUG", "REDUCER - EXTENSION WITH SEAL" , "FLAT SEAL", "REDUCER - EXTENSION WITH SEAL", "FIREWALL COUPLER", "EMC ADAPTER" };
            corrugatedConduitJunction = new List<string>() { "DTR T coupler", "DTR Y coupler", "DTR Extender" ,  "DTR Reducer", "TERMINAL SLEEVE" };
            AccesseriesComboBox.ItemsSource = accessoriesList;
            AdditionalComponents.ItemsSource = additionalAccessory;
            CorrugatedConduitJunctionSelection.ItemsSource = corrugatedConduitJunction;
            CableGland.Visibility = Visibility.Collapsed; // Hide CableGland by default
            alt_JsonReaderService = alt_JsonReaderService.GetInstance();
            MapSheets();
            
        }

        /// <summary>
        /// Maps the sheet names to their corresponding identifiers in json file.
        /// </summary>
        private void MapSheets()
        {
            mapSheets.Add("STRAIGHT SWIVEL COUPLER LT", "StraightSwivelCouplerLT");
            mapSheets.Add("STRAIGHT COUPLER LT", "StraightCouplerLT");
            mapSheets.Add("STRAIGHT SWIVEL COUPLER ST", "StraightSwivelCouplerST");
            mapSheets.Add("STRAIGHT COUPLER ST", "StraightCouplerST");
            mapSheets.Add("STRAIGHT COUPLER STRAIN REL LT", "StraightCouplerStrainReliefLT");
            mapSheets.Add("STRAIGHT COUPLER STRAIN REL ST", "StraightCouplerStrainReliefST");
            //mapSheets.Add("STRAIGHT COUPLER STRAIN RELIEF LT", "StraightCouplerStrainReliefLT");
            //mapSheets.Add("STRAIGHT COUPLER STRAIN RELIEF ST", "StraightCouplerStrainReliefST");
            mapSheets.Add("STR SWIVEL COUPLER ST EXT-BODY", "StrSwivelCouplerSTExtBody");
            mapSheets.Add("STRAIGHT FEMALE COUPLER", "StraightFemaleCoupler");
            mapSheets.Add("90dg COUPLER LT", "Deg90CouplerLT");
            mapSheets.Add("90dg SWIVEL COUPLER LT", "Deg90SwivelCouplerLT");
            mapSheets.Add("90dg COUPLER ST", "Deg90CouplerST");
            mapSheets.Add("90dg SWIVEL COUPLER ST", "Deg90SwivelCouplerST");
            mapSheets.Add("45dg COUPLER LT", "Deg45CouplerLT");
            mapSheets.Add("45dg SWIVEL COUPLER LT", "Deg45SwivelCouplerLT");
            mapSheets.Add("45dg COUPLER ST", "Deg45CouplerST");
            mapSheets.Add("45dg SWIVEL COUPLER ST", "Deg45SwivelCouplerST");
            mapSheets.Add("EMC ADAPTER", "EmcAdapter");
            mapSheets.Add("FIREWALL COUPLER", "FirewallCoupler");
            mapSheets.Add("SWIVEL ADAPTER", "SwiveledAdapter");
            mapSheets.Add("BLIND PLUG", "BlindPlug");
            mapSheets.Add("REDUCER - EXTENSION WITH SEAL", "ReducerExtender");
            mapSheets.Add("FLAT SEAL", "FlatSeal");
            mapSheets.Add("DTR T coupler", "Tcoupler");
            mapSheets.Add("DTR reducer", "Reducer");
            mapSheets.Add("DTR Straight coupler", "Straightcoupler");
            mapSheets.Add("DTR Extender", "Straightcoupler");
            mapSheets.Add("DTR Y coupler", "Ycoupler"); 
            mapSheets.Add("TERMINAL SLEEVE", "TerminalSleev");
            mapSheets.Add("DTR Reducer", "Reducer");
        }

        /// <summary>
        /// reads the 3PL and 3PL Projet json files and updates the dictionaries.
        /// </summary>
        public void Update3PLDictionaries()
        {
            string PL3JsonFilePath = mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path;
            _3PL = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Read3PLJson", PL3JsonFilePath) as PL3_Combined;
            string PL3ProjetJsonFilePath = mainWindow.my_PreProcessing.jsonFilePaths.PL3_Projet_Path;
            _3PL_Global = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Read3PLProjetJson", PL3ProjetJsonFilePath) as Dictionary<string, List<PL3_Global>>;
        }

        /// <summary>
        /// Selects the multibranchable from CATIA.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectMultibranchable_Click(object sender, RoutedEventArgs e)
        {
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Multibranchable");
            object returnMsg = null;
            object isMultibranchable = null;
            UpdateStackPanelStatesEnomoly(new List<string> { "Base" });
            UpdateStackPanelStatesEnomolyCoupler(new List<string> { "Base" });
            BundleSegmentTextBox.Text = "No file selected";
            await Task.Run(() =>
            {
                utils.BringApplicationToFront("CNEXT");
                returnMsg = orchestrator.step_3_process<alt_Step3_Accessorization>("SelectMultiBranchable") as string;
                utils.BringApplicationToFront("ALT_UI");
            });
            ClearAllAddedValues();
            if (returnMsg == "")
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Multibranchable");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection Failed");
                return;
            }
            else
            {
                MultibranchableTextBox.Text = returnMsg.ToString();
                harnessName = returnMsg.ToString();
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Multibranchable");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection is Successful");
            
        }

        /// <summary>
        /// Selects the bundle segment from CATIA.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectBundleSegment_Click(object sender, RoutedEventArgs e)
        {
            
            if (MultibranchableTextBox.Text == string.Empty)
            {
                alt_PopupMessageUtil.ShowMessage("Select the Multibranchable before selecting the Branchable.", "Warning", MessageType.Warning);
                return;
            }
            SleeveSizeInput.Visibility = Visibility.Collapsed;
            SleeveSize.Visibility = Visibility.Collapsed;
            UpdateStackPanelStatesEnomoly(new List<string> { "Base" });
            UpdateStackPanelStatesEnomolyCoupler(new List<string> { "Base" });
            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Bundle Segment");
            object returnMsg = null;
            List<string> BundleSegmentDetails = new List<string>();
            if (AccesseriesComboBox.Text == "Cable Gland")
            {
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("ALT_UI");
                    MessageBox.Show("Please select a bundle segment in catia", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    utils.BringApplicationToFront("CNEXT");
                    bundleSegmentDetails = orchestrator.step_3_process<alt_Step3_Accessorization>("SelectBundleSegment") as List<string>;
                });
                if (bundleSegmentDetails != null)
                {
                    BundleSegmentTextBox.Text = bundleSegmentDetails[0];
                    harnessdiameter = double.Parse(bundleSegmentDetails[1]);
                }

            }
            else
            {
                await Task.Run(() =>
                {
                    MessageBox.Show("Please select a sleeve in catia", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.step_3_process<alt_Step3_Accessorization>("SelectCorrugatedSleev");
                });
            }
            ClearAllAddedValues();
            if (returnMsg == null)
            {
                ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the BundleSegment");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: BundleSegment selection Failed");
                return;
            }
            else
            {
                string dtrVal = string.Empty;
                string returnValue = returnMsg.ToString();
                BundleSegmentTextBox.Text = returnValue;
                if (returnValue.Contains("-"))
                {
                    dtrVal = returnValue.Split('-')[0].Replace(" ","");
                    sleevdiameter = FindSleeveDiameterUsingDTR(dtrVal);
                }
                else
                {
                    if(returnValue.Contains("."))
                    {
                        dtrVal = returnValue.Replace(" ", "").Split('.')[0];
                        sleevdiameter = FindSleeveDiameterUsingDTR(dtrVal);
                    }
                    else
                    {
                        dtrVal = returnValue.Replace(" ", "");
                        sleevdiameter = FindSleeveDiameterUsingDTR(dtrVal);
                    }
                }

                if (sleevdiameter == "")
                {
                    MessageBox.Show("Please enter the sleev size", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    SleeveSizeInput.Visibility = Visibility.Visible;
                    SleeveSize.Visibility = Visibility.Visible;
                }

            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the BundleSegment");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: BundleSegment selection is Successful");
            
        }

        private void ClearAllAddedValues()
        {
            CorrugatedConduitJunctionSelection.SelectedItem = null;
            FilteredDTR.ItemsSource = null;
            FilteredDTR.SelectedItem = false;
            FilteredDTRDescription.Text = string.Empty;
        }
        /// <summary>
        /// Finds the sleeve diameter using the DTR value from the Sleev json file.
        /// </summary>
        /// <param name="dtr"> dtr name </param>
        /// <returns></returns>
        private string FindSleeveDiameterUsingDTR(string dtr)
        {
            PL3_Combined _3PL = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Read3PLJson", mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path) as PL3_Combined;
            string sleevSize = string.Empty;
            try
            {
                sleevSize = _3PL.CorrugatedSleeve.Where(kvp => kvp.Value.Any(abc => abc.DTR.Replace(" ","") == dtr))
                                    .ToDictionary(
                                        kvp => kvp.Key,
                                        kvp =>
                                        {
                                            return kvp.Value
                                                .Where(abc => abc.DTR.Replace(" ", "") == dtr)
                                                .FirstOrDefault().SIZE;
                                        }
                                    ).First().Value;
            }
            catch
            {
                return string.Empty;
            }
            
            return sleevSize;
        }

        /// <summary>
        /// Selects the accessory from the combobox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void AccesseriesCombobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(AccesseriesComboBox.SelectedItem == null) return;
            Update3PLDictionaries();
            if (_3PL == null || _3PL_Global == null || _3PL.CorrugatedSleeve == null)
            {
                alt_PopupMessageUtil.ShowMessage("Extract 3PL and 3PL Projet File from Pre-Processing Tab", "Warning", MessageType.Warning);
                AccesseriesComboBox.SelectedValue = null;
                return;
            }
            List<string> inputs = new List<string>();
            inputs.Add(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
            if (AccesseriesComboBox.SelectedItem == "Cable Gland") inputs.Add("Cable Gland");
            else if (AccesseriesComboBox.SelectedItem == "Coupler") inputs.Add("Coupler");
            else if (AccesseriesComboBox.SelectedItem == "Corrugated Conduit Junction") inputs.Add("Corrugated Conduit Junction");

            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting Accessory");
            object isMultibranchable = null;
            if (AccesseriesComboBox.SelectedItem == "FIREWALL COUPLER" || AccesseriesComboBox.SelectedItem == "EMC ADAPTER")
            {
                await Task.Run(() =>
                {
                    onlyDTRList = orchestrator.step_3_process<alt_Step3_Accessorization>("Read_Accessory_File_DTRs", inputs) as List<string>;
                });
            }
            else if (AccesseriesComboBox.SelectedItem == "Cable Gland")
            {
                BundleSegmentTextBox.Text = "No file selected";
                await Task.Run(() =>
                {
                    cableGlandList = orchestrator.step_3_process<alt_Step3_Accessorization>("Read_Accessory_File_CableGland", inputs) as List<CableGland>;
                });
            }
            else if (AccesseriesComboBox.SelectedItem == "Coupler" || AccesseriesComboBox.SelectedItem == "Corrugated Conduit Junction")
            {
                BundleSegmentTextBox.Text = "No file selected";
                await Task.Run(() =>
                {
                    accessoryList = orchestrator.step_3_process<alt_Step3_Accessorization>("Read_Accessory_File_FrontPage", inputs) as List<string>;
                });
            }
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting Accessory");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Accessory extraction is Successful");
            ShowStacksBasedOnAccessorySelection();
            ClearAllAddedValues();
        }

        /// <summary>
        /// Gets the json path for the given file name.
        /// </summary>
        /// <param name="name"> file name </param>
        /// <returns></returns>
        private string GetJsonPath(string name)
        {
            string folderPath = orchestrator.step_0_process<alt_Step0_PreProcessing>("GetCatiaFolderPath") as string;
            string jsonFilePath = System.IO.Path.Combine(folderPath, name);
            return jsonFilePath;
        }

        /// <summary>
        /// Manage visibility of the elements based on the selection in UI
        /// </summary>
        private void ShowStacksBasedOnAccessorySelection()
        {
            MainBorder.Visibility = Visibility.Visible;
            AdditionalAccessories.Visibility = Visibility.Collapsed;
            UpdateStackPanelStatesEnomoly(new List<string> { "Base" });
            UpdateStackPanelStatesEnomolyCoupler(new List<string> { "Base" });
            CorrugatedConduitJunctionSelection.Text = string.Empty;
            if (AccesseriesComboBox.SelectedItem == "Cable Gland")
            {
                CableGland.Visibility = Visibility.Visible;
                Coupler.Visibility = Visibility.Collapsed;
                CorrugatedConduitJunction.Visibility = Visibility.Collapsed;
            }
            else if (AccesseriesComboBox.SelectedItem == "Coupler")
            {
                Coupler.Visibility = Visibility.Visible;
                CableGland.Visibility = Visibility.Collapsed;
                CorrugatedConduitJunction.Visibility = Visibility.Collapsed;
            }
            else if (AccesseriesComboBox.SelectedItem == "Corrugated Conduit Junction")
            {
                CorrugatedConduitJunction.Visibility = Visibility.Visible;
                Coupler.Visibility = Visibility.Collapsed;
                CableGland.Visibility = Visibility.Collapsed;
                MessageBox.Show("Maximum 6m length for corrugated sleeve. If more than 6m, coupler must be added (straigth, T or Y)", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            SleeveSizeInput.Visibility = Visibility.Collapsed;
            SleeveSize.Visibility = Visibility.Collapsed;
            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
        }

        ///////////////////////////////// Cable Gland elements /////////////////////////////////////////////////////////

        /// <summary>
        /// checkbox for backshell selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <exception cref="InvalidOperationException"></exception>
        private async void BackshellCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (ShowPreSelectionMessage())
            {
                BackShell.IsChecked = false;
                return;
            }
            MessageBox.Show("When cable gland is mounted on a connector backshell, then O-ring must be used. If cable gland is provided with a flat seal then this one must be removed and replaced by the O-Ring", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            if (cableGlandList != null && cableGlandList.Count > 0)
            {
                backShellMetalPlaceCableGland = cableGlandList.Where(cg => cg.Type == "SHORT" && cg.SealType == "O-RING").ToList();
            }
            else
            {
                
                throw new InvalidOperationException("Cable Gland list is empty or not initialized.");
            }
            if (MetalPlate.IsChecked == true)
            {
                MetalPlate.IsChecked = false;
                UpdateStackPanelStatesEnomoly(new List<string> { "BSMP" });
            }
            UpdateStackPanelStates();
        }

        /// <summary>
        /// Uncheck function for backshell
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BackShellCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateStackPanelStatesEnomoly(new List<string> { "BSMP" });
            UpdateStackPanelStates();
        }

        /// <summary>
        /// checkbox for metal plate selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <exception cref="InvalidOperationException"></exception>
        private async void MetalPlateCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (ShowPreSelectionMessage())
            {
                MetalPlate.IsChecked = false;
                return;
            }
            MessageBox.Show("When cable gland is mounted on a plate, then flat seal must be used. If cable gland is provided with a O-Ring then this one must be removed and replaced by the flat seal", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            if (cableGlandList != null && cableGlandList.Count > 0)
            {
                backShellMetalPlaceCableGland = cableGlandList.Where(cg => cg.Type == "LONG" && cg.SealType == "FLAT").ToList();
            }
            else
            {
                throw new InvalidOperationException("Cable Gland list is empty or not initialized.");
            }
            if (BackShell.IsChecked == true)
            {
                BackShell.IsChecked = false;
                UpdateStackPanelStatesEnomoly(new List<string> { "BSMP" });
            }

            UpdateStackPanelStates();
        }

        /// <summary>
        /// Uncheck function for metal plate
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MetalPlateCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateStackPanelStatesEnomoly(new List<string> { "BSMP" });
            UpdateStackPanelStates();
        }

        /// <summary>
        /// Check function for O-Ring selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <exception cref="InvalidOperationException"></exception>
        private void ORingCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // filter to SHORT and O-Ring
            if (backShellMetalPlaceCableGland != null && backShellMetalPlaceCableGland.Count > 0)
            {
                if (BackShell.IsChecked == false) 
                {
                    MessageBox.Show("Flat should be selected for metal plate option", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    MetalPlate.IsChecked = false; // Ensure MetalPlate is checked
                    return;
                }
                else
                {
                    oringFlatsealCableGland = backShellMetalPlaceCableGland.Where(cg => cg.Type == "SHORT" && cg.SealType == "O-RING").ToList();
                } 
            }
            else
            {
                throw new InvalidOperationException("Cable Gland list is empty or not initialized.");
            }
            UpdateStackPanelStates();
            if (FlatSeal.IsChecked == true)
            {
                FlatSeal.IsChecked = false;
                UpdateStackPanelStatesEnomoly(new List<string> { "ORFS" });
            }
        }

        /// <summary>
        /// Uncheck function for O-Ring
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ORingCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateStackPanelStatesEnomoly(new List<string> { "ORFS" });
            UpdateStackPanelStates();
        }

        /// <summary>
        /// check function for Flat Seal selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FlatSealCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            
            if (MetalPlate.IsChecked == false)
            {
                MessageBox.Show("O Ring should be selected for backshell option", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                BackShell.IsChecked = false; // Ensure BackShell is checked
                return;
            }
            else
            {
                oringFlatsealCableGland = backShellMetalPlaceCableGland.Where(cg => cg.Type == "LONG" && cg.SealType == "FLAT").ToList();
            }
            UpdateStackPanelStates();
            if (ORing.IsChecked == true)
            {
                ORing.IsChecked = false;
                UpdateStackPanelStatesEnomoly(new List<string> { "ORFS" });
            }
        }

        /// <summary>
        /// Uncheck function for Flat Seal
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FlatSealCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateStackPanelStatesEnomoly(new List<string> { "ORFS" });
            UpdateStackPanelStates();
        }

        /// <summary>
        /// check function for Cable predisposed selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <exception cref="InvalidOperationException"></exception>
        private async void CPCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            // filter to SHORT and O-Ring
            if (oringFlatsealCableGland != null && oringFlatsealCableGland.Count > 0)
            {
                cporcnpCableGland = oringFlatsealCableGland.Where(cg =>
                    double.TryParse(cg.MinCableDiameter, out double minDia) &&
                    double.TryParse(cg.MaxCableDiameter, out double maxDia) &&
                    harnessdiameter >= minDia &&
                    harnessdiameter <= maxDia).ToList();
            }
            else
            {
                throw new InvalidOperationException("Cable Gland list is empty or not initialized.");
            }
            NotPredisposed.IsChecked = false; // Uncheck NotPredisposed when CP is checked
            UpdateStackPanelStates();
            /// update DTR
            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
            List<string> opDTRs = new List<string>();
            foreach (CableGland input in cporcnpCableGland)
            {
                opDTRs.Add(input.DTR + "-" + input.Supplier);
            }
            FilteredDTR.ItemsSource = opDTRs;
        }

        /// <summary>
        /// Uncheck function for Cable predisposed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void CPCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateStackPanelStates();
        }

        /// <summary>
        /// check function for Cable not predisposed selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <exception cref="InvalidOperationException"></exception>
        private async void CNPCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            if (oringFlatsealCableGland != null && oringFlatsealCableGland.Count > 0)
            {
                cporcnpCableGland = oringFlatsealCableGland.Where(cg =>
                      double.TryParse(cg.MinCableDiameter, out double minDia) &&
                      double.TryParse(cg.MaxCableDiameter, out double maxDia) &&
                      harnessdiameter >= minDia &&
                      harnessdiameter <= maxDia).ToList();
               
            }
            else
            {
                throw new InvalidOperationException("Cable Gland list is empty or not initialized.");
            }
            Predisposed.IsChecked = false; // Uncheck Predisposed when CNP is checked
            UpdateStackPanelStates();

            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
            List<string> opDTRs = new List<string>();
            foreach (CableGland input in cporcnpCableGland)
            {
                opDTRs.Add(input.DTR + "-" + input.Supplier);
            }
            FilteredDTR.ItemsSource = opDTRs;
        }

        /// <summary>
        /// Uncheck function for Cable not predisposed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void CNPCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateStackPanelStates();
        }

        /// <summary>
        /// update the states of the stack panels based on the selections
        /// </summary>
        private void UpdateStackPanelStates()
        {
            bool isFirstGroupChecked = (BackShell.IsChecked == true || MetalPlate.IsChecked == true);
            ORingOrFlatSeal.IsEnabled = isFirstGroupChecked;
            if(isFirstGroupChecked)
            {
                DTRCollection.IsEnabled = true;
                FilteredDTR.SelectedItem = null;
                FilteredDTRDescription.Text = string.Empty;
            }

            bool isSecondGroupChecked = (ORing.IsChecked == true || FlatSeal.IsChecked == true);
            CPOrCNP.IsEnabled = isFirstGroupChecked && isSecondGroupChecked;

            //bool isThirdGroupChecked = (Predisposed.IsChecked == true || NotPredisposed.IsChecked == true);
            //DTRCollection.IsEnabled = isFirstGroupChecked && isSecondGroupChecked && isThirdGroupChecked;

        }

        /// <summary>
        /// update the states of the stack panels based on the selections anomaly example Base means reset all checkbox to false
        /// </summary>
        /// <param name="selections"> Levels to be reset </param>
        private void UpdateStackPanelStatesEnomoly(List<string> selections)
        {
            if (selections.Contains("Base"))
            {
                BackShell.IsChecked = false;
                MetalPlate.IsChecked = false;
                ORing.IsChecked = false;
                FlatSeal.IsChecked = false;
                Predisposed.IsChecked = false;
                NotPredisposed.IsChecked = false;
            }

            if (selections.Contains("BSMP"))
            {
                ORing.IsChecked = false;
                FlatSeal.IsChecked = false;
                Predisposed.IsChecked = false;
                NotPredisposed.IsChecked = false;
            }

            if (selections.Contains("ORFS"))
            {
                Predisposed.IsChecked = false;
                NotPredisposed.IsChecked = false;
            }

        }

        /// <summary>
        /// combobox selection changed event to  select DTR
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FilteredDTR_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(FilteredDTR.SelectedItem == null) return;
            string dtr = string.Empty;
            if (FilteredDTR.SelectedItem.ToString().Contains("-"))
            { 
                dtr = FilteredDTR.SelectedItem.ToString().Split('-')[0].Replace(" ", "");
            }
            string retValue = CompareWith3PLFile(dtr);
            FilteredDTRDescription.Text = retValue;
        }

        /// <summary>
        /// Submit DTR for cable gland to import from DMA
        /// </summary>
        private async void SubmitCableGland_Click()
        {
            List<string> inputs = new List<string>();
            inputs.Add(harnessName);
            string dtr = string.Empty;
            if (FilteredDTR.Text.Contains("-"))
            {
                dtr = FilteredDTR.Text.Split('-')[0].Replace(" ", "");
            }
            else
            {
                dtr =FilteredDTR.Text;
            }
            inputs.Add(dtr);

            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Starting importing DTR from DMA");
            
            await mainWindow.ShowOverlayAsync(async () =>
            {
                harnessName = MultibranchableTextBox.Text;
                await Task.Run(() =>
                {
                    importStatus = orchestrator.step_3_process<alt_Step3_Accessorization>("ImportDTRFromDMA", inputs) as string;
                });
            });
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End importing DTR from DMA");

            UpdateApplicationStatus(dtr, importStatus);

            ComponentsOnAddedAccessory.Visibility = Visibility.Visible;
        }

        //////////////////////////////////////////////// Coupler elements ////////////////////////////////////////////////////////////////////:
        /// <summary>
        /// checkbox for backshell selection for coupler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void CouplerBackshellCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (ShowPreSelectionMessage())
            {
                CouplerBackShell.IsChecked = false;
                return; 
            }
            MessageBox.Show("When coupler is mounted on a connector backshell, then O-ring must be used. If coupler is provided with a flat seal then this one must be removed and replaced by the O-Ring", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            if (CouplerMetalPlate.IsChecked == true)
            {
                CouplerMetalPlate.IsChecked = false;
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "BSMP" });
            }
            UpdateCouplerStates();

        }

        /// <summary>
        /// uncheck function for backshell for coupler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CouplerBackShellCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// checkbox for metal plate selection for coupler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CouplerMetalPlateCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (ShowPreSelectionMessage())
            {
                CouplerMetalPlate.IsChecked = false;
                return;
            }
            MessageBox.Show("When Coupler is mounted on a  plate, then flat seal must be used. If coupler is provided with a o-ring then this one must be removed and replaced by the flat seal", "Warning", MessageBoxButton.OK, MessageBoxImage.Information);
            if (CouplerBackShell.IsChecked == true)
            {
                CouplerBackShell.IsChecked = false;
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "BSMP" });
            }
            UpdateCouplerStates(); 
        }

        /// <summary>
        /// uncheck function for metal plate for coupler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CouplerMetalPlateCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Straight coupler selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StraightCouplerCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            couplerList = accessoryList.Where(c => c.Contains("STRAIGHT") || c.Contains("STR")).ToList();
            if (ElbowCoupler.IsChecked == true)
            {
                ElbowCoupler.IsChecked = false;
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "STEL" });
            }
            UpdateCouplerStates();
        }

        /// <summary>
        /// uncheck function for Straight coupler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StraightCouplerCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Elbow coupler selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ElbowCouplerCheckBox_Checked(object sender, RoutedEventArgs e)
        {

            couplerList = accessoryList.Where(c => c.Contains("dg")).ToList();
            if (StraightCoupler.IsChecked == true)
            {
                StraightCoupler.IsChecked = false;
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "STEL" });
            }
            UpdateCouplerStates();
        }

        /// <summary>
        /// uncheck function for Elbow coupler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ElbowCouplerCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Short thread selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShortThreadCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (CouplerMetalPlate.IsChecked == true)
            {
                shortLongThread = couplerList.Where(c => c.Substring(c.Length - 2) == "LT").ToList();
                MessageBox.Show("long thread should be selected for metal plate selection", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                ShortThread.IsChecked = false;
                return;
            }
            else
            {
                shortLongThread = couplerList.Where(c => c.Substring(c.Length - 2) == "ST").ToList();
            }
  
            shortLongThread.AddRange(ExtractRelainingSTLT("ST", couplerList));

            if (LongThread.IsChecked == true)
            {
                LongThread.IsChecked = false;
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "SHLO" });
            }
            UpdateCouplerStates();

        }

        /// <summary>
        /// Gets ST or LT from the EXT-BODY name in Sheet Tab
        /// </summary>
        /// <param name="name"> ST or LT</param>
        /// <param name="couplerList"> couplet list</param>
        /// <returns></returns>
        private List<string> ExtractRelainingSTLT(string name, List<string> couplerList)
        {
            List<string> extBdySTLT = new List<string>();
            foreach (string item in couplerList.Where(c => c.Contains("EXT-BODY")).ToList())
            {
                if (item.Substring(item.IndexOf("EXT-BODY") - 3, 3).Contains(name))
                { extBdySTLT.Add(item); }
            }
            return extBdySTLT;
        }

        /// <summary>
        /// uncheck function for Short thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ShortThreadCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }


        /// <summary>
        /// check function for Long thread selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LongThreadCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if (CouplerBackShell.IsChecked == true) 
            {
                shortLongThread = couplerList.Where(c => c.Substring(c.Length - 2) == "ST").ToList();
                MessageBox.Show("Short thread should be selected for backshell selection", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                LongThread.IsChecked = false;
                return;
            }
            else 
            {
                shortLongThread = couplerList.Where(c => c.Substring(c.Length - 2) == "LT").ToList();
            }

            if (ShortThread.IsChecked == true)
            {
                ShortThread.IsChecked = false;
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "SHLO" }); /// SHLO 
            }
            UpdateCouplerStates();
            ShortThread.IsChecked = false;
        }

        /// <summary>
        /// uncheck function for Long thread
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LongThreadCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Extended body selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExtendedBodyCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            finalList = shortLongThread.Where(c => c.Contains("EXT-BODY")).ToList();
            //finalList = finalList.Where(c => !c.Contains("SWIVEL") && !c.Contains("STRAIN") && !c.Contains("FEMALE")).ToList();
            UpdateCouplerStates();
            GetDTRListCoupler();
        }

        /// <summary>
        /// uncheck function for Extended body
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ExtendedBodyCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Strained selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StrainedCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            finalList = shortLongThread.Where(c => c.Contains("STRAIN")).ToList();
            finalList = finalList.Where(c => !c.Contains("SWIVEL") && !c.Contains("EXT-BODY") && !c.Contains("FEMALE")).ToList();
            UpdateCouplerStates();
            GetDTRListCoupler();
        }

        /// <summary>
        /// uncheck function for Strained
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StrainedCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Male selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MaleCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            Female.IsChecked = false;
            finalList = shortLongThread.Where(c => !c.Contains("FEMALE")).ToList();
            finalList = finalList.Where(c => !c.Contains("SWIVEL") && !c.Contains("EXT-BODY") && !c.Contains("STRAIN")).ToList();
            UpdateCouplerStates();
            GetDTRListCoupler();
        }

        /// <summary>
        /// uncheck function for Male selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MaleCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Female selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FemaleCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            finalList = shortLongThread.Where(c => c.Contains("FEMALE")).ToList();
            finalList = finalList.Where(c => !c.Contains("SWIVEL") && !c.Contains("EXT-BODY") && !c.Contains("STRAIN")).ToList();
            if (finalList.Count == 0) 
            {
                finalList = couplerList.Where(c => c.Contains("FEMALE")).ToList();
            }
            Male.IsChecked = false;
            UpdateCouplerStates();
            GetDTRListCoupler();
        }

        /// <summary>
        /// uncheck function for Female selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FemaleCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Swiveled selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SwiveledCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            if (StraightCoupler.IsChecked == true)
            {
                finalList = shortLongThread.Where(c => c.Contains("SWIVEL")).ToList();
            }
            else if (ElbowCoupler.IsChecked == true)
            {
                finalList = angle4590.Where(c => c.Contains("SWIVEL")).ToList();
            }
            finalList = finalList.Where(c => !c.Contains("FEMALE") && !c.Contains("EXT-BODY") && !c.Contains("STRAIN")).ToList();
            NotSwiveled.IsChecked = false; // Uncheck NotSwiveled when Swiveled is checked
            UpdateCouplerStates();
            GetDTRListCoupler();

        }

        /// <summary>
        /// uncheck function for Swiveled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SwiveledCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Not Swiveled selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NotSwiveledCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            if (StraightCoupler.IsChecked == true)
            {
                finalList = shortLongThread.Where(c => !c.Contains("SWIVEL")).ToList();
            }
            else if (ElbowCoupler.IsChecked == true)
            {
                finalList = angle4590.Where(c => !c.Contains("SWIVEL")).ToList();
            }
            finalList = finalList.Where(c => !c.Contains("FEMALE") && !c.Contains("EXT-BODY") && !c.Contains("STRAIN")).ToList();

            Swiveled.IsChecked = false;
            UpdateCouplerStates();
            GetDTRListCoupler();
        }

        /// <summary>
        /// uncheck function for Not Swiveled
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NotSwiveledCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Angle 45 selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Angle45CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            angle4590 = shortLongThread.Where(c => c.Contains("45dg")).ToList();

            if (Angle90.IsChecked == true)
            {
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "DEG" });
            }
            Angle90.IsChecked = false; // Uncheck Angle90 when Angle45 is checked
            UpdateCouplerStates();

        }

        /// <summary>
        /// uncheck function for Angle 45
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Angle45CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// check function for Angle 90 selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Angle90CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            angle4590 = shortLongThread.Where(c => c.Contains("90dg")).ToList();
            if (Angle45.IsChecked == true)
            {
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "DEG" });
            }
            Angle45.IsChecked = false; // Uncheck Angle45 when Angle90 is checked
            UpdateCouplerStates();

        }

        /// <summary>
        /// uncheck function for Angle 90
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Angle90CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateCouplerStates();
        }

        /// <summary>
        /// Get DTR list based on the filters selected
        /// </summary>
        private void GetDTRListCoupler()
        {
            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
            if (sleevdiameter == "") sleevdiameter = SleeveSize.Text;
            if (finalList.Count == 0) return;
            string mappedValue = mapSheets[finalList[0]];
            List<Coupler> _coupler = alt_JsonReaderService.ReadCoupler(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path, mappedValue);
            alt_CATIA_Adapter adapter = alt_CATIA_Adapter.GetInstance();
            List<string> matchingDTRS = _coupler.Where(p => p.ConduitSize == sleevdiameter.ToString()).Select(p => p.CouplerDTR + "-" + p.Supplier).Distinct().ToList();
            if(matchingDTRS.Count == 0)
            {
                try
                {
                    if (finalList[0].Contains("STRAIN"))
                    {
                         matchingDTRS = _coupler
                            .Where(size => double.Parse(size.ConduitSize) > double.Parse(sleevdiameter.ToString()))
                            .OrderBy(size => double.Parse(size.ConduitSize))
                            .GroupBy(size => size.Supplier)
                            .Select(group => group.First())
                            .Select(p => p.CouplerDTR + "-" + p.Supplier).Distinct()
                            .ToList();
                    }
                    else
                    {
                        matchingDTRS = _coupler
                            .Where(size =>
                             double.Parse(size.ConduitSize) > double.Parse(sleevdiameter.ToString()) &&
                             double.Parse(size.InternalDiameter) > double.Parse(sleevdiameter.ToString()))
                            .OrderBy(size => double.Parse(size.ConduitSize))
                            .GroupBy(size => size.Supplier)
                            .Select(group => group.First())
                            .Select(p => p.CouplerDTR + "-" + p.Supplier).Distinct()
                            .ToList();
                    }
                }
                catch { }

            }
            FilteredDTR.ItemsSource = matchingDTRS;
        }

        /// <summary>
        /// Submit function to import dtr for coupler selection
        /// </summary>
        private async void CouplerSubmitButton_Click()
        {
            List<string> inputs = new List<string>();
            inputs.Add(harnessName);
            string dtr = string.Empty;
            if (FilteredDTR.Text.Contains("-"))
            {
                dtr = FilteredDTR.Text.Split('-')[0].Replace(" ", "");
            }
            else
            {
                dtr = FilteredDTR.Text;
            }
            inputs.Add(dtr);

            List<Coupler> _coupler = alt_JsonReaderService.ReadCoupler(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path, mapSheets[finalList[0]]);
            threadSizes = _coupler.Where(p => p.CouplerDTR == inputs[1]).Select(p => p.Thread).Distinct().ToList();

            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Starting importing DTR from DMA");
            await mainWindow.ShowOverlayAsync(async () =>
            {
                harnessName = MultibranchableTextBox.Text;
                await Task.Run(() =>
                {
                    importStatus = orchestrator.step_3_process<alt_Step3_Accessorization>("ImportDTRFromDMA", inputs) as string;
                });
            });

            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End importing DTR from DMA");
            UpdateApplicationStatus(dtr, importStatus);

            if (ElbowCoupler.IsChecked == false)
            {
                MessageBoxResult result = MessageBox.Show("Do you want to add additional accessory?", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    ComponentsOnAddedAccessory.Visibility = Visibility.Visible;
                    AdditionalAccessories.Visibility = Visibility.Visible;
                }
               
            }
            else if(NotSwiveled.IsChecked == true)
            {
                MessageBoxResult result = MessageBox.Show("Do you want to add a swivel adapter", "Warning", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    addSwivelAdapter = true;
                    AddSwivelCoupler();
                }
            }

        }

        /// <summary>
        /// Function to add swivel adapter if coupler is not swiveled
        /// </summary>
        private void AddSwivelCoupler()
        {
            string threadSize = threadSizes[0].Replace(" ", "");
            threadSize = threadSize.Replace(",", ".");
            List<SwivelAdapter> firewallCouplerList = alt_JsonReaderService.ReadSwivelAdapter(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
            threadSize = threadSize.Substring(0, 3);
            additionalComponentDTR = firewallCouplerList.Where(c => c.MaleThread == threadSize).Select(p => p.DTR).Distinct().ToList();
            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
            FilteredDTR.ItemsSource = additionalComponentDTR;
        }

        //////////////////////////////////////// Additional Accessories elements /////////////////////////////////////////////////////////
        /// <summary>
        /// Combobox selection changed event to select additional accessories
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void AdditionalComponents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (threadSizes.Count == 0) return;
            string threadSize = threadSizes[0].Replace(" ", "");
            threadSize = threadSize.Replace(",", ".");

            if (AdditionalComponents.SelectedItem == "FIREWALL COUPLER")
            {
                List<FirewallCoupler> firewallCouplerList = alt_JsonReaderService.ReadFirewallCoupler(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
                additionalComponentDTR = firewallCouplerList.Where(c => c.Thread_Male == threadSize).Select(p => p.DTR + "-" + p.Supplier).Distinct().ToList();
            }
            else if(AdditionalComponents.SelectedItem == "EMC ADAPTER")
            {
                List<EmcAdapter> firewallCouplerList = alt_JsonReaderService.ReadEmcAdapter(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
                additionalComponentDTR = firewallCouplerList.Where(c => c.Thread.Replace(" ", "").Replace(",", ".") == threadSize).Select(p => p.DTR + "-" + p.Supplier).Distinct().ToList();
            }
            else if(AdditionalComponents.SelectedItem == "FLAT SEAL")
            {
                threadSize = threadSize.Substring(0, 3);
                List<FlatSeal> firewallCouplerList = alt_JsonReaderService.ReadFlatSeal(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
                additionalComponentDTR = firewallCouplerList.Where(c => c.Size == threadSize).Select(p => p.DTR + "-" + p.Supplier).Distinct().ToList();
            }
            else if (AdditionalComponents.SelectedItem == "BLIND PLUG")
            {
                List<BlindPlug> firewallCouplerList = alt_JsonReaderService.ReadBlindPlug(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
                additionalComponentDTR = firewallCouplerList.Where(c => c.Thread_Size.Replace(" ", "") == threadSize).Select(p => p.DTR + "-" + p.Supplier).Distinct().ToList();
            }
            else if (AdditionalComponents.SelectedItem == "REDUCER - EXTENSION WITH SEAL")
            {
                threadSize = threadSize.Substring(0, 3);
                List<ReducerExtentionWithSeal> firewallCouplerList = alt_JsonReaderService.ReadReducerExtender(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path);
                additionalComponentDTR = firewallCouplerList.Where(c => c.MaleThread == threadSize).Select(p => p.DTR + "-" + p.Supplier).Distinct().ToList();
            }
            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
            FilteredDTR.ItemsSource = additionalComponentDTR;
        }

        /// <summary>
        /// Submit function to import dtr for additional accessories selection
        /// </summary>
        private async void AdditionalAccessory_Click()
        {
            List<string> inputs = new List<string>();
            inputs.Add(harnessName);
            string dtr = string.Empty;
            if (FilteredDTR.Text.Contains("-"))
            {
                dtr = FilteredDTR.Text.Split('-')[0].Replace(" ", "");
            }
            else
            {
                dtr = FilteredDTR.Text;
            }
            inputs.Add(dtr);

            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Starting importing DTR from DMA");
            await mainWindow.ShowOverlayAsync(async () =>
            {
                harnessName = MultibranchableTextBox.Text;
                await Task.Run(() =>
                {
                    importStatus = orchestrator.step_3_process<alt_Step3_Accessorization>("ImportDTRFromDMA", inputs) as string;
                });
            });
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End importing DTR from DMA");
            UpdateApplicationStatus(dtr, importStatus);

            addSwivelAdapter = false;
            ComponentsOnAddedAccessory.Visibility = Visibility.Visible;

        }

        /// <summary>
        /// Submit function to import dtr for corrugated conduit junction selection
        /// </summary>
        private async void SubmitCorrugatedConduitJunction_Click()
        {
            List<string> inputs = new List<string>();
            inputs.Add(harnessName);
            string dtr = string.Empty;
            if (FilteredDTR.Text.Contains("-"))
            {
                dtr = FilteredDTR.Text.Split('-')[0].Replace(" ", "");
            }
            else
            {
                dtr = FilteredDTR.Text;
            }
            inputs.Add(dtr);

            ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Starting importing DTR from DMA");
            await mainWindow.ShowOverlayAsync(async () =>
            {
                harnessName = MultibranchableTextBox.Text;
                await Task.Run(() =>
                {
                    importStatus = orchestrator.step_3_process<alt_Step3_Accessorization>("ImportDTRFromDMA", inputs) as string;
                });
            });
            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End importing DTR from DMA");
            UpdateApplicationStatus(dtr, importStatus);

            ComponentsOnAddedAccessory.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Combobox selection changed event to select corrugated conduit junction
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CorrugatedConduitJunctionSelection_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilteredDTR.ItemsSource = null;
            if (CorrugatedConduitJunctionSelection.SelectedItem == null) return;
            if (ShowPreSelectionMessage())
            {
                CorrugatedConduitJunctionSelection.SelectedItem = null;
                return;
            }
            if (sleevdiameter == "") sleevdiameter = SleeveSize.Text;
            string mappedValue = mapSheets[CorrugatedConduitJunctionSelection.SelectedValue.ToString()];
            List<string> matchingDTRS = new List<string>();
            if (CorrugatedConduitJunctionSelection.SelectedValue.ToString() == "DTR Y coupler")
            {
                List<YCoupler> yCouplers = alt_JsonReaderService.ReadYCoupler(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path, mappedValue);

                foreach(var yCoupler in yCouplers)
                {
                    if (double.Parse(yCoupler.ConduitInSize) >= double.Parse(sleevdiameter.ToString()) && double.Parse(yCoupler.ConduitOutSize) <= double.Parse(sleevdiameter.ToString()))
                    {
                        matchingDTRS.Add(yCoupler.DTR + "-" + yCoupler.Supplier);
                    }
                }
                //matchingDTRS = yCouplers.Where(p => double.Parse(p.ConduitInSize) >= double.Parse(sleevdiameter.ToString()) && double.Parse(p.ConduitOutSize) <= double.Parse(sleevdiameter.ToString())).Select(p => p.DTR).Distinct().ToList();
            }
            else if (CorrugatedConduitJunctionSelection.SelectedValue.ToString() == "TERMINAL SLEEVE")
            {
                List<TerminalSleev> yCouplers = alt_JsonReaderService.ReadTerminalSleev(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path, mappedValue);
                
                foreach(var terminal in yCouplers)
                {
                    if (double.Parse(terminal.ConduiSize) == double.Parse(sleevdiameter.ToString()))
                    {
                        matchingDTRS.Add(terminal.DTR + "-" + terminal.Supplier);
                    }
                }
                //matchingDTRS = yCouplers.Where(p => p.ConduiSize == sleevdiameter.ToString()).Select(p => p.DTR).Distinct().ToList();
            }
            else
            {
                List<CombinedCouplers> yCouplers = alt_JsonReaderService.ReadCombinedCouplers(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path, mappedValue);

                if (mappedValue == "Reducer" || mappedValue == "Straightcoupler")
                {
                    foreach (CombinedCouplers item in yCouplers)
                    {
                       List<string> range = item.ConduitSize.Split('-').ToList();
                       if(double.Parse(range[0]) <= double.Parse(sleevdiameter.ToString()) && double.Parse(range[1]) >= double.Parse(sleevdiameter.ToString()))
                       {
                            matchingDTRS.Add(item.DTR + "-" + item.Supplier);
                       }
                        else if (double.Parse(range[0]) >= double.Parse(sleevdiameter.ToString()) && double.Parse(range[1]) <= double.Parse(sleevdiameter.ToString()))
                        {
                            matchingDTRS.Add(item.DTR + "-" + item.Supplier);
                        }
                    }
                }
                else 
                {
                    foreach (var coupler in yCouplers)
                    {
                        if (double.Parse(coupler.ConduitSize) == double.Parse(sleevdiameter.ToString()))
                        {
                            matchingDTRS.Add(coupler.DTR + "-" + coupler.Supplier);
                        }
                    }
                    //matchingDTRS = yCouplers.Where(p => p.ConduitSize == sleevdiameter.ToString()).Select(p => p.DTR).Distinct().ToList(); 
                }
                    
            }
            /// check the ConduitSize in coupler with the third entry in inputs
            DTRCollection.IsEnabled = true;
            FilteredDTR.SelectedItem = null;
            FilteredDTRDescription.Text = string.Empty;
            FilteredDTR.ItemsSource = matchingDTRS;
        }

        /// <summary>
        /// Generic import button click event to import dtr.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ImportDTRGenericButton_Click(object sender, RoutedEventArgs e)
        {
            if (AccesseriesComboBox.SelectedItem == "Cable Gland")
            {
                SubmitCableGland_Click();
            }
            else if (AccesseriesComboBox.SelectedItem == "Coupler")
            {
                if(AdditionalComponents.Text != null && AdditionalComponents.Text != "")
                {
                    AdditionalAccessory_Click();
                }  
                else
                {
                    if(addSwivelAdapter) AdditionalAccessory_Click();
                    else CouplerSubmitButton_Click();
                }
                    
            }
            else if (AccesseriesComboBox.SelectedItem == "Corrugated Conduit Junction")
            {
                SubmitCorrugatedConduitJunction_Click();
            }

        }

        /// <summary>
        /// Update the states of coupler checkboxes and enable/disable based on the selection
        /// </summary>
        private void UpdateCouplerStates()
        {
            bool isFirstGroupChecked = (CouplerBackShell.IsChecked == true || CouplerMetalPlate.IsChecked == true);
            StraightOrElbow.IsEnabled = isFirstGroupChecked;
            if (StraightOrElbow.IsEnabled == false)
            { 
                StraightCoupler.IsChecked = false;
                ElbowCoupler.IsChecked = false;
            }
            else
            {
                DTRCollection.IsEnabled = true;
                FilteredDTR.SelectedItem = null;
                FilteredDTRDescription.Text = string.Empty;
            }

            bool isSecondGroupChecked = (StraightCoupler.IsChecked == true || ElbowCoupler.IsChecked == true);
            ShortOrLongThread.IsEnabled = isFirstGroupChecked && isSecondGroupChecked;
            if (ShortOrLongThread.IsEnabled == false)
            {
                ShortThread.IsChecked = false;
                LongThread.IsChecked = false;
            }

            bool isThirdGroupChecked = false;
            bool isfourthGroupChecked = false;

            isThirdGroupChecked = (ShortThread.IsChecked == true || LongThread.IsChecked == true);
            StraightCouplerGroup.IsEnabled = isFirstGroupChecked && isSecondGroupChecked && isThirdGroupChecked;
            if (StraightCouplerGroup.IsEnabled == false) 
            { 
                UpdateStackPanelStatesEnomolyCoupler(new List<string> { "SHLO" });
            }
            Angle.IsEnabled = isFirstGroupChecked && isSecondGroupChecked && isThirdGroupChecked;
            if(Angle.IsEnabled == false)
            {
                Angle45.IsChecked = false;
                Angle90.IsChecked = false;
            }

            if (StraightCoupler.IsChecked == true)
            {
                Angle.Visibility = Visibility.Collapsed;
                MaleOrFemale.Visibility = Visibility.Visible;
                ExtendedBody.Visibility = Visibility.Visible;
                SwiveledorNotSwiveled.Visibility = Visibility.Visible;
                Strained.Visibility = Visibility.Visible;

                bool extendedStatus = ExtendedBody.IsChecked == true;
                bool malefemaleStatus = (Male.IsChecked == true || Female.IsChecked == true);
                bool swiveledStatus = (Swiveled.IsChecked == true || NotSwiveled.IsChecked == true);
                bool strainedStatus = Strained.IsChecked == true;

                ExtendedBody.IsEnabled = !malefemaleStatus && !swiveledStatus && !strainedStatus;
                MaleOrFemale.IsEnabled = !extendedStatus && !swiveledStatus && !strainedStatus;
                SwiveledorNotSwiveled.IsEnabled = !extendedStatus && !malefemaleStatus && !strainedStatus;
                Strained.IsEnabled = !extendedStatus && !malefemaleStatus && !swiveledStatus;

            }
            else if (ElbowCoupler.IsChecked == true)
            {
                Strained.Visibility = Visibility.Collapsed;
                ExtendedBody.Visibility = Visibility.Collapsed;
                MaleOrFemale.Visibility = Visibility.Collapsed;
                Angle.Visibility = Visibility.Visible;
                SwiveledorNotSwiveled.Visibility = Visibility.Visible;

                bool angleStatus = (Angle45.IsChecked == true || Angle90.IsChecked == true);
                SwiveledorNotSwiveled.IsEnabled = isFirstGroupChecked && isSecondGroupChecked && isThirdGroupChecked && angleStatus;
                if(!SwiveledorNotSwiveled.IsEnabled)
                {
                    Swiveled.IsChecked = false;
                    NotSwiveled.IsChecked = false;
                }

            }

        }

        /// <summary>
        /// Update the states of coupler checkboxes based on the selection to avoid incompatible selections
        /// </summary>
        /// <param name="selections"> The reference list to update the checkbox </param>
        private void UpdateStackPanelStatesEnomolyCoupler(List<string> selections)
        {
            if (selections.Contains("Base"))
            {
                CouplerBackShell.IsChecked = false;
                CouplerMetalPlate.IsChecked = false;
                StraightCoupler.IsChecked = false;
                ElbowCoupler.IsChecked = false;
                ShortThread.IsChecked = false;
                LongThread.IsChecked = false;
                ExtendedBody.IsChecked = false;
                Male.IsChecked = false;
                Female.IsChecked = false;
                Swiveled.IsChecked = false;
                NotSwiveled.IsChecked = false;
                Angle45.IsChecked = false;
                Angle90.IsChecked = false;
            }

            if (selections.Contains("BSMP"))
            {
                StraightCoupler.IsChecked = false;
                ElbowCoupler.IsChecked = false;
                ShortThread.IsChecked = false;
                LongThread.IsChecked = false;
                ExtendedBody.IsChecked = false;
                Male.IsChecked = false;
                Female.IsChecked = false;
                Swiveled.IsChecked = false;
                NotSwiveled.IsChecked = false;
                Angle45.IsChecked = false;
                Angle90.IsChecked = false;
            }

            if (selections.Contains("STEL"))
            {
                ShortThread.IsChecked = false;
                LongThread.IsChecked = false;
                ExtendedBody.IsChecked = false;
                Male.IsChecked = false;
                Female.IsChecked = false;
                Swiveled.IsChecked = false;
                NotSwiveled.IsChecked = false;
                Angle45.IsChecked = false;
                Angle90.IsChecked = false;
            }

            if (selections.Contains("SHLO"))
            {
                ExtendedBody.IsChecked = false;
                Male.IsChecked = false;
                Female.IsChecked = false;
                Swiveled.IsChecked = false;
                NotSwiveled.IsChecked = false;
                Angle45.IsChecked = false;
                Angle90.IsChecked = false;
                Strained.IsChecked = false;
            }

            if (selections.Contains("DEG"))
            {
                Swiveled.IsChecked = false;
                NotSwiveled.IsChecked = false;
    
            }

        }

        /// <summary>
        /// Get the description from 3PL projet file based on the dtr selected
        /// </summary>
        /// <param name="dtr"> dtr value</param>
        /// <returns></returns>
        private string CompareWith3PLFile(string dtr)
        {
            string returnValue = "";
            Dictionary<string, List<PL3_Global>> _3PLFile = alt_JsonReaderService.Read3PLProjetJson(mainWindow.my_PreProcessing.jsonFilePaths.PL3_Projet_Path);
            bool dtrfound = false;
            foreach (string key in _3PLFile.Keys)
            {
                List<PL3_Global> matchingDTRs = _3PLFile[key].Where(p => p.DTR_Number == dtr).ToList();
                if (matchingDTRs.Count > 0)
                {
                    returnValue = matchingDTRs[0].Description;
                    dtrfound = true;
                    if (key == "0, 0, 0")
                    {
                        MessageBox.Show("This component is referred in the 3PL but outisde the PPL.Make sure you can use it.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                    else
                    {
                        if (NotPredisposed.IsChecked == true)
                        {
                            MessageBox.Show("Lug size is suitable for cable installation", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }
            }
            if(!dtrfound)
            {
                MessageBox.Show("This component is not referred in the 3PL, if you wish to use this component for the design, make sure to verify that the component is subscribed in orchestra, linked to your current project  and implement the component in the 3PL.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                if(NotPredisposed.IsChecked == true)
                {
                    MessageBox.Show("If the Harness on which you want to install this Cable Gland contains Lugs as extremity, verify that size of it enable installation of this component correctly", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                }

            }

            return returnValue;
        }

        /// <summary>
        /// Update the application status in the progress bar
        /// </summary>
        /// <param name="dtr"></param>
        /// <param name="status"></param>
        private void UpdateApplicationStatus(string dtr , string status)
        {
            if (status == "SUCCESS")
            {
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Successfully imported DTR from DMA: " + dtr);
            }
            else
            {
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Importing DTR failed: " + dtr);
            }
        }

        /// <summary>
        /// Show message box if multibranchable or bundle segment is not selected
        /// </summary>
        /// <returns></returns>
        private bool ShowPreSelectionMessage()
        {
            if(MultibranchableTextBox.Text == "No file selected")
            {
                MessageBox.Show("Please select a Multibranchable before proceeding.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return true;
            }
            else if (BundleSegmentTextBox.Text == "No file selected")
            {
                MessageBox.Show("Please select a bundleSegment or sleeve before proceeding.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return true;
            }
            return false;
        }
    }
}
