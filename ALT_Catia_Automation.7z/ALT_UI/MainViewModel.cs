﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;
using ALT_Data_Model;
using ALT_Data_Preparation;
using static ALT_UI.MainWindow;

namespace ALT_UI
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private string _enteredText;
        private double _progressValue;
        private string _progressText;

        public double ProgressValue
        {
            get => _progressValue;
            set
            {
                if (_progressValue != value)
                {
                    _progressValue = value;
                    OnPropertyChanged1(nameof(ProgressValue));
                }
            }
        }

        public string ProgressText
        {
            get => _progressText;
            set
            {
                if (_progressText != value)
                {
                    _progressText = value;
                    OnPropertyChanged1(nameof(ProgressText));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged1;

        protected void OnPropertyChanged1(string propertyName)
        {
            PropertyChanged1?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public async Task UpdateProgressAsync(double targetValue, Func<double, string> textGenerator, int delay = 100)
        {
            while (ProgressValue < targetValue)
            {
                ProgressValue += 1;
                ProgressText = textGenerator(ProgressValue); // Update progress text dynamically
                await Task.Delay(delay);
            }
        }

        public string EnteredText
        {
            get { return _enteredText; }
            set
            {
                _enteredText = value;
                OnPropertyChanged1("EnteredText");
            }
        }

        private List<ComparisionClass> _comparisionList;

        public List<ComparisionClass> ComparisionList
        {
            get { return _comparisionList; }
            set
            {
                _comparisionList = value;
                OnPropertyChanged1(nameof(ComparisionList));
            }
        }

        private bool _isMainCheckboxChecked;
        public bool IsMainCheckBoxChecked
        {
            get { return _isMainCheckboxChecked; }
            set
            {
                if (_isMainCheckboxChecked != value)
                {
                    _isMainCheckboxChecked = value;
                    OnPropertyChanged1(nameof(IsMainCheckBoxChecked));
                }
            }
        }

        public ICommand CheckBoxCommand { get; set; }
        public ICommand AllCheckBoxCommand { get; set; }
        public MainViewModel()
        {
            //ComparisionList = new List<ComparisionClass>();
            //ComparisionDataPreparation comparisionDataPreparation = new ComparisionDataPreparation();
            //foreach (ComparisionDataModel comparisionDataModel in comparisionDataPreparation.ComparisionListList)
            //{
            //    ComparisionClass myClass = new ComparisionClass();
            //    myClass.ConnectorHarness = comparisionDataModel.ConnectorHarness;
            //    myClass.ConnectorSynoptic = comparisionDataModel.ConnectorSynoptic;
            //    myClass.Action = comparisionDataModel.Action;
            //    myClass.IsChecked = true;
            //    ComparisionList.Add(myClass);
            //}
            CheckBoxCommand = new RelayCommand(OnCheckBoxClicked);
            AllCheckBoxCommand = new RelayCommand(OnAllCheckBoxClicked);
        }

        public void WorkFlow()
        {
            ComparisionList = new List<ComparisionClass>();
            ALT_Data_Validation_Service.alt_Data_Validation_Service service = ALT_Data_Validation_Service.alt_Data_Validation_Service.GetInstance();
            List<CADCompareData> compareList = service.CompareConnectorsData();
            foreach (CADCompareData comparisionDataModel in compareList)
            {
                ComparisionClass myClass = new ComparisionClass();
                myClass.ConnectorHarness = comparisionDataModel.SynopticConnector;
                myClass.ConnectorSynoptic = comparisionDataModel.CatiaConnector;
                myClass.Action = comparisionDataModel.Action;
                myClass.IsChecked = false;
                ComparisionList.Add(myClass);
            }
        }

        private void OnCheckBoxClicked(object obj)
        {
            ComparisionClass selectedRow = obj as ComparisionClass;
            if (selectedRow != null)
            {
                if (selectedRow.IsChecked)
                {
                    selectedRow.IsChecked = false;
                }
                else
                {
                    selectedRow.IsChecked = true;
                }
            }
        }

        private void OnAllCheckBoxClicked(object obj)
        {
            foreach (ComparisionClass item in ComparisionList)
            {
                if (IsMainCheckBoxChecked == false)
                {
                    item.IsChecked = true;
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ComparisionClass : INotifyPropertyChanged
    {
        public string ConnectorSynoptic { get; set; }
        public string ConnectorHarness { get; set; }
        public string Action { get; set; }

        private bool _isChecked;
        public bool IsChecked
        {
            get { return _isChecked; }
            set
            {
                if (_isChecked != value)
                {
                    _isChecked = value;
                    OnPropertyChanged(nameof(IsChecked));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }
    }

    public class CorrugatedCombination
    {
        public string Tab;
        public string FireSmoke;
        public string min_BR;
        public StackPanel ComboPanel;
        public StackPanel FireSmaokePanel;
    }

}