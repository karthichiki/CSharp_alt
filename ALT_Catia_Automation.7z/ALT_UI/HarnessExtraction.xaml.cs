﻿using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Preparation;
using ALT_Utilities;
using ApplicationLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using static MaterialDesignThemes.Wpf.Theme;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for HarnessExtraction.xaml
    /// </summary>
    public partial class HarnessExtraction : UserControl, INotifyPropertyChanged
    {
        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        private alt_Automation_Orchestrator orchestrator;
        //public ObservableCollection<SynopticInstance> PH_Synoptic_InstanceName { get; set; }
        //public ObservableCollection<SynopticInstance> PH_Synoptic_DTR_Number { get; set; }
        //public ObservableCollection<SynopticInstance> PH_CATIAConnector_InstanceName { get; set; }
        //public ObservableCollection<SynopticInstance> PH_CATIAConnector_DTR_Number { get; set; }
        public List<CorrugItem> CorrugItems { get; set; }
        public List<HartingItem> HartingItems { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        private ObservableCollection<SynopticInstance> _PH_Synoptic_InstanceName;
        public ObservableCollection<SynopticInstance> PH_Synoptic_InstanceName
        {
            get => _PH_Synoptic_InstanceName;
            set
            {
                _PH_Synoptic_InstanceName = value;
                OnPropertyChanged(nameof(PH_Synoptic_InstanceName));
            }
        }

        private ObservableCollection<SynopticInstance> _PH_Synoptic_DTR_Number;
        public ObservableCollection<SynopticInstance> PH_Synoptic_DTR_Number
        {
            get => _PH_Synoptic_DTR_Number;
            set
            {
                _PH_Synoptic_DTR_Number = value;
                OnPropertyChanged(nameof(PH_Synoptic_DTR_Number));
            }
        }

        private ObservableCollection<SynopticInstance> _PH_CATIAConnector_InstanceName;
        public ObservableCollection<SynopticInstance> PH_CATIAConnector_InstanceName
        {
            get => _PH_CATIAConnector_InstanceName;
            set
            {
                _PH_CATIAConnector_InstanceName = value;
                OnPropertyChanged(nameof(PH_CATIAConnector_InstanceName));
            }
        }

        private ObservableCollection<SynopticInstance> _PH_CATIAConnector_DTR_Number;
        public ObservableCollection<SynopticInstance> PH_CATIAConnector_DTR_Number
        {
            get => _PH_CATIAConnector_DTR_Number;
            set
            {
                _PH_CATIAConnector_DTR_Number = value;
                OnPropertyChanged(nameof(PH_CATIAConnector_DTR_Number));
            }
        }

        protected void OnPropertyChanged(string propertyName)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        ALT_Data_Model.PhysicalHarnessDataPreparation _PHDataPreparation = ALT_Data_Model.PhysicalHarnessDataPreparation.GetInstance();

        public HarnessExtraction()
        {
            InitializeComponent();
            orchestrator = new alt_Automation_Orchestrator();
        }

        /// <summary>
        /// PH_HarnessExtraction Button Click Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        async private void PH_HarnessExtraction_Click(object sender, RoutedEventArgs e)
        {
            string xmlstring = PH_xml_TextBox.Text;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ResetGroupBoxes();
                string result = string.Empty;
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the physical Harness data.");
                await Task.Run(() =>
                {
                    result = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ExtractPhycialHarness", xmlstring, mainWindow.my_PreProcessing.jsonFilePaths) as string;
                });

                if (result == string.Empty)
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the physical Harness data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Physical Harness data is sucessfully extracted.");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the physical Harness data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: " + result);
                }
            });
            
            PH_Synoptic_InstanceName = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_Synoptic_InstanceNameCheck.Select(x => new SynopticInstance
            {
                PHConnector = x.Item1,
                SynopticConnector = x.Item2,
                Status = x.Item3
            }));
            if (PH_Synoptic_InstanceName.Count > 0) PH_Synoptic_InstanceNameCheck_GroupBox.Visibility = Visibility.Visible;
            PH_Synoptic_DTR_Number = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_Synoptic_DTRNumberCheck.Select(x => new SynopticInstance
            {
                PHConnector = x.Item1,
                SynopticConnector = x.Item2,
                Status = x.Item3,
                CombinedNames = x.Item1 + "-" + x.Item4
            })); 
            if (PH_Synoptic_DTR_Number.Count > 0) PH_Synoptic_DTRNumberCheck_GroupBox.Visibility = Visibility.Visible;
            PH_CATIAConnector_InstanceName = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_CATIAConnector_InstanceNameCheck.Select(x => new SynopticInstance
            {
                PHConnector = x.Item1,
                SynopticConnector = x.Item2,
                Status = x.Item3
            }));
            if (PH_CATIAConnector_InstanceName.Count > 0) PH_CATIAConnector_InstanceNameCheck_GroupBox.Visibility = Visibility.Visible;
            PH_CATIAConnector_DTR_Number = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_CATIAConnector_DTRNumberCheck.Select(x => new SynopticInstance
            {
                PHConnector = x.Item1,
                SynopticConnector = x.Item2,
                Status = x.Item3,
                CombinedNames = x.Item1 + "-" + x.Item4
            }));
            if (PH_CATIAConnector_DTR_Number.Count > 0) PH_CATIAConnector_DTRNumberCheck_GroupBox.Visibility = Visibility.Visible;
            //PH_CATIALug_InstanceName = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_CATIALug_InstanceNameCheck.Select(x => new SynopticInstance
            //{
            //    PHConnector = x.Item1,
            //    SynopticConnector = x.Item2,
            //    Status = x.Item3
            //}));
            //if (PH_CATIALug_InstanceName.Count > 0) PH_CATIALug_InstanceNameCheck_GroupBox.Visibility = Visibility.Visible;
            //PH_CATIALug_DTR_Number = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_CATIALug_DTRNumberCheck.Select(x => new SynopticInstance
            //{
            //    PHConnector = x.Item1,
            //    SynopticConnector = x.Item2,
            //    Status = x.Item3
            //}));
            //if (PH_CATIALug_DTR_Number.Count > 0) PH_CATIALug_DTRNumberCheck.Visibility = Visibility.Visible;
            this.DataContext = this;
        }

        /// <summary>
        /// Select Physical Extraction xml File
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        async private void Browse_PH_xml_Click_1(object sender, RoutedEventArgs e)
        {

            await mainWindow.ShowOverlayAsync(async () =>
            {

                object FilePath = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Browse_file", "xml Source File | *.xml");
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(0, "Select Physical Extraction xml file.");
                if (FilePath != string.Empty)
                {
                    string fileName = Path.GetFileName(FilePath.ToString());
                    if (fileName.ToUpper().StartsWith("PH"))
                    {
                        PH_xml_TextBox.Text = FilePath.ToString();
                    }
                    else
                    {
                        ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End of selecting physical harness xml.");
                        ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Selected file is not physical Harness xml.");
                    }
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End of selecting physical harness xml.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: user did not select the PH xml.");
                }
            });
        }

        //async private void Browse_PH_xlsm_Click_1(object sender, RoutedEventArgs e)
        //{
        //    await mainWindow.ShowOverlayAsync(async () =>
        //    {
        //        object FilePath = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Browse_file", "xlsm Source File | *.xlsm");
        //        ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(0, "Select 3PL_LNVG xlsm file.");
        //        if (FilePath != string.Empty)
        //        {
        //            string fileName = Path.GetFileName(FilePath.ToString());
        //            if (fileName.ToUpper().StartsWith("3PL"))
        //            {
        //                _3PL_xlsm_TextBox.Text = FilePath.ToString();
        //            }
        //            else
        //            {
        //                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End of selecting 3PL_LNVG xlsm.");
        //                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Selected file is not 3PL_LNVG xlsm.");
        //            }
        //        }
        //        else
        //        {
        //            ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End of selecting 3PL_LNVG xlsm.");
        //            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: user did not select the 3PL_LNVG xlsm.");
        //        }
        //    });

        //}

        /// <summary>
        /// Extraction of physical Harness data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        async private void PH_CORRUGExtraction_Click(object sender, RoutedEventArgs e)
        {
            string xmlstring = PH_xml_TextBox.Text;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ResetGroupBoxes();
                string result = string.Empty;
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the physical Harness data.");
                await Task.Run(() =>
                {
                    result = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ExtractPhycialHarnessCORRUG", xmlstring, mainWindow.my_PreProcessing.jsonFilePaths) as string;
                });
                LoadDataForCorrugatedCheck();
                if (result == string.Empty)
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the physical Harness data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Physical Harness data is sucessfully extracted.");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the physical Harness data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: " + result);
                }
            });
        }

        /// <summary>
        /// Extracting the 3PL_LNVG xlsm data
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        async private void PH_HartingExtraction_Click(object sender, RoutedEventArgs e)
        {
            string xmlstring = PH_xml_TextBox.Text;
            //string xlsmstring = _3PL_xlsm_TextBox.Text;
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ResetGroupBoxes();
                string result = string.Empty;
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the 3PL_LNVG xlsm data.");
                await Task.Run(() =>
                {
                    result = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ExtractPhycialHarnessHarting", xmlstring, mainWindow.my_PreProcessing.jsonFilePaths) as string;
                });
                LoadDataForHartingCheck();
                if (result == string.Empty)
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the 3PL_LNVG xlsm data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: 3PL_LNVG data is sucessfully extracted.");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the 3PL_LNVG data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: " + result);
                }
            });
            
            
            //ALT_Data_Model.PhysicalHarnessDataPreparation _PHDataPreparation = ALT_Data_Model.PhysicalHarnessDataPreparation.GetInstance();
            //PH_Synoptic_InstanceName = new ObservableCollection<SynopticInstance>(_PHDataPreparation.PH_Synoptic_InstanceNameCheck.Select(x => new SynopticInstance
            //{
            //    PHConnector = x.Item1,
            //    SynopticConnector = x.Item2,
            //    Status = x.Item3
            //}));
            //if (PH_Synoptic_InstanceName.Count > 0) PH_Synoptic_InstanceNameCheck_GroupBox.Visibility = Visibility.Visible;

            this.DataContext = this;
        }

        /// <summary>
        /// Event for PHFilePathTextBox TextChanged: Make the Comparison buttons visible.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PHFilePathTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if(PH_xml_TextBox.Text.EndsWith("xml"))
            {
                // Enable the button if TextBox is not empty, disable otherwise
                if (!string.IsNullOrWhiteSpace(PH_xml_TextBox.Text))
                {
                    PHDataComparison_Button.Visibility = Visibility.Visible;
                    CORRUGComparison_Button.Visibility = Visibility.Visible;
                    HartingComparison_Button.Visibility = Visibility.Visible;
                }
            }
        }

        //private void Harting3PLFilePathTextBox_TextChanged(object sender, TextChangedEventArgs e)
        //{
        //    if (PH_xml_TextBox.Text.EndsWith("xml") && _3PL_xlsm_TextBox.Text.EndsWith("xlsm"))
        //    {
        //        // Enable the button if TextBox is not empty, disable otherwise
        //        if(!string.IsNullOrWhiteSpace(_3PL_xlsm_TextBox.Text))
        //        HartingComparison_Button.Visibility = Visibility.Visible;
        //    }
        //}

        /// <summary>
        /// Load the Result Data of CorrugatedCheck
        /// </summary>
        public void LoadDataForCorrugatedCheck()
        {
            CorrugItems = _PHDataPreparation.CORRUG_BRCheck
                .Select(t => new CorrugItem
                {
                    Branchable = t.Item1,
                    BundleSegment = t.Item2,
                    Sleeve = t.Item3,
                    Result = t.Item4? "Valid" : "Invalid",
                }).ToList();
            if (CorrugItems.Count > 0) CorrugatedResultGroupBox.Visibility = Visibility.Visible;
            CorrugatedResultGrid.ItemsSource = CorrugItems;
        }

        /// <summary>
        /// Load the Result Data of HartingCheck
        /// </summary>
        public void LoadDataForHartingCheck()
        {
            HartingItems = _PHDataPreparation.PHHarting3PLCheck
                .Select(t => new HartingItem
                {
                    DTRNumber = t.Item1,
                    InstanceName = t.Item2,
                }).ToList();
            if (HartingItems.Count > 0) HartingResultsBox.Visibility = Visibility.Visible;
            HartingResultGrid.ItemsSource = HartingItems;
        }

        /// <summary>
        /// Clear all results
        /// </summary>
        public void ResetGroupBoxes()
        {
            PH_Synoptic_InstanceNameCheck_GroupBox.Visibility = Visibility.Collapsed;
            PH_Synoptic_DTRNumberCheck_GroupBox.Visibility = Visibility.Collapsed;
            PH_CATIAConnector_InstanceNameCheck_GroupBox.Visibility = Visibility.Collapsed;
            PH_CATIAConnector_DTRNumberCheck_GroupBox.Visibility = Visibility.Collapsed;
            CorrugatedResultGroupBox.Visibility = Visibility.Collapsed;
            HartingResultsBox.Visibility = Visibility.Collapsed;
            PH_Synoptic_InstanceName?.Clear();
            PH_Synoptic_DTR_Number?.Clear();
            PH_CATIAConnector_InstanceName?.Clear();
            PH_CATIAConnector_DTR_Number?.Clear();
            CorrugItems?.Clear();
            HartingItems?.Clear();
        }

        /// <summary>
        /// Event to Reframe
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Reframe_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                if (sender is MenuItem menuItem &&
                menuItem.DataContext is SynopticInstance item)
                {
                    string text  = string.Empty;
                    if (item.CombinedNames == null)
                    {
                        text = item.PHConnector;
                    }
                    else { text = item.CombinedNames;  }

                    if (text.Contains("-"))
                    {
                        text = text.Split('-')[1];
                    }
                    await Task.Run(() =>
                    {
                        orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReframeFromCatiaProduct", text);
                    });
                }
                else
                {
                    alt_PopupMessageUtil.ShowMessage("Reframe On failed please try again.", "Warning", MessageType.Warning);
                }
            });

        }
    }


    public class BoolToBrushConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isOk = (bool)value;
            return isOk ? Brushes.Green : Brushes.Red;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

    }




}
