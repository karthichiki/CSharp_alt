﻿using ALT_Unity_Interface;
using ALT_Utilities;
using ApplicationLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for UnityCommunication.xaml
    /// </summary>
    public partial class UnityCommunication : UserControl
    {
        private alt_Automation_Orchestrator orchestrator;

        public UnityCommunication()
        {
            InitializeComponent();
            orchestrator = new alt_Automation_Orchestrator();
        }

        /// <summary>
        /// XXX.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void Send_receive_unity_data_Button_Click(object sender, RoutedEventArgs e)
        {
            Task<string> ret = orchestrator.step_2_process<alt_Unity_Interface>("ConnectAsyncAndSendReceiveData", to_send_to_unity.Text) as Task<string>;
            string result = await ret;

            if (result.Length > 0)
            {
                received_from_unity.Text = result;
            }
            else
            {
                string unity_url = orchestrator.step_2_process<alt_Unity_Interface>("GetUnityServerUrl") as string;
                alt_PopupMessageUtil.ShowMessage("Connection to Unity Failed at server " + unity_url, "Error", MessageType.Error);
            }
        }
    }
}
