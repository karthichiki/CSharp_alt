﻿using ALT_Data_Model;
using ALT_Data_Model.Electrical;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Preparation;
using ALT_Unity_Interface;
using ALT_Utilities;
using ApplicationLayer;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for BranchCreation.xaml
    /// </summary>
    public partial class BranchCreation : UserControl
    {
        
        private alt_Automation_Orchestrator orchestrator;
        private string _rgbSelected = "0,255,0";
        CADHarnessColors cADHarnessColors = new CADHarnessColors();
        private string _bendRadiousValue = "";
        private bool isSelectionChangedHandled = false;
        private alt_Utilities utils;
        private string _corrugatedSleevMemory = "";
        private string _bendRadiousRatioValue = "";
        //private Dictionary<string, List<PPL_Electrical>> _supplierData = null;
        private List<string> SupplierNames;
        private Extremity firstExtremity = null;
        private Extremity secondExtremity = null;
        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        List<PPL_Electrical> Selected_PPL_Electricals = new List<PPL_Electrical>();
        //private List<string> selectedMultibranchableZones = new List<string>();
        //ObservableCollection<FirstExtremityZoneModel> firstExtremityzones = null;
        //ObservableCollection<SecondExtremityZoneModel> secondExtremityZones = null;
        //ObservableCollection<MultibranchableZoneModel> multibranchableZones = null;

        /// <summary>
        /// Constructor
        /// </summary>
        public BranchCreation()
        {
            InitializeComponent();
            orchestrator = new alt_Automation_Orchestrator();
            ColorListView.ItemsSource = cADHarnessColors.SmallColorList;
            //string zonesFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "Zones.json");
            //firstExtremityzones = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadFirstExtremityZones", zonesFilePath) as ObservableCollection<FirstExtremityZoneModel>;
            //secondExtremityZones = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadSecondExtremityZones", zonesFilePath) as ObservableCollection<SecondExtremityZoneModel>;
            //multibranchableZones = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadMultibranchableZones", zonesFilePath) as ObservableCollection<MultibranchableZoneModel>;
            utils = new alt_Utilities();
            
        }

        //public async Task ShowProcessingOverlayAsync(Func<Task> longRunningTask)
        //{
        //    try
        //    {
        //        ProcessingOverlay.Visibility = Visibility.Visible;
        //        await longRunningTask();
        //    }
        //    finally
        //    {
        //        ProcessingOverlay.Visibility = Visibility.Collapsed;
        //    }
        //}

        /// <summary>
        /// Create Branch Button Event
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void CreateBranch_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                string resultJson = "";
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Sending the data to backend");
                List<string> parameters = new List<string>();
                parameters.Add(DiameterValue.Text.Replace("mm", "").Replace("inch", "").Trim());
                if (BendRadiusCheckBox.IsChecked == true) parameters.Add(CalculateBendRadiusFromRadiusRatio());
                else parameters.Add(BendRadiuaValue.Text.Replace("mm", "").Replace("inch", "").Trim());
                parameters.Add(_rgbSelected);
                parameters.Add(mainWindow?.my_PreProcessing.CatalogPath);
                await Task.Run(() =>
                {
                    resultJson = orchestrator.Step_1_process<alt_Step1_InputProcessing>("InitBranchInfo", parameters) as string;
                });

                await Task.Run(() =>
                {
                    Task<string> ret = orchestrator.step_2_process<alt_Unity_Interface>("InitWebSocket", resultJson) as Task<string>;
                });

                ResetSelection();
                //ResetZones();
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Sending the data to Unity");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Details loaded in Unity");
            });
        }

        //private void ResetZones()
        //{
        //    foreach (var zone in secondExtremityZones)
        //    {
        //        zone.SecondExtremityIsSelected = false;
        //    }
        //    foreach (var zone in firstExtremityzones)
        //    {
        //        zone.FirstExtremityIsSelected = false;
        //    }
            
        //    FirstExtremityZone_Combobox.Items.Refresh();
        //    SecondExtremityZone_Combobox.Items.Refresh();
        //    FirstExtremityZone_Combobox.Text = string.Empty;
        //    SecondExtremityZone_Combobox.Text = string.Empty;
        //    FirstExtremityZone_StackPanel.Visibility = Visibility.Collapsed;
        //    SecondExtremityZone_StackPanel.Visibility = Visibility.Collapsed;
        //}

        /// <summary>
        /// Calculate Bend Radius Ratio form Diameter and Bend Radius
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private string CalculateBendRadiusRatioFromRadius()
        {
            if (DiameterValue.Text != "" && BendRadiuaValue.Text != "")
            {
                return (double.Parse(RemoveUnwantedSubstring(BendRadiuaValue.Text)) / double.Parse(RemoveUnwantedSubstring(DiameterValue.Text))).ToString();
            }
            return "";
        }


        /// <summary>
        /// Calculate Bend Radius form Diameter and Bend Radius Ratio
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private string CalculateBendRadiusFromRadiusRatio()
        {
            if (DiameterValue.Text != "" && BendRadiuaValue.Text != "")
            {
                return (double.Parse(RemoveUnwantedSubstring(BendRadiuaValue.Text)) * double.Parse(RemoveUnwantedSubstring(DiameterValue.Text))).ToString();
            }
            return "";
        }

        /// <summary>
        /// Event for Toggle button checked to list colors according to the selected multibranchable
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private void ToggleColorListButton_Checked(object sender, RoutedEventArgs e)
        {
            if (MultiBranchableNameTextBox.Text.Contains("cC"))
            {
                ColorListView.ItemsSource = cADHarnessColors.CClassSubClassColorList;
            }
            else if (MultiBranchableNameTextBox.Text.Contains("cA"))
            {
                ColorListView.ItemsSource = cADHarnessColors.CAlassSubClassColorList;
            }
            else if (MultiBranchableNameTextBox.Text.Contains("cB"))
            {
                ColorListView.ItemsSource = cADHarnessColors.CBlassSubClassColorList;
            }
            else
            {
                ColorListView.ItemsSource = cADHarnessColors.LargeColorList;
            }

            ToggleText.Text = "SubClasses";
        }

        /// <summary>
        /// Event for BendRadiusCheckBox, When Checked It will get converted to Bend Radius Ratio
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BendRadiusCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                BendRadiusCheckBox.Content = "Bend Radius Ratio: ";
                if (DiameterValue.Text != "") BendRadiuaValue.Text = CalculateBendRadiusRatio();
                else BendRadiuaValue.Text = "";
            });
        }

        /// <summary>
        /// Event for BendRadiusCheckBox, When Unchecked It will get converted to Bend Radius
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void BendRadiusCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                BendRadiusCheckBox.Content = "Bend Radius: ";
                BendRadiuaValue.Text = CalculateBendRadius();
                AddUnitToBendRadius();
            });
        }

        /// <summary>
        /// Calculate Bend Radius Ratio form Diameter and Bend Radius
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private string CalculateBendRadiusRatio()
        {
            if (DiameterValue.Text != "" && BendRadiuaValue.Text != "")
            {
                return (double.Parse(RemoveUnwantedSubstring(BendRadiuaValue.Text)) / double.Parse(RemoveUnwantedSubstring(DiameterValue.Text))).ToString();
            }
            return "";
        }

        /// <summary>
        /// Calculate Bend Radius form Diameter and Bend Radius Ratio
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private string CalculateBendRadius()
        { 
            if (DiameterValue.Text != "" && BendRadiuaValue.Text != "")
            {
                return (double.Parse(RemoveUnwantedSubstring(BendRadiuaValue.Text)) * double.Parse(RemoveUnwantedSubstring(DiameterValue.Text))).ToString();
            }
            return "";
        }

        /// <summary>
        /// Event for Project Type Combobox SelectionChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ProjectType_Combobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Setting Project Type");
                CableType_Combobox.SelectedItem = null;
                isSelectionChangedHandled = false;
                if (DiameterValue.Text.Contains("mm") || DiameterValue.Text.Contains("inch")) DiameterValue.Text = "";
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "Selected Project Type");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Selected Project Type");
            });
        }

        /// <summary>
        /// Event for Toggle button unchecked to list colors according to the selected multibranchable
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private void ToggleColorListButton_Unchecked(object sender, RoutedEventArgs e)
        {
            if (MultiBranchableNameTextBox.Text.Contains("cC"))
            {
                ColorListView.ItemsSource = cADHarnessColors.CClassPrincipalColorList;
            }
            else if (MultiBranchableNameTextBox.Text.Contains("cA"))
            {
                ColorListView.ItemsSource = cADHarnessColors.CAlassPrincipalColorList;
            }
            else if (MultiBranchableNameTextBox.Text.Contains("cB"))
            {
                ColorListView.ItemsSource = cADHarnessColors.CBlassPrincipalColorList;
            }
            else
            {
                ColorListView.ItemsSource = cADHarnessColors.SmallColorList;
            }
            ToggleText.Text = "PrincipleClasses";
        }

        /// <summary>
        /// Event for Toggle button unchecked to list colors according to the selected multibranchable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BCClassCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if(BAClassCheckBox.IsChecked == true)
            {
                BAClassCheckBox.IsChecked = false;
            }
            ToggleColorListButton.Visibility = Visibility.Collapsed;
            ToggleText.Visibility = Visibility.Collapsed;
            ColorListView.ItemsSource = cADHarnessColors.BCClassColorList;
        }



        /// <summary>
        /// Event for BCClass CheckBox Unchecked.When unchecked all colors will be listed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BCClassCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            if(BAClassCheckBox.IsChecked == false)
            {
                ToggleColorListButton.Visibility = Visibility.Visible;
                ToggleText.Visibility = Visibility.Visible;
            }

            BC_BAClassCommonFunctionalityUnchecked();

        }

       
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BAClassCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            if (BCClassCheckBox.IsChecked == false)
            {
                ToggleColorListButton.Visibility = Visibility.Visible;
                ToggleText.Visibility = Visibility.Visible;
            }

            BC_BAClassCommonFunctionalityUnchecked();
        }

        /// <summary>
        /// Set the colors class from according to selected multibranchable  
        /// </summary>
        private void BC_BAClassCommonFunctionalityUnchecked()
        {
            if (ToggleColorListButton.IsChecked == true)
            {
                if (MultiBranchableNameTextBox.Text.Contains("cC"))
                {
                    ColorListView.ItemsSource = cADHarnessColors.CClassSubClassColorList;
                }
                else if (MultiBranchableNameTextBox.Text.Contains("cA"))
                {
                    ColorListView.ItemsSource = cADHarnessColors.CAlassSubClassColorList;
                }
                else if (MultiBranchableNameTextBox.Text.Contains("cB"))
                {
                    ColorListView.ItemsSource = cADHarnessColors.CBlassSubClassColorList;
                }
                else
                {
                    ColorListView.ItemsSource = cADHarnessColors.SmallColorList;
                }
                ToggleText.Text = "SubClasses";
                ToggleColorListButton.IsChecked = true;
            }
            else
            {
                if (MultiBranchableNameTextBox.Text.Contains("cC"))
                {
                    ColorListView.ItemsSource = cADHarnessColors.CClassPrincipalColorList;
                }
                else if (MultiBranchableNameTextBox.Text.Contains("cA"))
                {
                    ColorListView.ItemsSource = cADHarnessColors.CAlassPrincipalColorList;
                }
                else if (MultiBranchableNameTextBox.Text.Contains("cB"))
                {
                    ColorListView.ItemsSource = cADHarnessColors.CBlassPrincipalColorList;
                }
                else
                {
                    ColorListView.ItemsSource = cADHarnessColors.SmallColorList;
                }
                ToggleText.Text = "PrincipleClasses";
                ToggleColorListButton.IsChecked = false;
            }
            ToggleColorListButton.Visibility = Visibility.Visible;
            ToggleText.Visibility = Visibility.Visible;

            if (ToggleColorListButton.IsChecked == true)
            {
                ToggleColorListButton_Checked(null, new RoutedEventArgs());
            }
        }

        /// <summary>
        /// Show colors of BC Class in ListView
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BAClassCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            if(BCClassCheckBox.IsChecked == true)
            {
                BCClassCheckBox.IsChecked = false;
            }
            ToggleColorListButton.Visibility = Visibility.Collapsed;
            ToggleText.Visibility = Visibility.Collapsed;
            ColorListView.ItemsSource = cADHarnessColors.BAClassColorList;
        }

        /// <summary>
        /// Event for ColorListView SelectionChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ColorListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            ColorClass selectedItem = ColorListView.SelectedItem as ColorClass;
            if (selectedItem != null) _rgbSelected = selectedItem.RGBValues;
        }

        /// <summary>
        /// Event for Selecting FirstExtrimity
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void SelectFirstExtrimityButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(MultiBranchableNameTextBox.Text))
            {
                alt_PopupMessageUtil.ShowMessage("Please select the Harness before choosing the Extremities.", "Error", MessageType.Error);
                return;
            }
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Selecting First Extremity Harness product");

                //string selectedHarnessText = HarnessComboBox.Text;
                
                object returnMsg = null;

                Extremity extremity = null;
                await Task.Run(() =>
                {
                    //utils.BringApplicationToFront("CNEXT");
                    extremity = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectFirstExtremity", mainWindow.my_PreProcessing.jsonFilePaths.Extract_FAF_Path) as Extremity;
                });
                firstExtremity = extremity;
                
                //if (extremity is DerivationPoint derivationPoint)
                //    derivationPoint.DerivationType = "T";

                if (extremity != null)
                {
                    //FirstExtremityZone_StackPanel.Visibility = Visibility.Visible;
                    //foreach (var zone in firstExtremityzones)
                    //{
                    //    zone.FirstExtremityIsSelected = false;
                    //}
                    //FirstExtremityZone_Combobox.Items.Refresh();
                    FirstExtremityTextBox.Text = extremity.Name;
                    if (extremity.Name == SecondExtremityTextBox.Text &&
                        SecondExtremityTextBox.Text != string.Empty)
                    {
                        alt_PopupMessageUtil.ShowMessage("Extremities cannot be same, Please Select Again", "Warning", MessageType.Warning);
                        FirstExtremityTextBox.Text = "";
                        await Task.Run(() =>
                        {
                            utils.BringApplicationToFront("CNEXT");
                            extremity = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectFirstExtremity", mainWindow.my_PreProcessing.jsonFilePaths.Extract_FAF_Path) as Extremity;
                        });
                    }
                    FirstExtremityTextBox.Text = extremity.Name;
                    FirstExtremityDtrTextBox.Text = extremity.DtrName;
                    //Disable_DerivationType();
                }
                
                NullValues();
                DiameterValue.Text = string.Empty;
                ProjectType_Combobox.SelectedItem = null;
                CableType_Combobox.SelectedItem = null;
                BendRadiusCheckBox.IsChecked = false;
                if (SecondExtremityTextBox.Text != "" && FirstExtremityTextBox.Text != "")
                {
                    SelectIntermediateWaypoints();
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Selecting First Extremity Harness product");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: First Extremity Selected");
                }
                else
                {

                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Selecting First Extremity Harness product");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: failed to select the First Extremity, Please try again.");
                }
            });
        }

        /// <summary>
        /// Event for Selecting Second Extrimity
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void SelectSecondExtrimityButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(MultiBranchableNameTextBox.Text))
            {
                alt_PopupMessageUtil.ShowMessage("Please select the Harness before choosing the Extremities.", "Error", MessageType.Error);
                return;
            }
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Selecting Second Extremity Harness product");
                //string selectedHarnessText = mainWindow.my_BranchCreation.HarnessComboBox.Text;
                object returnMsg = null;

                Extremity extremity = null;
                await Task.Run(() =>
                {
                    //utils.BringApplicationToFront("CNEXT");
                    extremity = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectSecondExtremity", mainWindow.my_PreProcessing.jsonFilePaths.Extract_FAF_Path) as Extremity;
                });
                secondExtremity = extremity;
                
                if (extremity != null)
                {
                    //SecondExtremityZone_Button.Visibility = Visibility.Visible;
                    //SecondExtremityZone_StackPanel.Visibility = Visibility.Visible;
                    //foreach (var zone in secondExtremityZones)
                    //{
                    //    zone.SecondExtremityIsSelected = false;
                    //}
                    //SecondExtremityZone_Combobox.Items.Refresh();
                    SecondExtremityTextBox.Text = extremity.Name;
                    if (extremity.Name == FirstExtremityTextBox.Text &&
                        FirstExtremityTextBox.Text != string.Empty)
                    {
                        alt_PopupMessageUtil.ShowMessage("Extremities cannot be same, Please Select Again", "Warning", MessageType.Warning);
                        SecondExtremityTextBox.Text = "";
                        await Task.Run(() =>
                        {
                            utils.BringApplicationToFront("CNEXT");
                            extremity = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectSecondExtremity", mainWindow.my_PreProcessing.jsonFilePaths.Extract_FAF_Path) as Extremity;
                        });
                    }
                    SecondExtremityTextBox.Text = extremity.Name;
                    SecondExtremityDtrTextBox.Text = extremity.DtrName;
                    //Disable_DerivationType();
                }
                
                NullValues();
                DiameterValue.Text = string.Empty;
                ProjectType_Combobox.SelectedItem = null;
                CableType_Combobox.SelectedItem = null;
                BendRadiusCheckBox.IsChecked = false;
                if (FirstExtremityTextBox.Text != "" && SecondExtremityTextBox.Text != "")
                {
                    SelectIntermediateWaypoints();
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Selecting Second Extremity Harness product");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Second Extremity Selected");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End Selecting Second Extremity Harness product");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: failed to select the Second Extremity, Please try again.");
                }
            });
        }

        private void Disable_DerivationType()
        {
            if (firstExtremity?.ExtremityType.ToString() == "Derivation")
            {
                Derivation_Type_StackPanel.Visibility = Visibility.Visible;
                T_Type.IsChecked = true;
            }
            else
            {
                Derivation_Type_StackPanel.Visibility = Visibility.Collapsed;
                T_Type.IsChecked = false;
                Y_Type.IsChecked = false;
            }
            if (secondExtremity?.ExtremityType.ToString() == "Derivation")
            {
                Derivation_Type_StackPanel_SecondExtremity.Visibility = Visibility.Visible;
                T_Type_SecondExtremity.IsChecked = true;
            }
            else
            {
                Derivation_Type_StackPanel_SecondExtremity.Visibility = Visibility.Collapsed;
                T_Type_SecondExtremity.IsChecked = false;
                Y_Type_SecondExtremity.IsChecked = false;
            }
        }


        /// <summary>
        /// Select Intermediate Way points after selecting Extremities
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        public async void SelectIntermediateWaypoints()
        {
            MessageBoxResult result = alt_PopupMessageUtil.ShowMessageYesNo("Do you want to implement intermediate way point ?", "Intermediate waypoint", MessageType.Question);
            if (result == MessageBoxResult.Yes)
            {
                ForcedWeighPoint.Visibility = Visibility.Visible;
                ForcedWeighPointBtn.Visibility = Visibility.Visible;
                alt_PopupMessageUtil.ShowMessage("Please check the option required", "User Selection", MessageType.Information);
            }
        }

        /// <summary>
        /// Event for Selecting Intermediate Way Points After Selecting Extremities
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void SelectForcedWeighPoint_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                string parameter = "";
                if (ForceWeighPointPLS.IsChecked == true)
                {
                    parameter = "PLS";
                    ForceWeighPointEHI.IsEnabled = true;
                }
                else
                {
                    parameter = "EHI";
                    ForceWeighPointPLS.IsEnabled = true;
                }

                //utils.BringApplicationToFront("CNEXT");
                if (ForceWeighPointPLS.IsChecked == false && ForceWeighPointEHI.IsChecked == false) return;
                bool repetitionResult = false;
                do 
                {
                    await Task.Run(() =>
                    {
                        orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectIntermediateWayPoint", parameter);
                    });
                    utils.BringApplicationToFront("ALT_UI");
                    MessageBoxResult result = alt_PopupMessageUtil.ShowMessageYesNo("Do you want to repeat the selection again?", "User Selection", MessageType.Question);
                    if (result == MessageBoxResult.No)
                    {
                        ForceWeighPointPLS.IsChecked = false;
                        ForceWeighPointEHI.IsChecked = false;
                        ForcedWeighPoint.Visibility = Visibility.Collapsed;
                        ForcedWeighPointBtn.Visibility = Visibility.Collapsed;
                        repetitionResult = false;
                    }
                    else
                    {
                        repetitionResult = true;
                        ForceWeighPointPLS.IsChecked = false;
                        ForceWeighPointEHI.IsChecked = false;
                    }
                } 
                while (repetitionResult);
                
            });
        }
        internal void BindSupplierComboBox()
        {
            SupplierNames = mainWindow?.my_PreProcessing._supplierData.Keys.ToList();
            if(SupplierNames.Count > 1)
            SupplierNames?.RemoveAt(0);
            Supplier_Combobox.ItemsSource = SupplierNames;
        }

      

       

        /// <summary>
        /// Event for selecting multibranchable in CATIA
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void SelectMultibranchableButton_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                if (mainWindow.my_PreProcessing.jsonFilePaths.Synoptic_File_Path == null)
                {
                    alt_PopupMessageUtil.ShowMessage("Please Extract Synoptic File from \"Pre-Processing Tab\" and Try Again.", "Warning", MessageType.Warning);
                    return;
                }
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the multibranchable");
                object returnMsg = null;
                object isMultibranchable = null;
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectMultiBranchable");
                });
                if (returnMsg == "")
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the multibranchable");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Mutibranchable selection Failed");
                    return;
                }
                if (returnMsg != null)
                    await Task.Run(() =>
                    {
                        isMultibranchable = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ValidateSelectedMultiBranchable", returnMsg, mainWindow.my_PreProcessing.jsonFilePaths.Synoptic_File_Path);
                    });

                if (isMultibranchable.ToString() == "True")
                {
                    //foreach (var zone in multibranchableZones)
                    //{
                    //    zone.MultibranchableIsSelected = false;
                    //}
                    //MultibranchableZonesListBox.Items.Refresh();
                    if (returnMsg != null)
                        MultiBranchableNameTextBox.Text = returnMsg.ToString();
                    Multibranchable_GreenSignal.Fill = new SolidColorBrush(Colors.Green);
                    if (MultiBranchableNameTextBox.Text.Contains("cC"))
                    {
                        ColorListView.ItemsSource = cADHarnessColors.CClassPrincipalColorList;
                    }
                    else if (MultiBranchableNameTextBox.Text.Contains("cA"))
                    {
                        ColorListView.ItemsSource = cADHarnessColors.CAlassPrincipalColorList;
                    }
                    else
                    {
                        ColorListView.ItemsSource = cADHarnessColors.CBlassPrincipalColorList;
                    }
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the multibranchable");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Mutibranchable selected");
                }
                else
                {
                    MultiBranchableNameTextBox.Text = string.Empty;
                    Multibranchable_GreenSignal.Fill = new SolidColorBrush(Colors.Gray);
                    alt_PopupMessageUtil.ShowMessage("Selected Multibranchable is not found in Synoptic File, Select Correct Multibranchable and Try again", "Warning", MessageType.Warning);
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the multibranchable");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Mutibranchable selection Failed");
                }
            });
        }

        /// <summary>
        /// Event for NumericTextBox where it allows only numbers (Incliding Decimals)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumericTextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // Regex to match only digits
            //Regex regex = new Regex(@"^[0-9]*(?:\.[0-9]*)?$");
            //e.Handled = !regex.IsMatch(e.Text);

            TextBox textBox = (TextBox)sender;
            string decimalSeparator = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            // Build regex dynamically with correct decimal separator
            string pattern = @"^\d*(" + Regex.Escape(decimalSeparator) + @"?\d*)?$";
            Regex regex = new Regex(pattern);

            string newText = textBox.Text.Insert(textBox.SelectionStart, e.Text);

            e.Handled = !regex.IsMatch(newText);
        }

        /// <summary>
        ///  Prevent space or non-numeric characters from being entered
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NumericTextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Space)
            {
                e.Handled = true; // Prevent space
            }
        }

        /// <summary>
        /// Ensure the value is between 0 and 60
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void NumericTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(RemoveUnwantedSubstring(DiameterValue.Text), out double value))
            {
                if (value < 1 || value > 60)
                {
                    MessageBox.Show("Please enter a value between 1 and 60.");
                    DiameterValue.Text = ""; // Default to 1 if out of range
                }
                else
                {
                    string selectedWireType = WireType_Combobox.SelectedItem as string;
                    //if (selectedWireType == null) return;
                    double diameter = !string.IsNullOrEmpty(DiameterValue.Text) ? double.Parse(RemoveUnwantedSubstring(DiameterValue.Text)) : 0;
                    string bendradius_Ratio = "";
                    if (CableType_Combobox.SelectedItem == "Bundle" && selectedWireType != null)
                    {
                        await Task.Run(() =>
                        {
                            bendradius_Ratio = CalculateBendRadiusForBundle(selectedWireType, diameter, true);
                        });
                        BendRadiusCheckBox.IsChecked = true;
                        BendRadiuaValue.Text = bendradius_Ratio.ToString();
                    }
                    if (CorrugatedCheckbox.IsChecked == true) Calculate_BendRadius_For_Corrugated();
                    setdiameterUnit();
                }
            }
            else
            {
                DiameterValue.Text = ""; // Default to 1 if the input is invalid
            }
        }

        /// <summary>
        /// Set Diameter Unit in Diameter TextBox according to the ProjectType Selected
        /// </summary>
        private void setdiameterUnit()
        {
            string unit = " mm";
            if (ProjectType_Combobox.SelectedItem == "NAM (north american)") unit = " inch";
            else if (ProjectType_Combobox.SelectedItem == null) unit = "";
            if (!DiameterValue.Text.Contains(unit.Trim())) DiameterValue.Text = DiameterValue.Text + unit;
        }

        /// <summary>
        /// Event for the BendRadius textbox to prevent the user from setting the Bend Radius to "0"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void NoZeroOnlyTextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            if (BendRadiuaValue.Text.Replace("0", "").Length == 0)
            {
                MessageBox.Show("The value cannot be just 0.");
                BendRadiuaValue.Text = ""; // Clear the value
            }
        }

        /// <summary>
        /// Set the default items for ProjectType.
        /// </summary>
        internal void ProjecttypeItemSource()
        {
            List<string> standardCableTypes = new List<string> { "EN (european norme)", "NAM (north american)" };
            ProjectType_Combobox.ItemsSource = standardCableTypes;
        }

        /// <summary>
        /// Set the default items for Cabletype
        /// </summary>
        internal void CabletypeItemSource()
        {
            List<string> CableTypes = new List<string> { "Unique", "Specific", "Bundle" };
            CableType_Combobox.ItemsSource = CableTypes;
        }

        /// <summary>
        /// Set the default items for Wiretype
        /// </summary>
        internal void WiretypeItemSource()
        {
            List<string> WireTypes = new List<string> { "Shielded", "Not shielded", "Shielded + Not shielded", "Network" };
            WireType_Combobox.ItemsSource = WireTypes;
        }

        /// <summary>
        /// 
        /// </summary>
        //internal void ZoneComboboxItemSource()
        //{
        //    if(firstExtremityzones != null)
        //    {                
        //        SecondExtremityZone_Combobox.ItemsSource = secondExtremityZones;
        //        FirstExtremityZone_Combobox.ItemsSource = firstExtremityzones;
        //        //SecondExtremityZone_Combobox.ItemsSource = zoneNames;
        //    }
        //}


        /// <summary>
        /// Event for BendRadius, whenever the BendRadius value changes, this event will check whether the BendRadiusCheckBox is checked and update accordingly.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private void BendRadius_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (BendRadiuaValue.Text != "")
            {
                if (BendRadiusCheckBox.IsChecked == false)
                {
                    _bendRadiousValue = BendRadiuaValue.Text;
                    if(!string.IsNullOrEmpty(RemoveUnwantedSubstring(BendRadiuaValue.Text)) && !string.IsNullOrEmpty(RemoveUnwantedSubstring(DiameterValue.Text)))
                    _bendRadiousRatioValue = (double.Parse(RemoveUnwantedSubstring(BendRadiuaValue.Text)) / double.Parse(RemoveUnwantedSubstring(DiameterValue.Text))).ToString();
                }
                else
                {
                    _bendRadiousRatioValue = BendRadiuaValue.Text;
                    _bendRadiousValue = (double.Parse(RemoveUnwantedSubstring(BendRadiuaValue.Text)) * double.Parse(RemoveUnwantedSubstring(DiameterValue.Text))).ToString();
                }
            }
        }



        /// <summary>
        ///Event for Supplier Combobox SelectionChanged: Save the retrieved Sleeve and its Diameter in the DataModel.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void Supplier_Combobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Supplier_Combobox.SelectedItem == null) return;

            string unit = "";
            //BendRadiuaValue.Text = _corrugatedSleevMemory;
            if (CableType_Combobox.SelectedItem == "Bundle" && BendRadiusCheckBox.IsChecked == true && BendRadiuaValue.Text != "")
            {
                _corrugatedSleevMemory = BendRadiuaValue.Text;
                unit = "";
            }
            if (ProjectType_Combobox.SelectedItem == "NAM (north american)") unit = " inch";
            else if (ProjectType_Combobox.SelectedItem == "EN (european norme)") unit = " mm";
            if(BendRadiusCheckBox.IsChecked == true)
            BendRadiusCheckBox.IsChecked = false;
            MatchCollection matches = Regex.Matches(Supplier_Combobox.SelectedItem.ToString(), @"\bDTR\w*");
            string sleeve = string.Empty;
            if (matches.Count > 0)
            sleeve = matches[0].Value; 
            PPL_Electrical selectedElectrical = Selected_PPL_Electricals.FirstOrDefault(x => x.DTR_Number == sleeve);
            orchestrator.Step_1_process<alt_Step1_InputProcessing>("CorrugatedSelected", selectedElectrical.DTR_Number, selectedElectrical.External_Diameter);
            double bendRadius = double.Parse(selectedElectrical.Static_Bending_Radius);
            if (_corrugatedSleevMemory != "")
            {
                if (double.Parse(RemoveUnwantedSubstring(_corrugatedSleevMemory)) < bendRadius)
                {
                    BendRadiuaValue.Text = bendRadius.ToString() + unit;
                }
            }
            else
            {
                BendRadiuaValue.Text = bendRadius.ToString() + unit;
            }
            AddUnitToBendRadius();
            //CorrugatedCheckbox.IsChecked = false;
        }

        /// <summary>
        /// Event for Cable Combobox SelectionChanged
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void Cable_Combobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Selecting Cable type");
                HandleCableTypeSelection();
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "Cable Type Selected");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Selected Cable Type");
            });
        }

        /// <summary>
        /// Set Diameter, Bend Radius and Harness DTR according to the Cable Type Selected 
        /// </summary>
        private async void HandleCableTypeSelection()
        {
            try
            {
                if (mainWindow.my_PreProcessing.jsonFilePaths.Synoptic_File_Path == null || mainWindow.my_PreProcessing.jsonFilePaths.Extract_FAF_Path == null || mainWindow.my_PreProcessing.jsonFilePaths.PPL_Cable_Path == null || mainWindow.my_PreProcessing.jsonFilePaths.PPL_Electrical_Path == null)
                {
                    alt_PopupMessageUtil.ShowMessage("Please Select Required Files in \"Pre-Processing Tab\" to Extract Diameter Values.", "Warning", MessageType.Warning);
                    return;
                }

                string selectedCable = CableType_Combobox.SelectedItem as string;
                mainWindow.result = MessageBoxResult.None;
                NullValues();
                if (selectedCable != "Bundle")
                {
                    DiameterValue.Text = "";
                    BendRadiusCheckBox.IsChecked = false;
                    BendRadiuaValue.Text = "";
                }
                else if (DiameterValue.Text != "")
                {
                    MessageBoxResult messageBoxResult = alt_PopupMessageUtil.ShowMessageYesNo("The entered diameter is a valid input?", "UserInput", MessageType.Question);
                    if (messageBoxResult == MessageBoxResult.No)
                    {
                        CableType_Combobox.SelectedItem = null;
                        DiameterValue.Text = "";
                        alt_PopupMessageUtil.ShowMessage("Please enter the diameter manually", "Information", MessageType.Warning);
                        WireType_Combobox.IsEnabled = true;
                        return;
                    }
                }

                bool projectType = false; if (selectedCable == "Unique" && ProjectType_Combobox.SelectedItem == null) projectType = true;
                if (MultiBranchableNameTextBox.Text == "" || FirstExtremityTextBox.Text == "" || SecondExtremityTextBox.Text == "" || projectType)
                {
                    if (selectedCable != "Bundle")
                    {
                        WireType_Combobox.SelectedItem = null;
                        if (selectedCable == "Unique" && (MultiBranchableNameTextBox.Text == "" || FirstExtremityTextBox.Text == "" || SecondExtremityTextBox.Text == "" || projectType))
                        {
                            alt_PopupMessageUtil.ShowMessage("Please select Harness, Connectors, ProjectType before selecting Cable type", "Warning", MessageType.Warning);
                            CableType_Combobox.SelectedItem = null;
                            return;
                        }

                        else if (selectedCable == "Specific" && (MultiBranchableNameTextBox.Text == "" || FirstExtremityTextBox.Text == "" || SecondExtremityTextBox.Text == ""))
                        {
                            alt_PopupMessageUtil.ShowMessage("Please select Harness, Connectors before selecting Cable type", "Warning", MessageType.Warning);
                            CableType_Combobox.SelectedItem = null;
                            return;
                        }
                        else if (selectedCable == null) { return; }
                    }
                }

                //bool projectType = false; if (selectedCable == "Unique" && ProjectType_Combobox.SelectedItem == null) projectType = true;

                //if (MultiBranchableNameTextBox.Text == "" || FirstExtremityTextBox.Text == "" || SecondExtremityTextBox.Text == "" || projectType)
                //{
                //    if (selectedCable != "Bundle")
                //    {
                //        if (selectedCable == "Unique")
                //            MessageBox.Show("Please select Harness, Connectors, ProjectType before selecting Cable type", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                //        else if (selectedCable == "Specific" && (MultiBranchableNameTextBox.Text == "" || FirstExtremityTextBox.Text == "" || SecondExtremityTextBox.Text == ""))
                //            MessageBox.Show("Please select Harness, Connectors before selecting Cable type", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                //        isSelectionChangedHandled = true;
                //        CableType_Combobox.SelectedItem = null;
                //        return;
                //    }
                //}

                if (selectedCable == "Bundle")
                {
                    if (DiameterValue.Text == "")
                    {
                        alt_PopupMessageUtil.ShowMessage("Please fill diameter value before selecting the cable", "InvalidInput", MessageType.Error);
                        isSelectionChangedHandled = true;
                        CableType_Combobox.SelectedItem = null;
                    }
                    else
                    {
                        WireType_Combobox.IsEnabled = true;
                    }
                }
                else
                {
                    if (CableType_Combobox.SelectedItem == null) return;
                    string projectTypeSelected = ""; if (ProjectType_Combobox.SelectedItem != null) projectTypeSelected = ProjectType_Combobox.SelectedItem.ToString();
                    string dtrNumber = "";
                    PPL_Cables pPL_Cables_Data = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SetBendRadius", MultiBranchableNameTextBox.Text, mainWindow.my_PreProcessing.jsonFilePaths, FirstExtremityTextBox.Text, SecondExtremityTextBox.Text, projectTypeSelected, CableType_Combobox.SelectedItem.ToString()) as PPL_Cables;

                    if (pPL_Cables_Data.Static_Bending_Radius != null)
                    {
                        BendRadiusCheckBox.IsChecked = false;
                        BendRadiuaValue.Text = pPL_Cables_Data.Static_Bending_Radius.ToString();
                        DiameterValue.Text = pPL_Cables_Data.Diameter.ToString();
                        Harness_DTR.Text = pPL_Cables_Data.DTR_Number.ToString();
                        if (!pPL_Cables_Data.Section.ToString().Contains("NA")) SectionTextBox.Text = pPL_Cables_Data.Section.ToString();
                    }
                    else
                    {
                        CableType_Combobox.SelectedItem = null;
                    }

                    WireType_Combobox.IsEnabled = false;
                    WireType_Combobox.SelectedItem = null;
                    CorrugatedCheckbox.IsChecked = false;
                    Supplier_Combobox.SelectedItem = null;
                }
                isSelectionChangedHandled = false;
            }
            catch
            {

            }
        }

        /// <summary>
        /// Reset all the TextBoxes and comboboxes to null or Empty
        /// </summary>
        private void NullValues()
        {
            SectionTextBox.Text = "";
            Harness_DTR.Text = "";
            CorrugatedCheckbox.IsChecked = false;
            BendRadiuaValue.Text = "";
            Supplier_Combobox.SelectedItem = null;
            WireType_Combobox.SelectedItem = null;
            WireType_Combobox.IsEnabled = false;
        }

        /// <summary>
        /// Event for Cable Combobox SelectionChanged
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void Wire_Combobox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Selecting Wire type");
                string selectedWireType = WireType_Combobox.SelectedItem as string;
                if (selectedWireType == null) return;
                double diameter = !string.IsNullOrEmpty(DiameterValue.Text) ? double.Parse(RemoveUnwantedSubstring(DiameterValue.Text)) : 0;

                List<string> inputs = new List<string>();
                inputs.Add(selectedWireType);
                inputs.Add(diameter.ToString());
                string bendradius_Ratio = "";
                ///////////////////////////////////////////// bend radius calculation part :::::::::::::::::::::::::::::::::
                await Task.Run(() =>
                {
                    bendradius_Ratio = CalculateBendRadiusForBundle(selectedWireType, diameter);
                });


                CorrugatedCheckbox.IsChecked = false;
                BendRadiusCheckBox.IsChecked = true;
                BendRadiuaValue.Text = bendradius_Ratio.ToString();
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "Wire Type Selected");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Selected Wire Type");
            });
        }

        /// <summary>
        /// Calculate the BendRadius based on the selected Wire Type.
        /// </summary>
        /// <param name="selectedWireType"></param>
        /// <param name="diameter"></param>
        /// <param name="autoUpdate"></param>
        /// <returns></returns>
        private string CalculateBendRadiusForBundle(string selectedWireType, double diameter, bool autoUpdate = false)
        {
            double bendRadius = 0;
            string bendRadius_Ratio = "";

            if (selectedWireType == "Shielded")
            {
                if (mainWindow.result == MessageBoxResult.None || !autoUpdate)
                {
                    mainWindow.result = alt_PopupMessageUtil.ShowMessageYesNo("Bundle composition is less or equal to 3 wires?", "Wire Quantity", MessageType.Question);
                }

                if (mainWindow.result == MessageBoxResult.No)
                {
                    if (diameter <= 35) bendRadius = 6;
                    else if (diameter > 35 && diameter <= 45) bendRadius = 4;
                    else if (diameter > 45 && diameter <= 70) bendRadius = 3.5;
                    else bendRadius = 2.5;
                    bendRadius_Ratio = bendRadius.ToString();
                }
                else
                {
                    alt_PopupMessageUtil.ShowMessage("Please fill the bend radius manually", "User Input", MessageType.Information);
                    bendRadius_Ratio = "";
                }
            }
            else if (selectedWireType == "Shielded + Not shielded")
            {
                if (mainWindow.result == MessageBoxResult.None || !autoUpdate)
                {
                    mainWindow.result = alt_PopupMessageUtil.ShowMessageYesNo("Bundle composition is less or equal to 5 wires?", "Wire Quantity", MessageType.Question);
                }
                if (mainWindow.result == MessageBoxResult.No) bendRadius_Ratio = "3";
                else
                {
                    bendRadius_Ratio = "";
                    alt_PopupMessageUtil.ShowMessage("Please fill the bend radius manually", "User Input", MessageType.Information);
                }

            }
            else if (selectedWireType == "Network")
            {
                if (mainWindow.result == MessageBoxResult.None || !autoUpdate)
                {
                    mainWindow.result = alt_PopupMessageUtil.ShowMessageYesNo("Bundle composition is less than 5 wires?", "Wire Quantity", MessageType.Question);
                }
                if (mainWindow.result == MessageBoxResult.No)
                {
                    if (diameter <= 35) bendRadius = 3.5;
                    else if (diameter > 35) bendRadius = 6;
                    bendRadius_Ratio = bendRadius.ToString();
                }
                else
                {
                    bendRadius_Ratio = "";
                    alt_PopupMessageUtil.ShowMessage("Please fill the bend radius manually", "User Input", MessageType.Information);
                }
            }
            else
            {
                bendRadius_Ratio = "3";
            }

            return bendRadius_Ratio;
        }

        /// <summary>
        /// Remove Units and return only number
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        private string RemoveUnwantedSubstring(string value)
        {
            if (value.Contains("mm"))
            {
                value = value.Replace("mm", "");
                value = value.Replace(" ", string.Empty);
            }
            else if (value.Contains("inch"))
            {
                value = value.Replace("inch", "");
                value = value.Replace(" ", string.Empty);
            }
            return value;
        }

        /// <summary>
        /// Event for Corrugated Checkbox Checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void CorrugatedCheckbox_Checked(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                Calculate_BendRadius_For_Corrugated();
            });
        }

        /// <summary>
        /// Add a unit to the BendRadius according to the unit used for the Diameter.
        /// </summary>
        private void AddUnitToBendRadius()
        {
            if (BendRadiusCheckBox.IsChecked == false)
            {
                if (DiameterValue.Text.ToLower().Contains("mm") && !BendRadiuaValue.Text.ToLower().Contains("mm") && BendRadiuaValue.Text != "") BendRadiuaValue.Text = BendRadiuaValue.Text.Trim() + " mm";
                else if (DiameterValue.Text.ToLower().Contains("inch") && !BendRadiuaValue.Text.ToLower().Contains("inch") && BendRadiuaValue.Text != "") BendRadiuaValue.Text = BendRadiuaValue.Text.Trim() + " inch";
            }
        }

        /// <summary>
        /// Calculate Bend Radius using supplier data
        /// </summary>
        /// <returns></returns>
        private async Task Calculate_BendRadius_For_Corrugated()
        {
            //string selectedSupplier = Supplier_Combobox.SelectedItem as string;
            //if (selectedSupplier == null)
            //{
            //    alt_PopupMessageUtil.ShowMessage("Please select a supplier", "InvalidInput", MessageType.Error);
            //    CorrugatedCheckbox.IsChecked = false;
            //    return;
            //}

            if (BendRadiusCheckBox.IsChecked == true) _corrugatedSleevMemory = _bendRadiousValue;
            else _corrugatedSleevMemory = BendRadiuaValue.Text;

            if (DiameterValue.Text == "")
            {
                alt_PopupMessageUtil.ShowMessage("Please fill diameter value before selecting the corrugated sleeve", "InvalidInput", MessageType.Error);
                CorrugatedCheckbox.IsChecked = false;
                return;
            }
            //double bendRadius = 0;
            string diameter = RemoveUnwantedSubstring(DiameterValue.Text);
            await Task.Run(() =>
            {
                Selected_PPL_Electricals = orchestrator.Step_1_process<alt_Step1_InputProcessing>("BendRadiusUsingSupplier", diameter) as List<PPL_Electrical>;
            });
            Supplier_ComboboxTextBlock.Visibility = Visibility.Visible;
            Supplier_Combobox.Visibility = Visibility.Visible;
            List<string> DTRs = new List<string>();
            int i = 1;
            foreach (var item in Selected_PPL_Electricals)
            {
                string description = mainWindow.my_Covering.GetDTRDescription(item.DTR_Number);
                if(string.IsNullOrEmpty(description) && i==1) alt_PopupMessageUtil.ShowMessage("Please Extract Sleeve Catalog From PreProcessing", "Warning", MessageType.Warning);
                if (!string.IsNullOrEmpty(description))
                {
                    DTRs.Add(description);
                }
                else
                {
                    DTRs.Add(item.DTR_Number);
                }
                i++;
            }
            Supplier_Combobox.ItemsSource = DTRs;
        }

        /// <summary>
        //// <summary>
        /// Event for ForceWeighPointPLS Checkbox Checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ForceWeighPointPLS_Checked(object sender, RoutedEventArgs e)
        {
            ForceWeighPointEHI.IsEnabled = false;
        }

        /// <summary>
        /// Event for ForceWeighPointPLS Checkbox UnChecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ForceWeighPointPLS_UnChecked(object sender, RoutedEventArgs e)
        {
            ForceWeighPointEHI.IsEnabled = true;
        }

        /// <summary>
        /// Event for ForceWeighPointEHI Checkbox Checked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ForceWeighPointEHI_Checked(object sender, RoutedEventArgs e)
        {
            ForceWeighPointPLS.IsEnabled = false;
        }

        /// <summary>
        /// Event for ForceWeighPointEHI Checkbox UnChecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ForceWeighPointEHI_UnChecked(object sender, RoutedEventArgs e)
        {
            ForceWeighPointPLS.IsEnabled = true;
        }

        /// <summary>
        /// Event for CorrugatedCheckbox Unchecked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CorrugatedCheckbox_Unchecked(object sender, RoutedEventArgs e)
        {
            //if (CableType_Combobox.SelectedItem == "Bundle" && WireType_Combobox.SelectedItem != null)
            //{
            //    BendRadiusCheckBox.IsChecked = true;
            //}
            if (BendRadiusCheckBox.IsChecked == true)
            {
                BendRadiusCheckBox.IsChecked = false;
            }

            BendRadiuaValue.Text = _corrugatedSleevMemory;
            _corrugatedSleevMemory = "";
            Supplier_Combobox.ItemsSource = null;
            Supplier_ComboboxTextBlock.Visibility = Visibility.Collapsed;
            Supplier_Combobox.Visibility = Visibility.Collapsed;
            orchestrator.Step_1_process<alt_Step1_InputProcessing>("Corrugated_Unchecked");
        }

        /// <summary>
        /// Reset Selection of all TextBoxes, CheckBoxes, Combobxes
        /// </summary>
        private void ResetSelection()
        {
            FirstExtremityTextBox.Text = string.Empty;
            FirstExtremityDtrTextBox.Text = string.Empty;

            SecondExtremityTextBox.Text = string.Empty;
            SecondExtremityDtrTextBox.Text = string.Empty;

            DiameterValue.Text = string.Empty;
            Harness_DTR.Text = string.Empty;
            BendRadiusCheckBox.IsChecked = false;

            BendRadiuaValue.Text = string.Empty;
            SectionTextBox.Text = string.Empty;
            ProjectType_Combobox.Text = string.Empty;
            CableType_Combobox.Text = string.Empty;
            WireType_Combobox.Text = string.Empty;
            Supplier_Combobox.Text = string.Empty;

            CorrugatedCheckbox.IsChecked = false;
        }

        /// <summary>
        /// Event for First Extremity Deivation Type Changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Deivation_Type_Changed(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton radioButton)
            {
                orchestrator.Step_1_process<alt_Step1_InputProcessing>("SetDerivationType", radioButton.Content, "1");
            }
        }

        /// <summary>
        /// Event for Second Extremity Deivation Type Changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SecondExtremity_Derivation_Type_Changed(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton radioButton)
            {
                orchestrator.Step_1_process<alt_Step1_InputProcessing>("SetDerivationType", radioButton.Content, "2");
            }
        }
        
        //private void SecondExtremityZone_Button_Click(object sender, RoutedEventArgs e)
        //{
        //    SecondExtremityZonesListBox.Visibility = SecondExtremityZonesListBox.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        //    //SecondExtremityZone_Button.Visibility = Visibility.Collapsed;
        //    //SecondExtremityZonesListBox.Visibility = Visibility.Visible;
        //}

        //private void FirstExtremityZone_Button_Click(object sender, RoutedEventArgs e)
        //{
        //    //FirstExtremityZone_Button.Visibility = Visibility.Collapsed;
        //    FirstExtremityZonesListBox.Visibility = FirstExtremityZonesListBox.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        //}

        //private void CheckBox_Checked(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        Console.WriteLine($"Selected: {option}");
        //        orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateZoneForExtremity","1", option, "+");
        //    }
        //    string SelectedItemsText = string.Join(", ", firstExtremityzones.Where(i => i.FirstExtremityIsSelected).Select(i => i.FirstExtremityZoneName));
        //    FirstExtremityZone_Combobox.Text = SelectedItemsText;
        //}

        //private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        Console.WriteLine($"Deselected: {option}");
        //        orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateZoneForExtremity", "1", option, "-");
        //        // Remove from your selected options collection or update your data model here.
        //    }
        //    string SelectedItemsText = string.Join(", ", firstExtremityzones.Where(i => i.FirstExtremityIsSelected).Select(i => i.FirstExtremityZoneName));
        //    FirstExtremityZone_Combobox.Text = SelectedItemsText;
        //}

        //private void CheckBox_Checked_SecondExtremity(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        Console.WriteLine($"Selected: {option}");
        //        orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateZoneForExtremity", "2", option, "+");
        //    }
        //    string SelectedItemsText = string.Join(", ", secondExtremityZones.Where(i => i.SecondExtremityIsSelected).Select(i => i.SecondExtremityZoneName));
        //    SecondExtremityZone_Combobox.Text = SelectedItemsText;
        //}

        //private void CheckBox_Unchecked_SecondExtremity(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        Console.WriteLine($"Deselected: {option}");
        //        orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateZoneForExtremity", "2", option, "-");
        //        // Remove from your selected options collection or update your data model here.
        //    }
        //    string SelectedItemsText = string.Join(", ", secondExtremityZones.Where(i => i.SecondExtremityIsSelected).Select(i => i.SecondExtremityZoneName));
        //    SecondExtremityZone_Combobox.Text = SelectedItemsText;
        //}

        //private void CheckBox_Checked_MultibranchableZone(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        try
        //        {
        //            selectedMultibranchableZones.Add(option);
        //        }
        //        catch (Exception)
        //        {
        //            ALT_Logging.alt_Logging_class.AddError("Unable to add " + option + " to Selected Zones List");
        //        }
        //    }
        //}

        //private void CheckBox_Unchecked_MultibranchableZone(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        try
        //        {
        //            selectedMultibranchableZones.Remove(option);
        //        }
        //        catch (Exception)
        //        {
        //            ALT_Logging.alt_Logging_class.AddError(option + " is not there in Selected Zones List");
        //        }
                
        //    }
        //}


        //private void FirstExtremityZone_Combobox_DropDownClosed(object sender, EventArgs e)
        //{
        //    string SelectedItemsText = string.Join(", ", firstExtremityzones.Where(i => i.FirstExtremityIsSelected).Select(i => i.FirstExtremityZoneName));
        //    FirstExtremityZone_Combobox.Text = SelectedItemsText;
        //}

        //private void SecondExtremityZone_Combobox_DropDownClosed(object sender, EventArgs e)
        //{
        //    string SelectedItemsText = string.Join(", ", secondExtremityZones.Where(i => i.SecondExtremityIsSelected).Select(i => i.SecondExtremityZoneName));
        //    SecondExtremityZone_Combobox.Text = SelectedItemsText;
        //}
    }
}
