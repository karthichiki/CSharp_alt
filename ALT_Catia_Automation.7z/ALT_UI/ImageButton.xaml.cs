﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for ImageButton.xaml
    /// </summary>
    public partial class ImageButton : UserControl
    {
        public ImageButton()
        {
            InitializeComponent();
        }


        public event RoutedEventHandler Click;

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Click?.Invoke(this, e); // Bubble up the event with 'this' as sender
        }

        //public event RoutedEventHandler Click
        //{
        //    add => buttonControl.Click += value;
        //    remove => buttonControl.Click -= value;
        //}

        public ImageSource ImageSource
        {
            get => imageControl.Source;
            set => imageControl.Source = value;
        }



        /// <summary>
        /// Get or set the image stretch.
        /// </summary>
        public Stretch ImageStretch
        {
            get => imageControl.Stretch;
            set => imageControl.Stretch = value;
        }

        /// <summary>
        /// Get or set the button content.
        /// </summary>
        public string TextContent
        {
            get => textBlock1.Text;
            set => textBlock1.Text = value;
        }

        /// <summary>
        /// 
        /// </summary>
        public Style ButtonStyle
        {
            get => buttonControl.Style;
            set => buttonControl.Style = value;
        }
    }
}
