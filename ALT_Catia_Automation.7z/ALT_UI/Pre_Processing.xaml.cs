﻿using ALT_Data_Model;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Model.UnityDataModel;
using ALT_Data_Preparation;
using ALT_Utilities;
using ApplicationLayer;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Path = System.IO.Path;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for Pre_Processing.xaml
    /// </summary>
    public partial class Pre_Processing : UserControl
    {
        
        private alt_Automation_Orchestrator orchestrator;
        public Dictionary<string, List<PPL_Electrical>> _supplierData = null;
        string tempExcelFolderPath = "";
        const string deleteFolderName = "MyTempExcelFolder";
        private string synopticFilePath = "", extractFAFFilePath = "", ppl_Cables_FilePath = "", ppl_Electricals_FilePath = "", pl3_FilePath = "", pl3_Projet_FilePath="";
        private alt_Utilities utils;
        private List<string> SupplierNames;
        private BranchCreation branchCreation;
        public string CatalogPath = "";
        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        internal FilePaths jsonFilePaths = null;

        public Pre_Processing()
        {
            InitializeComponent();
            utils = new alt_Utilities();
            orchestrator = new alt_Automation_Orchestrator();
            CatalogPath = CatalogCheck();
        }

        /// <summary>
        /// Check the availability of files and show the color
        /// </summary>
        /// <returns> path </returns>
        public string CatalogCheck()
        {
            string Trigram = alt_CATIA_Adapter.GetInstance().GetEnvVariable("localTrigram");
            string localTrigram = Trigram != string.Empty?Trigram:"QAL";
            string initialTrigramFolderName = "DMAGS_" + localTrigram;
            string UserProfile = Environment.GetFolderPath(System.Environment.SpecialFolder.UserProfile);
            string CatalogLocation = @"CatiaV5\Catalog\Lib_ELEC_Catalog";
            string FileName = Properties.Settings.Default["Sleeve_File_Name"].ToString();
            string fullPath = Path.Combine(UserProfile, initialTrigramFolderName, CatalogLocation, FileName);
            if (File.Exists(fullPath))
            {
                Sleeve_Catalog_Status_Text.Text = "Available";
                Sleeve_Catalog_Status.Fill = new SolidColorBrush(Colors.Green);
            }
            else
            {
                Sleeve_Catalog_Status_Text.Text = "UnAvailable";
                Sleeve_Catalog_Status.Fill = new SolidColorBrush(Colors.Red);
            }
            return fullPath;    
        }

        /// <summary>
        /// Check the availability of selected files and show the color if no file selected
        /// </summary>
        internal void CheckSelectedFile()
        {
            if (Synoptic_TextBox.Text == "No file selected") { Synoptic_GreenSignal.Fill = new SolidColorBrush(Colors.Gray); ConvertXLSToJson.Visibility = Visibility.Visible; } else { Synoptic_GreenSignal.Fill = new SolidColorBrush(Colors.Green); }
            if (Extract_FaF_TextBox.Text == "No file selected") { Extract_FaF_GreenSignal.Fill = new SolidColorBrush(Colors.Gray); ConvertXLSToJson.Visibility = Visibility.Visible; } else { Extract_FaF_GreenSignal.Fill = new SolidColorBrush(Colors.Green); }
            if (PPL_Cables_TextBox.Text == "No file selected") { PPL_Cables_GreenSignal.Fill = new SolidColorBrush(Colors.Gray); ConvertXLSToJson.Visibility = Visibility.Visible; } else { PPL_Cables_GreenSignal.Fill = new SolidColorBrush(Colors.Green); }
            if (PPL_Electrical_TextBox.Text == "No file selected") { PPL_Electrical_GreenSignal1.Fill = new SolidColorBrush(Colors.Gray); ConvertXLSToJson.Visibility = Visibility.Visible; } else { PPL_Electrical_GreenSignal1.Fill = new SolidColorBrush(Colors.Green); }
            if (PL3_TextBox.Text == "No file selected") { PL3_GreenSignal1.Fill = new SolidColorBrush(Colors.Gray); ConvertXLSToJson.Visibility = Visibility.Visible; } else { PL3_GreenSignal1.Fill = new SolidColorBrush(Colors.Green); }
            if (PL3_Projet_TextBox.Text == "No file selected") { PL3_Projet_GreenSignal1.Fill = new SolidColorBrush(Colors.Gray); ConvertXLSToJson.Visibility = Visibility.Visible; } else { PL3_Projet_GreenSignal1.Fill = new SolidColorBrush(Colors.Green); }
        }

        /// <summary>
        /// covert selected files to json
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ConvertXLSToJson_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                if (Synoptic_TextBox.Text == "No file selected" || 
                    Extract_FaF_TextBox.Text == "No file selected" || 
                    PPL_Cables_TextBox.Text == "No file selected" || 
                    PPL_Electrical_TextBox.Text == "No file selected" || 
                    PL3_TextBox.Text == "No file selected")
                {
                    SubmitValidationTextBlock.Text = "Please Select all required files";
                    SubmitValidationTextBlock.Background = new SolidColorBrush(Colors.Red);
                    if (Synoptic_TextBox.Text == "No file selected") Synoptic_GreenSignal.Fill = new SolidColorBrush(Colors.Red);
                    if (Extract_FaF_TextBox.Text == "No file selected") Extract_FaF_GreenSignal.Fill = new SolidColorBrush(Colors.Red);
                    if (PPL_Cables_TextBox.Text == "No file selected") PPL_Cables_GreenSignal.Fill = new SolidColorBrush(Colors.Red);
                    if (PPL_Electrical_TextBox.Text == "No file selected") PPL_Electrical_GreenSignal1.Fill = new SolidColorBrush(Colors.Red);
                    if (PL3_TextBox.Text == "No file selected") PL3_GreenSignal1.Fill = new SolidColorBrush(Colors.Red);
                    if (PL3_Projet_TextBox.Text == "No file selected") PL3_Projet_GreenSignal1.Fill = new SolidColorBrush(Colors.Red);
                    return;
                }
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start Extracting the Selected Files...");
                string extracted_Location = "";
                await Task.Run(() =>
                {
                    extracted_Location = orchestrator.step_0_process<alt_Step0_PreProcessing>("ConvertExcelToJson", synopticFilePath, extractFAFFilePath, ppl_Cables_FilePath, ppl_Electricals_FilePath, pl3_FilePath,pl3_Projet_FilePath, deleteFolderName) as string;
                });

                jsonFilePaths = orchestrator.step_0_process<alt_Step0_PreProcessing>("InitializeInputProcessing", Synoptic_TextBox, Extract_FaF_TextBox, PPL_Cables_TextBox, PPL_Electrical_TextBox, PL3_TextBox,PL3_Projet_TextBox) as FilePaths;
                CheckSelectedFile();
                SubmitValidationTextBlock.Text = "Files are extracted in Path \"" + extracted_Location + "\"";
                SubmitValidationTextBlock.Background = new SolidColorBrush(Colors.White);
                DeleteCopiedFiles();
                CollectSupplierData();
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the Selected Files");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Extracted files are stored in the default location.");

            });
        }

        // File browse method, accepts the TextBox to update with the selected file path
        /// <summary>
        /// Browse file 
        /// </summary>
        /// <param name="textBox"> path value</param>
        /// <param name="file"> file name</param>
        /// <param name="Signal"> </param>
        /// <param name="validation_Textblock"></param>
        /// <returns></returns>
        private string BrowseFile(TextBox textBox, String file, Ellipse Signal, TextBlock validation_Textblock)
        {
            object excelFilePath = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Browse_file", "Excel Source File | *.xlsx");
            if (excelFilePath == string.Empty) return "";
            string pastedExcel = CopyPasteExcel(excelFilePath.ToString());
            if (pastedExcel == string.Empty) return "";
            Signal.Fill = new SolidColorBrush(Colors.Gray);
            bool result = Validate_SelectedFile(textBox, file, Signal, pastedExcel, validation_Textblock);
            if (result)
            {
                ConvertXLSToJson.Visibility = Visibility.Visible;
                return excelFilePath as string;
            }
            else
            {
                return string.Empty;
            }
        }

        private void DeleteCopiedFiles()
        {
            if (Directory.Exists(tempExcelFolderPath))
            {
                Directory.Delete(tempExcelFolderPath, true);
            }
        }

        /// <summary>
        /// Collect supplier data from PPL_Electrical json file
        /// </summary>
        internal async void CollectSupplierData()
        {

            try
            {
                _supplierData = new Dictionary<string, List<PPL_Electrical>>();
                if (jsonFilePaths == null || jsonFilePaths.PPL_Electrical_Path == null) return;
                string filePath = jsonFilePaths.PPL_Electrical_Path;
                if (!File.Exists(filePath))
                {
                    //alt_PopupMessageUtil.ShowMessage("The PPL_ELECTRICAL FITTING_SHEATH_RevAB01.json file does not exist in the selected location", "FileNotFound", MessageType.Error);
                }
                await Task.Run(() =>
                {
                    _supplierData = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadSupplierData", filePath) as Dictionary<string, List<PPL_Electrical>>;
                });
                //_supplierData.Remove("SUPPLIER 1");
                //mainWindow.my_BranchCreation.BindSupplierComboBox();
            }
            catch { }

        }

        /// <summary>
        /// Extract EQT location from CATIA
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ExtractEQTLocation_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                string result = string.Empty;
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the EQT connectors data.");
                //await MainWindow.progressBar.ProcessWithProgressAsync(10, "Start extracting the EQT connectors data.");
                await Task.Run(() =>
                {
                    result = orchestrator.step_0_process<alt_Step0_PreProcessing>("ExportEqtLocation") as string;
                });

                if (result == string.Empty)
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the EQT connectors data");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: EQT connectors are stored in the default location.");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the EQT connectors data");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: " + result);
                }
            });
        }

        /// <summary>
        /// Copy selected files and paste it in temp folder
        /// </summary>
        /// <param name="inputFilePath"> File path </param>
        /// <returns></returns>
        private string CopyPasteExcel(string inputFilePath)
        {
            // Validate input
            if (!File.Exists(inputFilePath))
            {
                MessageBox.Show("Invalid file path.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return "";
            }

            // Get the temporary folder path
            string releaseFolderDirectory = orchestrator.step_0_process<alt_Step0_PreProcessing>("GetCatiaFolderPath") as string;
            tempExcelFolderPath = Path.Combine(releaseFolderDirectory, "MyTempExcelFolder");
            //tempExcelFolderPath = orchestrator.step_0_process<alt_Step0_PreProcessing>(releaseFolderDirectory, mainWindow.deleteFolderName) as string;
            // Create the folder if it doesn't exist
            if (!Directory.Exists(tempExcelFolderPath))
            {
                Directory.CreateDirectory(tempExcelFolderPath);
            }

            // Define the destination path
            string fileName = Path.GetFileName(inputFilePath);
            string destinationPath = Path.Combine(tempExcelFolderPath, fileName);

            // Copy the file to the temporary folder
            File.Copy(inputFilePath, destinationPath, overwrite: true);

            return destinationPath;
        }

        /// <summary>
        /// Validate the excel file slected
        /// </summary>
        /// <param name="textBox"> Text box</param>
        /// <param name="file"> File name </param>
        /// <param name="Signal"></param>
        /// <param name="excelFilePath"> File path</param>
        /// <param name="validation_Textblock"></param>
        /// <returns></returns>
        private bool Validate_SelectedFile(TextBox textBox, string file, Ellipse Signal, object excelFilePath, TextBlock validation_Textblock)
        {
            string filePath = excelFilePath.ToString();
            if (ValidateFile(filePath, file))
            {
                Signal.Fill = new SolidColorBrush(Colors.Green);
                textBox.Text = Path.GetFileNameWithoutExtension(excelFilePath.ToString()).Replace(".json", "");
                return true;
            }
            else
            {
                Signal.Fill = new SolidColorBrush(Colors.Yellow);
                validation_Textblock.Text = "Please select the appropriate file.";
                return false;
                //Synoptic_Validation.Background = new SolidColorBrush(Colors.Red);
            }
        }

        /// <summary>
        /// Validate the file using orchestrator
        /// </summary>
        /// <param name="filePath"> File path</param>
        /// <param name="file"> File name </param>
        /// <returns></returns>
        private bool ValidateFile(string filePath, string file)
        {
            string correctFile = orchestrator.Step_1_process<alt_Step1_InputProcessing>(file, filePath) as string;
            return (correctFile.ToLower() == "true") ? true : false;

        }

        /// <summary>
        /// Browse and select the synoptic file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SynopticSelection_Click_1(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                SubmitValidationTextBlock.Text = string.Empty;
                Synoptic_Validation.Text = string.Empty;
                synopticFilePath = BrowseFile(Synoptic_TextBox, "Validate_Synoptic_File", Synoptic_GreenSignal, Synoptic_Validation);
            });
                
        }

        /// <summary>
        /// Browse and select the Extract FAF file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ExtractFAFSelection_Click_1(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                SubmitValidationTextBlock.Text = string.Empty;
                Extract_FaF_Validation.Text = string.Empty;
                extractFAFFilePath = BrowseFile(Extract_FaF_TextBox, "Validate_Extract_faf_File", Extract_FaF_GreenSignal, Extract_FaF_Validation);
            });
            
        }

        /// <summary>
        /// Browse and select the PPL Cables file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void PPLCablesSelection_Click_1(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                SubmitValidationTextBlock.Text = string.Empty;
                PPL_Cables_Validation.Text = string.Empty;
                ppl_Cables_FilePath = BrowseFile(PPL_Cables_TextBox, "Validate_PPL_Cables_File", PPL_Cables_GreenSignal, PPL_Cables_Validation);
            });
            
        }

        /// <summary>
        /// Browse and select the PPL Electrical file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void PPLElectricalSelection_Click_1(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                SubmitValidationTextBlock.Text = string.Empty;
                PPL_Electrical_Validation.Text = string.Empty;
                ppl_Electricals_FilePath = BrowseFile(PPL_Electrical_TextBox, "Validate_PPL_Electrical_File", PPL_Electrical_GreenSignal1, PPL_Electrical_Validation);
            });
        }

        /// <summary>
        /// Bulk extraction of IGES files status check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BulkExtraction_Checked(object sender, RoutedEventArgs e)
        {
            IGESExtractButton.IsEnabled = true;
        }

        private void BulkExtraction_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        /// <summary>
        /// Custom extraction of IGES files status check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomRadioButton_Checked(object sender, RoutedEventArgs e)
        {
            IGESExtractButton.IsEnabled = true;
            //DirectionSelectionCheckBox.Visibility = Visibility.Visible;
        }

        /// <summary>
        /// Custom extraction of IGES files status check
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CustomRadioButton_Unchecked(object sender, RoutedEventArgs e)
        {
                //DirectionSelectionCheckBox.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// Extract section cut segments from CATIA
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ExtractSectionCut_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                //ExtractIgesData
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the Section Cut data.");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Section Cut Extraction started.");
                this.IsEnabled = false;
                string result = "";
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    result = orchestrator.step_0_process<alt_Step0_PreProcessing>("ExtractSectionCutSegments") as string;
                    utils.BringApplicationToFront("ALT_UI");
                });
                this.IsEnabled = true;
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the Section Cut data.");
                if (result == string.Empty)
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Section Cut  Extraction is sucessfully completed.");
                else
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Section Cut  Extraction is unsucessfull, Please check.");
            });
        }

        private void DirectionSelectionCheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }

        private void DirectionSelectionCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {

        }

        /// <summary>
        /// Browse and select the 3PL file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ThreePLSelection_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                SubmitValidationTextBlock.Text = string.Empty;
                PL3_Validation.Text = string.Empty;
                pl3_FilePath = BrowseFile(PL3_TextBox, "Validate_3PL_File", PL3_GreenSignal1, PL3_Validation);
            });
        }

        /// <summary>
        /// Browse and select the 3PL_Projet file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ThreePL_Projet_Selection_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                SubmitValidationTextBlock.Text = string.Empty;
                PL3_Projet_Validation.Text = string.Empty;
                pl3_Projet_FilePath = BrowseFile(PL3_Projet_TextBox, "Validate_3PL_Projet_File", PL3_Projet_GreenSignal1, PL3_Projet_Validation);
            });
        }

        /// <summary>
        /// Extract IGES files from CATIA
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Extract_IGES_Click_1(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                //ExtractIgesData
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the IGES data.");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : IGS Extraction started.");
                this.IsEnabled = false;
                bool BulkExtractionChecked = BulkExtraction.IsChecked.Value;

                await Task.Run(() =>
                {
                    if (BulkExtractionChecked)
                    {
                        orchestrator.step_0_process<alt_Step0_PreProcessing>("BulkExtractIgesData");
                    }
                    else
                    {
                        utils.BringApplicationToFront("CNEXT");
                        orchestrator.step_0_process<alt_Step0_PreProcessing>("CustomExtractIgesData");

                        utils.BringApplicationToFront("ALT_UI");
                    }
                });
                this.IsEnabled = true;
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the IGES data.");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : IGS Extraction is sucessfully completed.");
            });
        }

        /// <summary>
        /// Run the command to extract GH file from CATIA
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void RunCommand_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Please click OK in CATIA to extract GH file.", "Extract GH", MessageBoxButton.OK, MessageBoxImage.Information);
            await mainWindow.ShowOverlayAsync(async () =>
            {
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    orchestrator.Step_1_process<alt_Step1_InputProcessing>("RunCommand");
                });
            });
        }

        /// <summary>
        /// Extract Sleeve Catalog data from CATIA
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void ExtractSleeveCatalog_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start extracting the Sleeve Catalog data.");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Sleeve Catalog Extraction started.");
                string result = "";
                if (string.IsNullOrEmpty(CatalogPath))
                    result = "2";
                else
                    result = orchestrator.step_0_process<alt_Step0_PreProcessing>("ExtractCatalogData", CatalogPath) as string;

                if (result == string.Empty)
                {
                    alt_PopupMessageUtil.ShowMessage("Please Open any CATProduct In CATIA and Try again", "Error", MessageType.Error);
                    ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End extracting the Sleeve Catalog data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Sleeve Catalog Extraction Failed.");
                }
                else if (result != "1")
                {
                    alt_PopupMessageUtil.ShowMessage("Extracion of catalog failed", "Error", MessageType.Error);
                    ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End extracting the Sleeve Catalog data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Sleeve Catalog Extraction Failed.");
                }
                else
                {
                    mainWindow.my_Covering.ReadSleeveCatalog();
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End extracting the Sleeve Catalog data.");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status : Sleeve Catalog Extraction is sucessfully completed.");
                }

            });
        }

    
    }
}
