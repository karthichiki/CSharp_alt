﻿using ALT_CATIA_Adapter;
using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Preparation;
using ALT_Unity_Interface;
using ALT_Utilities;
using ApplicationLayer;
using Infrastructure_Layer.ALT_CATIA_Adapter;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Policy;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Shell;
using File = System.IO.File;
using JsonSerializer = System.Text.Json.JsonSerializer;
using Path = System.IO.Path;

namespace ALT_UI
{
    /// <summary>
    /// Loads SharePoint access configuration from a JSON file.
    /// </summary>
    /// <param name="configPath">Full file path to the configuration JSON.</param>
    /// <returns>Returns a populated <see cref="AppConfig"/> instance or null if the file doesn't exist.</returns>
    public class AppConfig
    {
        public string TenantId { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string SiteUrl { get; set; }
        public string ResourceId { get; set; }
        public string SharePointRootPath { get; set; }
        public string BaseLineEnvVar { get; set; }
        public string ZoneEnvVar { get; set; }
        public bool SharePointAccessConfigFound { get; set; } = false;

        public static AppConfig Load(string configPath)
        {
            if (!File.Exists(configPath))
            {
                //throw new FileNotFoundException($"Configuration file not found at {configPath}");
                //AppConfig.SharePointAccessConfigFound = false;
                return null;
            }
            else
            {
                //SharePointAccessConfigFound = true
                string json = File.ReadAllText(configPath);
                return JsonSerializer.Deserialize<AppConfig>(json);
            }            
        }
    }
    
    public class UserSelection
    {
        public string Project { get; set; }
        public string Zone { get; set; }
        public string Baseline { get; set; }
        public string Version { get; set; }
    }

    public class SharePointZipDownloader
    {
        private readonly string project;
        private readonly string zone;
        private readonly string baseline;
        public AppConfig SharePointAccessConfig { get; set; } = null;

        //All of below are coming from config file
        //private readonly string tenantId = "0d993ad3-fa73-421a-b129-1fe5590103f3";
        //private readonly string clientId = "07cf4826-3135-4b7a-9c81-1874ae9140ba";
        //private readonly string clientSecret = "NG82OFF+c19VWEMxSGJieG5+SzVhT2Q5aE8tOVdza2dIMEpQSWJjbg==";
        //private readonly string siteUrl = "https://alstomgroup.sharepoint.com/sites/VPF1-DMAexchangeswithRATP";

        private readonly HttpClient httpClient = new HttpClient();

        /// <summary>
        /// Checks for the HAT_SharePoint_Access_Config.json file in the DMAGS_QAL folder (common path). 
        /// If the file is not found, attempts to retrieve it from UserRootPath and displays a message box if the file cannot be located.
        /// </summary>
        public SharePointZipDownloader(string project, string zone, string baseline, string UserRootPath)
        {
            this.project = project;
            this.zone = zone;
            this.baseline = baseline;

            string siteId = alt_CATIA_Adapter.GetInstance().GetEnvVariable("localTrigram");
            string userName = Environment.UserName;
            string SharePointAccessConfigPath = $@"C:\Users\{userName}\DMAGS_{siteId}\CatiaV5\ConfigurationFiles\HAT\HAT_SharePoint_Access_Config.json";
            
            if (!File.Exists(SharePointAccessConfigPath))
            {
                //check local file when server file is not available
                string LocalSharePointAccessConfigPath = $@"{UserRootPath}\HAT_SharePoint_Access_Config.json";

                if (!File.Exists(LocalSharePointAccessConfigPath))
                {
                    alt_PopupMessageUtil.ShowMessage($"HAT Project SharePoint Config file not found in folder {SharePointAccessConfigPath} or locally at {LocalSharePointAccessConfigPath}. Please contact DMA admin for help.", "Warning", MessageType.Warning);
                    return;
                }
                SharePointAccessConfigPath = LocalSharePointAccessConfigPath;
            }
            SharePointAccessConfig = AppConfig.Load(SharePointAccessConfigPath);
            SharePointAccessConfig.SharePointAccessConfigFound = true;
        }

        /// <summary>
        /// Checks for the HAT_SharePoint_Access_Config.json file in the DMAGS_QAL folder (common path). 
        /// If the file is not found, attempts to retrieve it from UserRootPath and displays a message box if the file cannot be located.
        /// </summary>
        public SharePointZipDownloader(string UserRootPath, bool verbose=true)
        {
            string siteId = alt_CATIA_Adapter.GetInstance().GetEnvVariable("localTrigram");
            string userName = Environment.UserName;
            string SharePointAccessConfigPath = $@"C:\Users\{userName}\DMAGS_{siteId}\CatiaV5\ConfigurationFiles\HAT\HAT_SharePoint_Access_Config.json";
            if (!File.Exists(SharePointAccessConfigPath))
            {
                //check local file when server file is not available
                string LocalSharePointAccessConfigPath = $@"{UserRootPath}\HAT_SharePoint_Access_Config.json";

                if (!File.Exists(LocalSharePointAccessConfigPath))
                {
                    if (verbose) alt_PopupMessageUtil.ShowMessage($"HAT Project SharePoint Config file not found in folder {SharePointAccessConfigPath} or locally at {LocalSharePointAccessConfigPath}. Please contact DMA admin for help.", "Warning", MessageType.Warning);
                    return;
                }
                SharePointAccessConfigPath = LocalSharePointAccessConfigPath;
            }
            SharePointAccessConfig = AppConfig.Load(SharePointAccessConfigPath);
            SharePointAccessConfig.SharePointAccessConfigFound = true;
        }

        /// <summary>
        /// Downloads a SharePoint folder and saves it as a local ZIP archive.
        /// </summary>
        /// <param name="folderRelativeUrl">Relative URL of the folder in SharePoint.</param>
        /// <param name="outputZipPath">Local path to save the resulting ZIP file.</param>
        /// <returns>Path to the saved ZIP file.</returns>
        public async Task<string> DownloadFolderAsZipAsync(string folderRelativeUrl, string outputZipPath)
        {
            var token = await GetAccessTokenAsync();

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            httpClient.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");

            var tempDir = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());
            Directory.CreateDirectory(tempDir);

            await DownloadFolderRecursive(folderRelativeUrl, tempDir);

            ZipFile.CreateFromDirectory(tempDir, outputZipPath, CompressionLevel.Fastest, false);
            Directory.Delete(tempDir, true);

            return outputZipPath;
        }

        /// <summary>
        /// Recursively downloads all files and subfolders from a SharePoint folder.
        /// </summary>
        /// <param name="folderRelativeUrl">Relative SharePoint folder URL.</param>
        /// <param name="localPath">Local destination path for downloads.</param>
        /// 
        private async Task DownloadFolderRecursive(string folderRelativeUrl, string localPath)
        {
            Directory.CreateDirectory(localPath);

            var files = await GetFileListAsync(folderRelativeUrl);
            foreach (var file in files)
            {
                var fileName = file.GetProperty("Name").GetString();
                var fileUrl = file.GetProperty("ServerRelativeUrl").GetString();
                var downloadUrl = $"{SharePointAccessConfig.SiteUrl}/_api/web/getfilebyserverrelativeurl('{fileUrl}')/$value";

                var downloadPath = Path.Combine(localPath, fileName);

                Stream responseStream = null;
                FileStream fileStream = null;
                try
                {
                    responseStream = await httpClient.GetStreamAsync(downloadUrl);
                    fileStream = new FileStream(downloadPath, FileMode.Create, FileAccess.Write, FileShare.None);
                    await responseStream.CopyToAsync(fileStream);
                    await fileStream.FlushAsync();
                }
                finally
                {
                    if (responseStream != null)
                        responseStream.Close();

                    if (fileStream != null)
                        fileStream.Close();
                }
            }

            var subFolders = await GetSubFoldersAsync(folderRelativeUrl);
            List<string> AllPorjectsCommonFolderNames = PathHelper.GetEachProjectCommonFolderNames();

            foreach (var folder in subFolders)
            {
                var folderName = folder.GetProperty("Name").GetString();
                if (folderName.ToUpper().Contains("Backup".ToUpper())) { continue; }
                var folderUrl = folder.GetProperty("ServerRelativeUrl").GetString();

                if (folderName.Equals("Forms", StringComparison.OrdinalIgnoreCase))
                    continue;

                var subLocalPath = Path.Combine(localPath, folderName);
                await DownloadFolderRecursive(folderUrl, subLocalPath);
            }
        }

        /// <summary>
        /// Retrieves an access token using SharePoint credentials.
        /// </summary>
        /// <returns>OAuth2 access token string.</returns>
        /// <exception cref="Exception">Thrown if token retrieval fails.</exception>
        private async Task<string> GetAccessTokenAsync()
        {
            var resource = $"{SharePointAccessConfig.ResourceId}@{SharePointAccessConfig.TenantId}";
            var tokenEndpoint = $"https://accounts.accesscontrol.windows.net/{SharePointAccessConfig.TenantId}/tokens/OAuth/2";

            var content = new FormUrlEncodedContent(new[]
            {
            new KeyValuePair<string, string>("grant_type", "client_credentials"),
            new KeyValuePair<string, string>("client_id", $"{SharePointAccessConfig.ClientId}@{SharePointAccessConfig.TenantId}"),
            new KeyValuePair<string, string>("client_secret", SharePointAccessConfig.ClientSecret),
            new KeyValuePair<string, string>("resource", resource),
        });

            var response = await httpClient.PostAsync(tokenEndpoint, content);
            var result = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                throw new Exception($"Token fetch failed: {result}");

            var json = JsonDocument.Parse(result);
            return json.RootElement.GetProperty("access_token").GetString();
        }

        /// <summary>
        /// Fetches file list from the specified SharePoint folder.
        /// </summary>
        /// <param name="folderRelativeUrl">Relative URL to the folder.</param>
        /// <returns>List of file metadata elements.</returns>
        private async Task<List<JsonElement>> GetFileListAsync(string folderRelativeUrl)
        {
            var endpoint = $"{SharePointAccessConfig.SiteUrl}/_api/web/GetFolderByServerRelativeUrl('{folderRelativeUrl}')/Files";
            var res = await httpClient.GetStringAsync(endpoint);
            var doc = JsonDocument.Parse(res);

            return new List<JsonElement>(
                doc.RootElement.GetProperty("d").GetProperty("results").EnumerateArray()
            );
        }

        /// <summary>
        /// Fetches list of subfolders for the given SharePoint folder.
        /// </summary>
        /// <param name="folderRelativeUrl">Relative folder path in SharePoint.</param>
        /// <returns>List of folder metadata elements.</returns>
        private async Task<List<JsonElement>> GetSubFoldersAsync(string folderRelativeUrl)
        {
            var endpoint = $"{SharePointAccessConfig.SiteUrl}/_api/web/GetFolderByServerRelativeUrl('{folderRelativeUrl}')/Folders";
            var res = await httpClient.GetStringAsync(endpoint);
            var doc = JsonDocument.Parse(res);

            return new List<JsonElement>(
                doc.RootElement.GetProperty("d").GetProperty("results").EnumerateArray()
            );
        }

        /// <summary>
        /// Extracts a ZIP file into a specified directory and deletes the ZIP afterward.
        /// </summary>
        /// <param name="zipFilePath">Full path to the ZIP file.</param>
        /// <param name="destinationPath">Target extraction directory.</param>
        /// <returns>Path to the extracted folder.</returns>
        public bool UnzipToUserDirectory(string zipFilePath, string destinationPath)
        {
            bool ret = false;
            List<string> Failedfiles = new List<string>();

            using (ZipArchive archive = ZipFile.OpenRead(zipFilePath))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    string fullPath = Path.Combine(destinationPath, entry.FullName);

                    // Skip directory entries
                    if (string.IsNullOrEmpty(entry.Name))
                        continue;

                    try
                    {
                        // Ensure directory exists
                        string directoryPath = Path.GetDirectoryName(fullPath);
                        if (!Directory.Exists(directoryPath))
                            Directory.CreateDirectory(directoryPath);

                        // Overwrite file
                        using (FileStream fs = new FileStream(fullPath, FileMode.Create, FileAccess.Write, FileShare.None))
                        using (Stream entryStream = entry.Open())
                        {
                            entryStream.CopyTo(fs);
                        }
                    }
                    catch (IOException ioEx)
                    {
                        Failedfiles.Add(entry.FullName);
                        // Handle locked files or other IO issues
                        alt_PopupMessageUtil.ShowMessage($"Skipped locked or inaccessible file: {entry.FullName}. Reason: {ioEx.Message}", "Warning", MessageType.Warning);                        
                    }
                }
            }

            if (File.Exists(zipFilePath))
                File.Delete(zipFilePath);
                        
            return Failedfiles.Count == 0;
        }
        
        /// <summary>
        /// Generates a JSON structure representing SharePoint folder hierarchy with support for Project_ folders containing SYNOPTIC and Zone_ folders.
        /// Projects without SYNOPTIC folder are skipped.
        /// </summary>
        /// <param name="rootRelativeUrl">Relative path of the root folder.</param>
        /// <param name="outputJsonPath">Full path to save the JSON file.</param>
        /// <returns>Path to the saved JSON file.</returns>
        public async Task<string> ExportProjectStructureAsJsonAsync(string rootRelativeUrl, string outputJsonPath)
        {
            var token = await GetAccessTokenAsync();

            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            httpClient.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");

            var rootStructure = new Dictionary<string, object>();
            var projectFolders = await GetSubFoldersAsync(rootRelativeUrl);

            foreach (var projectFolder in projectFolders)
            {
                var projectName = projectFolder.GetProperty("Name").GetString();
                if (!projectName.StartsWith("Project_", StringComparison.OrdinalIgnoreCase)) continue;

                var projectUrl = projectFolder.GetProperty("ServerRelativeUrl").GetString();
                var synopticUrl = $"{projectUrl}/SYNOPTIC";

                // Check if SYNOPTIC exists
                List<JsonElement> synopticFolders;
                try
                {
                    synopticFolders = await GetSubFoldersAsync(synopticUrl);
                    if (synopticFolders.Count == 0) continue; // skip if SYNOPTIC has no baselines
                }
                catch
                {
                    continue; // skip if SYNOPTIC does not exist or fails to load
                }

                var projectEntry = new Dictionary<string, object>();

                // Handle SYNOPTIC -> BASELINE_X -> BASELINE_1.0/2.0
                var synopticStructure = new Dictionary<string, List<string>>();
                foreach (var baselineFolder in synopticFolders)
                {
                    var baselineName = baselineFolder.GetProperty("Name").GetString();
                    var baselineUrl = baselineFolder.GetProperty("ServerRelativeUrl").GetString();

                    var versionFolders = await GetSubFoldersAsync(baselineUrl);
                    var versionNames = versionFolders.Select(v => v.GetProperty("Name").GetString()).ToList();

                    synopticStructure[baselineName] = versionNames;
                }
                projectEntry["SYNOPTIC"] = synopticStructure;

                // Handle Zone_ folders
                var zones = new List<string>();
                var allSubFolders = await GetSubFoldersAsync(projectUrl);

                foreach (var folder in allSubFolders)
                {
                    var name = folder.GetProperty("Name").GetString();
                    if (name.StartsWith("Zone_", StringComparison.OrdinalIgnoreCase))
                    {
                        zones.Add(name);
                    }
                }
                projectEntry["ZONES"] = zones;

                rootStructure[projectName] = projectEntry;
            }

            var options = new JsonSerializerOptions { WriteIndented = true };
            var json = JsonSerializer.Serialize(rootStructure, options);
            await Task.Run(() => File.WriteAllText(outputJsonPath, json));
            return outputJsonPath;
        }

        private async Task<Dictionary<string, object>> GetFolderStructureAsync(string folderRelativeUrl)
    => await GetFolderStructureAsync(folderRelativeUrl, 1);

        /// <summary>
        /// Recursively builds folder structure dictionary from SharePoint (up to 3 levels deep).
        /// </summary>
        /// <param name="folderRelativeUrl">SharePoint folder path.</param>
        /// <param name="level">Current recursion level.</param>
        /// <returns>Dictionary representing folder hierarchy.</returns>
        private async Task<Dictionary<string, object>> GetFolderStructureAsync(string folderRelativeUrl, int level)
        {
            var structure = new Dictionary<string, object>();
            if (level > 4) return structure;

            var subFolders = await GetSubFoldersAsync(folderRelativeUrl);

            foreach (var folder in subFolders)
            {
                var name = folder.GetProperty("Name").GetString();
                var relativeUrl = folder.GetProperty("ServerRelativeUrl").GetString();
                structure[name] = await GetFolderStructureAsync(relativeUrl, level + 1);
            }

            return structure;
        }

        /// <summary>
        /// Downloads only the files (not folders or subfolders) from a specified SharePoint folder
        /// and saves them to a specified local directory.
        /// </summary>
        /// <param name="folderRelativeUrl">
        /// The server-relative URL of the SharePoint folder (e.g., "/sites/siteName/Shared Documents/Folder").
        /// </param>
        /// <param name="localPath">
        /// The full local directory path where the files will be saved. Directory will be created if it doesn't exist.
        /// </param>
        /// <returns>
        /// A task representing the asynchronous operation.
        /// </returns>
        /// <remarks>
        /// This method does not recurse into subfolders. It only processes files that are directly under the given folder.
        /// It also overwrites existing local files with the same name.
        /// </remarks>
        public async Task DownloadFilesInFolderOnlyAsync(string folderRelativeUrl, string localPath)
        {
            //Directory.CreateDirectory(localPath);

            var files = await GetFileListAsync(folderRelativeUrl);
            foreach (var file in files)
            {
                var fileName = file.GetProperty("Name").GetString();
                var fileUrl = file.GetProperty("ServerRelativeUrl").GetString();
                var downloadUrl = $"{SharePointAccessConfig.SiteUrl}/_api/web/getfilebyserverrelativeurl('{fileUrl}')/$value";

                var downloadPath = Path.Combine(localPath, fileName);
                Stream responseStream = null;
                FileStream fileStream = null;
                try
                {
                    responseStream = await httpClient.GetStreamAsync(downloadUrl);
                    fileStream = new FileStream(downloadPath, FileMode.Create, FileAccess.Write, FileShare.None);
                    await responseStream.CopyToAsync(fileStream);
                    await fileStream.FlushAsync();
                }
                finally
                {
                    if (responseStream != null) responseStream.Close();
                    if (fileStream != null) fileStream.Close();
                }
            }
        }
    }


    public static class PathHelper
    {
        /// <summary>
        /// Returns the user-specific root path for HAT project files.
        /// </summary>
        /// <returns>Full path to user's HAT data directory.</returns>
        public static string GetUserHATRootPath()
        {
            string userRoot = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            string UserHATBasePath = System.IO.Path.Combine(userRoot, "Harness_Assistant_Data");
            return UserHATBasePath;
        }

        /// <summary>
        /// Retrieves the names of common folders to be copied from all projects.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetAllProjectCommonFolderNames()
        {
            return new List<string>
            {
                "ACCESSORIES",
                "PPL"
            };
        }

        /// <summary>
        /// Retrieves the names of common folders to be copied from each project.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetEachProjectCommonFolderNames()
        {
            return new List<string>
            {
                "3PL"
            };
        }
    }

    /// <summary>
    /// Interaction logic for SharePoint_Synchronization.xaml
    /// </summary>
    public partial class SharePoint_Synchronization : UserControl
    {
        private alt_Automation_Orchestrator orchestrator;
        Dictionary<string, Dictionary<string, object>> configData = null;
        //Coming from config file
        //private string BaseLineDirEnv = "HAT_User_Baseline_Path";

        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        public SharePoint_Synchronization()
        {
            orchestrator = new alt_Automation_Orchestrator();
            InitializeComponent();
            LoadConfig();
        }

        /// <summary>
        /// Saves the user's last project, zone, and baseline selection to local storage.
        /// </summary>
        /// <param name="project">Selected project name.</param>
        /// <param name="zone">Selected zone name.</param>
        /// <param name="baseline">Selected baseline name.</param>
        public static void SaveLastSelection(string project, string zone, string baseline, string version)
        {
            var selection = new UserSelection
            {
                Project = project,
                Zone = zone,
                Baseline = baseline,
                Version = version
            };

            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HAT");
            Directory.CreateDirectory(folder);
            var jsonPath = Path.Combine(folder, "last_selection.json");
            var json = JsonSerializer.Serialize(selection);
            File.WriteAllText(jsonPath, json);
        }

        /// <summary>
        /// Loads the last saved user selection (project, zone, baseline).
        /// </summary>
        /// <returns>Deserialized user selection object or null.</returns>
        public static UserSelection LoadLastSelection()
        {
            var jsonPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "HAT", "last_selection.json");
            if (!File.Exists(jsonPath)) return null;

            var json = File.ReadAllText(jsonPath);
            return JsonSerializer.Deserialize<UserSelection>(json);
        }

        /// <summary>
        /// Clear all Selections
        /// </summary>
        private void ClearAllPickers()
        {
            Project_Picker.ItemsSource = null;
            Zone_Picker.ItemsSource = null;
            Baseline_Picker.ItemsSource = null;
            Version_Picker.ItemsSource = null;
        }

        /// <summary>
        /// Returns the user-specific root path for HAT project files.
        /// </summary>
        /// <returns>Full path to user's HAT data directory.</returns>
        public string GetUserHATRootPath()
        {
            return PathHelper.GetUserHATRootPath();
        }

        /// <summary>
        /// Loads configuration data for the project, zone, and baseline pickers.
        /// </summary>
        private void LoadConfig()
        {
            //Base path where folders will be created
            string UserHATBasePath = GetUserHATRootPath();
            if (!Directory.Exists(UserHATBasePath))
            {
                Directory.CreateDirectory(UserHATBasePath);
            }

            string HATProjConfigFilePath = Path.Combine(UserHATBasePath, "HAT_Project_Config.json");

            if (!File.Exists(HATProjConfigFilePath))
            {
                string userRoot = GetUserHATRootPath().Trim();
                alt_PopupMessageUtil.ShowMessage($"HAT Project Config file not found in folder {userRoot}. \nClick Ok here and proceed on HAT UI and generate config file once using Blue button 'Refresh HAT Configuration from SharePoint' present on main HAT user interface.", "Warning", MessageType.Warning);
                return;
            }

            string json = File.ReadAllText(HATProjConfigFilePath);
            configData = JsonSerializer.Deserialize<Dictionary<string, Dictionary<string, object>>>(json);
            
            ClearAllPickers();
            Project_Picker.ItemsSource = configData.Keys.OrderBy(p => p);

            // Load on startup
            var last = LoadLastSelection();
            if (last != null)
            {
                Project_Picker.SelectedItem = last.Project;
                Zone_Picker.SelectedItem = last.Zone;
                Baseline_Picker.SelectedItem = last.Baseline;
                Version_Picker.SelectedItem = last.Version;
            }
        }

        /// <summary>
        /// Updates picker items based on selected project.
        /// </summary>
        private void Project_Picker_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (Project_Picker.SelectedItem is string selectedProject)
            {
                if (configData[selectedProject].TryGetValue("ZONES", out var zoneObj))
                {
                    var zoneList = JsonSerializer.Deserialize<List<string>>(zoneObj.ToString());
                    Zone_Picker.ItemsSource = zoneList.OrderBy(z => z);
                    Zone_Picker.SelectedIndex = -1;
                }

                if (configData[selectedProject].TryGetValue("SYNOPTIC", out var synopticObj))
                {
                    var baselineDict = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(synopticObj.ToString());
                    Baseline_Picker.ItemsSource = baselineDict.Keys.OrderBy(b => b);
                    Baseline_Picker.SelectedIndex = -1;
                }
            }
        }

        /// <summary>
        /// Updates picker items based on selected zone.
        /// </summary>
        private void Zone_Picker_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (Project_Picker.SelectedItem is string selectedProject && Zone_Picker.SelectedItem is string selectedZone && Baseline_Picker.SelectedItem is string selectedBaseline && Version_Picker.SelectedItem is string selectedVersion)
            {
                var userHATRootPath = GetUserHATRootPath();
                string zoneVal = Path.Combine(userHATRootPath, selectedProject, selectedZone);
                SharePointZipDownloader downloader = new SharePointZipDownloader(GetUserHATRootPath());
                if (downloader.SharePointAccessConfig != null)
                {
                    Environment.SetEnvironmentVariable(downloader.SharePointAccessConfig.ZoneEnvVar, zoneVal, EnvironmentVariableTarget.User);
                    SaveLastSelection(selectedProject, selectedZone, selectedBaseline, selectedVersion);
                }
            }
        }

        /// <summary>
        /// Triggers baseline environment setup when a baseline is selected.
        /// </summary>
        private void Baseline_Picker_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (Project_Picker.SelectedItem is string selectedProject && Baseline_Picker.SelectedItem is string selectedBaseline)
            {
                if (configData[selectedProject].TryGetValue("SYNOPTIC", out var synopticObj))
                {
                    var baselineDict = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(synopticObj.ToString());
                    if (baselineDict.TryGetValue(selectedBaseline, out var versions))
                    {
                        Version_Picker.ItemsSource = versions.OrderBy(v => v);
                    }
                }
            }
            Version_Picker.SelectedIndex = -1;
        }

        /// <summary>
        /// Triggered when the version is changed in the ComboBox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Version_Picker_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (Project_Picker.SelectedItem is string selectedProject && Zone_Picker.SelectedItem is string selectedZone && Baseline_Picker.SelectedItem is string selectedBaseline && Version_Picker.SelectedItem is string selectedVersion)
            {
                var userHATRootPath = GetUserHATRootPath();
                string baseVal = Path.Combine(userHATRootPath, selectedProject, "SYNOPTIC", selectedBaseline, selectedVersion);
                string zoneVal = Path.Combine(userHATRootPath, selectedProject, selectedZone);
                SharePointZipDownloader downloader = new SharePointZipDownloader(GetUserHATRootPath());
                if (downloader.SharePointAccessConfig != null)
                {
                    Environment.SetEnvironmentVariable(downloader.SharePointAccessConfig.BaseLineEnvVar, baseVal, EnvironmentVariableTarget.User);
                    Environment.SetEnvironmentVariable(downloader.SharePointAccessConfig.ZoneEnvVar, zoneVal, EnvironmentVariableTarget.User);
                    SaveLastSelection(selectedProject, selectedZone, selectedBaseline, selectedVersion);
                }
            }
        }

        /// <summary>
        /// Downloads project folder structure from SharePoint and saves to config JSON.
        /// </summary>
        private async void Configuration_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                string project = Project_Picker.Text;
                string zone = Zone_Picker.Text;
                string baseline = Baseline_Picker.Text;

                // Usage in WPF button click:
                var downloader = new SharePointZipDownloader(project, zone, baseline, GetUserHATRootPath());
                if (downloader.SharePointAccessConfig != null)
                {
                    string rootPath = downloader.SharePointAccessConfig.SharePointRootPath; //"/sites/VPF1-DMAexchangeswithRATP/Shared Documents/General/HAT_ACN_Test/Harness_Assistant_Data";

                    var destinationPath = GetUserHATRootPath();

                    await downloader.ExportProjectStructureAsJsonAsync(rootPath, Path.Combine(destinationPath, "HAT_Project_Config.json"));
                    LoadConfig();
                    alt_PopupMessageUtil.ShowMessage($"Your HAT Project configuration is successfully updated at {destinationPath}.\n\nNow you can proceed by selecting your Project, zone, Baseline & Version in the respective dropdowns.", "Information", MessageType.Information);
                }
            });
        }

        /// <summary>
        /// Retrieves the user's currently selected baseline folder path.
        /// </summary>
        /// <returns>Full path to the baseline directory.</returns>
        private string GetUserSelectedBaselinePath()
        {
            var userHATRootPath = GetUserHATRootPath();
            var destinationPath = Path.Combine(userHATRootPath,
                Project_Picker.Text,
                "SYNOPTIC",
                Baseline_Picker.Text,
                Version_Picker.Text);
            return destinationPath;
        }

        /// <summary>
        /// Retrieves the user's currently selected baseline folder path.
        /// </summary>
        /// <returns>Full path to the baseline directory.</returns>
        private string GetUserSelectedZonePath()
        {
            var userHATRootPath = GetUserHATRootPath();
            var destinationPath = Path.Combine(userHATRootPath,
                Project_Picker.Text,
                Zone_Picker.Text);
            return destinationPath;
        }

        /// <summary>
        /// Retrieves the user's currently selected project folder path.
        /// </summary>
        /// <returns>Full path to the project directory.</returns>
        private string GetUserSelectedProjectPath()
        {
            var userHATRootPath = GetUserHATRootPath();
            var destinationPath = Path.Combine(userHATRootPath, Project_Picker.Text);
            return destinationPath;
        }

        /// <summary>
        /// Downloads all common project data folders from SharePoint using the provided downloader.
        /// </summary>
        /// <param name="downloader">An instance of <see cref="SharePointZipDownloader"/> used to perform the download operations.</param>
        /// <param name="tempPath">The temporary local path where downloaded files will be extracted or stored.</param>
        /// <remarks>
        /// This method is asynchronous and performs I/O operations. It should handle exceptions and errors gracefully.
        /// </remarks>
        private async Task<bool> DownloadAllProjectsCommonData(SharePointZipDownloader downloader, string tempPath)
        {
            //We are first downloading folders which are common for all folders are are kept under root folder i.e. SharePointRootPath in config file
            List<string> AllPorjectsCommonFolderNames = PathHelper.GetAllProjectCommonFolderNames();
            int successCnt = 0;

            foreach (string foldername in AllPorjectsCommonFolderNames)
            {
                var spPath = $"{downloader.SharePointAccessConfig.SharePointRootPath}/{foldername}";
                string commonZipPath = Path.Combine(tempPath, $"{foldername}.zip");

                try
                {
                    if (File.Exists(commonZipPath))
                    {
                        File.Delete(commonZipPath);
                    }
                    await downloader.DownloadFolderAsZipAsync(spPath, commonZipPath);
                    var commonDestinationPath = Path.Combine(GetUserHATRootPath(), foldername);
                    var commonUnzipResult = downloader.UnzipToUserDirectory(commonZipPath, commonDestinationPath);
                    if (commonUnzipResult) successCnt++;
                }
                catch (Exception ex)
                {
                    alt_PopupMessageUtil.ShowMessage($"Error in downloading folder {spPath} from SharePoint. System Error is:  + {ex.Message}", "Error", MessageType.Error);
                }
            }
            return successCnt == AllPorjectsCommonFolderNames.Count;
        }

        /// <summary>
        /// Downloads common data specific to a given project from SharePoint using the specified downloader.
        /// </summary>
        /// <param name="downloader">An instance of <see cref="SharePointZipDownloader"/> used to download project data.</param>
        /// <param name="ProjectName">The name of the project whose common data is to be downloaded.</param>
        /// <param name="tempPath">The temporary local path where the downloaded data will be saved.</param>
        /// <remarks>
        /// This asynchronous method initiates a download operation for project-specific common data. 
        /// Consider changing the return type to <c>Task</c> for better async exception handling.
        /// </remarks>
        private async Task<bool> DownloadProjectSpecificCommonData(SharePointZipDownloader downloader, string ProjectName, string tempPath, string zone)
        {
            //We are first downloading folders which are common for all folders are are kept under root folder i.e. SharePointRootPath in config file
            List<string> AllPorjectsCommonFolderNames = PathHelper.GetEachProjectCommonFolderNames();
            int successCnt = 0; 

            foreach (string foldername in AllPorjectsCommonFolderNames)
            {
                var spPath = $"{downloader.SharePointAccessConfig.SharePointRootPath}/{ProjectName}/{foldername}";
                string commonZipPath = Path.Combine(tempPath, $"{ProjectName}_{foldername}.zip");
                successCnt = await DownloadFolderandCopyData(downloader, ProjectName, successCnt, foldername, spPath, commonZipPath);
            }
            try
            {
                var zonePath = $"{downloader.SharePointAccessConfig.SharePointRootPath}/{ProjectName}/{zone}";
                string zoneZipPath = Path.Combine(tempPath, $"{ProjectName}_{zone}.zip");
                await DownloadFolderandCopyData(downloader, ProjectName, successCnt, zone + "\\Unity_Data\\Ref_Data", zonePath, zoneZipPath);
            }
            catch { ALT_Logging.alt_Logging_class.AddError($"Error while downloading files in Zone: {zone}"); }
            return successCnt == AllPorjectsCommonFolderNames.Count;
        }

        /// <summary>
        /// Downloads the folder, copies its files and subfolders, and unzips it to the specified location.
        /// </summary>
        /// <param name="downloader"></param>
        /// <param name="ProjectName"></param>
        /// <param name="successCnt"></param>
        /// <param name="foldername"></param>
        /// <param name="spPath"></param>
        /// <param name="commonZipPath"></param>
        /// <returns></returns>
        private async Task<int> DownloadFolderandCopyData(SharePointZipDownloader downloader, string ProjectName, int successCnt, string foldername, string spPath, string commonZipPath)
        {
            try
            {
                if (File.Exists(commonZipPath))
                {
                    File.Delete(commonZipPath);
                }
                await downloader.DownloadFolderAsZipAsync(spPath, commonZipPath);
                var commonDestinationPath = Path.Combine(GetUserHATRootPath(), ProjectName, foldername);
                var commonUnzipResult = downloader.UnzipToUserDirectory(commonZipPath, commonDestinationPath);
                if (commonUnzipResult) successCnt++;
            }
            catch (Exception ex)
            {
                alt_PopupMessageUtil.ShowMessage($"Error in downloading folder {spPath} from SharePoint. System Error is:  + {ex.Message}", "Error", MessageType.Error);
            }

            return successCnt;
        }

        /// <summary>
        /// Downloads a specific version of a project baseline from SharePoint, unzips it to the user's local folder,
        /// and returns success status. It targets the path structure:
        /// {ProjectName}/SYNOPTIC/{baseline}/{version}
        /// </summary>
        /// <param name="downloader">Instance of SharePointZipDownloader with authentication and config loaded.</param>
        /// <param name="ProjectName">Name of the selected project (e.g., "Project_CairoL1").</param>
        /// <param name="synoptic">Name of the selected zone (used for local path resolution).</param>
        /// <param name="baseline">Name of the baseline folder (e.g., "BASELINE_4").</param>
        /// <param name="version">Name of the version folder inside the baseline (e.g., "BASELINE_4.0").</param>
        /// <param name="tempPath">Temporary path where the ZIP file will be saved before extraction.</param>
        /// <returns>True if download and unzip succeed, otherwise false.</returns>
        private async Task<bool> DownloadUserSelectedVersionData(SharePointZipDownloader downloader, string ProjectName, string synoptic, string baseline, string version, string tempPath)
        {
            var projectPath = $"{downloader.SharePointAccessConfig.SharePointRootPath}/{ProjectName}";
            
            var basePath = $"{downloader.SharePointAccessConfig.SharePointRootPath}/{ProjectName}/{synoptic}/{baseline}/{version}";

            string zipPath = Path.Combine(tempPath, $"{ProjectName}_{synoptic}_{baseline}.zip");
            var destinationPath = "";
            bool unzipResult = false;
            string baselineVersionZipPath = string.Empty;
            //try
            //{
            //    //var zonePath = $"{downloader.SharePointAccessConfig.SharePointRootPath}/{ProjectName}/{synoptic}";
            //    baselineVersionZipPath = Path.Combine(tempPath, $"{ProjectName}_{synoptic}_{baseline}_{version}.zip");
            //    await DownloadFolderandCopyData(downloader, ProjectName, 0, synoptic, basePath, baselineVersionZipPath);
            //}
            //catch { ALT_Logging.alt_Logging_class.AddError($"Error while downloading files in BaselineVersionZipPath: {baselineVersionZipPath}"); }

            try
            {
                if (File.Exists(zipPath))
                {
                    File.Delete(zipPath);
                }
                await downloader.DownloadFolderAsZipAsync(basePath, zipPath);
                destinationPath = GetUserSelectedBaselinePath();
                unzipResult = downloader.UnzipToUserDirectory(zipPath, destinationPath);

                //Now check if any project specific files are present on SharePoint under Project folder and download them
                string projectLocalPath = GetUserSelectedProjectPath();
                await downloader.DownloadFilesInFolderOnlyAsync(projectPath, projectLocalPath);
            }
            catch (Exception ex)
            {
                alt_PopupMessageUtil.ShowMessage("Error: " + ex.Message, "Error", MessageType.Error);
                return false;
            }
            return unzipResult;
        }

        /// <summary>
        /// Downloads and synchronizes project baseline data from SharePoint.
        /// </summary>
        private async void Synch_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                string project = Project_Picker.Text;
                string zone = Zone_Picker.Text;
                string baseline = Baseline_Picker.Text;
                string version = Version_Picker.Text;

                if (project == string.Empty || zone == string.Empty || baseline == string.Empty || version == string.Empty)
                {
                    alt_PopupMessageUtil.ShowMessage("Please select Project -> Zone -> Baseline -> Version to proceed for Synch.", "Warning", MessageType.Warning);
                    return;
                }

                // Usage in WPF button click:
                var downloader = new SharePointZipDownloader(project, zone, baseline, GetUserHATRootPath());

                if (downloader.SharePointAccessConfig != null)
                {
                    string tempPath = Path.GetTempPath();

                    //Download all projects common data first
                    bool unzipResult = await DownloadAllProjectsCommonData(downloader, tempPath);

                    //Now download project specific common data
                    unzipResult = await DownloadProjectSpecificCommonData(downloader, project, tempPath, zone);

                    //Now download user selecteed baseline version data
                    string synoptic = "SYNOPTIC";
                    unzipResult = await DownloadUserSelectedVersionData(downloader, project, synoptic, baseline, version, tempPath);
                    var userPath = Path.Combine(PathHelper.GetUserHATRootPath(), project, synoptic, baseline, version);

                    if (unzipResult == true)
                    {
                        alt_PopupMessageUtil.ShowMessage($"Your Data is synchronized with SharePoint based on your Project, Zone and Base line selection at location: {userPath}", "Information", MessageType.Information);
                        mainWindow.my_PreProcessing.jsonFilePaths = orchestrator.step_0_process<alt_Step0_PreProcessing>("InitializeInputProcessing", mainWindow.my_PreProcessing.Synoptic_TextBox, mainWindow.my_PreProcessing.Extract_FaF_TextBox, mainWindow.my_PreProcessing.PPL_Cables_TextBox, mainWindow.my_PreProcessing.PPL_Electrical_TextBox, mainWindow.my_PreProcessing.PL3_TextBox, mainWindow.my_PreProcessing.PL3_Projet_TextBox) as FilePaths;
                        mainWindow.my_PreProcessing.CheckSelectedFile();
                        mainWindow.my_PreProcessing.CollectSupplierData();
                        PostSelectionAction();
                    }
                    else
                    {
                        alt_PopupMessageUtil.ShowMessage($"Your Data could not be synchronized with SharePoint based on your Project, Zone and Base line & Version selection. Please close all the file from {userPath} from all applications.", "Warning", MessageType.Warning);
                    }                    
                }
            });
        }

        /// <summary>
        /// Applies UI updates and prepares the environment after user makes selection.
        /// </summary>
        private void PostSelectionAction()
        {
            mainWindow.my_SharePoint_Synchronization.Visibility = Visibility.Collapsed;
            mainWindow.ALTTabControl.Visibility = Visibility.Visible;
            mainWindow.InfoCard.Visibility = Visibility.Visible;
            mainWindow.ProjectText.Text = Project_Picker.SelectedItem?.ToString();
            mainWindow.ZoneText.Text = Zone_Picker.SelectedItem?.ToString();
            mainWindow.BaselineText.Text = Baseline_Picker.SelectedItem?.ToString();
            mainWindow.VersionText.Text = Version_Picker.SelectedItem?.ToString();
            mainWindow.Refresh.Visibility = Visibility.Visible;
            mainWindow.ProgressBarPanel.Visibility = Visibility.Visible;
            VerifyUsersBaselineFolderStructure();
            RunUnityApplication();
        }

        /// <summary>
        /// Bypasses SharePoint sync check and proceeds if local folder is valid.
        /// </summary>
        private async void ByPassButton_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                string project = Project_Picker.Text;
                string zone = Zone_Picker.Text;
                string baseline = Baseline_Picker.Text;

                if (project == string.Empty || zone == string.Empty || baseline == string.Empty)
                {
                    alt_PopupMessageUtil.ShowMessage("Please select Project -> Zone -> Baseline to proceed.", "Warning", MessageType.Warning);
                    return;
                }

                var destinationPath = GetUserSelectedBaselinePath();
                if (!Directory.Exists(destinationPath))
                {
                    alt_PopupMessageUtil.ShowMessage($"Selected Project -> zone -> Baseline is not yet synched locally. Please synch using 'Synch HAT Data from SharePoint' button.", "Information", MessageType.Information);
                    return;
                }

                mainWindow.my_PreProcessing.jsonFilePaths = orchestrator.step_0_process<alt_Step0_PreProcessing>("InitializeInputProcessing", mainWindow.my_PreProcessing.Synoptic_TextBox, mainWindow.my_PreProcessing.Extract_FaF_TextBox, mainWindow.my_PreProcessing.PPL_Cables_TextBox, mainWindow.my_PreProcessing.PPL_Electrical_TextBox, mainWindow.my_PreProcessing.PL3_TextBox, mainWindow.my_PreProcessing.PL3_Projet_TextBox) as FilePaths;
                mainWindow.my_PreProcessing.CheckSelectedFile();
                mainWindow.my_PreProcessing.CollectSupplierData();
                PostSelectionAction();
            });
        }

        /// <summary>
        /// Verifies and ensures required folders exist in the user's baseline directory.
        /// </summary>
        private void VerifyUsersBaselineFolderStructure()
        {
            string basePath = GetUserSelectedBaselinePath();
            string zonePath = GetUserSelectedZonePath();
            // List of directories to create
            var directories = new List<string>
            {
                "", // Root folder itself
                "HAT_Data\\Catia_Data",
                "HAT_Data\\Catia_Data",
                "HAT_Data\\Catia_Data\\Json_Data",
                "HAT_Data\\Catia_Data\\Json_Data\\EQT_Location",
                "HAT_Data\\Catia_Data\\Logs",
                "HAT_Data\\Unity_Data",
                "HAT_Data\\Unity_Data\\Config",
                "HAT_Data\\Unity_Data\\Logs",
            };

            // List of zone directories to create
            var zoneDirectories = new List<string>
            {
                "", // Root folder itself
                "Unity_Data",
                "Unity_Data\\Ref_Data",
                "Unity_Data\\Ref_Data\\IGES",
                "Unity_Data\\Ref_Data\\3DXML",
                "Unity_Data\\Ref_Data\\SectionCuts"
            };

            // Create each directory
            int count = 0;
            foreach (var dir in directories)
            {
                string fullPath = Path.Combine(basePath, dir);
                if (Directory.Exists(fullPath) == false)
                {
                    Directory.CreateDirectory(fullPath);
                    Console.WriteLine($"Created: {fullPath}");
                    count++;
                }
            }
            foreach (var dir in zoneDirectories)
            {
                string fullPath = Path.Combine(zonePath, dir);
                if (Directory.Exists(fullPath) == false)
                {
                    Directory.CreateDirectory(fullPath);
                    Console.WriteLine($"Created: {fullPath}");
                    count++;
                }
            }
        }

        /// <summary>
        /// Launches the Unity application for visualization if not already running.
        /// </summary>
        internal async void RunUnityApplication()
        {
            string processName = "EFR_Trident_Unity"; // without .exe
            bool isRunning = Process.GetProcessesByName(processName).Any();

            var downloader = new SharePointZipDownloader(GetUserHATRootPath());
            if (downloader.SharePointAccessConfig != null)
            {
                if (!string.IsNullOrEmpty(downloader.SharePointAccessConfig.BaseLineEnvVar) && !isRunning)
                    await Task.Run(() =>
                    {
                        orchestrator.step_2_process<alt_Unity_Interface>("RunUnityApplication");
                    });
            }
        }
    }
}
