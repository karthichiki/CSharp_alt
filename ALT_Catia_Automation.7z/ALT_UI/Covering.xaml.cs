﻿using ALT_Data_Model;
using ALT_Data_Model.Electrical;
using ALT_Data_Model.Input_Processing_Extraction_Data_Model;
using ALT_Data_Model.UI_Data_Model;
using ALT_Data_Preparation;
using ALT_Harness_Definition;
using ALT_Utilities;
using ApplicationLayer;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using static MaterialDesignThemes.Wpf.Theme.ToolBar;

namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for Covering.xaml
    /// </summary>
    public partial class Covering : UserControl
    {
        private alt_Automation_Orchestrator orchestrator;
        private alt_Utilities utils;
        private SleeveCatalog _CatalogData;
        private Dictionary<string, List<string>> _currentMainDict;
        MainWindow mainWindow = Application.Current.MainWindow as MainWindow;
        ObservableCollection<CoveringZoneModel> zones = null;
        public PL3_Combined _3PL { get; set; }
        public Dictionary<string, List<PL3_Global>> _3PL_Global { get; set; }
        string corrugatedDiaInt = string.Empty;
        string fillrate = "60";
        DataGrid colorRingDataGrid = null;
        public Covering()
        {
            InitializeComponent();
            utils = new alt_Utilities();
            orchestrator = new alt_Automation_Orchestrator();
            //UpdateZoneCombobox();
            ReadSleeveCatalog();
        }

        /// <summary>
        /// Read 3PL and 3PLProjet Json Files
        /// </summary>
        public void Update3PLDictionaries()
        {
            string PL3JsonFilePath = mainWindow.my_PreProcessing.jsonFilePaths.PL3_Path;
            _3PL = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Read3PLJson", PL3JsonFilePath) as PL3_Combined;
            string PL3ProjetJsonFilePath = mainWindow.my_PreProcessing.jsonFilePaths.PL3_Projet_Path;
            _3PL_Global = orchestrator.Step_1_process<alt_Step1_InputProcessing>("Read3PLProjetJson", PL3ProjetJsonFilePath) as Dictionary<string, List<PL3_Global>>;
            
        }

        /// <summary>
        /// Read SLEEVE_ELEC.json
        /// </summary>
        public void ReadSleeveCatalog()
        {
            //string jsonFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "SLEEVE_ELEC.json");
            string jsonFilePath = orchestrator.step_0_process<alt_Step0_PreProcessing>("GetCatiaFolderPath") as string;
            jsonFilePath = System.IO.Path.Combine(jsonFilePath, "SLEEVE_ELEC.json");
            _CatalogData = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadSleeveElecJson", jsonFilePath) as SleeveCatalog;
        
        }

        //private void UpdateZoneCombobox()
        //{
        //    string zonesFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Resources", "Zones.json");
        //    zones = orchestrator.Step_1_process<alt_Step1_InputProcessing>("ReadCoveringZones", zonesFilePath) as ObservableCollection<CoveringZoneModel>;
        //    ZoneComboBox.ItemsSource = zones;
        //}

        /// <summary>
        /// Event to Select MultiBranchable
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectMultibranchable_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the Multibranchable");
                object returnMsg = null;
                object isMultibranchable = null;
                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectMultiBranchableForCovering");
                });
                if (returnMsg == "")
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the Multibranchable");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection Failed");
                    return;
                }
                else
                {
                    MultibranchableTextBox.Text = returnMsg.ToString();
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the Multibranchable");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Multibranchable selection is Successful");
            });
        }

        /// <summary>
        /// Event to Select Bundle Segments
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void SelectBundleSegment_Click(object sender, RoutedEventArgs e)
        {
            await mainWindow.ShowOverlayAsync(async () =>
            {
                if (MultibranchableTextBox.Text == string.Empty)
                {
                    alt_PopupMessageUtil.ShowMessage("Select the Multibranchable before selecting the BundleSegment.", "Warning", MessageType.Warning);
                    return;
                }
                Update3PLDictionaries();
                if(_3PL == null || _3PL_Global == null || _3PL.CorrugatedSleeve == null)
                {
                    alt_PopupMessageUtil.ShowMessage("Extract 3PL and 3PL Projet File from Pre-Processing Tab", "Warning", MessageType.Warning);
                    return;
                }
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Start selecting the BundleSegment");
                object returnMsg = null;

                await Task.Run(() =>
                {
                    utils.BringApplicationToFront("CNEXT");
                    returnMsg = orchestrator.Step_1_process<alt_Step1_InputProcessing>("SelectBundleSegment");
                });
            
                AddSlidesForProtection();
            
                if (returnMsg == "")
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End selecting the BundleSegment");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: BundleSegment selection Failed");
                    return;
                }
                else
                {
                    BranchableTextBox.Text = returnMsg.ToString();
                }
                ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End selecting the BundleSegment");
                ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: BundleSegment selection is Successful");
        });
        }

        /// <summary>
        /// Group the Selected Bundle Segments accourding to its Diameter
        /// </summary>
        /// <returns></returns>
        async Task AddSlidesForProtection()
        {
            CoveringDataPreparation coveringDataPreparation = CoveringDataPreparation.GetInstance();
            var groupedByDiameter = coveringDataPreparation.IBundleSegments.GroupBy(p => p.diameter);
            string type = groupedByDiameter.GetType().ToString();
            int number_of_Groups = groupedByDiameter.Count();
            GenerateSlides(groupedByDiameter);
        }

        //private void SleeveComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    string selectedMain = SleeveComboBox.SelectedItem as string;
        //    if (selectedMain != null)
        //    {
        //        _currentMainDict = _data.Sleeve_Elec[selectedMain];
        //        ProtectionComboBox.ItemsSource = _currentMainDict.Keys;
        //        ProtectionComboBox.SelectedItem = null;
        //        DTRComboBox.ItemsSource = null;
        //    }
        //}

        //private void ProtectionComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        //{
        //    if (ProtectionComboBox.SelectedItem != null && _currentMainDict != null)
        //    {
        //        string selectedRange = ProtectionComboBox.SelectedItem as string;
        //        DTRComboBox.ItemsSource = _currentMainDict[selectedRange];
        //    }
        //}

        //private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        //{
        //    if (MultibranchableTextBox.Text == string.Empty || BranchableTextBox.Text == string.Empty || DTRComboBox.SelectedItem == null)
        //    {
        //        alt_PopupMessageUtil.ShowMessage("Please fill in the required information above.", "Warning", MessageType.Warning);
        //        return;
        //    }
        //    ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Started creating Protection");
        //    string sleeveDTRNumber = string.Empty;
        //    string result = string.Empty;
        //    string pattern = @"\bDTR\d+\b";
        //    MatchCollection matches = Regex.Matches(DTRComboBox.SelectedItem.ToString(), pattern);
        //    if (matches.Count > 0) 
        //    sleeveDTRNumber = matches[0].Value;
        //    result = orchestrator.Step_1_process<alt_Step1_InputProcessing>("CreateProtection", mainWindow?.my_PreProcessing.CatalogPath, sleeveDTRNumber) as string;
        //    ClearSelection();
        //    orchestrator.Step_1_process<alt_Step1_InputProcessing>("ClearSelection");
        //    if (result == "1")
        //    {
        //        ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End creating the Protection");
        //        ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Creating Protection is Successful");
        //    }
        //    else
        //    {
        //        ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End creating the Protection");
        //        ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Creating Protection is Failed");
        //    }
        //}


        //private void CheckBox_Checked_Covering(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        Console.WriteLine($"Selected: {option}");
        //        orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateZoneForCovering", option, "+");
        //    }
        //    string SelectedItemsText = string.Join(", ", zones.Where(i => i.CoveringIsSelected).Select(i => i.CoveringZoneName));
        //    ZoneComboBox.Text = SelectedItemsText;
        //}

        //private void CheckBox_Unchecked_Covering(object sender, RoutedEventArgs e)
        //{
        //    if (sender is CheckBox checkBox)
        //    {
        //        var option = checkBox.Content.ToString();
        //        Console.WriteLine($"Deselected: {option}");
        //        orchestrator.Step_1_process<alt_Step1_InputProcessing>("UpdateZoneForCovering", option, "-");
        //        // Remove from your selected options collection or update your data model here.
        //    }
        //    string SelectedItemsText = string.Join(", ", zones.Where(i => i.CoveringIsSelected).Select(i => i.CoveringZoneName));
        //    ZoneComboBox.Text = SelectedItemsText;
        //}

        //private void ZoneComboBox_DropDownClosed(object sender, EventArgs e)
        //{
        //    string SelectedItemsText = GetSelectedZones();
        //    ZoneComboBox.Text = SelectedItemsText;
        //}

        //private string GetSelectedZones()
        //{
        //    string SelectedItemsText = string.Join(", ", zones.Where(i => i.CoveringIsSelected).Select(i => i.CoveringZoneName));
        //    return SelectedItemsText;
        //}

        /// <summary>
        /// Create Slides
        /// </summary>
        /// <param name="bungleSegmentsSlides"></param>
        private void GenerateSlides(IEnumerable<IGrouping<double, CoveringDataPreparation.SelectedBundleSegment>> bungleSegmentsSlides)
        {
            SlideContainer.Children.Clear();

            if (bungleSegmentsSlides.Count() > 0)
            {
                int i = 0;
                foreach (var segment in bungleSegmentsSlides)
                {
                    SlideContainer.Children.Add(CreateSlide(i, segment));
                    i++;
                }
            }
        }

        /// <summary>
        /// Create Slides according to the Grouped Bundle Segments
        /// </summary>
        /// <param name="number"></param>
        /// <param name="selectedBundleSegments"></param>
        /// <returns></returns>
        private UIElement CreateSlide(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments)
        {
            Border slide = new Border
            {
                Width = 350,
                Margin = new Thickness(10),
                Background = Brushes.AliceBlue,
                CornerRadius = new CornerRadius(10),
                Padding = new Thickness(10),
                Effect = new System.Windows.Media.Effects.DropShadowEffect
                {
                    BlurRadius = 8,
                    ShadowDepth = 3,
                    Opacity = 0.2
                },
                Name = $"Slide_{number}" 
            };
            string name = "";
            foreach (var segment in selectedBundleSegments)
            {
                name += segment.bundleSegmentName + "; ";
            }
            StackPanel content = new StackPanel();

            // Line 1: TextBlock + TextBox (Name)
            var line1 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
            line1.Children.Add(new TextBlock { Text = "BundleSegment:", VerticalAlignment = VerticalAlignment.Center });
            var nameTextBox = new TextBox { Width=200, Text=name, Name = $"NameTextBox_{number}"  };
            line1.Children.Add(nameTextBox);
            content.Children.Add(line1);

            //// Line 2: FillRate and Diameter
            //var line2 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
            //line2.Children.Add(new TextBlock { Text = "FillRate:",  VerticalAlignment = VerticalAlignment.Center });
            //var ageTextBox = new TextBox {  Name = $"FillRateTextBox_{number}", Margin = new Thickness(0, 0, 0, 0) };
            //line2.Children.Add(ageTextBox);
            //line2.Children.Add(new TextBlock { Text = "ID:", VerticalAlignment = VerticalAlignment.Center });
            //var idTextBox = new TextBox { Name = $"IdTextBox_{number}" };
            //line2.Children.Add(idTextBox);
            //content.Children.Add(line2);

            // Line 3: Role ComboBox
            var line2 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
            line2.Children.Add(new TextBlock { Text = "Type:", VerticalAlignment = VerticalAlignment.Center });
            var SleeveTypeComboBox = new ComboBox
            {
                MinWidth = 200,
                Name = $"SleeveTypeComboBox_{number}",
                ItemsSource = Enum.GetValues(typeof(SleeveTypes)),
                Margin = new Thickness(0, 5, 0, 5),
                SelectedItem = null,
            };
            
            line2.Children.Add(SleeveTypeComboBox);
            content.Children.Add(line2);

            StackPanel line3 = null;
            StackPanel line4 = null;
            StackPanel line5 = null;
            StackPanel line3_1 = null;
            SleeveTypeComboBox.SelectionChanged += (s, e) =>
            {
                if (SleeveTypeComboBox.SelectedItem == null) return;
                if(content.Children.Contains(line3)) content.Children.Remove(line3);
                if (content.Children.Contains(line3_1)) content.Children.Remove(line3_1);
                if (content.Children.Contains(line4)) content.Children.Remove(line4);
                if(line5 != null)line5.Visibility = Visibility.Collapsed;
                if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.Corrugated_conduit.ToString())
                {
                    
                    CorrugatedCombination selectedCombination = new CorrugatedCombination();
                    // Line 3: FillRate and Diameter
                    line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                    CheckBox fillrateCheckBox = new CheckBox { Content=" Change % Fillrate: ", Margin = new Thickness(10, 5, 0, 5), VerticalAlignment = VerticalAlignment.Center };
                    TextBlock defaultFillRateBlock = new TextBlock { Text = "% FillRate = 60 ", VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 5, 0, 5) };
                    line3.Children.Add(defaultFillRateBlock);
                    line3.Children.Add(fillrateCheckBox);
                    var fillrateTextBox = new TextBox { Name = $"FillRateTextBox_{number}", Margin = new Thickness(0, 5, 0, 5), Visibility = Visibility.Collapsed };
                    line3.Children.Add(fillrateTextBox);
                    content.Children.Add(line3);
                    
                    line3_1 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                    line3_1.Children.Add(new TextBlock { Text = "Min BR:", VerticalAlignment = VerticalAlignment.Center });
                    var minBRTextBox = new TextBox { Name = $"MinBRTextBox_{number}" };
                    minBRTextBox.IsReadOnly =true;
                    line3_1.Children.Add(minBRTextBox);
                    content.Children.Add(line3_1);
                    corrugatedDiaInt = CalculateInternalDiameter(selectedBundleSegments.First().diameter, fillrate);
                    line5 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), HorizontalAlignment = HorizontalAlignment.Center, Visibility = Visibility.Collapsed };
                    // Line 4: "Divisible" or "Non Divisible" RadioButtons with Checked Event
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 5, 0, 5) };
                    line4.Children.Add(CreateDivisibleOrNonDivisibleRadioGroup(number, selectedBundleSegments, line5, minBRTextBox));
                    content.Children.Add(line4);
                    //TextBlock descriptionTextBlock = new TextBlock { Margin = new Thickness(0, 5, 0, 5) };
                    //content.Children.Add(descriptionTextBlock);
                    List<RadioButton> checkedRadio = new List<RadioButton>();
                    StackPanel comboPanel = null;
                    List<(TextBlock textBlock, StackPanel parentPanel)> DTRTextBlocks = new List<(TextBlock textBlock, StackPanel parentPanel)>();
                    List<(ComboBox comboBox, StackPanel parentPanel)> DTRCombobox = new List<(ComboBox comboBox, StackPanel parentPanel)>();
                    fillrateTextBox.LostFocus += (sender, args) =>
                    {
                        fillrate = ((TextBox)sender).Text;
                        UpdateDTRs(number, selectedBundleSegments, line4, line5, fillrate, minBRTextBox, ref checkedRadio, ref comboPanel, ref DTRTextBlocks, ref DTRCombobox);
                        //line5.Visibility = Visibility.Visible;
                    };
                    fillrateCheckBox.Checked += (sender, args) =>
                    {
                        fillrateTextBox.Visibility = Visibility.Visible;
                    };
                    fillrateCheckBox.Unchecked += (sender, args) =>
                    {
                        fillrateTextBox.Visibility = Visibility.Collapsed;
                        fillrate = "60";
                        UpdateDTRs(number, selectedBundleSegments, line4, line5, fillrate, minBRTextBox, ref checkedRadio, ref comboPanel, ref DTRTextBlocks, ref DTRCombobox);
                    };
                    line5.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                    content.Children.Add(line5);
                }
                else if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.EMC.ToString())
                {
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), HorizontalAlignment = HorizontalAlignment.Center, Visibility = Visibility.Collapsed };
                    line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5)};
                    line3.Children.Add(EMC_DTRSelection(number, selectedBundleSegments, line4));
                    content.Children.Add(line3);
                    line4.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                    content.Children.Add(line4);
                }
                else if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.Electrical_Insulation.ToString())
                {
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), HorizontalAlignment = HorizontalAlignment.Center, Visibility = Visibility.Collapsed };
                    line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                    line3.Children.Add(CreateRadioButtonFordielectricStrength(number, selectedBundleSegments, line4));
                    content.Children.Add(line3);
                    
                    line4.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                    content.Children.Add(line4);
                }
                else if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.Expand_Roundit_Roundit_Grip.ToString())
                {
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), HorizontalAlignment = HorizontalAlignment.Center, Visibility = Visibility.Collapsed };

                    line3_1 = new StackPanel
                    {
                        Orientation = Orientation.Horizontal,
                        Margin = new Thickness(0, 5, 0, 5)
                    };
                    TextBlock zoneTextBlock = new TextBlock
                    {
                        Text = "Zone: ",
                        Margin = new Thickness(0, 5, 0, 5)
                    };
                    ComboBox comboBox = new ComboBox
                    {
                        ItemsSource = new List<string> { "ZinD", "ZinW", "Zout" },
                        Margin = new Thickness(0, 5, 0, 5),
                        Width = 200
                    };
                    line3_1.Children.Add(zoneTextBlock);
                    line3_1.Children.Add(comboBox);
                    content.Children.Add(line3_1);
                    comboBox.SelectionChanged += (sender, eargus) =>
                    {
                        line4.Children.Clear();
                        line4.Visibility = Visibility.Collapsed;
                        if (content.Children.Contains(line3)) content.Children.Remove(line3);
                        if (content.Children.Contains(line4)) content.Children.Remove(line4);
                        if (sender is ComboBox cb)
                        {
                            if (cb.SelectedItem.ToString() != "ZinD")
                            {
                                MessageBoxResult messageBoxResult = alt_PopupMessageUtil.ShowMessageYesNo("This type of sleeve should ONLY be installed inside Dry Zone, do you really want to choose this covering type?", "Question", MessageType.Question);
                                if (messageBoxResult == MessageBoxResult.No)
                                {
                                    SleeveTypeComboBox.SelectedItem = null;
                                    return;
                                }
                            }
                        }
                       
                        line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                        line3.Children.Add(CreateExpandoRounditRounditGrip(number, selectedBundleSegments, line4));
                        content.Children.Add(line3);
                        if(!content.Children.Contains(line4))
                        {
                            line4.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                            content.Children.Add(line4);
                        }
                        
                    };
                }
                else if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.Flame_Retardant_sleeve.ToString())
                {
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Center };
                    line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                    line3.Children.Add(FlameRetardantSleeve_DTRSelection(number, selectedBundleSegments, line4));
                    content.Children.Add(line3);
                    line4.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                    content.Children.Add(line4);
                }
                else if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.Heat_Shrinkable_sleeve.ToString())
                {
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), HorizontalAlignment = HorizontalAlignment.Center, Visibility = Visibility.Collapsed };
                    line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                    line3.Children.Add(HeatShrinkableSleeve_DTRSelection(number, selectedBundleSegments, line4));
                    content.Children.Add(line3);
                    if (!content.Children.Contains(line4))
                    {
                        line4.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                        content.Children.Add(line4);
                    }
                }
                else if (SleeveTypeComboBox.SelectedItem.ToString() == SleeveTypes.Color_Ring.ToString())
                {
                    line4 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5), Visibility = Visibility.Collapsed, HorizontalAlignment = HorizontalAlignment.Center };
                    line3 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
                    line3.Children.Add(Color_RingSleeve_DTRSelection(number, selectedBundleSegments, line4));
                    content.Children.Add(line3);
                    line4.Children.Add(SubmitSlideButton(number, selectedBundleSegments));
                    content.Children.Add(line4);
                }
            };
            slide.Child = content;
            return slide;
        }

        /// <summary>
        /// Create Options to Filter Color Ring
        /// </summary>
        /// <param name="number">Slide number</param>
        /// <param name="selectedBundleSegments">Bundle Segments</param>
        /// <param name="submitPanel">Submit Button Stack panel</param>
        /// <returns></returns>
        private UIElement Color_RingSleeve_DTRSelection(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        {
            double diameter = selectedBundleSegments.First().diameter;
            List<string> keys = _3PL.ColorRingSleeve.Keys.ToList();
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var ColorRingTypeRadioGroup = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5),
                VerticalAlignment = VerticalAlignment.Center,
            };
            TextBlock textBlock = new TextBlock { Text = "Type:  ", Margin = new Thickness(0, 5, 0, 5) };
            ColorRingTypeRadioGroup.Children.Add(textBlock);
            List<RadioButton> radioButtons = new List<RadioButton>();
            foreach (string key in keys)
            {
                if (string.IsNullOrEmpty(key))
                {
                    continue;
                }
                string newKey = key.Replace(" ", "_");
                RadioButton rb = new RadioButton
                {
                    GroupName = $"Type{number}",
                    Name = $"Type_{number}{newKey}",
                    Tag = diameter,
                    Margin = new Thickness(0, 0, 10, 0),
                    VerticalAlignment = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalContentAlignment = VerticalAlignment.Center,
                    HorizontalContentAlignment = HorizontalAlignment.Center,
                    Content = new TextBlock
                    {
                        Text = newKey,
                        VerticalAlignment = VerticalAlignment.Center,
                        TextAlignment = TextAlignment.Center
                    }
                };

                rb.Checked += (sender, e) =>
                {
                    try { wrapperPanel.Children.Remove(colorRingDataGrid); } catch { }
                    RadioButton selected = sender as RadioButton;
                    double dia = 0;
                    double.TryParse(selected.Tag.ToString(), out dia);
                    if (selected != null)
                    {
                        TextBlock text = selected.Content as TextBlock;
                        string selectedValue = text.Text;
                        var filteredDictionary = _3PL.ColorRingSleeve.Where(x => x.Key.Replace("_", " ").Trim() == selectedValue.Replace("_", " ").Trim()).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                       
                        colorRingDataGrid = CreateDataGrid();
                        colorRingDataGrid.ItemsSource = filteredDictionary.Values.FirstOrDefault();
                        colorRingDataGrid.SelectionChanged += (sr, ex) =>
                        {
                            var grid = sr as DataGrid;
                            if (grid.SelectedItem is Tapes_Labels selectedItem)
                            {
                                ValidateIn3PLPrjet(selectedItem.DTR);
                                foreach (var segment in selectedBundleSegments)
                                {
                                    segment.Sleeve = selectedItem.DTR;
                                }
                                
                                if (!GetDTRDescription(selectedItem.DTR).Contains("not found in the Sleeve Catalog."))
                                {
                                    submitPanel.Visibility = Visibility.Visible;
                                }
                                else
                                {
                                    submitPanel.Visibility = Visibility.Collapsed;
                                    alt_PopupMessageUtil.ShowMessage(selectedItem.DTR + " not found in the Sleeve Catalog.", "Warning", MessageType.Warning);
                                    
                                }
                            }
                        };
                        //DataGridStackPanel.Children.Add(dataGrid);
                        //var closestMatch = filteredDictionary.SelectMany(kvp => kvp.Value).ToList();
                        //string requiredDTR = "";
                        ////if (closestMatch.Count > 0) requiredDTR = closestMatch.First().DTR;
                        //stackPanel = CreateTextboxForDTRs(1, requiredDTR, submitPanel);
                        //if (!string.IsNullOrEmpty(requiredDTR))
                        //{
                        //    //ValidateIn3PLPrjet(closestMatch.First().DTR);
                        //    foreach (var segment in selectedBundleSegments)
                        //    {
                        //        //segment.Sleeve = closestMatch.First().DTR;
                        //    }
                        //}
                        wrapperPanel.Children.Add(colorRingDataGrid);
                    }
                };
                ColorRingTypeRadioGroup.Children.Add(rb);
            }

            wrapperPanel.Children.Add(ColorRingTypeRadioGroup);
            return wrapperPanel;
        }

        /// <summary>
        /// Data Grid to show Color Ring Details
        /// </summary>
        /// <returns>Data grid</returns>
        private DataGrid CreateDataGrid()
        {
            DataGrid dataGrid = new DataGrid
            {
                AutoGenerateColumns = false,
                HeadersVisibility = DataGridHeadersVisibility.Column,
                Margin = new Thickness(5),
                Foreground = Brushes.Black,
                Background = Brushes.White,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center,
                CanUserAddRows = false,
            };

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "DTR",
                Binding = new Binding(nameof(Tapes_Labels.DTR)),
            });

            dataGrid.Columns.Add(new DataGridTextColumn
            {
                Header = "Supplier",
                MaxWidth = 110,
                Binding = new Binding(nameof(Tapes_Labels.Supplier)),
            });

            DataGridTemplateColumn colorColumn = new DataGridTemplateColumn { Header = "Color" };

            FrameworkElementFactory rectangleFactory = new FrameworkElementFactory(typeof(Rectangle));
            rectangleFactory.SetValue(Rectangle.WidthProperty, 80.0);
            rectangleFactory.SetValue(Rectangle.HeightProperty, 20.0);
            rectangleFactory.SetValue(Rectangle.StrokeProperty, Brushes.Black);

            var binding = new Binding(nameof(Tapes_Labels.Color))
            {
                Converter = new StringToBrushConverter()
            };
            rectangleFactory.SetBinding(Rectangle.FillProperty, binding);

            DataTemplate cellTemplate = new DataTemplate { VisualTree = rectangleFactory };
            colorColumn.CellTemplate = cellTemplate;

            dataGrid.Columns.Add(colorColumn);

            return dataGrid;
        }

        /// <summary>
        /// Update the DTR's Listed whenever the %fillrate changes
        /// </summary>
        /// <param name="number">Slide Number</param>
        /// <param name="selectedBundleSegments">Bundle Segments</param>
        /// <param name="line4">Divisible Non Divisible Stackpanel</param>
        /// <param name="line5">Submit Button Stack Panel</param>
        /// <param name="fillrate">Updated %fillraate</param>
        /// <param name="minBRTextBox">BendRadius TextBox</param>
        /// <param name="checkedRadio">Radio Button</param>
        /// <param name="comboPanel">DTR's Combobox Stack panel</param>
        /// <param name="DTRTextBlocks">Tect Block</param>
        /// <param name="DTRCombobox">DTR's containing Combobox</param>
        private void UpdateDTRs(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel line4, StackPanel line5, string fillrate, TextBox minBRTextBox, ref List<RadioButton> checkedRadio, ref StackPanel comboPanel, ref List<(TextBlock textBlock, StackPanel parentPanel)> DTRTextBlocks, ref List<(ComboBox comboBox, StackPanel parentPanel)> DTRCombobox)
        {
            corrugatedDiaInt = CalculateInternalDiameter(selectedBundleSegments.First().diameter, fillrate);
            foreach (UIElement child in line4.Children)
            {
                checkedRadio = GetAllCheckedRadioButtons(child);
                DTRTextBlocks = GetAllTextBlockWithParentPanel(child);
                DTRCombobox = GetAllComboBoxesWithParentPanel(child);
            }
            if (checkedRadio.Count > 0)
            {
                if (checkedRadio.First().Content.ToString() == "Divisible")
                {
                    GetDTRandCreteComboBox_DiviSible(selectedBundleSegments, number, corrugatedDiaInt, DTRTextBlocks.Last().parentPanel, line5, minBRTextBox);
                    //minBRTextBox.Text = divisible.Min_BR;
                    //foreach (var segment in selectedBundleSegments)
                    //{
                    //    segment.Sleeve = divisible.DTR;
                    //}
                }
                else if (checkedRadio.First().Content == "Non Divisible")
                {
                    if (checkedRadio.Count > 1)
                        comboPanel = DTRTextBlocks.Last().parentPanel;
                    CreateDTRComboBox_Corrugated(selectedBundleSegments, comboPanel, checkedRadio.Last().Content.ToString(), corrugatedDiaInt, number, line5, minBRTextBox); // Create ComboBox for 'HL2'
                }
            }
        }

        /// <summary>
        /// Create Stackpanel containing Submit Button
        /// </summary>
        /// <param name="number">Slide Number</param>
        /// <param name="selectedBundleSegments"></param>
        /// <returns></returns>
        private UIElement SubmitSlideButton(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments)
        {
            StackPanel stackPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
            };

            var submitSlideButton = new Button
            {
                Content = $"Create Protection",
                Width = 250,
                Background = Brushes.SteelBlue,
                Foreground = Brushes.White,
                Margin = new Thickness(0, 10, 0, 0),
                Name = $"SubmitButton_{number}"
            };
            var textBlock = new TextBlock
            {
                Text = $"⚠ Ensure that no protective sleeve is already present on the selected bundle segment",
                Name = $"EnsureTextBlock_{number}",
                Foreground = Brushes.OrangeRed,
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 300
            };
            submitSlideButton.Click += (s, e) =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Started creating Protection");
                string result = orchestrator.Step_1_process<alt_Step1_InputProcessing>("CreateProtectionForBundleSegments", mainWindow?.my_PreProcessing.CatalogPath, selectedBundleSegments) as string;
                //ClearSelection();
                //orchestrator.Step_1_process<alt_Step1_InputProcessing>("ClearSelection");
                if (result == "1")
                {
                    alt_PopupMessageUtil.ShowMessageYesNo("Protection has been created. Do you want to add another one?", "", MessageType.Information);
                    ProgressBarSingletonClass.Instance.ProgressSimulation(1, 100, "End creating the Protection");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Creating Protection is Successful");
                }
                else
                {
                    ProgressBarSingletonClass.Instance.ProgressSimulation(0, 0, "End creating the Protection");
                    ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: Creating Protection is Failed");
                }
            };
            stackPanel.Children.Add(submitSlideButton);
            stackPanel.Children.Add(textBlock);
            return stackPanel;
        }

        /// <summary>
        /// Create options for HeatShrinkableSleeve
        /// </summary>
        /// <param name="number">Slide Number</param>
        /// <param name="selectedBundleSegments">BundleSegments</param>
        /// <param name="submitPanel">Submit button Stack panel</param>
        /// <returns>Stack Panel containing Options</returns>
        private UIElement HeatShrinkableSleeve_DTRSelection(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        {
            double diameter = selectedBundleSegments.First().diameter;
            StackPanel wrapperpanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            StackPanel radioTextpanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            StackPanel radiopanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };

            TextBlock textBlock = new TextBlock
            {
                Text = "Color Type:",
                Margin = new Thickness(0, 5, 0, 5)
            };

            StackPanel zonepanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            TextBlock zoneTextBlock = new TextBlock
            {
                Text = "Zone:",
                Margin = new Thickness(0, 5, 0, 5)
            };
            ComboBox comboBox = new ComboBox
            {
                ItemsSource = new List<string> { "ZinD", "ZinW", "Zout" },
                Margin = new Thickness(0, 5, 0, 5),
                Width = 200
            };

            
            StackPanel stackPanel = new StackPanel();
            comboBox.SelectionChanged += (sender, eargus) =>
            {
                var blackRadio = new RadioButton
                {
                    Content = "Black",
                    GroupName = $"Color_Type{number}",
                    Name = $"Black_Radio_{number}",
                    Margin = new Thickness(0, 5, 0, 5)
                };
                var YellowGreenRadio = new RadioButton
                {
                    Content = "Yellow/green for Earthing",
                    GroupName = $"Color_Type{number}",
                    Name = $"YellowGreen_Radio_{number}",
                    Margin = new Thickness(0, 05, 0, 05)
                };
                //if (radiopanel.Children.Contains(blackRadio)) radioTextpanel.Children.Remove(blackRadio);
                blackRadio.IsChecked = false;
                YellowGreenRadio.IsChecked = false;
                radiopanel.Children.Clear();
                radioTextpanel.Children.Clear();
                stackPanel.Children.Clear();
                //if (radiopanel.Children.Contains(YellowGreenRadio)) radioTextpanel.Children.Remove(YellowGreenRadio);
                //if (radioTextpanel.Children.Contains(textBlock)) radioTextpanel.Children.Remove(textBlock);
                //if (radioTextpanel.Children.Contains(radiopanel)) radioTextpanel.Children.Remove(radiopanel);
                //if (wrapperpanel.Children.Contains(radioTextpanel)) wrapperpanel.Children.Remove(radioTextpanel);
                //if (wrapperpanel.Children.Contains(stackPanel)) wrapperpanel.Children.Remove(stackPanel);
                submitPanel.Visibility = Visibility.Collapsed;
                if (sender is ComboBox cb)
                {
                    //double diameter = selectedBundleSegments.First().diameter;
                    List<string> DTRs = new List<string>();
                    int black = 1;
                    int YellowGreen = 1;
                    blackRadio.Checked += (senders, argus) =>
                    {
                        submitPanel.Visibility = Visibility.Collapsed;
                        if (wrapperpanel.Children.Contains(stackPanel)) wrapperpanel.Children.Remove(stackPanel);

                        if (comboBox.SelectedItem == null)
                        {
                            alt_PopupMessageUtil.ShowMessage("Please select a Zone before choosing the Color Type.", "Error", MessageType.Error);
                            blackRadio.IsChecked = false;
                            return;
                        }
                        else if (comboBox.SelectedItem.ToString() == "ZinD" || comboBox.SelectedItem.ToString() == "ZinW")
                        {
                            var filtereDictionary = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key.ToUpper() == "Black".ToUpper()) // filter only "Black" key
                                                        .ToDictionary(
                                                            kvp => kvp.Key,
                                                            kvp => kvp.Value
                                                                .Where(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "N")
                                                                .ToList()
                                                        );
                            DTRs = GetDTRs(filtereDictionary, diameter);
                        }
                        else if (comboBox.SelectedItem.ToString() == "Zout")
                        {
                            MessageBoxResult messageBoxResult = alt_PopupMessageUtil.ShowMessageYesNo("Do you want to ensure sealing by TA37 with glue on Non-Insulated Lug/Conical ring cable gland?", "Question", MessageType.Question);
                            if (messageBoxResult == MessageBoxResult.Yes)
                            {
                                var filtereDictionary = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key.ToUpper() == "Black".ToUpper()) // filter only "Black" key
                                                        .ToDictionary(
                                                            kvp => kvp.Key,
                                                            kvp => kvp.Value
                                                                .Where(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" && abc.Part_number.ToUpper().Contains("TA37"))
                                                                .ToList()
                                                        );
                                //.Where(kvp => kvp.Key != null && kvp.Key.IndexOf("BLACK", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                //                        kvp.Value.Any(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" && abc.Part_number.ToUpper().Contains("TA37"))).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                                DTRs = GetDTRs(filtereDictionary, diameter);
                            }
                            else if (messageBoxResult == MessageBoxResult.No)
                            {
                                var filtereDictionary = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key.ToUpper() == "Black".ToUpper()) // filter only "Black" key
                                                        .ToDictionary(
                                                            kvp => kvp.Key,
                                                            kvp => kvp.Value
                                                                .Where(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" && !abc.Part_number.ToUpper().Contains("TA37"))
                                                                .ToList()
                                                        );
                                //var filtereDictionary1 = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key != null && kvp.Key.IndexOf("BLACK", StringComparison.OrdinalIgnoreCase) >= 0 &&
                                //                        kvp.Value.Any(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" && !abc.Part_number.ToUpper().Contains("TA37"))).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                                DTRs = GetDTRs(filtereDictionary, diameter);
                            }
                        }
                        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);

                        wrapperpanel.Children.Add(stackPanel);
                        
                    };

                    YellowGreenRadio.Checked += (sendar, eargs) =>
                    {
                        submitPanel.Visibility = Visibility.Collapsed;
                        if (wrapperpanel.Children.Contains(stackPanel)) wrapperpanel.Children.Remove(stackPanel);

                        if (comboBox.SelectedItem == null)
                        {
                            alt_PopupMessageUtil.ShowMessage("Please select a Zone before choosing the Color Type.", "Error", MessageType.Error);
                            YellowGreenRadio.IsChecked = false;
                            return;
                        }
                        else if (comboBox.SelectedItem.ToString() == "ZinD" || comboBox.SelectedItem.ToString() == "ZinW")
                        {
                            var filtereDictionary = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key.ToUpper() == "YELLOW/GREEN".ToUpper()) // filter only "Black" key
                                                        .ToDictionary(
                                                            kvp => kvp.Key,
                                                            kvp => kvp.Value
                                                                .Where(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "N")
                                                                .ToList()
                                                        );
                            DTRs = GetDTRs(filtereDictionary, diameter);
                        }
                        else if (comboBox.SelectedItem.ToString() == "Zout")
                        {

                            MessageBoxResult messageBoxResult = alt_PopupMessageUtil.ShowMessageYesNo("Do you want to ensure sealing by TA37 with glue on Non-Insulated Lug/Conical ring cable gland?", "Question", MessageType.Question);
                            if (messageBoxResult == MessageBoxResult.Yes)
                            {
                                var filtereDictionary = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key.ToUpper() == "YELLOW/GREEN".ToUpper()) // filter only "Black" key
                                                        .ToDictionary(
                                                            kvp => kvp.Key,
                                                            kvp => kvp.Value
                                                                .Where(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" && abc.Part_number.ToUpper().Contains("TA37"))
                                                                .ToList()
                                                        );
                                DTRs = GetDTRs(filtereDictionary, diameter);
                            }
                            else if (messageBoxResult == MessageBoxResult.No)
                            {
                                var filtereDictionary = _3PL.HeatShrinkableSleeve.Where(kvp => kvp.Key.ToUpper() == "YELLOW/GREEN".ToUpper()) // filter only "Black" key
                                                        .ToDictionary(
                                                            kvp => kvp.Key,
                                                            kvp => kvp.Value
                                                                .Where(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" && !abc.Part_number.ToUpper().Contains("TA37"))
                                                                .ToList()
                                                        );
                                DTRs = GetDTRs(filtereDictionary, diameter);
                            }
                        }
                        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                        wrapperpanel.Children.Add(stackPanel);
                        
                    };

                    if (!radioTextpanel.Children.Contains(textBlock)) radioTextpanel.Children.Add(textBlock);
                    if (!radiopanel.Children.Contains(blackRadio)) radiopanel.Children.Add(blackRadio);
                    if (!radiopanel.Children.Contains(YellowGreenRadio)) radiopanel.Children.Add(YellowGreenRadio);
                    if (!radioTextpanel.Children.Contains(radiopanel)) radioTextpanel.Children.Add(radiopanel);
                    if (!wrapperpanel.Children.Contains(radioTextpanel)) wrapperpanel.Children.Add(radioTextpanel);
                }
            };
            zonepanel.Children.Add(zoneTextBlock);
            zonepanel.Children.Add(comboBox);
            wrapperpanel.Children.Add(zonepanel);

            // State-tracking variable (using closure)
            

            return wrapperpanel;
        }



        //    private void HandleColorSelection(
        //ComboBox comboBox,
        //string colorKey,
        //RadioButton radioButton,
        //StackPanel stackPanel,
        //StackPanel wrapperpanel,
        //double diameter,
        //IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments,
        //StackPanel submitPanel, int number)
        //    {
        //        submitPanel.Visibility = Visibility.Collapsed;
        //        stackPanel.Children.Clear();
        //        if (currentStackPanel != null && wrapperpanel.Children.Contains(currentStackPanel))
        //        {
        //            wrapperpanel.Children.Remove(currentStackPanel);
        //        }

        //        if (comboBox.SelectedItem == null)
        //        {
        //            alt_PopupMessageUtil.ShowMessage("Please select a Zone before choosing the Color Type.", "Error", MessageType.Error);
        //            radioButton.IsChecked = false;
        //            return;
        //        }

        //        var selectedZone = comboBox.SelectedItem.ToString();
        //        var DTRs = new List<string>();

        //        if (selectedZone == "ZinD" || selectedZone == "ZinW")
        //        {
        //            var filtered = _3PL.HeatShrinkableSleeve
        //                .Where(kvp => kvp.Key != null && kvp.Key.IndexOf(colorKey, StringComparison.OrdinalIgnoreCase) >= 0 &&
        //                       kvp.Value.Any(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "N" && !abc.Part_number.ToUpper().Contains("TA37")))
        //                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);

        //            DTRs = GetDTRs(filtered, diameter);
        //        }
        //        else if (selectedZone == "Zout")
        //        {
        //            var result = alt_PopupMessageUtil.ShowMessageYesNo("Do you want to ensure sealing by TA37 with glue on Non-Insulated Lug/Conical ring cable gland?", "Question", MessageType.Question);
        //            bool useTA37 = result == MessageBoxResult.Yes;

        //            var filtered = _3PL.HeatShrinkableSleeve
        //                .Where(kvp => kvp.Key != null && kvp.Key.IndexOf(colorKey, StringComparison.OrdinalIgnoreCase) >= 0 &&
        //                       kvp.Value.Any(abc => abc.RESISTANT_TO_FUEL.ToUpper() == "Y" &&
        //                            abc.Part_number.ToUpper().Contains("TA37") == useTA37))
        //                .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);

        //            DTRs = GetDTRs(filtered, diameter);
        //        }

        //        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
        //        wrapperpanel.Children.Add(stackPanel);
        //    }

        /// <summary>
        /// Create options for DielectricStrength
        /// </summary>
        /// <param name="number">Slide Number</param>
        /// <param name="selectedBundleSegments">BundleSegments</param>
        /// <param name="submitPanel">Submit button Stack panel</param>
        /// <returns>Stack Panel containing Options</returns>
        private UIElement CreateExpandoRounditRounditGrip(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        {
             double diameter = selectedBundleSegments.First().diameter;
            StackPanel wrapperpanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            StackPanel radiopanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            
            var VelcroRadio = new RadioButton
            {
                Content = "Velcro",
                GroupName = $"VelcroOrNonVelcro{number}",
                Name = $"Velcro_Radio_{number}",
                //Tag = comboPanel,
                Margin = new Thickness(0, 0, 10, 0)
            };

            var NonVelcroRadio = new RadioButton
            {
                Content = "Non Velcro",
                GroupName = $"VelcroOrNonVelcro{number}",
                //Tag = (FireSmokeOptionPanel, comboPanel),
                Name = $"Non_Velcro_Radio_{number}"
            };
            //double diameter = selectedBundleSegments.First().diameter;
            List<string> DTRs = new List<string>();
            StackPanel stackPanel = new StackPanel
            {
                Margin = new Thickness(0, 5, 0, 5)
            };
            VelcroRadio.Checked += (senders, argus) =>
            {
                submitPanel.Visibility = Visibility.Collapsed;
                if (stackPanel != null) wrapperpanel.Children.Remove(stackPanel);
                if (senders is RadioButton rb)
                {
                    DTRs = GetDTRs(_3PL.WrapAroundGripSleeve, diameter);
                    stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                    wrapperpanel.Children.Add(stackPanel);
                }
            };

            NonVelcroRadio.Checked += (sendar, eargs) =>
            {
                submitPanel.Visibility = Visibility.Collapsed;
                if (stackPanel != null) wrapperpanel.Children.Remove(stackPanel);
                if (sendar is RadioButton rb)
                {
                    DTRs = GetDTRs(_3PL.WrapAroundSleeve, diameter);
                    List<string> DTRstrings = GetDTRs(_3PL.ExpandableSleeve, diameter);
                    foreach (string s in DTRstrings) { DTRs.Add(s); }
                    stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                    wrapperpanel.Children.Add(stackPanel);
                    //PartNumberRadioGroup.Children.Add(BraidMeshButton);
                    //PartNumberRadioGroup.Children.Add(DWRadioButton);
                }
            };

            radiopanel.Children.Add(VelcroRadio);
            radiopanel.Children.Add(NonVelcroRadio);
            wrapperpanel.Children.Add(radiopanel);
                

            return wrapperpanel;
        }

        /// <summary>
        /// Create options for DielectricStrength
        /// </summary>
        /// <param name="number">Slide Number</param>
        /// <param name="selectedBundleSegments">BundleSegments</param>
        /// <param name="submitPanel">Submit button Stack panel</param>
        /// <returns>Stack Panel containing Options</returns>
        private UIElement CreateRadioButtonFordielectricStrength(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        { 
            double diameter = selectedBundleSegments.First().diameter;
            List<string> keys = _3PL.ElectricalInsulationSleeve.Keys.ToList();
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var dielectricStrengthRadioGroup = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            TextBlock textBlock = new TextBlock { Text = "Dielectric Strength (kV):  ", Margin = new Thickness(0, 5, 0, 5) };
            dielectricStrengthRadioGroup.Children.Add(textBlock);
            List<RadioButton> radioButtons = new List<RadioButton>();
            StackPanel stackPanel = null;
            foreach (string key in keys) 
            {
                if (key.ToUpper() == "DIELECTRIC STRENGTH (kV)".ToUpper())
                {
                    continue;
                }
                RadioButton rb = new RadioButton
                {
                    Content = key,
                    GroupName = $"Dielectric{number}",
                    Name = $"Dielectric_{number}{key}",
                    Tag = diameter,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 0, 10, 0)
                };
                
                rb.Checked += (sender, e) =>
                {
                    try { wrapperPanel.Children.Remove(stackPanel); } catch { }
                    RadioButton selected = sender as RadioButton;
                    double dia = 0;
                    double.TryParse(selected.Tag.ToString(), out dia);
                    if (selected != null)
                    {
                        string selectedValue = selected.Content.ToString();
                        var filteredDictionary = _3PL.ElectricalInsulationSleeve.Where(x => x.Key == selectedValue).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                        var closestMatch = filteredDictionary.SelectMany(kvp => kvp.Value).Where(abc => double.TryParse(abc.DIA_int, out double max) &&
                                                max > dia).OrderBy(abc => double.Parse(abc.DIA_int)).ToList();
                        string requiredDTR = "";
                        if (closestMatch.Count > 0) requiredDTR = closestMatch.First().DTR + " - " + closestMatch.First().Supplier;
                        stackPanel = CreateTextboxForDTRs(1, requiredDTR, submitPanel);
                        if(!string.IsNullOrEmpty(requiredDTR))
                        {
                            ValidateIn3PLPrjet(closestMatch.First().DTR);
                            foreach (var segment in selectedBundleSegments)
                            {
                                segment.Sleeve = closestMatch.First().DTR;
                            }
                            if (!GetDTRDescription(closestMatch.First().DTR).Contains("not found in the Sleeve Catalog."))
                                submitPanel.Visibility = Visibility.Visible;
                            else submitPanel.Visibility = Visibility.Collapsed;
                        }
                        wrapperPanel.Children.Add(stackPanel);
                    }
                };
                dielectricStrengthRadioGroup.Children.Add(rb);
            }
            
            wrapperPanel.Children.Add(dielectricStrengthRadioGroup);
            return wrapperPanel;
        }

        /// <summary>
        /// Create options for EMC
        /// </summary>
        /// <param name="number">Slide Number</param>
        /// <param name="selectedBundleSegments">BundleSegments</param>
        /// <param name="submitPanel">Submit button Stack panel</param>
        /// <returns>Stack Panel containing Options</returns>
        private UIElement EMC_DTRSelection(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        {
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var OpenCloseRadioGroup = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var PartNumberRadioGroup = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var comboPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var OpenRadio = new RadioButton
            {
                Content = "Open",
                GroupName = $"OpenOrClose{number}",
                Name = $"Open_{number}",
                //Tag = comboPanel,
                Margin = new Thickness(0, 0, 10, 0)
            };

            var CloseRadio = new RadioButton
            {
                Content = "Close",
                GroupName = $"OpenOrClose{number}",
                //Tag = (FireSmokeOptionPanel, comboPanel),
                Name = $"CloseRadio_{number}"
            };
            double diameter = selectedBundleSegments.First().diameter;
            List<string> DTRs = new List<string>();
            StackPanel stackPanel = null;
            OpenRadio.Checked += (senders, argus) =>
            {
                if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                if (senders is RadioButton rb)
                {
                    PartNumberRadioGroup.Children.Clear();
                    comboPanel.Children.Clear();
                    //panel.Margin = new Thickness(0, 5, 0, 5);
                    var FMJRadioButton = new RadioButton
                    {
                        Content = "FMJ PLUS",
                        GroupName = $"PartNumberGroup_{number}",
                        Name = $"HL2Radio_{number}",
                        Margin = new Thickness(0, 0, 20, 0),
                        //Tag = combooPanel

                    };

                    var DWRadioButton = new RadioButton
                    {
                        Content = "DW",
                        GroupName = $"PartNumberGroup_{number}",
                        Name = $"HL3Radio_{number}",
                        //Tag = combooPanel
                    };

                    FMJRadioButton.Checked += (sender, args) =>
                    {
                        if(wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                        var filteredDictionary = _3PL.EMC.Where(kvp => kvp.Key != null && kvp.Key.IndexOf(FMJRadioButton.Content.ToString(), StringComparison.OrdinalIgnoreCase) >= 0)
                                                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);

                        DTRs = GetDTRs(filteredDictionary, diameter);
                        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                        wrapperPanel.Children.Add(stackPanel);
                    };

                    DWRadioButton.Checked += (sender, args) =>
                    {
                        if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                        var filteredDictionary = _3PL.EMC.Where(kvp => kvp.Key != null && kvp.Key.IndexOf(DWRadioButton.Content.ToString(), StringComparison.OrdinalIgnoreCase) >= 0)
                                                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);

                        DTRs = GetDTRs(filteredDictionary, diameter);
                        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                        wrapperPanel.Children.Add(stackPanel);
                    };
                    PartNumberRadioGroup.Children.Add(FMJRadioButton);
                    PartNumberRadioGroup.Children.Add(DWRadioButton);
                }
            };

            CloseRadio.Checked += (sendar, eargs) =>
            {
                if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                if (sendar is RadioButton rb)
                {
                    PartNumberRadioGroup.Children.Clear();
                    //panel.Margin = new Thickness(0, 5, 0, 5);
                    var BraidMeshButton = new RadioButton
                    {
                        Content = "Braid Mesh",
                        GroupName = $"PartNumberGroup_{number}",
                        Name = $"HL2Radio_{number}",
                        Margin = new Thickness(0, 0, 20, 0),
                        //Tag = combooPanel

                    };

                    var DWRadioButton = new RadioButton
                    {
                        Content = "F.CK",
                        GroupName = $"PartNumberGroup_{number}",
                        Name = $"HL3Radio_{number}",
                        //Tag = combooPanel
                    };

                    BraidMeshButton.Checked += (sender, args) =>
                    {
                        if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                        var filteredDictionary = _3PL.EMC.Where(kvp => kvp.Key != null && kvp.Key.IndexOf(BraidMeshButton.Content.ToString(), StringComparison.OrdinalIgnoreCase) >= 0)
                                                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                        DTRs = GetDTRs(filteredDictionary, diameter);
                        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                        wrapperPanel.Children.Add(stackPanel);
                    };

                    DWRadioButton.Checked += (sender, args) =>
                    {
                        if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                        var filteredDictionary = _3PL.EMC.Where(kvp => kvp.Key != null && kvp.Key.IndexOf(DWRadioButton.Content.ToString(), StringComparison.OrdinalIgnoreCase) >= 0)
                                                    .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                        DTRs = GetDTRs(filteredDictionary, diameter);
                        stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                        wrapperPanel.Children.Add(stackPanel);
                    };
                    PartNumberRadioGroup.Children.Add(BraidMeshButton);
                    PartNumberRadioGroup.Children.Add(DWRadioButton);
                }
            };
            OpenCloseRadioGroup.Children.Add(OpenRadio);
            OpenCloseRadioGroup.Children.Add(CloseRadio);

            wrapperPanel.Children.Add(OpenCloseRadioGroup);
            wrapperPanel.Children.Add(PartNumberRadioGroup);
            wrapperPanel.Children.Add(comboPanel);

            return wrapperPanel;
        }

        /// <summary>
        /// Create options for FlameRetardantSleeve
        /// </summary>
        /// <param name="number">Slide number</param>
        /// <param name="selectedBundleSegments">BundleSegments</param>
        /// <param name="submitPanel">Submit button Stack panel</param>
        /// <returns>StackPanel Containing options</returns>
        private UIElement FlameRetardantSleeve_DTRSelection(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        {
            double diameter = selectedBundleSegments.First().diameter;
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var OpenCloseRadioGroup = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var comboPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var OpenRadio = new RadioButton
            {
                Content = "Opened",
                GroupName = $"OpenOrClose{number}",
                Name = $"Open_{number}",
                //Tag = comboPanel,
                Margin = new Thickness(0, 0, 10, 0)
            };

            var CloseRadio = new RadioButton
            {
                Content = "Closed",
                GroupName = $"OpenOrClose{number}",
                //Tag = (FireSmokeOptionPanel, comboPanel),
                Name = $"CloseRadio_{number}"
            };
            
            List<string> DTRs = new List<string>();
            StackPanel stackPanel = null;
            OpenRadio.Checked += (senders, argus) =>
            {
                if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                if (senders is RadioButton rb)
                {
                    var filteredDictionary = _3PL.FlameRetardantSleeve.Where(x=>x.Key.ToLower().Contains("FyreJacket".ToLower())).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                    DTRs = GetDTRs(filteredDictionary, diameter);
                    stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                    wrapperPanel.Children.Add(stackPanel);
                }
            };

            CloseRadio.Checked += (senders, argus) =>
            {
                if (wrapperPanel.Children.Contains(stackPanel)) wrapperPanel.Children.Remove(stackPanel);
                if (senders is RadioButton rb)
                {
                    var filteredDictionary = _3PL.FlameRetardantSleeve.Where(x => x.Key.ToLower().Contains("Thermotubix".ToLower())).ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
                    DTRs = GetDTRs(filteredDictionary, diameter);
                    stackPanel = CreateComboboxForDTRs(number, DTRs, selectedBundleSegments, submitPanel);
                    wrapperPanel.Children.Add(stackPanel);
                }
            };
            OpenCloseRadioGroup.Children.Add(OpenRadio);
            OpenCloseRadioGroup.Children.Add(CloseRadio);

            wrapperPanel.Children.Add(OpenCloseRadioGroup);
            //wrapperPanel.Children.Add(comboPanel);

            return wrapperPanel;
        }

        /// <summary>
        /// Create a combobox and Show the Selected DTR number's
        /// </summary>
        /// <param name="number">Slide number</param>
        /// <param name="DTR">Selected DTR</param>
        /// <param name="submitPanel">Submit button StackPanel</param>
        /// <returns>Combobox containing StackPanel</returns>
        private StackPanel CreateComboboxForDTRs(int number, List<string> DTRs, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel)
        {
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var comboPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };

            TextBlock textBlock = new TextBlock
            {
                Text = "DTR: ",
                Margin = new Thickness(0, 5, 0, 5),
            };
            TextBlock descriptionTextBlock = new TextBlock
            {
                Margin = new Thickness(0, 5, 0, 5),
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 300,
            };
            ComboBox comboBox = new ComboBox
            {
                ItemsSource = DTRs,
                MinWidth = 200,
                Margin = new Thickness(0, 5, 0, 5),
                Name = $"DTRComboBox_{number}",
            };
            comboBox.SelectionChanged += (sender, eargus) =>
            {
                if (sender is ComboBox cb)
                {
                    ValidateIn3PLPrjet(comboBox.SelectedItem.ToString());
                    foreach (var segment in selectedBundleSegments)
                    {
                        segment.Sleeve = comboBox.SelectedItem.ToString();
                    }
                    descriptionTextBlock.Text = GetDTRDescription(comboBox.SelectedItem.ToString());
                    if (!descriptionTextBlock.Text.Contains("not found in the Sleeve Catalog."))
                        submitPanel.Visibility = Visibility.Visible;
                    else submitPanel.Visibility = Visibility.Collapsed;
                   
                }
            };
            comboPanel.Children.Add(textBlock);
            comboPanel.Children.Add(comboBox);
            wrapperPanel.Children.Add(comboPanel);
            wrapperPanel.Children.Add(descriptionTextBlock);

            return wrapperPanel;
        }

        /// <summary>
        /// Create a Textbox and Show the Selected DTR number
        /// </summary>
        /// <param name="number">Slide number</param>
        /// <param name="DTR">Selected DTR</param>
        /// <param name="submitPanel">Submit button StackPanel</param>
        /// <returns>Textbox containing StackPanel</returns>
        private StackPanel CreateTextboxForDTRs(int number, string DTR, StackPanel submitPanel )
        {
            var comboPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            TextBlock descriptionTextBlock = new TextBlock
            {
                Margin = new Thickness(0, 5, 0, 5),
                TextWrapping = TextWrapping.Wrap,
                MaxWidth = 300
            };
            TextBlock textBlock = new TextBlock
            {
                Text = "DTR: ",
                Margin = new Thickness(0, 5, 0, 5),
                VerticalAlignment = VerticalAlignment.Center
            };
            TextBox textBox = new TextBox
            {
                Text = DTR,
                MinWidth = 200,
                Margin = new Thickness(0, 5, 0, 5),
                Name = $"DTRTextBox_{number}",
                VerticalAlignment = VerticalAlignment.Center
            };
            if (!string.IsNullOrEmpty(DTR))
            {
                descriptionTextBlock.Text = GetDTRDescription(DTR);
                if (!GetDTRDescription(descriptionTextBlock.Text).Contains("not found in the Sleeve Catalog."))
                    submitPanel.Visibility = Visibility.Visible;
                else submitPanel.Visibility = Visibility.Collapsed;
            }
            comboPanel.Children.Add(textBlock);
            comboPanel.Children.Add(textBox);
            wrapperPanel.Children.Add(comboPanel);
            wrapperPanel.Children.Add(descriptionTextBlock);
            return wrapperPanel;
        }

        /// <summary>
        /// Returns only the DTR's of entries where the diameter is greater than the minimum diameter and less than the maximum diameter.
        /// </summary>
        /// <param name="filteredDictionary">EMC Dictionary</param>
        /// <param name="diameter">Bundlesegment Diameter</param>
        /// <returns>DTR's List</returns>
        private List<string> GetDTRs(Dictionary<string, List<EMC>> filteredDictionary, double diameter)
        {
            List<string> result = new List<string>();
            var filteredDict = filteredDictionary.Where(kvp => kvp.Value.Any(abc =>
            {
                if (double.TryParse(abc.Dia_Min, out double min) && double.TryParse(abc.DIA_Max, out double max))
                {
                    return diameter >= min && diameter <= max;
                }
                return false;
            }))
            .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
            result = filteredDict.SelectMany(kvp => kvp.Value).Select(abc => abc.DTR + " - " + abc.Supplier).ToList();

            return result;
        }

        /// <summary>
        /// Returns only the DTR's of entries where the diameter is greater than the minimum diameter and less than the maximum diameter.
        /// </summary>
        /// <param name="filteredDictionary">Heat_Shrinkable_Sleeve Dictionary</param>
        /// <param name="diameter">Bundlesegment Diameter</param>
        /// <returns>DTR's List</returns>
        private List<string> GetDTRs(Dictionary<string, List<Heat_Shrinkable_Sleeve>> filteredDictionary, double diameter)
        {
            List<string> result = new List<string>();
            var filteredDict = filteredDictionary.Select(kvp => new
            {
                Key = kvp.Key,
                FilteredList = kvp.Value
            .Where(abc =>
                double.TryParse(abc.DIAMETER_AFTER_SHRINKABLE_mm, out double min) &&
                double.TryParse(abc.DIAMETER_BEFORE_SHRINKABLE_mm, out double max) &&
                diameter >= min && diameter <= max)
            .ToList()
            })
            .Where(x => x.FilteredList.Any()) // Keep only entries with matching ABCs
            .ToDictionary(x => x.Key, x => x.FilteredList);
            result = filteredDict.SelectMany(kvp => kvp.Value).Select(abc => abc.DTR + " - " + abc.Supplier).ToList();

            return result;
        }

        /// <summary>
        /// Returns only the DTR's of entries where the diameter is greater than the minimum diameter and less than the maximum diameter.
        /// </summary>
        /// <param name="filteredDictionary">Flame_Retardant_Sleeve Dictionary</param>
        /// <param name="diameter">Bundlesegment Diameter</param>
        /// <returns>DTR's List</returns>
        private List<string> GetDTRs(Dictionary<string, List<Flame_Retardant_Sleeve>> filteredDictionary, double diameter)
        {
            List<string> result = new List<string>();
            var filteredDict = filteredDictionary.Where(kvp => kvp.Value.Any(abc =>
            {
                if (double.TryParse(abc.Dia_Min, out double min) && double.TryParse(abc.DIA_Max, out double max))
                {
                    return diameter >= min && diameter <= max;
                }
                return false;
            }))
            .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
            result = filteredDict.SelectMany(kvp => kvp.Value).Select(abc => abc.DTR + " - " + abc.Supplier).ToList();

            return result;
        }

        /// <summary>
        /// Returns only the DTR's of entries where the diameter is greater than the minimum diameter and less than the maximum diameter.
        /// </summary>
        /// <param name="filteredDictionary">WrapAroundGripSleeve Dictionary</param>
        /// <param name="diameter">Bundlesegment Diameter</param>
        /// <returns>DTR's List</returns>
        private List<string> GetDTRs(Dictionary<string, List<WrapAroundGripSleeve>> filteredDictionary, double diameter)
        {
            List<string> result = new List<string>();
            var filteredDict = filteredDictionary.Where(kvp => kvp.Value.Any(abc =>
            {
                if (double.TryParse(abc.Dia_Min, out double min) && double.TryParse(abc.DIA_Max, out double max))
                {
                    return diameter >= min && diameter <= max;
                }
                return false;
            }))
            .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
            result = filteredDict.SelectMany(kvp => kvp.Value).Select(abc => abc.DTR + " - " + abc.SUPPLIER ).ToList();

            return result;
        }

        /// <summary>
        /// Returns only the DTR's of entries where the diameter is greater than the minimum diameter and less than the maximum diameter.
        /// </summary>
        /// <param name="filteredDictionary">WrapAroundSleeve Dictionary</param>
        /// <param name="diameter">Bundlesegment Diameter</param>
        /// <returns>DTR's List</returns>
        private List<string> GetDTRs(Dictionary<string, List<WrapAroundSleeve>> filteredDictionary, double diameter)
        {
            List<string> result = new List<string>();
            var filteredDict = filteredDictionary.Where(kvp => kvp.Value.Any(abc =>
            {
                if (double.TryParse(abc.Dia_Min, out double min) && double.TryParse(abc.DIA_Max, out double max))
                {
                    return diameter >= min && diameter <= max;
                }
                return false;
            }))
            .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
            result = filteredDict.SelectMany(kvp => kvp.Value).Select(abc => abc.DTR + " - " + abc.SUPPLIER).ToList();

            return result;
        }

        /// <summary>
        /// Returns only the DTR's of entries where the diameter is greater than the minimum diameter and less than the maximum diameter.
        /// </summary>
        /// <param name="filteredDictionary">ExpandableSleeve Dictionary</param>
        /// <param name="diameter">Bundlesegment Diameter</param>
        /// <returns>DTR's List</returns>
        private List<string> GetDTRs(Dictionary<string, List<ExpandableSleeve>> filteredDictionary, double diameter)
        {
            List<string> result = new List<string>();
            var filteredDict = filteredDictionary.Where(kvp => kvp.Value.Any(abc =>
            {
                if (double.TryParse(abc.Dia_Min, out double min) && double.TryParse(abc.DIA_Max, out double max))
                {
                    return diameter >= min && diameter <= max;
                }
                return false;
            }))
            .ToDictionary(kvp => kvp.Key, kvp => kvp.Value);
            result = filteredDict.SelectMany(kvp => kvp.Value).Select(abc => abc.DTR + " - " + abc.Supplier).ToList();

            return result;
        }

        /// <summary>
        /// Collect all the RadioButtons within the UIElement.
        /// </summary>
        /// <param name="root"></param>
        /// <returns>List of Radio Buttons</returns>
        public static List<RadioButton> GetAllCheckedRadioButtons(UIElement root)
        {
            var result = new List<RadioButton>();

            void Traverse(DependencyObject current)
            {
                if (current is RadioButton rb && rb.IsChecked == true)
                {
                    result.Add(rb);
                }

                int childrenCount = VisualTreeHelper.GetChildrenCount(current);
                for (int i = 0; i < childrenCount; i++)
                {
                    var child = VisualTreeHelper.GetChild(current, i);
                    Traverse(child);
                }
            }

            Traverse(root);
            return result;
        }

        /// <summary>
        /// Collect all the TextBoxes within the UIElement.
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        public static List<(TextBlock textBox, StackPanel parentPanel)> GetAllTextBlockWithParentPanel(UIElement root)
        {
            var result = new List<(TextBlock, StackPanel)>();

            void Traverse(DependencyObject current, StackPanel currentParent)
            {
                if (current is TextBlock tb && currentParent != null)
                {
                    result.Add((tb, currentParent));
                }

                int childrenCount = VisualTreeHelper.GetChildrenCount(current);
                for (int i = 0; i < childrenCount; i++)
                {
                    var child = VisualTreeHelper.GetChild(current, i);

                    // If child is a StackPanel, update currentParent
                    if (child is StackPanel sp)
                        Traverse(child, sp);
                    else
                        Traverse(child, currentParent); // Pass along the existing parent
                }
            }

            Traverse(root, null);
            return result;
        }

        /// <summary>
        /// Collect all the ComboBoxes within the UIElement.
        /// </summary>
        /// <param name="root"></param>
        /// <returns></returns>
        public static List<(ComboBox comboBox, StackPanel parentPanel)> GetAllComboBoxesWithParentPanel(UIElement root)
        {
            var result = new List<(ComboBox, StackPanel)>();

            void Traverse(DependencyObject current, StackPanel currentParent)
            {
                if (current is ComboBox cb && currentParent != null)
                {
                    result.Add((cb, currentParent));
                }

                int childrenCount = VisualTreeHelper.GetChildrenCount(current);
                for (int i = 0; i < childrenCount; i++)
                {
                    var child = VisualTreeHelper.GetChild(current, i);

                    // If child is a StackPanel, update currentParent
                    if (child is StackPanel sp)
                        Traverse(child, sp);
                    else
                        Traverse(child, currentParent); // Pass along the existing parent
                }
            }

            Traverse(root, null);
            return result;
        }

        /// <summary>
        /// Calculate Internal Diameter with the Diameter and %Fill rate
        /// </summary>
        /// <param name="diameter"></param>
        /// <param name="fillrate"></param>
        /// <returns></returns>
        private string CalculateInternalDiameter(double diameter, string fillrate)
        {
            double fillRateDouble = 0;
            double.TryParse(fillrate, out fillRateDouble);
            double x = (10 * diameter) / Math.Sqrt(fillRateDouble);
            return x.ToString();
        }

        /// <summary>
        /// Corrugated Sleeve Selection: provide the user with radio button options for Divisible or Non-Divisible and HL2 or HL3. Retrieve the suitable Sleeve based on the selected options.
        /// </summary>
        /// <param name="number"></param>
        /// <param name="selectedBundleSegments"></param>
        /// <param name="submitPanel"></param>
        /// <param name="minBRBox"></param>
        /// <returns></returns>
        private StackPanel CreateDivisibleOrNonDivisibleRadioGroup(int number, IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel submitPanel, TextBox minBRBox)
        {
            var wrapperPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            var radioGroup = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var FireSmokeOptionPanel = new StackPanel
            {
                Name = $"FireSmokePanel_{number}",
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            var comboPanel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin = new Thickness(0, 5, 0, 5)
            };
            
            var DivisibleRadio = new RadioButton
            {
                Content = "Divisible",
                GroupName = $"DivisibleOrNonDivisible{number}",
                Name = $"Divisible_{number}",
                Tag = comboPanel,
                Margin = new Thickness(0, 0, 10, 0)
            };

            var NonDivisibleRadio = new RadioButton
            {
                Content = "Non Divisible",
                GroupName = $"DivisibleOrNonDivisible{number}",
                Tag = (FireSmokeOptionPanel, comboPanel),
                Name = $"NonDivisibleRadio_{number}"
            };

            // Attach event handler
            //DivisibleRadio.Checked += DivisibleOrNonDivisibleRadio_Checked;
            //NonDivisibleRadio.Checked += DivisibleOrNonDivisibleRadio_Checked;
            
            NonDivisibleRadio.Checked += (s, e) =>
            {
                if (s is RadioButton rb && rb.Tag is ValueTuple<StackPanel, StackPanel> tag)
                {
                    var FireSmokePanel = tag.Item1;
                    var combooPanel = tag.Item2;
                    FireSmokePanel.Children.Clear();
                    combooPanel.Children.Clear();
                    combooPanel.Orientation = Orientation.Horizontal;
                    //panel.Margin = new Thickness(0, 5, 0, 5);
                    var HL2RadioButton = new RadioButton
                    {
                        Content = "HL2",
                        GroupName = $"FireSmokeGroup_{number}",
                        Name = $"HL2Radio_{number}",
                        Margin = new Thickness(0, 0, 20, 0),
                        Tag = combooPanel

                    };

                    var HL3RadioButton = new RadioButton
                    {
                        Content = "HL3",
                        GroupName = $"FireSmokeGroup_{number}",
                        Name = $"HL3Radio_{number}",
                        Tag = combooPanel
                    };
                    string selectedRadioButton = string.Empty;
                    HL2RadioButton.Checked += (sender, args) =>
                    {
                        selectedRadioButton = HL2RadioButton.Content.ToString();
                        CreateDTRComboBox_Corrugated(selectedBundleSegments, combooPanel, selectedRadioButton, corrugatedDiaInt, number, submitPanel, minBRBox); // Create ComboBox for 'HL2'
                    };

                    HL3RadioButton.Checked += (sender, args) =>
                    {
                        selectedRadioButton = HL3RadioButton.Content.ToString();
                        CreateDTRComboBox_Corrugated(selectedBundleSegments, combooPanel, selectedRadioButton, corrugatedDiaInt, number, submitPanel, minBRBox); // Create ComboBox for 'HL3'
                    };
                    
                    //if (!string.IsNullOrEmpty(requiredCorrugatedSleeve.DTR))
                    //{
                    //    foreach (var segment in selectedBundleSegments)
                    //    {
                    //        segment.Sleeve = requiredCorrugatedSleeve.DTR;
                    //    }
                    //    DTRTextBlock.Text = GetDTRDescription(requiredCorrugatedSleeve.DTR);

                    //    submitPanel.Visibility = Visibility.Visible;
                    //}
                    FireSmokePanel.Children.Add(HL2RadioButton);
                    FireSmokePanel.Children.Add(HL3RadioButton);
                }
            };

            DivisibleRadio.Checked += (s, e) =>
            {
                if (s is RadioButton rb && rb.Tag is StackPanel panel)
                {
                    FireSmokeOptionPanel.Children.Clear();
                    comboPanel.Children.Clear();
                    GetDTRandCreteComboBox_DiviSible(selectedBundleSegments, number, corrugatedDiaInt, panel, submitPanel, minBRBox);
                    //if (!string.IsNullOrEmpty(divisible.DTR))
                    //{
                    //    foreach (var segment in selectedBundleSegments)
                    //    {
                    //        segment.Sleeve = divisible.DTR;
                    //    }
                    //    DTRTextBlock.Text = GetDTRDescription(divisible.DTR);
                    //    submitPanel.Visibility = Visibility.Visible;
                    //}
                }
            };
            radioGroup.Children.Add(DivisibleRadio);
            radioGroup.Children.Add(NonDivisibleRadio);

            wrapperPanel.Children.Add(radioGroup);
            wrapperPanel.Children.Add(FireSmokeOptionPanel);
            wrapperPanel.Children.Add(comboPanel);

            return wrapperPanel;
        }

        /// <summary>
        /// Get % FillRate from BundleSegment Diameter and SleeveDiameter
        /// </summary>
        /// <param name="dIA_int"></param>
        /// <param name="bundleDiameter"></param>
        /// <returns></returns>
        private double getFillRate(string dIA_int, double bundleDiameter)
        {
            double rate =  100 * (bundleDiameter / double.Parse(dIA_int)) * (bundleDiameter / double.Parse(dIA_int));
            return rate;
        }

        /// <summary>
        /// Get the Description of Sleeve from Catalog Json file
        /// </summary>
        /// <param name="dTR"></param>
        /// <returns></returns>
        public string GetDTRDescription(string dTR)
        {
            if (_CatalogData == null || _CatalogData.Sleeve_Elec == null) { return string.Empty; }
            string sleeve = _CatalogData.Sleeve_Elec
                    .SelectMany(outer => outer.Value.Values) // Flatten to List<List<string>>
                    .SelectMany(list => list)                // Flatten to List<string>
                    .FirstOrDefault(item => item.Contains( dTR));   // Find the match
            return string.IsNullOrEmpty(sleeve)? dTR + " not found in the Sleeve Catalog." : sleeve;
        }

        /// <summary>
        /// For Corrugated Sleeve, Sleeve Selection for Divisible or non Divisible.
        /// </summary>
        /// <param name="selectedBundleSegments"></param>
        /// <param name="number"></param>
        /// <param name="diaInt"></param>
        /// <param name="panel"></param>
        /// <param name="submitPanel"></param>
        /// <param name="minBRBox"></param>
        private void GetDTRandCreteComboBox_DiviSible(IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, int number, string diaInt, StackPanel panel, StackPanel submitPanel, TextBox minBRBox)
        {
            panel.Children.Clear();
            //comboPanel.Children.Clear();
            panel.Orientation = Orientation.Vertical;
            StackPanel comboPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(0, 5, 0, 5)
            };
            comboPanel.Children.Add(new TextBlock
            {
                Text = "DTR:",
                Margin = new Thickness(0, 5, 0, 5)
            });
            var descriptionTextBlock = new TextBlock { Margin = new Thickness(0, 5, 0, 5), TextWrapping = TextWrapping.Wrap, MaxWidth = 300 };
            var fillRateTextBlock = new TextBlock { Margin = new Thickness(0, 5, 0, 5), TextWrapping = TextWrapping.Wrap, MaxWidth = 300 };
            //Divisible divisible = _3PL.Divisible.SelectMany(kvp => kvp.Value).Where(abc =>
            //                                     double.TryParse(abc.Dia_Int, out _))
            //                                    .OrderBy(abc => double.Parse(abc.Dia_Int) - double.Parse(diaInt))
            //                                    .FirstOrDefault();// Get the nearest one,
           
            var closestDict = _3PL.Divisible
                                    .Where(kvp => kvp.Value.Any(abc => double.TryParse(abc.Dia_Int, out _)))
                                    .ToDictionary(
                                        kvp => kvp.Key,
                                        kvp =>
                                        {
                                            return kvp.Value
                                                .Where(abc => double.TryParse(abc.Dia_Int, out _) && getFillRate(abc.Dia_Int, selectedBundleSegments.First().diameter) < double.Parse(fillrate))
                                                .OrderBy(abc => Math.Abs(double.Parse(abc.Dia_Int) - double.Parse(diaInt)))
                                                .FirstOrDefault();
                                        }
                                    );
            var comboBox = new ComboBox
            {
                ItemsSource = closestDict
                                .Where(kvp => kvp.Value != null && !string.IsNullOrWhiteSpace(kvp.Value.DTR))
                                .Select(kvp => kvp.Value.DTR + " - " + kvp.Key)
                                .ToList(),
                Width = 230,
                Name = $"DTRDivisibleComboBox_{number}"
            };
            comboBox.SelectionChanged += (sender, eargus) =>
            {
                if (comboBox.SelectedItem != null)
                {
                    Divisible selectedDivisible = closestDict.Values.Where(abc => abc != null && abc.DTR.Equals(comboBox.SelectedItem.ToString().Split('-')[0].Trim(), StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                    double calculatedFillRate = getFillRate(selectedDivisible.Dia_Int, selectedBundleSegments.First().diameter);
                    MessageBoxResult messageBoxResult = MessageBoxResult.None;
                    if (calculatedFillRate > 60)
                    {
                        messageBoxResult = WriteMessageAsFillRateIsAbove60(submitPanel, descriptionTextBlock, fillRateTextBlock, comboBox, calculatedFillRate);
                    }

                    if (!string.IsNullOrEmpty(selectedDivisible.DTR) && comboBox.SelectedItem != null)
                    {
                        foreach (var segment in selectedBundleSegments)
                        {
                            segment.Sleeve = selectedDivisible.DTR;
                        }
                        ALT_Logging.alt_Logging_class.AddMessage(selectedDivisible.Min_BR.ToString() + " % Fill Rate: " + calculatedFillRate + GetDTRDescription(selectedDivisible.DTR) + selectedDivisible.DTR);
                        minBRBox.Text = selectedDivisible.Min_BR.ToString();
                        fillRateTextBlock.Text = "% Fill Rate: " + calculatedFillRate;
                        descriptionTextBlock.Text = GetDTRDescription(selectedDivisible.DTR);
                        if (!descriptionTextBlock.Text.Contains("not found in the Sleeve Catalog."))
                            submitPanel.Visibility = Visibility.Visible;
                        else submitPanel.Visibility = Visibility.Collapsed;
                        ValidateIn3PLPrjet(selectedDivisible.DTR);
                    }
                }
            };
                
            comboPanel.Children.Add(comboBox);
            panel.Children.Add(comboPanel);
            panel.Children.Add(fillRateTextBlock);
            panel.Children.Add(descriptionTextBlock);
        }

        /// <summary>
        /// Show %FillRate in MessageBox
        /// </summary>
        /// <param name="submitPanel"></param>
        /// <param name="descriptionTextBlock"></param>
        /// <param name="fillRateTextBlock"></param>
        /// <param name="comboBox"></param>
        /// <param name="calculatedFillRate"></param>
        /// <returns></returns>
        private static MessageBoxResult WriteMessageAsFillRateIsAbove60(StackPanel submitPanel, TextBlock descriptionTextBlock, TextBlock fillRateTextBlock, ComboBox comboBox, double calculatedFillRate)
        {
            MessageBoxResult messageBoxResult = alt_PopupMessageUtil.ShowMessageYesNo($"The selected Sleeve has a fill rate of {calculatedFillRate}%, which is above the 60% threshold. Do you still want to implement it anyway?", "Warning", MessageType.Warning);
            if (messageBoxResult == MessageBoxResult.No || messageBoxResult == MessageBoxResult.None)
            {
                comboBox.SelectedItem = null;
                fillRateTextBlock.Text = string.Empty;
                descriptionTextBlock.Text = string.Empty;
                submitPanel.Visibility = Visibility.Collapsed;
            }

            return messageBoxResult;
        }

        /// <summary>
        /// DTR Selection For Corrugated Sleeve
        /// </summary>
        /// <param name="selectedBundleSegments">Grouped BundleSegments</param>
        /// <param name="panel"></param>
        /// <param name="rbContent"></param>
        /// <param name="diaInt"></param>
        /// <param name="number"></param>
        /// <param name="submitPanel"></param>
        /// <param name="minBRBox"></param>
        private void CreateDTRComboBox_Corrugated(IGrouping<double, CoveringDataPreparation.SelectedBundleSegment> selectedBundleSegments, StackPanel panel, string rbContent, string diaInt, int number, StackPanel submitPanel, TextBox minBRBox)
        {
            panel.Children.Clear(); // clear previous control
            panel.Orientation = Orientation.Vertical;
            StackPanel ComboPanel = new StackPanel
            {
                Orientation = Orientation.Horizontal
            };
            var textBlock = new TextBlock { Text = "DTR:" };
            var descriptionTextBlock = new TextBlock { Margin = new Thickness(0,5,0,5), TextWrapping = TextWrapping.Wrap, MaxWidth = 300 };
            var fillRateTextBlock = new TextBlock { Margin = new Thickness(0, 5, 0, 5), TextWrapping = TextWrapping.Wrap, MaxWidth = 300 };
            //var textbox = new TextBox
            //{
            //    Width = 150,
            //    Name = $"DTRTextBox",
            //    Margin = new Thickness(0, 5, 0, 5)
            //};
          
            var closestDiaSleeve = _3PL.CorrugatedSleeve
                                                    .ToDictionary(
                                                        kvp => kvp.Key,
                                                        kvp => kvp.Value
                                                            .Where(abc =>
                                                                !string.IsNullOrEmpty(abc.DTR) &&
                                                                abc.FIRE_AND_SMOKE.Contains(rbContent) &&
                                                                double.TryParse(abc.DIA_int, out _) && getFillRate(abc.DIA_int, selectedBundleSegments.First().diameter) < double.Parse(fillrate))
                                                            .OrderBy(abc => Math.Abs(double.Parse(abc.DIA_int) - double.Parse(diaInt)))
                                                            .FirstOrDefault()
                                                    );

            var comboBox = new ComboBox
            {
                ItemsSource = closestDiaSleeve.Where(kvp => kvp.Value != null && !string.IsNullOrWhiteSpace(kvp.Value.DTR))
                                .Select(kvp => kvp.Value.DTR + " - " + kvp.Key)
                                .ToList(),
                Width = 230,
                Name = $"DTRCorrugatedComboBox_{number}"
            };
            comboBox.SelectionChanged += (sender, eargus) =>
            {
                if (comboBox.SelectedItem != null)
                {
                    CorrugatedSleeve selectedSleeve = closestDiaSleeve.Values.Where(abc => abc != null && abc.DTR.Equals(comboBox.SelectedItem.ToString().ToString().Split('-')[0].Trim(), StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

                    double calculatedFillRate = getFillRate(selectedSleeve.DIA_int, selectedBundleSegments.First().diameter);
                    MessageBoxResult messageBoxResult = MessageBoxResult.None;
                    if (calculatedFillRate > 60)
                    {
                        messageBoxResult = WriteMessageAsFillRateIsAbove60(submitPanel, descriptionTextBlock, fillRateTextBlock, comboBox, calculatedFillRate);
                        //messageBoxResult = alt_PopupMessageUtil.ShowMessageYesNo($"The selected Sleeve has a fill rate of {calculatedFillRate}%, which is above the 60% threshold. Do you still want to implement it anyway?", "Warning", MessageType.Warning);
                        //if (messageBoxResult == MessageBoxResult.No || messageBoxResult == MessageBoxResult.None)
                        //{
                        //    comboBox.SelectedItem = null;
                        //    fillRateTextBlock.Text = string.Empty;
                        //    descriptionTextBlock.Text = string.Empty;
                        //    submitPanel.Visibility = Visibility.Collapsed;
                        //}
                    }
                    if (!string.IsNullOrEmpty(selectedSleeve.DTR) && comboBox.SelectedItem != null)
                    {
                        foreach (var segment in selectedBundleSegments)
                        {
                            segment.Sleeve = selectedSleeve.DTR;
                        }
                        ALT_Logging.alt_Logging_class.AddMessage(selectedSleeve.Min_BR_mm_ST.ToString() + " % Fill Rate: " + calculatedFillRate + GetDTRDescription(selectedSleeve.DTR) + selectedSleeve.DTR);
                        minBRBox.Text = selectedSleeve.Min_BR_mm_ST.ToString();
                        fillRateTextBlock.Text = "% Fill Rate: " + calculatedFillRate;
                        descriptionTextBlock.Text = GetDTRDescription(selectedSleeve.DTR);
                        if (!descriptionTextBlock.Text.Contains("not found in the Sleeve Catalog."))
                            submitPanel.Visibility = Visibility.Visible;
                        else submitPanel.Visibility = Visibility.Collapsed;
                        ValidateIn3PLPrjet(comboBox.SelectedItem.ToString());
                    }
                }
            };
            ComboPanel.Children.Add(textBlock);
            ComboPanel.Children.Add(comboBox);
            panel.Children.Add(ComboPanel);
            panel.Children.Add(fillRateTextBlock);
            panel.Children.Add(descriptionTextBlock);
        }

        /// <summary>
        /// Check the selected SLeeve is resent in 3PL Projet file or not
        /// </summary>
        /// <param name="dtr"> DTR number of Sleeve</param>
        private void ValidateIn3PLPrjet(string dtr)
        {
            List<PL3_Global> pL3_Global = _3PL_Global.SelectMany(kvp => kvp.Value).Where(abc => abc.DTR_Number != null && abc.DTR_Number.Contains(dtr)).ToList();
            if (pL3_Global.Count == 0 || (pL3_Global.Count > 0 && pL3_Global.First().PPL == ""))
            {
                alt_PopupMessageUtil.ShowMessage("This component is not referred in the 3PL, if you wish to use this component for the design, make sure to verify that the component is subscribed in orchestra, linked to your current project  and implement the component in the 3PL.", "Information", MessageType.Information);
            }
            else
            {
                if (pL3_Global.First().PPL == "OPPL")
                {
                    alt_PopupMessageUtil.ShowMessage("This component is referred in the 3PL but outisde the PPL.Make sure you can use it.", "Information", MessageType.Information);
                }
            }
        }

        //private void DivisibleOrNonDivisibleRadio_Checked(object sender, RoutedEventArgs e)
        //{
        //    if (sender is RadioButton rb && rb.Tag is int number)
        //    {
        //        if(rb.Content == "Non Divisible")
        //        {
        //            // Line 6: "Divisible" or "Non Divisible" RadioButtons with Checked Event
        //            var line6 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
        //            line6.Children.Add(CreateHL2orHL3RadioGroup(number, rb.));

        //        }
        //        else
        //        {
        //            // Line 6: DTR Number Combobox 
        //            var line6 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
        //            line6.Children.Add(CreateDTRCombobox(number, _3PL.Divisible));
        //        }
        //    }
        //}

        //private UIElement CreateDTRCombobox<TKey, TValue>(int number, Dictionary<TKey, TValue> dictionary)
        //{
        //    List<string> dtrs = dictionary.Select(x => x.GetType().Name).ToList();
        //    var DTRComboBox = new ComboBox
        //    {
        //        Width = 200,
        //        Margin = new Thickness(0, 5, 0, 5),
        //        Name = $"SupplierComboBox_{number}",
        //        ItemsSource = dictionary.Select(x => x.GetType().Name).ToList(),
        //        SelectedItem = null
        //    };
        //    return DTRComboBox;
        //}

        //private UIElement CreateDTRComboboxAccordingToFireAndSmoke<TKey, TValue>(int number, Dictionary<TKey, TValue> dictionary, string checkboxContent)
        //{
        //    var fireSmokeProp = typeof(TValue).GetProperty("FIRE_AND_SMOKE");
        //    List<string> dtrs = dictionary.Select(x => x.GetType().Name).ToList();
        //    var DTRComboBox = new ComboBox
        //    {
        //        Width = 200,
        //        Margin = new Thickness(0, 5, 0, 5),
        //        Name = $"SupplierComboBox_{number}",
        //        ItemsSource = dictionary.Where(x => fireSmokeProp != null && fireSmokeProp.GetValue(x.Value) is string fireSmoke && fireSmoke.Contains(checkboxContent)).Select(x => fireSmokeProp.GetValue(x.Value) as string).ToList(),
        //        SelectedItem = null
        //    };
        //    return DTRComboBox;
        //}

        //private StackPanel CreateHL2orHL3RadioGroup(int number)
        //{
        //    var radioGroup = new StackPanel
        //    {
        //        Orientation = Orientation.Horizontal,
        //        Margin = new Thickness(0, 5, 0, 5)
        //    };

        //    var HL2Radio = new RadioButton
        //    {
        //        Content = "HL2",
        //        GroupName = $"HL2OrHL3_{number}",
        //        Name = $"HL2_{number}",
        //        Margin = new Thickness(0, 0, 10, 0)
        //    };

        //    var HL3Radio = new RadioButton
        //    {
        //        Content = "HL3",
        //        GroupName = $"HL2OrHL3_{number}",
        //        Name = $"HL2_{number}"
        //    };

        //    // Attach event handler
        //    HL2Radio.Checked += HL2orHL3Radio_Checked;
        //    HL3Radio.Checked += HL2orHL3Radio_Checked;

        //    radioGroup.Children.Add(HL2Radio);
        //    radioGroup.Children.Add(HL3Radio);

        //    return radioGroup;
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void HL2orHL3Radio_Checked(object sender, RoutedEventArgs e)
        //{
        //    if (sender is RadioButton rb && rb.Tag is int number)
        //    {
        //        string numberString = number.ToString();
        //        var line6 = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 5, 0, 5) };
        //        line6.Children.Add(CreateDTRComboboxAccordingToFireAndSmoke(number, _3PL.CorrugatedSleeve, rb.Content.ToString()));
        //    }
        //}

        //private void ScrollLeft_Click(object sender, RoutedEventArgs e)
        //{
        //    SlideScrollViewer.ScrollToHorizontalOffset(SlideScrollViewer.HorizontalOffset - 300); // Slide width
        //}

        //private void ScrollRight_Click(object sender, RoutedEventArgs e)
        //{
        //    SlideScrollViewer.ScrollToHorizontalOffset(SlideScrollViewer.HorizontalOffset + 300);
        //}

        /// <summary>
        /// Types of Sleeves listed in Combobox
        /// </summary>
        public enum SleeveTypes
        {
            Flame_Retardant_sleeve,
            Electrical_Insulation,
            EMC,
            Heat_Shrinkable_sleeve,
            Expand_Roundit_Roundit_Grip,
            Corrugated_conduit,
            Color_Ring
        }
    }

    /// <summary>
    /// Converts color name to color
    /// </summary>
    public class StringToBrushConverter : System.Windows.Data.IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null) return Brushes.Transparent;

            try
            {
                var color = (Color)ColorConverter.ConvertFromString(value.ToString());
                return new SolidColorBrush(color);
            }
            catch
            {
                return Brushes.Transparent;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
