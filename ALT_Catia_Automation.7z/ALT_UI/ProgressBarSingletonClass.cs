﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace ALT_UI
{
    public sealed class ProgressBarSingletonClass : BackgroundWorker, IDisposable
    {
        private static ProgressBarSingletonClass instance;
        private static MainWindow mainWindow;
        //private CustomProgressWindow progresswindow = null;
        public static readonly object lockObject = new object();
        public bool IsPartFile = false;
        static ProgressBarSingletonClass() { }

        private Action<object, DoWorkEventArgs> DoWorkCallback { get; set; }
        private Action<object, RunWorkerCompletedEventArgs> RunWorkerCompletedCallback { get; set; }
        private Action<object, ProgressChangedEventArgs> ProgressChangedCallback { get; set; }
        // Public static property to access the single instance
        public static ProgressBarSingletonClass Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ProgressBarSingletonClass();
                    if (mainWindow == null)
                    {
                        foreach (var item in System.Windows.Application.Current.Windows)
                        {
                            if (item is MainWindow)
                            {
                                mainWindow = item as MainWindow;
                            }
                        }
                    }
                }
                return instance;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private ProgressBarSingletonClass()
        {
            WorkerReportsProgress = true;
            WorkerSupportsCancellation = true;
            DoWork += WorkDOWork;
            ProgressChanged += WorkProgressChanged;
            RunWorkerCompleted += WorkProgressCompleted;
        }

        /// <summary>
        /// Updates the Progress Bar 
        /// </summary>
        /// <param name="startValue"></param>
        /// <param name="endValue"></param>
        /// <param name="progressText"></param>
        public void ProgressSimulation(int startValue, int endValue, string progressText)
        {
            for (int i = startValue; i <= endValue; i++)
            {
                Thread.Sleep(5);
                Application.Current.Dispatcher.Invoke(() =>
                {
                    ReportProgress(i);
                }, System.Windows.Threading.DispatcherPriority.Background);
            }
            mainWindow.progressText1.Text = progressText;
        }

        /// <summary>
        /// Update the Status in TextBox above ProgressBar
        /// </summary>
        /// <param name="progressText"></param>
        public void UpdateApplicationStatus(string progressText)
        {
            mainWindow.ApplicationStatus1.Text = progressText;
        }

        /// <summary>
        /// Updates Progress Status with Percentage
        /// </summary>
        /// <param name="percentage"></param>
        /// <param name="progressText"></param>
        public void ReportProgressWithPercentage(int percentage, string progressText)
        {
            ReportProgress(percentage);
            mainWindow.progressText1.Text = progressText;
            mainWindow.ApplicationStatus1.Text = string.Empty;
        }

        /// <summary>
        /// Event for Do Work
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WorkDOWork(object sender, DoWorkEventArgs e)
        {
            DoWorkCallback?.Invoke(sender, e);
        }

        /// <summary>
        /// Event for WorkProgressChanged
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WorkProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            ProgressChangedCallback?.Invoke(sender, e);
            mainWindow.Dispatcher.Invoke(() =>
            {
                mainWindow.progressBar1.Value = e.ProgressPercentage;
            });
        }

        /// <summary>
        /// Event for WorkProgressCompleted
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void WorkProgressCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            mainWindow.Dispatcher.Invoke(() =>
            {
                mainWindow.progressBar1.Value = 0;
            });
            RunWorkerCompletedCallback?.Invoke(sender, e);
            Dispose(true);

        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            instance = null;
        }
    }
}
