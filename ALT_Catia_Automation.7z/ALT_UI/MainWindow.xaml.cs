﻿/// <summary>
/// class for .
/// </summary>
/// <remarks>
/// This class is used to .
/// </remarks>
/// 

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ALT_Data_Model;
using ApplicationLayer;
using ALT_Data_Preparation;
using ALT_Utilities;
using System.IO;
using System.Windows.Threading;
using ALT_Unity_Interface;
using ALT_Logging;
using System.Diagnostics;


namespace ALT_UI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Fields
        private alt_Automation_Orchestrator orchestrator;
        private alt_Utilities utils;
        private List<string> filteredItems;
        private List<string> equipmentFiles;
        internal string deleteFolderName = "MyTempExcelFolder";
        private MenuItem reframeItem, addItem, modifyItems, deleteItem, addSelectedItem, modifySelectedItem, deleteSelectedItem, UpdateAllSelectedItems, itemProperties;
        internal static ProgressBar progressBar;
        private string _rgbSelected = "255,255,255";
        List<string> cadConnectorsNames = null;
        List<CADConnector> CADConnectors = new List<CADConnector>();
        CADHarnessColors cADHarnessColors = new CADHarnessColors();
        private string synopticFilePath = "", extractFAFFilePath = "", ppl_Cables_FilePath = "", ppl_Electricals_FilePath = "";
        string tempExcelFolderPath = "";
        internal MessageBoxResult result;

        /// <summary>
        /// Event for "Open Base Line Folder" Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenBaseLine_Click(object sender, RoutedEventArgs e)
        {
            string envValue = Environment.GetEnvironmentVariable("HAT_User_Baseline_Path", EnvironmentVariableTarget.User);

            if (Directory.Exists(envValue))
            {
                Process.Start("explorer.exe", envValue);
            }
            else
            {
                Console.WriteLine("Folder does not exist.");
            }
        }

        /// <summary>
        /// Event for "Open Share Point" Button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OpenSharePoint_Click(object sender, RoutedEventArgs e)
        {
            string UserRootPath = ALT_UI.PathHelper.GetUserHATRootPath();
            var SharePointAccessObj = new SharePointZipDownloader(UserRootPath, false);
            
            // Extract and sanitize Site URL
            string siteUrl = SharePointAccessObj.SharePointAccessConfig.SiteUrl.TrimEnd('/');

            // Drop first 2 folders from SharePointRootPath
            string[] rootPathParts = SharePointAccessObj.SharePointAccessConfig.SharePointRootPath
                .Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries)
                .Skip(2)
                .ToArray();

            // Other parts (trimmed inputs)
            string[] otherParts = new[] {
                ProjectText.Text?.Trim(),
                ZoneText.Text?.Trim(),
                BaselineText.Text?.Trim(),
                VersionText.Text?.Trim(),
            };

            // Combine all parts and URL-encode them
            string UrlPath = string.Join("/",
                new[] { siteUrl }
                    .Concat(rootPathParts)
                    .Concat(otherParts)                        
            );
            
            string[] parts = UrlPath.Split('/');
            for (int i = 0; i < parts.Length; i++)
            {
                if (parts[i].StartsWith("Zone_", StringComparison.OrdinalIgnoreCase))
                {
                    parts[i] = "SYNOPTIC";
                    break;
                }
            }

            string updatedUrl = string.Join("/", parts);
            //MessageBox.Show("Launching " + updatedUrl);

            Process.Start(new ProcessStartInfo
            {
                FileName = updatedUrl,
                UseShellExecute = true
            });
        }

        //internal string releaseFolderDirectory = Environment.GetEnvironmentVariable("HAT_User_Baseline_Path", EnvironmentVariableTarget.User) + "\\Catia_Data\\Json_Data";

        public MainViewModel viewModel { get; }
        #endregion

        #region Constructor
        /// <summary>
        /// XXX.
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        public MainWindow()
        {
            orchestrator = new alt_Automation_Orchestrator();
            InitializeComponent();
            viewModel = new MainViewModel();
            DataContext = viewModel;
            Title = Title + " - " + Properties.Settings.Default["Version"].ToString();
            my_BranchCreation.ProjecttypeItemSource();
            my_BranchCreation.CabletypeItemSource();
            my_BranchCreation.WiretypeItemSource();
            my_BranchCreation.ColorListView.ItemsSource = cADHarnessColors.SmallColorList;
            my_PreProcessing.CollectSupplierData();
            
            Dispatcher.UnhandledException += Dispatcher_UnhandledException;
        }
        #endregion

        /// <summary>
        /// Triggered whenever an error occurs in the application tool.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void Dispatcher_UnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            MessageBox.Show($"An unhandled exception occurred: Please check the process again", "Unhandled Exception", MessageBoxButton.OK, MessageBoxImage.Error);
            e.Handled = true;
            alt_Logging_class.AddError($"An unhandled exception occurred: {e.Exception.Message}");

            ProgressBarSingletonClass.Instance.ReportProgress(100, "Please repeat the operation");
            ProgressBarSingletonClass.Instance.UpdateApplicationStatus("Status: There is an error!! Please check the operation performed");
        }

        /// <summary>
        /// Runs the GIF while the long-running task is in progress and invokes all other tasks from here.
        /// </summary>
        /// <param name="longRunningTask"></param>
        /// <returns></returns>
        internal async Task ShowOverlayAsync(Func<Task> longRunningTask)
        {
            try
            {
                // Show the overlay
                CommonOverlay.Visibility = Visibility.Visible;

                // Perform the long-running task
                await longRunningTask();
            }
            finally
            {
                // Hide the overlay
                CommonOverlay.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Triggered when the tab selection changes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedTabItem = ALTTabControl.SelectedItem as TabItem;
            if (selectedTabItem.Header.ToString() == "Input-Processing")
            {
                EnableRefreshButton();
            }
            else
            {
                DisableRefreshButton();
            }
        }      



        /// <summary>
        /// Apply Design mode to Root Product
        /// </summary>
        /// <value>
        /// A <see cref="Guid"/> representing the customer's unique ID.
        /// </value>
        private async void ApplyDesignMode()
        {
            await ShowOverlayAsync(async () =>
            {
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(10, "Applying Design Mode");
                await Task.Run(() =>
                {
                    orchestrator.Step_1_process<alt_Step1_InputProcessing>("ApplyDesignModeToRootProduct");
                });
                ProgressBarSingletonClass.Instance.ReportProgressWithPercentage(100, "Design Mode Applied");
            });
        }

        /// <summary>
        /// Run Uniti Application
        /// </summary>
        private async void RunUnityApplication()
        {
            await Task.Run(() =>
            {
                orchestrator.step_2_process<alt_Unity_Interface>("RunUnityApplication");
            });          
        }

        /// <summary>
        /// Triggered when the application is closed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closed(object sender, EventArgs e)
        {
            orchestrator.step_0_process<alt_Step0_PreProcessing>("DeleteMyTempExcelFolder", deleteFolderName);
        }

        /// <summary>
        /// Event handler for the Refresh button.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private async void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            if (Refresh.Content == "Refresh")
            {
                string harnessName = my_InputProcessing.HarnessComboBox.Text;
                await my_InputProcessing.RefreshConnectorStatus(harnessName);
            }
            else if (Refresh.Content == "Launch Unity")
            {
                my_SharePoint_Synchronization.RunUnityApplication();
            }
        }

        /// <summary>
        /// Change Refresh Button Content to "Launch Unity"
        /// </summary>
        internal void DisableRefreshButton()
        {
            Refresh.Content = "Launch Unity";
        }

        /// <summary>
        /// Change Refresh Button Content to "Refresh"
        /// </summary>
        internal void EnableRefreshButton()
        {
            Refresh.Content = "Refresh";
            Refresh.IsEnabled = true;
        }
    }
}