﻿/// <summary>
/// class for orchestrating the UI actions. Aim here is to keep UI call back actions separated out from core logic of the code.
/// </summary>
/// <remarks>
/// All UI callback actions will be called from here.
/// </remarks>
/// 

using System;
using System.Reflection;
using ALT_Logging;
using ALT_Data_Preparation;
using ALT_Unity_Interface;
using System.Diagnostics;

namespace ApplicationLayer
{
    public class alt_Automation_Orchestrator
    {
        // Injected dependencies
        private readonly alt_Logging_class _logging;
        private readonly alt_Step1_InputProcessing step1_obj;
        private readonly alt_Unity_Interface unity_Interface;
        private readonly alt_Step0_PreProcessing step0_obj;
        private readonly alt_Step3_Accessorization step3_obj;

        /// <summary>
        /// Constructor Class.
        /// </summary>
        /// <value>
        /// Class Constructor.
        /// </value>
        public alt_Automation_Orchestrator()
        {
            _logging = new alt_Logging_class();
            step1_obj = new alt_Step1_InputProcessing(_logging);
            unity_Interface = new alt_Unity_Interface();
            step0_obj = new alt_Step0_PreProcessing(_logging);
            step3_obj = new alt_Step3_Accessorization(_logging);
        }

        /// <summary>
        /// Workflow start.
        /// </summary>
        /// <value>
        /// Starting of a work flow.
        /// </value>
        public void StartAutomationWorkflow()
        {
            try
            {
                InitializeWorkflow();
            }
            catch (Exception ex)
            {
                _logging.LogError("An error occurred during the automation workflow: " + ex.Message);
            }
        }

        /// <summary>
        /// Step 0 in the workflow.
        /// </summary>
        /// <value>
        /// This iis pre-processing activity in the workflow.
        /// </value>
        public object step_0_process<T>(string method_name, params object[] parameters)
        {
            Debug.Print("method_name : " + method_name);
            Type type_step_0 = typeof(T);
            MethodInfo methodInfo = type_step_0.GetMethod(method_name);

            object obj = methodInfo.Invoke(step0_obj, parameters);
            return obj;
        }

        /// <summary>
        /// Step 1 in the workflow.
        /// </summary>
        /// <value>
        /// Action callback for Step 1 in the work flow.
        /// </value>
        public object Step_1_process<T>(string method_name, params object[] parameters)
        {
            Type type_step_1 = typeof(T);
            MethodInfo methodInfo = type_step_1.GetMethod(method_name);

            object obj = methodInfo.Invoke(step1_obj, parameters);
            return obj;
        }

        /// <summary>
        /// Step 2 in the workflow.
        /// </summary>
        /// <value>
        /// Action callback for Step 2 in the work flow.
        /// </value>
        public object step_2_process<T>(string method_name, params object[] parameters)
        {
            Type type_step_2 = typeof(T);
            MethodInfo methodInfo = type_step_2.GetMethod(method_name);

            object obj = methodInfo.Invoke(unity_Interface, parameters);
            return obj;
        }

        /// <summary>
        /// Step 2 in the workflow.
        /// </summary>
        /// <value>
        /// Action callback for Step 2 in the work flow.
        /// </value>
        public object step_3_process<T>(string method_name, params object[] parameters)
        {
            Type type_step_3 = typeof(T);
            MethodInfo methodInfo = type_step_3.GetMethod(method_name);

            object obj = methodInfo.Invoke(step3_obj, parameters);
            return obj;
        }

        /// <summary>
        /// End of workflow.
        /// </summary>
        /// <value>
        /// ending the work flow.
        /// </value>
        public void FinishAutomationWorkflow()
        {
            try
            {
                FinalizeWorkflow();
            }
            catch (Exception ex)
            {
                _logging.LogError("An error occurred during the automation workflow: " + ex.Message);
            }
        }

        /// <summary>
        /// Starting the workflow.
        /// </summary>
        /// <value>
        /// start of the work flow.
        /// </value>
        private void InitializeWorkflow()
        {
            //_logging.LogInfo("Initializing automation workflow...");
            //_configurationManager.LoadConfiguration();
            //_ui.ShowMessage("Automation workflow started. Please follow the steps.");
        }

        /// <summary>
        /// Final action of the workflow.
        /// </summary>
        /// <value>
        /// Call before finishing the work flow
        /// </value>
        private void FinalizeWorkflow()
        {
            //_logging.LogInfo("Finalizing automation workflow...");
            //_ui.ShowMessage("Automation workflow completed successfully.");
        }
    }    
}