﻿using System;
using System.IO;

namespace ALT_Logging
{
    public class alt_Logging_class
    {
        /// <summary>
        /// Logs the specified error message.
        /// </summary>
        /// <remarks>This method records the provided error message for diagnostic purposes.  Ensure that
        /// the <paramref name="error"/> parameter contains meaningful information  about the error to aid in
        /// troubleshooting.</remarks>
        /// <param name="error">The error message to log. Cannot be null or empty.</param>
        public void LogError(string error)
        {

        }

        private static readonly string _FilePath = Path.Combine(Environment.GetEnvironmentVariable("HAT_User_Baseline_Path", EnvironmentVariableTarget.User) + "\\HAT_Data\\Catia_Data\\Logs", "ALT_HyperAutomation_" + DateTime.Now.ToString("yyyyMMddhhmm") + ".log");
        
        /// <summary>
        /// Appends a message to the log file, including a timestamp.
        /// </summary>
        /// <remarks>The message is prefixed with the current time in the format "HH:mm:ss" before being
        /// written to the log file. The log file is specified by the internal file path and is opened in append
        /// mode.</remarks>
        /// <param name="iMessage">The message to be written to the log file. Cannot be null or empty.</param>
        public static void AddMessage(string iMessage)
        {
            using (StreamWriter sw = new StreamWriter(_FilePath, true))
            {
                string timestampedMessage = $"[{DateTime.Now:HH:mm:ss}] {iMessage}";
                sw.WriteLine(timestampedMessage);
            }
        }

        /// <summary>
        /// Appends a warning message to the log file.
        /// </summary>
        /// <remarks>The warning message is prefixed with "--- Warning ---" and appended to the log file
        /// specified by the internal file path. This method opens the file in append mode and writes the message on a
        /// new line.</remarks>
        /// <param name="iMessage">The warning message to be written to the log file. Cannot be null or empty.</param>
        public static void AddWarning(string iMessage)
        {
            using (StreamWriter sw = new StreamWriter(_FilePath, true))
            {
                sw.WriteLine("--- Warning --- " + iMessage);
            }
        }

        /// <summary>
        /// Logs an error message to the specified file.
        /// </summary>
        /// <remarks>The error message is appended to the file specified by the internal file path.  Each
        /// message is prefixed with "*** ERROR ***". Ensure the file path is accessible  and writable to avoid runtime
        /// exceptions.</remarks>
        /// <param name="iMessage">The error message to log. Cannot be null or empty.</param>
        public static void AddError(string iMessage)
        {
            using (StreamWriter sw = new StreamWriter(_FilePath, true))
            {
                sw.WriteLine("*** ERROR *** " + iMessage);
            }
        }
    }
}
