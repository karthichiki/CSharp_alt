﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ALT_GlobalServices
{
    public static class alt_WindowTracker
    {

        [DllImport("User32.dll")]
        public static extern IntPtr SetForegroundWindow(IntPtr point);
        [DllImport("user32.dll")]
        public static extern bool PostMessage(IntPtr hwnd, int uMsg, int wParam, int lParam);
        const int WM_KEYDOWN = 0x100;
        const int WM_KEYUP = 0x101;
        const int VK_ESCAPE = 0x1B;
    
        /// <summary>
        /// 
        /// </summary>
        /// <param name="strProcess"></param>
        public static void BringApplicationToFront(string strProcess)
        {
            Process catiaProcess = Process.GetProcessesByName(strProcess).FirstOrDefault();
            if (catiaProcess != null)
            {
                IntPtr catiaProcessHandle = catiaProcess.MainWindowHandle;
                SetForegroundWindow(catiaProcessHandle);
                PostMessage(catiaProcessHandle, WM_KEYDOWN, VK_ESCAPE, 0);
                PostMessage(catiaProcessHandle, WM_KEYUP, VK_ESCAPE, 0);
            }
        }


    }
}
