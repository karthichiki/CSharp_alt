﻿using ALT_Data_Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ALT_Catia_Automation_Unit_Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestSynopticConnectorName()
        {
            SynopticConnector synopticData = new SynopticConnector();
            string synopticCntName = synopticData.CreateSynopticConnectorName("52A01", "X_L4;2");
            if (synopticCntName != "52A01_X_L4;2")
                Assert.Fail("Synoptic Connector Name wrongly calculated");

            synopticCntName = synopticData.CreateSynopticConnectorName("52A01", "");
            if (synopticCntName != "52A01")
                Assert.Fail("Synoptic Connector Name wrongly calculated");

            synopticCntName = synopticData.CreateSynopticConnectorName("", "X_L4;2");
            if (synopticCntName != "X_L4;2")
                Assert.Fail("Synoptic Connector Name wrongly calculated");

            synopticCntName = synopticData.CreateSynopticConnectorName("PB", "X_L4;2");
            if (synopticCntName != "X_L4;2")
                Assert.Fail("Synoptic Connector Name wrongly calculated");

            synopticCntName = synopticData.CreateSynopticConnectorName("PBM", "X_L4;2");
            if (synopticCntName != "X_L4;2")
                Assert.Fail("Synoptic Connector Name wrongly calculated");
        }
    }
}
