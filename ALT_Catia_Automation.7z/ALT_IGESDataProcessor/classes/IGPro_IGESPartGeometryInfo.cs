﻿using IGES3DNSP;
using System;
using System.Collections.Generic;

namespace IGESDataProcessor
{
	/// <summary>
	/// Represents geometry information for an IGES part, including native and transformed shells, as well as the part
	/// body.
	/// </summary>
	/// <remarks>This class provides a structure to store and manage geometry data for an IGES part. It includes
	/// collections for both native and transformed shells, as well as a reference to the part body. The <see
	/// cref="DeepCopy"/> method can be used to create a new instance of this class with the same data.</remarks>
	[Serializable]
	public class IGPro_IGESPartGeometryInfo
	{
		public List<IG_Shell> Transformed_Shells = new List<IG_Shell>();
		public List<IG_Shell> Native_Shells = new List<IG_Shell>();

		public IG_Body partBody = new IG_Body();

        /// <summary>
		/// Creates a deep copy of the current <see cref="IGPro_IGESPartGeometryInfo"/> instance.
		/// </summary>
		/// <remarks>The returned object is a new instance with the same values as the original, including references
		/// to the same <see cref="Native_Shells"/> and <see cref="partBody"/> objects. However, the <see
		/// cref="Transformed_Shells"/> collection is reinitialized as a new, empty list.</remarks>
		/// <returns>A new <see cref="IGPro_IGESPartGeometryInfo"/> instance that is a deep copy of the current instance.</returns>
        public IGPro_IGESPartGeometryInfo DeepCopy()
		{
			IGPro_IGESPartGeometryInfo prtInfo_New = (IGPro_IGESPartGeometryInfo)this.MemberwiseClone();

			prtInfo_New.Native_Shells = Native_Shells;
			prtInfo_New.partBody = partBody;
			prtInfo_New.Transformed_Shells = new List<IG_Shell>();

			return prtInfo_New;
		}
	}
}
