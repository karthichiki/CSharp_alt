﻿using System;
using System.Collections.Generic;
using System.Windows.Media.Media3D;

namespace IGESDataProcessor
{
	/// <summary>
	/// Represents a pair of matched faces between two parts, along with their associated intersection data.
	/// </summary>
	/// <remarks>This class is used to store information about two matched faces, including their geometric details,
	/// the polygon formed by their intersection, and the centroid of the intersection.</remarks>
	[Serializable]
	public class IGPro_MatchedFaces
	{
		public IGES3DNSP.IG_Face primaryPartFace = new IGES3DNSP.IG_Face();
		public IGES3DNSP.IG_Face secondaryPartFace = new IGES3DNSP.IG_Face();
		public List<Point3D> IntersectedPolygon = new List<Point3D>();
		public Point3D Centroiod = new Point3D();
		//Hold HNF here TO be added
	}
}
