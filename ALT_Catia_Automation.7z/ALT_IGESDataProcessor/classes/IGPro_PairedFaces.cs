﻿using System;
using System.Collections.Generic;

namespace IGESDataProcessor
{
	/// <summary>
	/// Represents a pair of faces along with the calculated distance between them.
	/// </summary>
	/// <remarks>This class is typically used to store and analyze paired face data, including the distance metric
	/// that quantifies the relationship between the two faces.</remarks>
	[Serializable]
	public class IGPro_PairedFaces
	{
		public double Distance { get; set; }
		public List<IGES3DNSP.IG_Face> FacePair { get; set; }
	}
}
