﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media.Media3D;
using IGES3DNSP;
using ProductStructureTypeLib;
using MECMOD;
using INFITF;
using CATIdeSettings;
using Mathlib;
using System.Runtime.InteropServices;
using OpenTK;
using ALT_Logging;

namespace IGESDataProcessor
{
    /// <summary>
    /// Provides utility methods for processing IGES (Initial Graphics Exchange Specification) data.
    /// </summary>
    /// <remarks>This static class contains methods for handling IGES data, including exporting, transforming,
    /// and analyzing geometric information. It is designed to work with 3D product data and perform  operations such as
    /// retrieving part geometry, transforming data, and calculating bounding boxes.</remarks>
    public static class IGESDataProcesser_cls
    {

        //NOTE: This method only retrieves native data, need to transform this data to bring it back to the original position.
        /// <summary>
        /// Retrieves the native IGES part geometry information for the specified product.
        /// </summary>
        /// <remarks>This method retrieves the native IGES data for the specified product and applies the
        /// specified transformation matrix to the data. Note that the retrieved data may need further transformation to
        /// restore it to its original position.</remarks>
        /// <param name="iPrd">The product for which the IGES part geometry information is to be retrieved.</param>
        /// <param name="matrix3D">The transformation matrix to be applied to the IGES data.</param>
        /// <param name="oPrtGeomInfo">An output parameter that will hold the retrieved IGES part geometry information, including native shells.</param>
        /// <returns><see langword="true"/> if the IGES part geometry information is successfully retrieved and processed;
        /// otherwise, <see langword="false"/>.</returns>
        public static bool GetIGESPartGeometryInfo(Product iPrd, Matrix3D matrix3D, IGPro_IGESPartGeometryInfo oPrtGeomInfo)
        {
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetIGESPartGeometryInfo ::  Start.");
            bool status = true;
            try
            {
                Tuple<List<IG_Body>, List<IG_Shell>> IGESData = ExportToIGES3DData(iPrd);
                oPrtGeomInfo.Native_Shells = IGESData.Item2;

                alt_Logging_class.AddMessage("IGESDataProcesser_cls :: ExportToIGES3DData :: Success :: " + iPrd.get_Name());

                bool valied = TransformIGESData(oPrtGeomInfo, matrix3D);

                alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: Success :: " + iPrd.get_Name());
            }
            catch (Exception err)
            {
                alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: Failed :: " + iPrd.get_Name());

                System.Windows.MessageBox.Show("WARNING: Unexpected error has occured while trying to retreive IGES Native data: Error info - " + err.Message);
                return false;
            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: End");
            return status;
        }

        /// <summary>
        /// Converts a <see cref="Matrix4d"/> to a <see cref="Matrix3D"/>.
        /// </summary>
        /// <remarks>This method maps the elements of the input <see cref="Matrix4d"/> to the
        /// corresponding elements of a <see cref="Matrix3D"/>. It is useful for interoperability between libraries that
        /// use different matrix types.</remarks>
        /// <param name="openTkMatrix">The <see cref="Matrix4d"/> instance to convert.</param>
        /// <returns>A <see cref="Matrix3D"/> instance that represents the same transformation as the input <see
        /// cref="Matrix4d"/>.</returns>
        public static Matrix3D ConvertToMatrix3D(Matrix4d openTkMatrix)
        {
            return new Matrix3D(
                openTkMatrix.M11, openTkMatrix.M12, openTkMatrix.M13, openTkMatrix.M14,
                openTkMatrix.M21, openTkMatrix.M22, openTkMatrix.M23, openTkMatrix.M24,
                openTkMatrix.M31, openTkMatrix.M32, openTkMatrix.M33, openTkMatrix.M34,
                openTkMatrix.M41, openTkMatrix.M42, openTkMatrix.M43, openTkMatrix.M44
            );
        }

        /// <summary>
        /// Exports the 3D data of the specified product to an IGES file and parses the resulting file into a collection
        /// of IGES bodies and shells.
        /// </summary>
        /// <remarks>This method configures the IGES export settings, generates a temporary IGES file for
        /// the specified product,  and parses the file to extract 3D entities. The temporary IGES file is deleted after
        /// processing.</remarks>
        /// <param name="InputProduct">The product whose 3D data is to be exported and processed. This must be a valid CATIA product.</param>
        /// <returns>A tuple containing two lists: <list type="bullet"> <item> <description>A list of <see cref="IG_Body"/>
        /// objects representing the bodies parsed from the IGES file.</description> </item> <item> <description>A list
        /// of <see cref="IG_Shell"/> objects representing the shells parsed from the IGES file.</description> </item>
        /// </list></returns>
        public static Tuple<List<IG_Body>, List<IG_Shell>> ExportToIGES3DData(Product InputProduct)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: ExportToIGES3DData :: start");
            // For IGES 3D Setting
            SettingControllers SCs = ((Application)Marshal.GetActiveObject("CATIA.Application")).SettingControllers;
            IgesSettingAtt IGES3D_Setting = (IgesSettingAtt)SCs.Item("CATIdeIgesSettingCtrl");

            IGES3D_Setting.CrvMod = 0;
            //IGES3D_Setting.RepMod = 0;
            IGES3D_Setting.ExportMSBO = 1;

            IGES3D_Setting.SaveRepository();

            // SeatRail product convert to IGES
            string StrSeatRailFileName = System.IO.Path.GetTempPath() + InputProduct.ReferenceProduct.get_Name();

            // Deleting SeatRail IGES
            if (System.IO.File.Exists(StrSeatRailFileName + ".igs"))
            {
                System.IO.File.Delete(StrSeatRailFileName + ".igs");
            }


            ((Document)InputProduct.ReferenceProduct.Parent).ExportData(StrSeatRailFileName + ".igs", "igs");
            StrSeatRailFileName = StrSeatRailFileName + ".igs";

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: ExportToIGES3DData :: Export Success.");

            //Tuple<List<IGES3DNSP.IG_Face>, List<IGES3DNSP.IG_Shell>> IGESSeatRailEntities_Tuble = IGES3D.ReadFileParse(StrSeatRailFileName);
            //BRepBody bRepBody =  IGES3DParser.ReadFileParse(StrSeatRailFileName);
            Tuple<List<IG_Body>, List<IG_Shell>> IGESSeatRailEntities_Tuble = IGES3DParser.ReadFileParse(StrSeatRailFileName);
            //Tuple<List<IGES3DNSP.IG_Face>, List<IGES3DNSP.IG_Shell>> Faces_And_Shells_Tuple = bRepBody.Faces_And_Shells_Tuple;

            //List<IGES3DNSP.IG_Face> IGESSeatRailEntities = Faces_And_Shells_Tuple.Item1;

            // Deleting SeatRail IGES
            if (System.IO.File.Exists(StrSeatRailFileName))
            {
                System.IO.File.Delete(StrSeatRailFileName);
            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: ExportToIGES3DData :: End");

            return IGESSeatRailEntities_Tuble;
        }

        /// <summary>
        /// Calculates the bounding box for a given set of 3D faces and determines the center of gravity (CG) point.
        /// </summary>
        /// <remarks>The method projects the vertices of the provided 3D faces onto the XY and YZ planes
        /// to calculate the bounding box dimensions. It then computes the planes that form the bounding box and
        /// determines the center of gravity (CG) point.</remarks>
        /// <param name="IGESTemp">A list of 3D faces represented as <see cref="IGES3DNSP.IG_Face"/> objects. These faces are used to compute
        /// the bounding box.</param>
        /// <param name="CG_Pt">A reference to a <see cref="Point3D"/> object that will be updated to represent the center of gravity (CG)
        /// point of the bounding box.</param>
        /// <returns>A list of six <see cref="Plane3D"/> objects representing the planes that define the bounding box.</returns>
        public static List<Plane3D> GetBoundingBox(List<IGES3DNSP.IG_Face> IGESTemp, ref Point3D CG_Pt)
        {
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetBoundingBox :: Start");
            Vector3D ZVector = new Vector3D() { X = 0, Y = 0, Z = 1 };
            Vector3D XVector = new Vector3D() { X = 1, Y = 0, Z = 0 };
            Vector3D YVector = new Vector3D() { X = 0, Y = 1, Z = 0 };

            var OriginePoint_XY_Start = IGESTemp.Min(x => x.Outer_Loop_List[0].Edge_List.Min(y => y.Start_Vertex.Z));

            var OriginePoint_XY_End = IGESTemp.Min(x => x.Outer_Loop_List[0].Edge_List.Min(y => y.End_Vertex.Z));


            //var OriginePoint_XY_Control = IGESTemp.Min(x => x.Outer_Loop_List[0].Edge_List.Min(y => y.NURB_Cuve.ControlPoints.Min(z => z.X)));

            List<double> MinOfZ = new List<double>() { OriginePoint_XY_Start, OriginePoint_XY_End };

            double MinofAll_Z = MinOfZ.Min();


            var OriginePoint_YZ_Start_Max = IGESTemp.Min(x => x.Outer_Loop_List[0].Edge_List.Min(y => y.Start_Vertex.X));

            var OriginePoint_YZ_End_Max = IGESTemp.Min(x => x.Outer_Loop_List[0].Edge_List.Min(y => y.End_Vertex.X));


            //var OriginePoint_XY_Control = IGESTemp.Min(x => x.Outer_Loop_List[0].Edge_List.Min(y => y.NURB_Cuve.ControlPoints.Min(z => z.X)));

            List<double> MinOfX_Max = new List<double>() { OriginePoint_YZ_Start_Max, OriginePoint_YZ_End_Max };

            double MinofAll_X = MinOfX_Max.Min();


            Plane3D XYPlane = new Plane3D() { NormalVector = ZVector, PlaneOrigin = new Point3D() { X = 0, Y = 0, Z = MinofAll_Z } };
            Plane3D YZPlane = new Plane3D() { NormalVector = XVector, PlaneOrigin = new Point3D() { X = MinofAll_X, Y = 0, Z = 0 } };
            //Plane3D ZXPlane = new Plane3D() { NormalVector = YVector, PlaneOrigin = OriginePoint };

            List<Point3D> XY_Proj_Points = new List<Point3D>();
            List<Point3D> YZ_Proj_Points = new List<Point3D>();

            foreach (IGES3DNSP.IG_Face IFC in IGESTemp)
            {
                for (int i = 0; i <= IFC.Outer_Loop_List[0].Edge_List.Count - 1; i++)
                {
                    Point3D SV_Point = IFC.Outer_Loop_List[0].Edge_List[i].Start_Vertex;
                    Point3D EV_Point = IFC.Outer_Loop_List[0].Edge_List[i].End_Vertex;

                    XY_Proj_Points.Add(Mathlib.matlib.ProjectPointOnPlane(SV_Point, XYPlane));
                    XY_Proj_Points.Add(Mathlib.matlib.ProjectPointOnPlane(EV_Point, XYPlane));


                    Point3D SV_Point_1 = IFC.Outer_Loop_List[0].Edge_List[i].Start_Vertex;
                    Point3D EV_Point_1 = IFC.Outer_Loop_List[0].Edge_List[i].End_Vertex;

                    YZ_Proj_Points.Add(Mathlib.matlib.ProjectPointOnPlane(SV_Point_1, YZPlane));
                    YZ_Proj_Points.Add(Mathlib.matlib.ProjectPointOnPlane(EV_Point_1, YZPlane));

                }

            }


            //List<IGES3DNSP.IG_Face> FacesParalleltoPlane_FirstPart = PrimaryPart_IGES.NativeData.Where(x => matlib.AreVectorsParallel(x.PlaneSurface.NormalDirection, ListNearestPlanes[0].NormalVector) == true).ToList();

            //List<Point3D> Temp = XY_Proj_Points.Where(x => x.X)
            double xMinP1 = XY_Proj_Points.Min(x => x.X);

            double yMinP1 = XY_Proj_Points.Min(x => x.Y);

            double zMinP1 = XY_Proj_Points.Min(x => x.Z);


            Point3D MinPointP1 = new Point3D() { X = xMinP1, Y = yMinP1, Z = zMinP1 };


            double xMaxP2 = XY_Proj_Points.Max(x => x.X);

            double yMaxP2 = XY_Proj_Points.Max(x => x.Y);

            double zMaxP2 = XY_Proj_Points.Max(x => x.Z);


            Point3D MaxPointP2 = new Point3D() { X = xMaxP2, Y = yMinP1, Z = zMaxP2 };


            double xMinP3 = YZ_Proj_Points.Min(x => x.X);

            double zMinP3 = YZ_Proj_Points.Min(x => x.Z);

            double yMinP3 = YZ_Proj_Points.Min(x => x.Y);


            Point3D MinPointP3 = new Point3D() { X = xMinP3, Y = yMinP3, Z = zMinP3 };

            double xMaxP4 = YZ_Proj_Points.Max(x => x.X);

            double zMaxP4 = YZ_Proj_Points.Max(x => x.Z);

            double yMaxP4 = YZ_Proj_Points.Max(x => x.Y);


            Point3D MaxPointP4 = new Point3D() { X = xMaxP4, Y = yMaxP4, Z = zMinP3 };

            Point3D MaxPointP5 = new Point3D() { X = xMaxP2, Y = yMaxP4, Z = zMaxP4 };

            List<Point3D> TempPoint = new List<Point3D>();
            TempPoint.Add(MinPointP1);
            TempPoint.Add(MaxPointP2);
            TempPoint.Add(MinPointP3);
            TempPoint.Add(MaxPointP4);
            TempPoint.Add(MaxPointP5);



            Plane3D Plane1 = new Plane3D() { PlaneOrigin = MinPointP1, NormalVector = ZVector };

            Vector3D DirVec2 = Point3D.Subtract(MaxPointP2, MinPointP1);
            DirVec2.Normalize();
            Plane3D Plane2 = new Plane3D() { PlaneOrigin = MinPointP1, NormalVector = DirVec2 };

            Vector3D DirVec3 = Point3D.Subtract(MaxPointP4, MinPointP1);
            DirVec3.Normalize();
            Plane3D Plane3 = new Plane3D() { PlaneOrigin = MinPointP1, NormalVector = DirVec3 };


            ZVector.Negate();
            Plane3D Plane4 = new Plane3D() { PlaneOrigin = MaxPointP5, NormalVector = ZVector };


            DirVec2.Negate();
            Plane3D Plane5 = new Plane3D() { PlaneOrigin = MaxPointP5, NormalVector = DirVec2 };


            DirVec3.Negate();
            Plane3D Plane6 = new Plane3D() { PlaneOrigin = MaxPointP5, NormalVector = DirVec3 };


            // CG
            double XlenCG = Math.Abs((MaxPointP5.X) - (MinPointP1.X)) / 2;
            double YlenCG = Math.Abs((MaxPointP5.Y) - (MinPointP1.Y)) / 2;
            double ZlenCG = Math.Abs((MaxPointP5.Z) - (MinPointP1.Z)) / 2;

            Point3D cgPt = new Point3D((MinPointP1.X + XlenCG), (MinPointP1.Y + YlenCG), (MinPointP1.Z + ZlenCG));
            CG_Pt = cgPt;
            //double cg = Abs(MaxPointP5.X )


            List<Plane3D> BoundingPlanes = new List<Plane3D>();

            BoundingPlanes.Add(Plane1);
            BoundingPlanes.Add(Plane2);
            BoundingPlanes.Add(Plane3);
            BoundingPlanes.Add(Plane4);
            BoundingPlanes.Add(Plane5);
            BoundingPlanes.Add(Plane6);

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetBoundingBox :: End");
            return BoundingPlanes;
        }

        /// <summary>
        /// Transforms the geometry data of an IGES part using the specified transformation matrix.
        /// </summary>
        /// <remarks>This method processes the shells in the input IGES data, applies the specified
        /// transformation matrix to their geometry, and stores the transformed shells in the <c>Transformed_Shells</c>
        /// collection of the input object. If an error occurs during the transformation, the method logs the error and
        /// returns <see langword="false"/>.</remarks>
        /// <param name="ioInputIGESData">The IGES part geometry data to be transformed. This object will be updated with the transformed geometry.</param>
        /// <param name="ipartMatrix">The transformation matrix to apply to the IGES part geometry. This matrix defines the transformation to be
        /// applied, such as translation, rotation, or scaling.</param>
        /// <returns><see langword="true"/> if the transformation is successfully applied; otherwise, <see langword="false"/>.</returns>
        public static bool TransformIGESData(IGPro_IGESPartGeometryInfo ioInputIGESData, Matrix3D ipartMatrix)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: Start");
            bool status = true;
            try
            {
                foreach (IG_Shell sh in ioInputIGESData.Native_Shells)
                {
                    IG_Shell transShell = new IG_Shell();
                    transShell.Face_List = TransformIGESData(sh.Face_List, ipartMatrix);

                    if (sh.IsClosedShell) // Expecting only one closed shell - the actual body
                    {
                        transShell.IsClosedShell = true;
                    }
                    else
                    {
                        transShell.IsClosedShell = false;
                    }

                    ioInputIGESData.Transformed_Shells.Add(transShell);
                }
            }
            catch (Exception err)
            {

                alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: Failed");
                System.Windows.MessageBox.Show("WARNING: Unexpected error has occured while trying to transform IGES data: Error info - " + err.Message);
                return false;
            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: End");
            return status;
        }

        /// <summary>
        /// Transforms the geometric data of a collection of IGES faces using the specified transformation matrix.
        /// </summary>
        /// <remarks>This method applies the specified transformation matrix to the geometric properties
        /// of each face in the input IGES data. The transformation includes updating the positions of vertices, control
        /// points, and construction points, as well as transforming the normal direction and other geometric attributes
        /// of the faces.</remarks>
        /// <param name="InputIGESData">A list of <see cref="IGES3DNSP.IG_Face"/> objects representing the input IGES data to be transformed.</param>
        /// <param name="PartMatrix">A <see cref="Matrix3D"/> representing the transformation matrix to apply to the IGES data.</param>
        /// <returns>A list of <see cref="IGES3DNSP.IG_Face"/> objects containing the transformed IGES data.</returns>
        public static List<IGES3DNSP.IG_Face> TransformIGESData(List<IGES3DNSP.IG_Face> InputIGESData, Matrix3D PartMatrix)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: Start");
            Dictionary<Int32, Int32> Dic_EdgeID = new Dictionary<int, int>();

            List<IGES3DNSP.IG_Face> OutputIGESData = new List<IGES3DNSP.IG_Face>();

            int iCount = 0;

            foreach (IGES3DNSP.IG_Face oFEntity in InputIGESData)
            {


                IGES3DNSP.IG_Face NewFace = (IGES3DNSP.IG_Face)oFEntity.DeepCopy();


                NewFace.PlaneSurface.PointONSurface = matlib.transformPoint(PartMatrix, NewFace.PlaneSurface.PointONSurface);

                NewFace.PlaneSurface.NormalDirection = Vector3D.Multiply(NewFace.PlaneSurface.NormalDirection, PartMatrix);



                for (int i = 0; i <= NewFace.Outer_Loop_List[0].Edge_List.Count - 1; i++)
                {
                    //Start vertex transformation
                    NewFace.Outer_Loop_List[0].Edge_List[i].Start_Vertex = matlib.transformPoint(PartMatrix, NewFace.Outer_Loop_List[0].Edge_List[i].Start_Vertex);
                    NewFace.Outer_Loop_List[0].Edge_List[i].Center_Vertex = matlib.transformPoint(PartMatrix, NewFace.Outer_Loop_List[0].Edge_List[i].Center_Vertex);
                    NewFace.Outer_Loop_List[0].Edge_List[i].End_Vertex = matlib.transformPoint(PartMatrix, NewFace.Outer_Loop_List[0].Edge_List[i].End_Vertex);


                    if (NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ConstructionPoints.Count > 0)
                    {

                        iCount = NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ConstructionPoints.Count;

                        for (int j = 0; j < iCount; j++)
                        {
                            NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ConstructionPoints[j] = matlib.transformPoint(PartMatrix, NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ConstructionPoints[j]);
                        }

                        iCount = NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ControlPoints.Count;

                        for (int j = 0; j < iCount; j++)
                        {
                            NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ControlPoints[j] = matlib.transformPoint(PartMatrix, NewFace.Outer_Loop_List[0].Edge_List[i].NURB_Cuve.ControlPoints[j]);
                        }
                    }


                    if (NewFace.Outer_Loop_List[0].Edge_List[i].circularArc_Abs.ArcPoints.Count > 0)
                    {

                        iCount = NewFace.Outer_Loop_List[0].Edge_List[i].circularArc_Abs.ArcPoints.Count;

                        for (int j = 0; j < iCount; j++)
                        {
                            NewFace.Outer_Loop_List[0].Edge_List[i].circularArc_Abs.ArcPoints[j] = matlib.transformPoint(PartMatrix, NewFace.Outer_Loop_List[0].Edge_List[i].circularArc_Abs.ArcPoints[j]);
                        }
                    }

                    //if (iCount == 1)
                    //{
                    //    CreatePoint(oTempPart, "COORDINATES", objHybridBodyAutomation, NewFace.Outer_Loop_List[0].Edge_List[i].Start_Vertex);
                    //    CreatePoint(oTempPart, "COORDINATES", objHybridBodyAutomation, NewFace.Outer_Loop_List[0].Edge_List[i].End_Vertex);
                    //}

                }
                for (int ij = 0; ij <= NewFace.Internal_Loop_List.Count - 1; ij++)
                {
                    IG_Loop lp = NewFace.Internal_Loop_List[ij];
                    for (int i = 0; i <= lp.Edge_List.Count - 1; i++)
                    {
                        lp.Edge_List[i].Start_Vertex = matlib.transformPoint(PartMatrix, lp.Edge_List[i].Start_Vertex);
                        lp.Edge_List[i].Center_Vertex = matlib.transformPoint(PartMatrix, lp.Edge_List[i].Center_Vertex);
                        lp.Edge_List[i].End_Vertex = matlib.transformPoint(PartMatrix, lp.Edge_List[i].End_Vertex);


                        if (lp.Edge_List[i].NURB_Cuve.ConstructionPoints.Count > 0)
                        {

                            iCount = lp.Edge_List[i].NURB_Cuve.ConstructionPoints.Count;

                            for (int j = 0; j < iCount; j++)
                            {
                                lp.Edge_List[i].NURB_Cuve.ConstructionPoints[j] = matlib.transformPoint(PartMatrix, lp.Edge_List[i].NURB_Cuve.ConstructionPoints[j]);
                            }

                            iCount = lp.Edge_List[i].NURB_Cuve.ControlPoints.Count;

                            for (int j = 0; j < iCount; j++)
                            {
                                lp.Edge_List[i].NURB_Cuve.ControlPoints[j] = matlib.transformPoint(PartMatrix, lp.Edge_List[i].NURB_Cuve.ControlPoints[j]);
                            }
                        }
                        if (lp.Edge_List[i].circularArc_Abs.ArcPoints.Count > 0)
                        {

                            iCount = lp.Edge_List[i].circularArc_Abs.ArcPoints.Count;

                            for (int j = 0; j < iCount; j++)
                            {
                                lp.Edge_List[i].circularArc_Abs.ArcPoints[j] = matlib.transformPoint(PartMatrix, lp.Edge_List[i].circularArc_Abs.ArcPoints[j]);
                            }
                        }
                    }
                }

                if (NewFace != new IGES3DNSP.IG_Face())
                {
                    OutputIGESData.Add(NewFace);
                }

            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: TransformIGESData :: End");
            return OutputIGESData;
        }

        /// <summary>
        /// Identifies and returns a list of matched faces between two parts based on their geometric properties.
        /// </summary>
        /// <remarks>This method identifies matched faces between two parts by comparing their geometric
        /// properties, such as the distance between their planes and the parallelism of their normal vectors. Matched
        /// faces are further validated by checking for intersected polygons between the face pairs.  The method ensures
        /// that the returned list contains unique matches based on the secondary part's face IDs.</remarks>
        /// <param name="PrimaryPart_IGES">A list of faces representing the primary part.</param>
        /// <param name="SecondaryPart_IGES">A list of faces representing the secondary part.</param>
        /// <param name="PrimaryPart_BoundPlane">A list of bounding planes for the primary part.</param>
        /// <param name="SecondaryPart_BoundPlane">A list of bounding planes for the secondary part.</param>
        /// <returns>A list of <see cref="IGPro_MatchedFaces"/> objects, where each object represents a pair of matched faces
        /// from the primary and secondary parts, along with their intersected polygon points.</returns>
        public static List<IGPro_MatchedFaces> GetBuddingSurfacesOFTwoParts(List<IGES3DNSP.IG_Face> PrimaryPart_IGES, List<IGES3DNSP.IG_Face> SecondaryPart_IGES, List<Plane3D> PrimaryPart_BoundPlane, List<Plane3D> SecondaryPart_BoundPlane)
        {
            //List<Plane3D> ListNearestPlanes = new List<Plane3D>();
            //ListNearestPlanes = matlib.GetNearestPlanesBetweenTwoBoundingBox(PrimaryPart_BoundPlane, SecondaryPart_BoundPlane);


            //Find the faces between CB abd SR, which have the minimum distance between them.
            //////double Temp_Value = 10000;

            IGES3DNSP.IG_Face MFace1 = new IGES3DNSP.IG_Face();
            IGES3DNSP.IG_Face MFace2 = new IGES3DNSP.IG_Face();


            List<IGES3DNSP.IG_Face> MatchingFace1 = new List<IGES3DNSP.IG_Face>();
            List<IGES3DNSP.IG_Face> MatchingFace2 = new List<IGES3DNSP.IG_Face>();

            List<Tuple<IGES3DNSP.IG_Face, IGES3DNSP.IG_Face>> Matched_FaceList = new List<Tuple<IGES3DNSP.IG_Face, IGES3DNSP.IG_Face>>();

            ///List<PairedFaces> FacePaires = new List<PairedFaces>();

            foreach (IGES3DNSP.IG_Face FaceCB in PrimaryPart_IGES)
            {
                foreach (IGES3DNSP.IG_Face FaceSR in SecondaryPart_IGES)
                {
                    double iDistance = Math.Abs(matlib.FindDistanceBWPlanes(new Plane3D() { PlaneOrigin = FaceCB.PlaneSurface.PointONSurface, NormalVector = FaceCB.PlaneSurface.NormalDirection },
                                new Plane3D() { PlaneOrigin = FaceSR.PlaneSurface.PointONSurface, NormalVector = FaceSR.PlaneSurface.NormalDirection }));

                    bool VectorParallel = matlib.AreVectorsParallel(FaceCB.PlaneSurface.NormalDirection, FaceSR.PlaneSurface.NormalDirection);

                    //////if ((iDistance < Temp_Value) && VectorParallel)
                    //////{
                    //////    Temp_Value = iDistance;
                    //////    Console.WriteLine(Temp_Value);
                    //////    //MFace1 = new IGES3DNSP.IG_Face;
                    //////    MFace1 = FaceCB;
                    //////    MFace2 = FaceSR;
                    //////}

                    if (Math.Abs(iDistance) <= 1 && VectorParallel) //  iDistance == Temp_Value ||// then we have reached the possible intersecting faces
                    //if (Math.Abs(iDistance) < 2 && VectorParallel) //  iDistance == Temp_Value ||// then we have reached the possible intersecting faces
                    {
                        Console.WriteLine(iDistance);

                        Matched_FaceList.Add(Tuple.Create(FaceCB, FaceSR));

                        //MatchingFace1.Add(FaceCB);
                        //MatchingFace2.Add(FaceSR);

                        //FacePaires.Add(new PairedFaces() { Distance = Math.Abs(iDistance) , FacePair = new List<IGES3DNSP.IG_Face>() { FaceCB, FaceSR } });
                    }
                }
            }

            //double nearestFaceVal = 1000000;
            IGES3DNSP.IG_Face nearestFace2 = new IGES3DNSP.IG_Face();

            //Find Mating surface for each PrimaryFaceSet

            List<IGPro_MatchedFaces> MatchedFaceList = new List<IGPro_MatchedFaces>();

            List<Point3D> intPoints = new List<Point3D>();

            Dictionary<IGES3DNSP.IG_Face, IGES3DNSP.IG_Face> FacePairs = new Dictionary<IGES3DNSP.IG_Face, IGES3DNSP.IG_Face>();

            foreach (Tuple<IGES3DNSP.IG_Face, IGES3DNSP.IG_Face> ThisPair in Matched_FaceList)
            {
                //foreach (IGES3DNSP.IG_Face InnerFace in MatchingFace2)
                //{
                intPoints = new List<Point3D>();


                intPoints = GetIntersectionOfPolygons(ThisPair.Item1, ThisPair.Item2);

                if (intPoints.Count > 0)
                {
                    IGPro_MatchedFaces ThisMatch = new IGPro_MatchedFaces();

                    ThisMatch.primaryPartFace = ThisPair.Item1;
                    ThisMatch.secondaryPartFace = ThisPair.Item2;
                    ThisMatch.IntersectedPolygon = intPoints;

                    //printButtingFacePts(ThisPair, oTempPart, objHybridBodyAutomation);

                    MatchedFaceList.Add(ThisMatch);

                }
                //}
            }

            //}

            MatchedFaceList = (MatchedFaceList.GroupBy(x => x.secondaryPartFace.Face_ID)
                                                    .Select(g => g.First())).ToList();



            return MatchedFaceList;
        }

        /// <summary>
        /// Determines the direction and origin point corresponding to the maximum distance between parallel planes from
        /// a given set of bounding planes.
        /// </summary>
        /// <remarks>This method groups the input planes into three distinct sets based on their normal
        /// vectors being parallel. It calculates the distance between the closest pair of planes in each set and
        /// identifies the set with the maximum distance. The direction vector is computed based on the plane origins
        /// and their projections.</remarks>
        /// <param name="BoundingPlanes">A list of <see cref="Plane3D"/> objects representing the bounding planes. The planes are expected to include
        /// at least three distinct sets of parallel planes, each with at least two planes.</param>
        /// <returns>A <see cref="Tuple{Point3D, Vector3D}"/> where the first item is the origin point of the plane in the
        /// direction of the maximum distance, and the second item is the vector representing that direction.</returns>
        public static Tuple<Point3D, Vector3D> GetMaxDir_MaxPoints(List<Plane3D> BoundingPlanes)
        {
            //FirstDirection
            List<Plane3D> FirstSetofPlanes = BoundingPlanes.Where(x => matlib.AreVectorsParallel(x.NormalVector, BoundingPlanes[0].NormalVector) == true).ToList();

            List<Plane3D> RemainingPlanes = BoundingPlanes.Except(FirstSetofPlanes).ToList();

            //SecondDirection
            List<Plane3D> SecondSetofPlanes = RemainingPlanes.Where(x => matlib.AreVectorsParallel(x.NormalVector, RemainingPlanes[0].NormalVector) == true).ToList();

            RemainingPlanes = RemainingPlanes.Except(SecondSetofPlanes).ToList();

            //ThidDirection
            List<Plane3D> ThirdSetofPlanes = RemainingPlanes.Where(x => matlib.AreVectorsParallel(x.NormalVector, RemainingPlanes[0].NormalVector) == true).ToList();

            double FirstDistance = Mathlib.matlib.DistanceBetweenPoints(FirstSetofPlanes[0].PlaneOrigin, matlib.ProjectPointOnPlane(FirstSetofPlanes[0].PlaneOrigin, FirstSetofPlanes[1]));

            double SecondDistance = Mathlib.matlib.DistanceBetweenPoints(SecondSetofPlanes[0].PlaneOrigin, matlib.ProjectPointOnPlane(SecondSetofPlanes[0].PlaneOrigin, SecondSetofPlanes[1]));

            double ThirdDistance = Mathlib.matlib.DistanceBetweenPoints(ThirdSetofPlanes[0].PlaneOrigin, matlib.ProjectPointOnPlane(ThirdSetofPlanes[0].PlaneOrigin, ThirdSetofPlanes[1]));

            if (FirstDistance > SecondDistance && FirstDistance > ThirdDistance)
            {
                Vector3D Direction = Point3D.Subtract(FirstSetofPlanes[1].PlaneOrigin, matlib.ProjectPointOnPlane(FirstSetofPlanes[1].PlaneOrigin, FirstSetofPlanes[0]));

                return Tuple.Create(FirstSetofPlanes[0].PlaneOrigin, Direction);
            }
            else if (SecondDistance > FirstDistance && SecondDistance > ThirdDistance)
            {
                Vector3D Direction = Point3D.Subtract(SecondSetofPlanes[1].PlaneOrigin, matlib.ProjectPointOnPlane(SecondSetofPlanes[1].PlaneOrigin, SecondSetofPlanes[0]));

                return Tuple.Create(SecondSetofPlanes[0].PlaneOrigin, Direction);
            }
            else
            {
                Vector3D Direction = Point3D.Subtract(ThirdSetofPlanes[1].PlaneOrigin, matlib.ProjectPointOnPlane(ThirdSetofPlanes[1].PlaneOrigin, ThirdSetofPlanes[0]));

                return Tuple.Create(ThirdSetofPlanes[0].PlaneOrigin, Direction);
            }

        }

        /// <summary>
        /// Computes the intersection of two 3D polygons represented by the specified IGES faces.
        /// </summary>
        /// <remarks>This method calculates the intersection of two polygons by determining the points of
        /// one polygon  that lie inside the other, as well as the intersection points of their edges. The resulting
        /// intersection  polygon is represented as a list of distinct 3D points.</remarks>
        /// <param name="Face1">The first IGES face, representing the first polygon.</param>
        /// <param name="Face2">The second IGES face, representing the second polygon.</param>
        /// <returns>A list of <see cref="Point3D"/> objects representing the vertices of the intersection polygon.  The list
        /// will be empty if there is no intersection.</returns>
        public static List<Point3D> GetIntersectionOfPolygons(IGES3DNSP.IG_Face Face1, IGES3DNSP.IG_Face Face2)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetIntersectionOfPolygons :: Start");
            List<Point3D> clippedCorners = new List<Point3D>();

            //Add  the corners of poly1 which are inside poly2       

            List<Point3D> Poly_List1 = new List<Point3D>();

            Poly_List1 = GetPolygonFromIGESFace(Face1);

            Poly_List1 = Poly_List1.Distinct().ToList();



            List<Point3D> Poly_List2 = new List<Point3D>();

            Poly_List2 = GetPolygonFromIGESFace(Face2);

            Poly_List2 = Poly_List2.Distinct().ToList();

            foreach (Point3D ThisPoint in Poly_List1)
            {
                //Project Point in PolyList1

                Point3D ProjectedPoint = matlib.ProjectPointOnPlane(ThisPoint, new Plane3D() { PlaneOrigin = Face2.PlaneSurface.PointONSurface, NormalVector = Face2.PlaneSurface.NormalDirection });

                //CreatePointInCatia(new List<Point3D>() { ProjectedPoint });

                if (matlib.IsPointInsidePoly3D_ForHNF(ProjectedPoint, Poly_List2, Face2.PlaneSurface.NormalDirection))
                {
                    AddPoints(clippedCorners, new List<Point3D>() { ThisPoint });

                    //if (K ==1)  CATIAFunctions.CreatePoint(oTempPart, "COORDINATES", objHybridBodyAutomation, ThisPoint);
                }
            }


            //Add the corners of poly2 which are inside poly1

            foreach (Point3D ThisPoint in Poly_List2)
            {
                //Project Point in PolyList1

                Point3D ProjectedPoint = matlib.ProjectPointOnPlane(ThisPoint, new Plane3D() { PlaneOrigin = Face1.PlaneSurface.PointONSurface, NormalVector = Face1.PlaneSurface.NormalDirection });

                //CreatePointInCatia(new List<Point3D>() { ProjectedPoint });

                if (matlib.IsPointInsidePoly3D_ForHNF(ProjectedPoint, Poly_List1, Face1.PlaneSurface.NormalDirection))
                {
                    AddPoints(clippedCorners, new List<Point3D>() { ProjectedPoint });

                    //CATIAFunctions.CreatePoint(oTempPart, "COORDINATES", objHybridBodyAutomation, ThisPoint);
                }
            }


            //Intersected Profiles

            AddPoints(clippedCorners, GetIntersectionPoints(Poly_List1, Face1.PlaneSurface.NormalDirection, Poly_List2, Face2.PlaneSurface.NormalDirection));

            //////////return new ConvexPolygon2D(OrderClockwise(clippedCorners));

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetIntersectionOfPolygons :: End");
            return (clippedCorners);
        }

        /// <summary>
        /// Calculates the intersection points between two 3D polygons.
        /// </summary>
        /// <remarks>This method determines the intersection points by evaluating the edges of the two
        /// polygons.  Each edge of the first polygon is checked against each edge of the second polygon to find
        /// intersections. Only intersection points that lie within both polygons are included in the result.</remarks>
        /// <param name="FirstPolygon">The list of 3D points defining the first polygon. The points should be ordered to form a closed loop.</param>
        /// <param name="NormalVec_Poly1">The normal vector of the plane containing the first polygon.</param>
        /// <param name="SecondPolygon">The list of 3D points defining the second polygon. The points should be ordered to form a closed loop.</param>
        /// <param name="NormalVec_Poly2">The normal vector of the plane containing the second polygon.</param>
        /// <returns>A list of <see cref="Point3D"/> objects representing the intersection points between the two polygons. The
        /// list will be empty if no intersections are found.</returns>
        public static List<Point3D> GetIntersectionPoints(List<Point3D> FirstPolygon, Vector3D NormalVec_Poly1, List<Point3D> SecondPolygon, Vector3D NormalVec_Poly2)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetIntersectionPoints :: Start");
            List<Point3D> intersectionPoints = new List<Point3D>();

            for (int First_I = 0, Next_I = 1; First_I < FirstPolygon.Count; First_I++, Next_I = (First_I + 1 == FirstPolygon.Count) ? 0 : First_I + 1)
            {

                for (int Second_J = 0; Second_J < SecondPolygon.Count(); Second_J++)
                {

                    int Next_J = (Second_J + 1 == SecondPolygon.Count) ? 0 : Second_J + 1;


                    if (matlib.AretheVectorsInSameDirection(Point3D.Subtract(FirstPolygon[First_I], FirstPolygon[Next_I]), Point3D.Subtract(SecondPolygon[Second_J], SecondPolygon[Next_J])) == false)
                    {
                        //List<Point3D> ip = LineIntersection(FirstPolygon[First_I], FirstPolygon[Next_I], SecondPolygon[Second_J], SecondPolygon[Next_J]);

                        Point3D resultSegmentPoint1 = new Point3D(); Point3D resultSegmentPoint2 = new Point3D();

                        bool Result = matlib.CalculateLineLineIntersection(FirstPolygon[First_I], FirstPolygon[Next_I], SecondPolygon[Second_J], SecondPolygon[Next_J], out resultSegmentPoint1, out resultSegmentPoint2);

                        if (Result && Math.Abs(Mathlib.matlib.DistanceBetweenPoints(resultSegmentPoint1, resultSegmentPoint2)) < 0.5)
                        {

                            //CreatePointInCatia(ip);

                            bool ResultA1 = matlib.IsPointInsidePoly3D_ForHNF(resultSegmentPoint1, FirstPolygon, NormalVec_Poly1);

                            bool ResultA2 = Mathlib.matlib.IsPointOnLine(resultSegmentPoint1, FirstPolygon[First_I], FirstPolygon[Next_I]);


                            bool ResultB1 = matlib.IsPointInsidePoly3D_ForHNF(resultSegmentPoint2, SecondPolygon, NormalVec_Poly2);

                            bool ResultB2 = Mathlib.matlib.IsPointOnLine(resultSegmentPoint2, SecondPolygon[Second_J], SecondPolygon[Next_J]);


                            if ((ResultA1 && ResultA2) && (ResultB1 && ResultB2))
                            {
                                intersectionPoints.Add(resultSegmentPoint1);
                            }

                        }
                    }
                }
            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetIntersectionPoints :: End");
            return intersectionPoints;
        }

        /// <summary>
        /// Extracts a polygonal representation of the outer loop of the specified IGES face.
        /// </summary>
        /// <remarks>This method processes the edges of the outer loop of the given IGES face and converts
        /// them into a polygonal representation. Supported edge types include lines, B-splines, and circular arcs. For
        /// B-spline edges, the construction points are used to approximate the curve. The method ensures that the
        /// vertices are connected in the correct order to form a continuous polygon.  The method assumes that the input
        /// face has a valid outer loop and that the edges are well-defined. If the edges are not connected within a
        /// small tolerance, the method attempts to handle the discontinuities by matching endpoints within a threshold
        /// distance.</remarks>
        /// <param name="IG_Face">The IGES face from which the polygon is to be extracted. The face must contain an outer loop with edges that
        /// define its boundary.</param>
        /// <returns>A list of <see cref="Point3D"/> objects representing the vertices of the polygon. The vertices are ordered
        /// sequentially to form a closed loop. The list will be empty if the face contains no valid edges.</returns>
        public static List<Point3D> GetPolygonFromIGESFace(IGES3DNSP.IG_Face IG_Face) // To treat the edge in its native formate (Line, Nurb, circular and so on)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetPolygonFromIGESFace :: Start");
            List<Point3D> ThisPolygon = new List<Point3D>();

            List<IGES3DNSP.IG_Edge> AddedEdges = new List<IGES3DNSP.IG_Edge>();

            foreach (IGES3DNSP.IG_Edge ThisEdge in IG_Face.Outer_Loop_List[0].Edge_List)
            {
                IGES3DNSP.IG_Edge Selec_Start = null; IGES3DNSP.IG_Edge Selec_End = null;

                if (ThisPolygon.Count != 0)
                {
                    List<IGES3DNSP.IG_Edge> RemainingEdges = IG_Face.Outer_Loop_List[0].Edge_List.Except(AddedEdges).ToList();

                    foreach (IGES3DNSP.IG_Edge RemainEdge in RemainingEdges)
                    {
                        if (Math.Abs(matlib.DistanceBetweenPoints(RemainEdge.Start_Vertex, ThisPolygon.Last())) <= 0.001)
                        //if (matlib.TruncateNumbers(RemainEdge.Start_Vertex.X, 3) == matlib.TruncateNumbers(ThisPolygon.Last().X, 3) && matlib.TruncateNumbers(RemainEdge.Start_Vertex.Y, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Y, 3) && matlib.TruncateNumbers(RemainEdge.Start_Vertex.Z, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Z, 3))
                        {
                            Selec_Start = RemainEdge;
                            break;
                        }
                        else if (Math.Abs(matlib.DistanceBetweenPoints(RemainEdge.End_Vertex, ThisPolygon.Last())) <= 0.001)
                        //else if (matlib.TruncateNumbers(RemainEdge.End_Vertex.X, 3) == matlib.TruncateNumbers(ThisPolygon.Last().X, 3) && matlib.TruncateNumbers(RemainEdge.End_Vertex.Y, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Y, 3) && matlib.TruncateNumbers(RemainEdge.End_Vertex.Z, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Z, 3))
                        {
                            Selec_End = RemainEdge;
                            break;
                        }
                    }

                    if (Selec_Start != null)
                    {
                        if (Selec_Start.Edge_Type == IGES3DNSP.IG_EdgeType.Line)
                        {
                            //ThisPolygon.Add(IG_Edge.Start_Vertex);
                            ThisPolygon.Add(Selec_Start.End_Vertex);
                        }
                        else if (Selec_Start.Edge_Type == IGES3DNSP.IG_EdgeType.BSpline)
                        {
                            if (Selec_Start.NURB_Cuve.ConstructionPoints.Count > 0)
                            {
                                //if (matlib.TruncateNumbers(Selec_Start.NURB_Cuve.ConstructionPoints.First().X, 3) == matlib.TruncateNumbers(ThisPolygon.Last().X, 3) && matlib.TruncateNumbers(Selec_Start.NURB_Cuve.ConstructionPoints.First().Y, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Y, 3) && matlib.TruncateNumbers(Selec_Start.NURB_Cuve.ConstructionPoints.First().Z, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Z, 3))
                                if (Math.Abs(matlib.DistanceBetweenPoints(Selec_Start.NURB_Cuve.ConstructionPoints.First(), ThisPolygon.Last())) <= 0.001)
                                {
                                    foreach (Point3D ThisPoint in Selec_Start.NURB_Cuve.ConstructionPoints)
                                    {
                                        if (!((Double.IsNaN(ThisPoint.X)) || (Double.IsNaN(ThisPoint.Y)) || (Double.IsNaN(ThisPoint.Z))))
                                            ThisPolygon.Add(ThisPoint);
                                    }
                                }
                                else
                                {
                                    for (int i = Selec_Start.NURB_Cuve.ConstructionPoints.Count - 1; i >= 0; i--)
                                    {
                                        if (!((Double.IsNaN(Selec_Start.NURB_Cuve.ConstructionPoints[i].X)) || (Double.IsNaN(Selec_Start.NURB_Cuve.ConstructionPoints[i].Y)) || (Double.IsNaN(Selec_Start.NURB_Cuve.ConstructionPoints[i].Z))))
                                            ThisPolygon.Add(Selec_Start.NURB_Cuve.ConstructionPoints[i]);
                                    }
                                }
                            }
                            else // Just add the start and end vertex as the curve may be two small
                            {
                                ThisPolygon.Add(Selec_Start.End_Vertex);
                            }

                        }
                        else if (Selec_Start.Edge_Type == IGES3DNSP.IG_EdgeType.CircularArc)
                        {
                            //ThisPolygon.Add(IG_Edge.Start_Vertex);
                            ThisPolygon.Add(Selec_Start.End_Vertex);
                        }

                        AddedEdges.Add(Selec_Start);
                    }

                    if (Selec_End != null)
                    {
                        if (Selec_End.Edge_Type == IGES3DNSP.IG_EdgeType.Line)
                        {
                            //ThisPolygon.Add(IG_Edge.End_Vertex);
                            ThisPolygon.Add(Selec_End.Start_Vertex);
                        }
                        else if (Selec_End.Edge_Type == IGES3DNSP.IG_EdgeType.BSpline)
                        {
                            if (Selec_End.NURB_Cuve.ConstructionPoints.Count > 0)
                            {
                                //if (matlib.TruncateNumbers(Selec_End.NURB_Cuve.ConstructionPoints.First().X, 3) == matlib.TruncateNumbers(ThisPolygon.Last().X, 3) && matlib.TruncateNumbers(Selec_End.NURB_Cuve.ConstructionPoints.First().Y, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Y, 3) && matlib.TruncateNumbers(Selec_End.NURB_Cuve.ConstructionPoints.First().Z, 3) == matlib.TruncateNumbers(ThisPolygon.Last().Z, 3))
                                if (Math.Abs(matlib.DistanceBetweenPoints(Selec_End.NURB_Cuve.ConstructionPoints.First(), ThisPolygon.Last())) <= 0.001)
                                {
                                    foreach (Point3D ThisPoint in Selec_End.NURB_Cuve.ConstructionPoints)
                                    {
                                        if (!((Double.IsNaN(ThisPoint.X)) || (Double.IsNaN(ThisPoint.Y)) || (Double.IsNaN(ThisPoint.Z))))
                                            ThisPolygon.Add(ThisPoint);
                                    }
                                }
                                else
                                {
                                    for (int i = Selec_End.NURB_Cuve.ConstructionPoints.Count - 1; i >= 0; i--)
                                    {
                                        if (!((Double.IsNaN(Selec_End.NURB_Cuve.ConstructionPoints[i].X)) || (Double.IsNaN(Selec_End.NURB_Cuve.ConstructionPoints[i].Y)) || (Double.IsNaN(Selec_End.NURB_Cuve.ConstructionPoints[i].Z))))
                                            ThisPolygon.Add(Selec_End.NURB_Cuve.ConstructionPoints[i]);
                                    }
                                }
                            }
                            else // Just add the start and end vertex as the curve may be two small
                            {
                                ThisPolygon.Add(Selec_End.Start_Vertex);
                            }
                        }
                        else if (Selec_End.Edge_Type == IGES3DNSP.IG_EdgeType.CircularArc)
                        {
                            //ThisPolygon.Add(IG_Edge.End_Vertex);
                            ThisPolygon.Add(Selec_End.Start_Vertex);
                        }

                        AddedEdges.Add(Selec_End);
                    }
                }
                else
                {
                    if (ThisEdge.Edge_Type == IGES3DNSP.IG_EdgeType.Line)
                    {
                        ThisPolygon.Add(ThisEdge.Start_Vertex);
                        ThisPolygon.Add(ThisEdge.End_Vertex);
                    }
                    else if (ThisEdge.Edge_Type == IGES3DNSP.IG_EdgeType.BSpline)
                    {
                        foreach (Point3D ThisPoint in ThisEdge.NURB_Cuve.ConstructionPoints)
                        {
                            ThisPolygon.Add(ThisPoint);
                        }
                    }
                    else if (ThisEdge.Edge_Type == IGES3DNSP.IG_EdgeType.CircularArc)
                    {
                        ThisPolygon.Add(ThisEdge.Start_Vertex);
                        ThisPolygon.Add(ThisEdge.End_Vertex);
                    }

                    AddedEdges.Add(ThisEdge);
                }
            }

            //ThisPolygon = OrderClockwise(ThisPolygon);

            //ThisPolygon = ThisPolygon.Distinct(new DistanceComparer()).ToList();

            //var ThisPolygon_1 = ThisPolygon.GroupBy( m => new DistanceComparer()).ToList();

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: GetPolygonFromIGESFace :: End");
            return ThisPolygon;
        }

        /// <summary>
        /// Orders a list of 3D points in a clockwise direction around their centroid.
        /// </summary>
        /// <remarks>The method calculates the centroid of the input points and orders them based on their
        /// angular position relative to the centroid. Points are sorted using the <see cref="Math.Atan2"/> function,
        /// which determines the angle of each point relative to the centroid.</remarks>
        /// <param name="points">The list of <see cref="Point3D"/> objects to be ordered. The list must contain at least one point.</param>
        /// <returns>A new list of <see cref="Point3D"/> objects ordered in a clockwise direction around the centroid of the
        /// input points.</returns>
        public static List<Point3D> OrderClockwise(List<Point3D> points)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: OrderClockwise :: Start");
            double mX = 0;
            double my = 0;
            foreach (Point3D p in points)
            {
                mX += p.X;
                my += p.Y;
            }
            mX /= points.Count;
            my /= points.Count;

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: OrderClockwise :: End");
            return points.OrderBy(v => Math.Atan2(v.Y - my, v.X - mX)).ToList();
        }

        /// <summary>
        /// Determines whether a given point lies inside a polygon defined by a list of vertices.
        /// </summary>
        /// <remarks>The method uses the ray-casting algorithm to determine if the point is inside the
        /// polygon.  The polygon is assumed to be a simple polygon (non-self-intersecting). If the polygon is not
        /// simple, the behavior is undefined.</remarks>
        /// <param name="test">The point to test for inclusion within the polygon.</param>
        /// <param name="Poly_List">A list of vertices defining the polygon. The vertices should be ordered either clockwise or
        /// counterclockwise.</param>
        /// <returns><see langword="true"/> if the point lies inside the polygon; otherwise, <see langword="false"/>.</returns>
        // taken from https://wrf.ecse.rpi.edu//Research/Short_Notes/pnpoly.html
        public static bool IsPointInsidePoly(Point3D test, List<Point3D> Poly_List)
        {
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: IsPointInsidePoly :: Start");
            int i;
            int j;
            bool result = false;
            for (i = 0, j = Poly_List.Count() - 1; i < Poly_List.Count(); j = i++)
            {
                if ((Poly_List[i].Y > test.Y) != (Poly_List[j].Y > test.Y) &&
                    (test.X < (Poly_List[j].X - Poly_List[i].X) * (test.Y - Poly_List[i].Y) / (Poly_List[j].Y - Poly_List[i].Y) + Poly_List[i].X))
                {
                    result = !result;
                }
            }
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: IsPointInsidePoly :: End");
            return result;


        }

        /// <summary>
        /// Determines whether a specified point lies inside a polygon defined by a list of vertices.
        /// </summary>
        /// <remarks>The method assumes that the polygon is defined in a 2D plane, even though the points
        /// are represented in 3D space. The z-coordinate of the points is ignored during the calculation. The polygon
        /// should be closed, meaning the last vertex in the list should connect back to the first vertex.</remarks>
        /// <param name="test">The point to test for inclusion within the polygon.</param>
        /// <param name="Poly_List">A list of <see cref="Point3D"/> objects representing the vertices of the polygon.  The vertices should be
        /// ordered sequentially to define the polygon's edges.</param>
        /// <returns><see langword="true"/> if the specified point lies inside the polygon; otherwise, <see langword="false"/>.</returns>
        public static bool IsPointInsidePolygon(Point3D test, List<Point3D> Poly_List)
        {
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: IsPointInsidePolygon :: Start");

            for (int i = 0; i < Poly_List.Count - 1; i++)
            {

                double Length = Point3D.Subtract(Poly_List[i], Poly_List[i + 1]).Length;

                double diagnal1 = Point3D.Subtract(Poly_List[i], test).Length;

                double diagnal2 = Point3D.Subtract(Poly_List[i + 1], test).Length;

                if (!((Length * Length) + (diagnal1 * diagnal1) - (diagnal2 * diagnal2) >= 0 && (Length * Length) + (diagnal2 * diagnal2) - (diagnal1 * diagnal1) >= 0))
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: IsPointInsidePolygon :: End");
            return false;
        }

        /// <summary>
        /// Adds unique 3D points from the specified collection to the existing pool of points.
        /// </summary>
        /// <remarks>A point is considered unique if its X, Y, and Z coordinates do not match those of any
        /// point already in the <paramref name="pool"/>.</remarks>
        /// <param name="pool">The collection of existing 3D points. Points from <paramref name="newpoints"/> that are not already in this
        /// collection will be added.</param>
        /// <param name="newpoints">The collection of 3D points to be added to the <paramref name="pool"/>. Only points not already present in
        /// the <paramref name="pool"/> will be added.</param>
        private static void AddPoints(List<Point3D> pool, List<Point3D> newpoints)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: AddPoints :: Start");
            foreach (Point3D np in newpoints)
            {
                bool found = false;
                foreach (Point3D p in pool)
                {
                    if (p.X.Equals(np.X) && p.Y.Equals(np.Y) && p.Z.Equals(np.Z))
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    pool.Add(np);

                    //CreatePointInCatia(new List<Point3D>() { np });
                }

            }

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: AddPoints :: End");
        }

        /// <summary>
        /// Calculates the geometric center (centroid) of a 3D face represented by the specified IGES entity.
        /// </summary>
        /// <remarks>This method computes the centroid of a 3D face by analyzing its edges, which may
        /// include B-splines, lines, circular arcs, and conic arcs. The method processes the control points and
        /// geometric properties of the edges to calculate the centroid based on the face's area and vertex positions. 
        /// The input IGES entity must be well-formed, with valid edge definitions and associated control points. If the
        /// entity contains unsupported or malformed edges, the behavior of this method is undefined.</remarks>
        /// <param name="IGESEntities">The IGES face entity containing the geometric data used to compute the centroid. This entity must include
        /// outer loop edges and their associated control points.</param>
        /// <returns>A <see cref="Point3D"/> representing the centroid of the face. The returned point contains the X, Y, and Z
        /// coordinates of the centroid.</returns>
        public static Point3D FindingCentre(IGES3DNSP.IG_Face IGESEntities)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: FindingCentre :: Start");

            //double[] func1 = new double[IGESEntities.Count];
            //int[] m = new int[IGESEntities.Count];
            int j, i, k;
            double area = 0, sum = 0, area1, a, xc, yc, zc, sum1 = 0, sum2 = 0, b, c;
            double area2 = 0, sum22 = 0, area12, a2, c2, sum222 = 0;
            Point3D ReturnPoint = new Point3D();

            INFITF.Application CATIAApplicationHandle;
            CATIAApplicationHandle = (INFITF.Application)Marshal.GetActiveObject("CATIA.Application");
            PartDocument objPartDoc = (PartDocument)CATIAApplicationHandle.ActiveDocument;
            //for (Ig = 0; Ig < IGESEntities.Count; Ig++)
            //{
            //func1[Ig] = 0;
            int m = IGESEntities.Outer_Loop_List[0].Edge_List.Count;
            double[] Cx = new double[5];
            double[] Cy = new double[5];
            double sss = 0;
            double[] point_x = new double[1000];
            double[] point_y = new double[1000];
            double[] point_z = new double[1000];

            double[] points_v1x = new double[1000];
            double[] points_v1y = new double[1000];
            double[] points_v1z = new double[1000];



            double[] points_v2x = new double[1000];
            double[] points_v2y = new double[1000];
            double[] points_v2z = new double[1000];

            double[] points_vv1x = new double[1000];
            double[] points_vv1y = new double[1000];
            double[] points_vv1z = new double[1000];

            double[] points_vv2x = new double[1000];
            double[] points_vv2y = new double[1000];
            double[] points_vv2z = new double[1000];

            double[] points_xxx = new double[1000];
            double[] points_yyy = new double[1000];
            double[] points_zzz = new double[1000];
            double aaa;
            double zzzz;
            int s = 0;

            Point3D CntrlPoint = new Point3D();


            List<Point3D> ProCntrlPoints = new List<Point3D>();
            for (j = 0; j < m; j++)
            {

                if (IGESEntities.Outer_Loop_List[0].Edge_List[j].Edge_Type == IG_EdgeType.BSpline)
                {
                    //B_Spline Temp = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve;
                    //ProCntrlPoints = Temp.ConstructionPoints;
                    //#region Nurb Basis Function

                    //int UpperIndex = IGESEntities[Ig].Outer_Loop_List[0].Edge_List[j].NURB_Cuve.UpperIndex;
                    //int Degree = IGESEntities[Ig].Outer_Loop_List[0].Edge_List[j].NURB_Cuve.Degree;
                    //List<Point3D> ctrlPts = IGESEntities[Ig].Outer_Loop_List[0].Edge_List[j].NURB_Cuve.ControlPoints;
                    List<Point3D> ConstructionPtList = new List<Point3D>();
                    int UpperIndex = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve.UpperIndex; //(K)
                    int Degree = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve.Degree; //M
                    int parameter = 1 + UpperIndex - Degree; //N= 1+K-M
                    int numOfKnots = parameter + 2 * Degree;
                    List<double> knots = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve.KnotVector;
                    List<Point3D> ctrlPts = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve.ControlPoints;
                    double stParam = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve.startParam;
                    double edParam = IGESEntities.Outer_Loop_List[0].Edge_List[j].NURB_Cuve.endParam;
                    double[,] N = new double[UpperIndex + Degree + 1, 6]; //Basis function

                    double A, B, C, D, E, F;
                    double increment = Math.Abs((edParam - stParam) / 100);
                    for (double u = stParam; u < edParam; u = u + (edParam) / 30)
                    {
                        CntrlPoint = new Point3D();
                        for (i = 0; i <= (UpperIndex); i++)
                        {
                            if (knots[i] <= u && u < knots[i + 1])
                            {
                                N[i, 0] = 1;//edParam;// 1;

                            }
                            else
                                N[i, 0] = 0;
                        }

                        for (k = 1; k <= Degree; k++)
                        {
                            for (i = 0; i <= (UpperIndex); i++)
                            {
                                A = u - knots[i];
                                B = knots[i + k] - knots[i];
                                C = knots[i + k + 1] - u;
                                D = knots[i + k + 1] - knots[i + 1];

                                if (B == 0 || A == 0)
                                    E = 0;
                                else
                                    E = A / B;

                                if (C == 0 || D == 0)
                                    F = 0;
                                else
                                    F = C / D;

                                N[i, k] = E * N[i, k - 1] + F * N[i + 1, k - 1];
                            }
                        }



                        double x = 0;
                        double y = 0;
                        double z = 0;
                        for (i = 0; i <= UpperIndex; i++)
                        {
                            x = x + N[i, Degree];// * ctrlPtsX[i];
                            y = y + N[i, Degree];// * ctrlPtsY[i];
                            z = z + N[i, Degree];// * ctrlPtsZ[i];
                        }


                        double nx = 0;
                        double ny = 0;
                        double nz = 0;
                        for (i = 0; i <= UpperIndex; i++)
                        {
                            nx = nx + ((N[i, Degree] / x) * ctrlPts[i].X);
                            ny = ny + ((N[i, Degree] / y) * ctrlPts[i].Y);
                            nz = nz + ((N[i, Degree] / z) * ctrlPts[i].Z);
                        }
                        CntrlPoint.X = nx;
                        CntrlPoint.Y = ny;
                        CntrlPoint.Z = nz;



                        ProCntrlPoints.Add(CntrlPoint);


                    }
                }

                else if (IGESEntities.Outer_Loop_List[0].Edge_List[j].Edge_Type == IG_EdgeType.Line)

                {

                    CntrlPoint = new Point3D();



                    CntrlPoint.X = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.X;
                    CntrlPoint.Y = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.Y;
                    CntrlPoint.Z = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.Z;

                    if (!ProCntrlPoints.Contains(CntrlPoint))
                    {
                        ProCntrlPoints.Add(CntrlPoint);
                    }
                    else
                    {
                        CntrlPoint.X = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.X;
                        CntrlPoint.Y = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.Y;
                        CntrlPoint.Z = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.Z;
                        ProCntrlPoints.Add(CntrlPoint);

                    }



                }
                else if (IGESEntities.Outer_Loop_List[0].Edge_List[j].Edge_Type == IG_EdgeType.CircularArc)

                {

                    points_v1x[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.X;
                    points_v1y[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.Y;
                    points_v1z[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.Z;
                    //s++;
                    points_v2x[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.X;
                    points_v2y[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.Y;
                    points_v2z[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.Z;
                    //s++;
                    point_x[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Center_Vertex.X;
                    point_y[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Center_Vertex.Y;
                    point_z[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Center_Vertex.Z;
                    double t = point_x[s];
                    double q = point_y[s];
                    double r = point_z[s];



                    //Vector3D z = new Vector3D(points_v1x[s] - point_x[s], points_v1y[s] - point_y[s], 0);
                    // Vector3D zz = new Vector3D(points_v2x[s] - point_x[s], points_v2y[s] - point_y[s], 0);
                    Vector3D z = new Vector3D(points_v1x[s] - point_x[s], points_v1y[s] - point_y[s], points_v1z[s] - point_z[s]);

                    Vector3D zz = new Vector3D(points_v2x[s] - point_x[s], points_v2y[s] - point_y[s], points_v2z[s] - point_z[s]);
                    ///////////////////////////////////////////////////////////////////////////////////////////






                    Vector3D ssss = Vector3D.CrossProduct(z, zz);
                    Vector3D ttt1 = Vector3D.CrossProduct(ssss, z);
                    Vector3D ttt2 = Vector3D.CrossProduct(ssss, zz);
                    z.Normalize();
                    zz.Normalize();
                    ttt1.Normalize();
                    ttt2.Normalize();
                    if ((point_x[s] > 0 && point_y[s] > 0 && point_z[s] > 0) || (point_x[s] < 0 && point_y[s] > 0 && point_z[s] < 0) || (point_x[s] < 0 && point_y[s] > 0 && point_z[s] > 0))


                    {

                        if (ssss.Z < 0)


                        {
                            aaa = 360 - (Vector3D.AngleBetween(z, zz));
                        }
                        else
                        {
                            aaa = (Vector3D.AngleBetween(z, zz));
                        }
                    }

                    else
                    {
                        if (ssss.Z > 0)
                        {
                            aaa = 360 - (Vector3D.AngleBetween(z, zz));
                        }
                        else
                        {
                            aaa = (Vector3D.AngleBetween(z, zz));
                        }
                    }


                    double radius = IGESEntities.Outer_Loop_List[0].Edge_List[j].Arc_Radius;

                    CntrlPoint = new Point3D();
                    for (sss = 0; sss <= (aaa * 3.145) / 180;)
                    {
                        if (aaa < 180)
                        {
                            CntrlPoint.X = (radius * Math.Cos(sss) * z.X) + (radius * Math.Sin(sss) * ttt1.X) + point_x[s];
                            CntrlPoint.Y = (radius * Math.Cos(sss) * z.Y) + (radius * Math.Sin(sss) * ttt1.Y) + point_y[s];
                            CntrlPoint.Z = (radius * Math.Cos(sss) * z.Z) + (radius * Math.Sin(sss) * ttt1.Z) + point_z[s];
                            //CntrlPoint.Z = r+(((((point_x[s] - CntrlPoint.X) * point_x[s]) - ((CntrlPoint.Y - point_y[s]) * point_y[s])) / point_z[s]) + point_z[s]);
                            ProCntrlPoints.Add(CntrlPoint);

                            sss = sss + ((1 * 3.142) / 180);
                        }
                        else
                        {
                            CntrlPoint.X = (radius * Math.Cos(sss) * zz.X) + (radius * Math.Sin(sss) * ttt2.X) + point_x[s];
                            CntrlPoint.Y = (radius * Math.Cos(sss) * zz.Y) + (radius * Math.Sin(sss) * ttt2.Y) + point_y[s];
                            CntrlPoint.Z = (radius * Math.Cos(sss) * zz.Z) + (radius * Math.Sin(sss) * ttt2.Z) + point_z[s];
                            //CntrlPoint.Z = r+(((((point_x[s] - CntrlPoint.X) * point_x[s]) - ((CntrlPoint.Y - point_y[s]) * point_y[s])) / point_z[s]) + point_z[s]);
                            ProCntrlPoints.Add(CntrlPoint);

                            sss = sss + ((1 * 3.142) / 180);

                        }
                    }
                }
                else if (IGESEntities.Outer_Loop_List[0].Edge_List[j].Edge_Type == IG_EdgeType.conicArc)
                {
                    points_vv1x[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.X;
                    points_vv1y[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.Y;
                    points_vv1z[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Start_Vertex.Z;

                    points_vv2x[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.X;
                    points_vv2y[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.Y;
                    points_vv2z[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].End_Vertex.Z;

                    points_xxx[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Center_Vertex1.X;
                    points_yyy[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Center_Vertex1.Y;
                    points_zzz[s] = IGESEntities.Outer_Loop_List[0].Edge_List[j].Center_Vertex1.Z;



                    double coeff_F = IGESEntities.Outer_Loop_List[0].Edge_List[j].coeffF;
                    double coeff_A = IGESEntities.Outer_Loop_List[0].Edge_List[j].coeffA;
                    double coeff_C = IGESEntities.Outer_Loop_List[0].Edge_List[j].coeffC;

                    double majorRA = Math.Sqrt(-(coeff_F / coeff_A));

                    double minorRB = Math.Sqrt(-(coeff_F / coeff_C));

                    Vector3D zt = new Vector3D(points_vv1x[s] - points_xxx[s], points_vv1y[s] - points_yyy[s], points_vv1z[s] - points_zzz[s]);
                    Vector3D zzt = new Vector3D(points_vv2x[s] - points_xxx[s], points_vv2y[s] - points_yyy[s], points_vv2z[s] - points_zzz[s]);

                    Vector3D vvv = Vector3D.CrossProduct(zt, zzt);

                    Vector3D tt1 = Vector3D.CrossProduct(vvv, zt);
                    Vector3D tt2 = Vector3D.CrossProduct(vvv, zzt);

                    tt1.Normalize();
                    tt2.Normalize();
                    Vector3D maj = tt2 * majorRA;
                    Vector3D min = tt1 * minorRB;
                    maj.Normalize();
                    min.Normalize();

                    zt.Normalize();
                    zzt.Normalize();
                    if (vvv.Z < 0)
                    {
                        zzzz = 360 - (Vector3D.AngleBetween(zt, zzt));
                    }
                    else
                    {
                        zzzz = Vector3D.AngleBetween(zt, zzt);
                    }

                    for (sss = 0; sss <= ((zzzz * 3.145) / 180);)
                    {
                        CntrlPoint = new Point3D();
                        CntrlPoint.X = (majorRA * Math.Cos(sss) * maj.X) + (minorRB * Math.Sin(sss) * min.X) + points_xxx[s];
                        CntrlPoint.Y = (majorRA * Math.Cos(sss) * maj.Y) + (minorRB * Math.Sin(sss) * min.Y) + points_yyy[s];
                        CntrlPoint.Z = (majorRA * Math.Cos(sss) * maj.Z) + (minorRB * Math.Sin(sss) * min.Z) + points_zzz[s];
                        ProCntrlPoints.Add(CntrlPoint);
                        s++;
                        sss = sss + ((1 * 3.142) / 180);

                    }
                }
            }
            /////////////////////////////////////////////////////////////////////////////////////////
            for (int iCnt = 0; iCnt < ProCntrlPoints.Count() - 1; iCnt++)
            {
                area = ((ProCntrlPoints[iCnt].X * ProCntrlPoints[iCnt + 1].Y) - (ProCntrlPoints[iCnt + 1].X * ProCntrlPoints[iCnt].Y));
                sum = sum + area;
            }
            a = (ProCntrlPoints[ProCntrlPoints.Count - 1].X * ProCntrlPoints[0].Y) - (ProCntrlPoints[0].X * ProCntrlPoints[ProCntrlPoints.Count - 1].Y);
            area1 = (sum + a) / 2;

            for (int JCnt = 0; JCnt < ProCntrlPoints.Count - 1; JCnt++)
            {
                xc = (ProCntrlPoints[JCnt].X + ProCntrlPoints[JCnt + 1].X) * ((ProCntrlPoints[JCnt].X * ProCntrlPoints[JCnt + 1].Y) - (ProCntrlPoints[JCnt + 1].X * ProCntrlPoints[JCnt].Y));
                sum1 = sum1 + xc;
            }


            b = (ProCntrlPoints[ProCntrlPoints.Count - 1].X + ProCntrlPoints[0].X) * ((ProCntrlPoints[ProCntrlPoints.Count - 1].X * ProCntrlPoints[0].Y) - (ProCntrlPoints[0].X * ProCntrlPoints[ProCntrlPoints.Count - 1].Y));
            ReturnPoint.X = (sum1 + b) / (6 * area1);


            for (int KCnt = 0; KCnt < ProCntrlPoints.Count - 1; KCnt++)
            {
                yc = (ProCntrlPoints[KCnt].Y + ProCntrlPoints[KCnt + 1].Y) * ((ProCntrlPoints[KCnt].X * ProCntrlPoints[KCnt + 1].Y) - (ProCntrlPoints[KCnt + 1].X * ProCntrlPoints[KCnt].Y));
                sum2 = sum2 + yc;
            }
            c = (ProCntrlPoints[ProCntrlPoints.Count - 1].Y + ProCntrlPoints[0].Y) * ((ProCntrlPoints[ProCntrlPoints.Count - 1].X * ProCntrlPoints[0].Y) - (ProCntrlPoints[0].X * ProCntrlPoints[ProCntrlPoints.Count - 1].Y));

            ReturnPoint.Y = ((sum2 + c) / (6 * area1));
            //////////////////////////////////////////////////////////////////////
            /////////////////////////////////////////////////////////////////////
            ////////////////////////////////////////////////////////////////////
            for (int iCnt = 0; iCnt < ProCntrlPoints.Count() - 1; iCnt++)
            {
                area2 = ((ProCntrlPoints[iCnt].X * ProCntrlPoints[iCnt + 1].Z) - (ProCntrlPoints[iCnt + 1].X * ProCntrlPoints[iCnt].Z));
                sum22 = sum22 + area2;
            }
            a2 = (ProCntrlPoints[ProCntrlPoints.Count - 1].X * ProCntrlPoints[0].Z) - (ProCntrlPoints[0].X * ProCntrlPoints[ProCntrlPoints.Count - 1].Z);
            area12 = (sum22 + a2) / 2;

            for (int KCnt = 0; KCnt < ProCntrlPoints.Count - 1; KCnt++)
            {
                zc = (ProCntrlPoints[KCnt].Z + ProCntrlPoints[KCnt + 1].Z) * ((ProCntrlPoints[KCnt].X * ProCntrlPoints[KCnt + 1].Z) - (ProCntrlPoints[KCnt + 1].X * ProCntrlPoints[KCnt].Z));
                sum222 = sum222 + zc;
            }
            c2 = (ProCntrlPoints[ProCntrlPoints.Count - 1].Z + ProCntrlPoints[0].Z) * ((ProCntrlPoints[ProCntrlPoints.Count - 1].X * ProCntrlPoints[0].Z) - (ProCntrlPoints[0].X * ProCntrlPoints[ProCntrlPoints.Count - 1].Z));

            ReturnPoint.Z = ((sum222 + c2) / (6 * area12));

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: FindingCentre :: End");
            return ReturnPoint;
        }

        /// <summary>
        /// Computes the construction points and normal vectors for a NURBS surface.
        /// </summary>
        /// <remarks>This method calculates the construction points and their corresponding normal vectors
        /// for the given NURBS surface based on its control points, weights, and knot vectors. The results are added to
        /// the provided lists.</remarks>
        /// <param name="nSurf">The NURBS surface for which the construction points and normals are to be calculated.</param>
        /// <param name="ConstructionPtList">A reference to a list that will be populated with the computed construction points on the NURBS surface.
        /// Each point represents a position on the surface.</param>
        /// <param name="NormalList">A reference to a list that will be populated with the computed normal vectors at the corresponding
        /// construction points. Each vector represents the surface normal at the respective point.</param>
        static void GetNURBSurfConstructionPoints(IG_NURBSurface nSurf, ref List<Point3D> ConstructionPtList, ref List<Vector3D> NormalList)
        {

            //List<Point3D> ConstructionPtList = new List<Point3D>();
            //List<Vector3D> NormalList = new List<Vector3D>();
            int UpperIndex_u = nSurf.UpperIndex_U;//K1
            int UpperIndex_v = nSurf.UpperIndex_V; //K2
            int Degree_u = nSurf.Degree_U;//M1
            int Degree_v = nSurf.Degree_V;//M2

            List<double> knots_u = nSurf.KnotVector_U;
            List<double> knots_v = nSurf.KnotVector_V;

            List<Point3D> ctrlPts = nSurf.ControlPoints;
            List<double> weights = nSurf.Weight;

            double[,] ControlPoints_X = new double[UpperIndex_v + 1, UpperIndex_u + 1];
            double[,] ControlPoints_Y = new double[UpperIndex_v + 1, UpperIndex_u + 1];
            double[,] ControlPoints_Z = new double[UpperIndex_v + 1, UpperIndex_u + 1];
            double stParam_u = nSurf.startParam_U;
            double edParam_u = nSurf.endParam_U;
            double stParam_v = nSurf.startParam_V;
            double edParam_v = nSurf.endParam_V;

            double[,] N_u = new double[UpperIndex_u + Degree_u + 1, Degree_u];
            double[,] N_v = new double[UpperIndex_v + Degree_v + 1, Degree_v];

            double[] N1 = new double[UpperIndex_u + 1];
            double[] N2 = new double[UpperIndex_v + 1];
            double u, v;
            int i, j;
            double interval_u;
            double interval_v;

            double temp1 = 0, temp2 = 0, temp3 = 0;
            double temp01 = 0, temp02 = 0, temp03 = 0; // To Calculate Denominator as mentioned in Nurb Book(Section 4.4 Page No:128)

            int k = 0;

            for (i = 0; i <= UpperIndex_v; i++)
            {
                for (j = 0; j <= UpperIndex_u; j++)
                {
                    ControlPoints_X[i, j] = ctrlPts[k].X;
                    ControlPoints_Y[i, j] = ctrlPts[k].Y; // ctrlPts[(UpperIndex_v+1) * i + j].Y  Earlier code
                    ControlPoints_Z[i, j] = ctrlPts[k].Z;
                    k++;
                }
            }

            double[,] ControlPoints_X1 = new double[UpperIndex_u + 1, UpperIndex_v + 1];
            double[,] ControlPoints_Y1 = new double[UpperIndex_u + 1, UpperIndex_v + 1];
            double[,] ControlPoints_Z1 = new double[UpperIndex_u + 1, UpperIndex_v + 1];

            for (i = 0; i <= UpperIndex_u; i++)
            {
                for (j = 0; j <= UpperIndex_v; j++)
                {
                    ControlPoints_X1[i, j] = ControlPoints_X[j, i];
                    ControlPoints_Y1[i, j] = ControlPoints_Y[j, i]; // ctrlPts[(UpperIndex_v+1) * i + j].Y  Earlier code
                    ControlPoints_Z1[i, j] = ControlPoints_Z[j, i];

                }
            }
            //Weights Added****************
            double[,] Weight = new double[UpperIndex_v + 1, UpperIndex_u + 1];


            k = 0;

            for (i = 0; i <= UpperIndex_v; i++)
            {
                for (j = 0; j <= UpperIndex_u; j++)
                {
                    Weight[i, j] = weights[k];
                    k++;
                }
            }

            double[,] Weight_1 = new double[UpperIndex_u + 1, UpperIndex_v + 1];

            for (i = 0; i <= UpperIndex_u; i++)
            {
                for (j = 0; j <= UpperIndex_v; j++)
                {
                    Weight_1[i, j] = Weight[j, i];

                }
            } // Weights Added till here. Chnages Done on 7-Dec-2017
            interval_u = Math.Abs(edParam_u - stParam_u) / (UpperIndex_u + 1);
            interval_v = Math.Abs(edParam_v - stParam_v) / (UpperIndex_v + 1);
            for (u = stParam_u; u <= edParam_u; u = u + interval_u)
            {
                N_u = BasisFunction(UpperIndex_u, Degree_u, u, knots_u);

                N1 = DerBasisFunction(UpperIndex_u, Degree_u, knots_u, N_u);

                for (v = stParam_v; v <= edParam_v; v = v + interval_v)
                {
                    N_v = BasisFunction(UpperIndex_v, Degree_v, v, knots_v);
                    N2 = DerBasisFunction(UpperIndex_v, Degree_v, knots_v, N_v);

                    double S1 = 0, S2 = 0, S3 = 0;
                    double S01 = 0, S02 = 0, S03 = 0;

                    //Calculating the point on surface                                                            

                    for (i = 0; i <= UpperIndex_v; i++)
                    {
                        temp1 = 0; temp2 = 0; temp3 = 0;
                        temp01 = 0; temp02 = 0; temp03 = 0;
                        for (j = 0; j <= UpperIndex_u; j++)
                        {
                            temp01 = temp01 + N_u[j, Degree_u] * Weight[i, j];
                            temp02 = temp02 + N_u[j, Degree_u] * Weight[i, j];
                            temp03 = temp03 + N_u[j, Degree_u] * Weight[i, j];

                            temp1 = temp1 + N_u[j, Degree_u] * Weight[i, j] * ControlPoints_X[i, j]/*ctrlPts[k].X*/;
                            temp2 = temp2 + N_u[j, Degree_u] * Weight[i, j] * ControlPoints_Y[i, j]/*ctrlPts[k].Y*/;
                            temp3 = temp3 + N_u[j, Degree_u] * Weight[i, j] * ControlPoints_Z[i, j]/*ctrlPts[k].Z*/;
                            k++;
                        }
                        S1 = S1 + N_v[i, Degree_v] * temp1;
                        S2 = S2 + N_v[i, Degree_v] * temp2;
                        S3 = S3 + N_v[i, Degree_v] * temp3;

                        S01 = S01 + N_v[i, Degree_v] * temp01;
                        S02 = S02 + N_v[i, Degree_v] * temp02;
                        S03 = S03 + N_v[i, Degree_v] * temp03;
                    }
                    S1 = S1 / S01;
                    S2 = S2 / S02;
                    S3 = S3 / S03;

                    Point3D pt = new Point3D(S1, S2, S3);
                    ConstructionPtList.Add(pt);
                    //return ConstructionPtList;



                    ////Refrence Equation 4.19 Page No. 75 from Nurbs Book
                    double tempw = 0;
                    double Sux = 0, Suy = 0, Suz = 0, Suw = 0;
                    for (i = 0; i <= UpperIndex_u; i++)
                    {
                        temp1 = 0; temp2 = 0; temp3 = 0; tempw = 0;

                        for (j = 0; j <= UpperIndex_v; j++)
                        {

                            temp1 = temp1 + N_v[j, Degree_v] * Weight_1[i, j] * ControlPoints_X1[i, j]/*ctrlPts[k].X*/;
                            temp2 = temp2 + N_v[j, Degree_v] * Weight_1[i, j] * ControlPoints_Y1[i, j]/*ctrlPts[k].Y*/;
                            temp3 = temp3 + N_v[j, Degree_v] * Weight_1[i, j] * ControlPoints_Z1[i, j]/*ctrlPts[k].Z*/;
                            tempw = tempw + N_v[j, Degree_v] * Weight_1[i, j];
                        }
                        Sux = Sux + N1[i] * temp1;
                        Suy = Suy + N1[i] * temp2;
                        Suz = Suz + N1[i] * temp3;
                        Suw = Suw + N1[i] * tempw;
                    }

                    Sux = Sux - (Suw * S1);
                    Suy = Suy - (Suw * S2);
                    Suz = Suz - (Suw * S3);


                    double Svx = 0, Svy = 0, Svz = 0, svw = 0;
                    for (i = 0; i <= UpperIndex_v; i++)
                    {
                        temp1 = 0; temp2 = 0; temp3 = 0; tempw = 0;
                        //int vind = vspan - Degree_v + i;
                        for (j = 0; j <= UpperIndex_u; j++)
                        {

                            temp1 = temp1 + N_u[j, Degree_u] * Weight[i, j] * ControlPoints_X[i, j]/*ctrlPts[k].X*/;
                            temp2 = temp2 + N_u[j, Degree_u] * Weight[i, j] * ControlPoints_Y[i, j]/*ctrlPts[k].Y*/;
                            temp3 = temp3 + N_u[j, Degree_u] * Weight[i, j] * ControlPoints_Z[i, j]/*ctrlPts[k].Z*/;
                            tempw = tempw + N_u[j, Degree_u] * Weight[i, j];
                            k++;
                        }
                        Svx = Svx + N2[i] * temp1;
                        Svy = Svy + N2[i] * temp2;
                        Svz = Svz + N2[i] * temp3;
                        svw = svw + N2[i] * tempw;
                    }

                    Svx = Svx - (svw * S1);
                    Svy = Svy - (svw * S2);
                    Svz = Svz - (svw * S3);

                    Vector3D P1 = new Vector3D(Sux, Suy, Suz);

                    Vector3D P2 = new Vector3D(Svx, Svy, Svz);

                    Vector3D CrossProVect = Vector3D.CrossProduct(P2, P1);
                    NormalList.Add(CrossProVect);


                }

            }

        }

        /// <summary>
        /// Computes the B-spline basis functions for a given parameter value, degree, and knot vector.
        /// </summary>
        /// <remarks>The computed basis functions are used in B-spline curve and surface evaluations. The
        /// algorithm follows the Cox-de Boor recursion formula.</remarks>
        /// <param name="UpperIndex_u">The upper index of the basis functions to compute. This is typically the number of control points minus one.</param>
        /// <param name="Degree_u">The degree of the B-spline basis functions.</param>
        /// <param name="u">The parameter value at which the basis functions are evaluated.</param>
        /// <param name="knots_u">The knot vector, represented as a list of non-decreasing parameter values.</param>
        /// <returns>A two-dimensional array where each element <c>N_u[i, p]</c> represents the value of the basis function of
        /// index <c>i</c> and degree <c>p</c> at the parameter value <paramref name="u"/>.</returns>
        public static double[,] BasisFunction(int UpperIndex_u, int Degree_u, double u,/*double[] knots_u*/List<double> knots_u)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: BasisFunction :: Start");
            double[,] N_u = new double[UpperIndex_u + Degree_u + 1, 6];
            double A, B, C, D, E, F;

            int i;

            for (i = 0; i <= UpperIndex_u; i++)
            {
                //        if (knots_u[i] <= u && u < knots_u[i + 1])  //Earlier code 
                if (knots_u[i] <= u && u <= knots_u[i + 1]) //Major chnages done here
                {
                    N_u[i, 0] = 1;//edParam;// 1;

                }
                else
                    N_u[i, 0] = 0;
            }

            for (int p = 1; p <= Degree_u; p++)
            {
                for (i = 0; i <= UpperIndex_u; i++)
                {
                    A = u - knots_u[i];
                    B = knots_u[i + p] - knots_u[i];
                    C = knots_u[i + p + 1] - u;
                    D = knots_u[i + p + 1] - knots_u[i + 1];

                    if (B == 0 || A == 0)
                        E = 0;
                    else
                        E = A / B;

                    if (C == 0 || D == 0)
                        F = 0;
                    else
                        F = C / D;

                    N_u[i, p] = E * N_u[i, p - 1] + F * N_u[i + 1, p - 1];
                }
            }
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: BasisFunction :: End");
            return N_u;

        }  //Written by Sagar.. Derived from the Formulae

        /// <summary>
        /// Computes the derivative of the basis functions for a given degree and knot vector.
        /// </summary>
        /// <remarks>This method calculates the derivative of the basis functions using the recursive
        /// definition of B-spline basis functions. The input knot vector and basis function values must be properly
        /// initialized for the computation to be valid.</remarks>
        /// <param name="UpperIndex_u">The upper index of the basis function to compute the derivative for.</param>
        /// <param name="Degree_u">The degree of the basis functions.</param>
        /// <param name="knots_u">The knot vector, represented as a list of doubles.</param>
        /// <param name="N">A two-dimensional array representing the basis function values.  The first dimension corresponds to the
        /// index of the basis function, and the second dimension corresponds to the degree.</param>
        /// <returns>An array of doubles representing the derivative of the basis functions for the specified degree and knot
        /// vector. The length of the array is equal to <paramref name="UpperIndex_u"/> + 1.</returns>
        public static double[] DerBasisFunction(int UpperIndex_u, int Degree_u,/*double[] knots_u*/List<double> knots_u, double[,] N)
        {

            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: DerBasisFunction :: Start");


            double A, B, C, D, E, F;

            int i;


            double[] N1 = new double[UpperIndex_u + 1];

            for (i = 0; i <= (UpperIndex_u); i++)
            {

                A = Degree_u;
                B = knots_u[i + Degree_u] - knots_u[i];
                C = Degree_u;
                D = knots_u[i + Degree_u + 1] - knots_u[i + 1];

                if (B == 0 || A == 0)
                    E = 0;
                else
                    E = A / B;

                if (C == 0 || D == 0)
                    F = 0;
                else
                    F = C / D;

                N1[i] = E * N[i, Degree_u - 1] - F * N[i + 1, Degree_u - 1];
            }
            alt_Logging_class.AddMessage("IGESDataProcesser_cls :: DerBasisFunction :: End");
            return N1;

        }//Written by Sagar.. Derived from the Formulae

        //  ###############   Intersection of TwoFaces  END #####################

    }

}
